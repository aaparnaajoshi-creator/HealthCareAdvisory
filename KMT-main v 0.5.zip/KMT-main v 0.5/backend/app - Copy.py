import os
import threading
from flask import Flask, request, jsonify
from flask_cors import CORS
from werkzeug.utils import secure_filename

from config import Config
from models import db, Fabric
from services.ingestion import process_fabric_build
from services.agent import ChatAgent

app = Flask(__name__)
app.config.from_object(Config)
CORS(app)
db.init_app(app)

# Ensure tables exist (In production, use Flask-Migrate/Alembic)
with app.app_context():
    db.create_all()

@app.route('/api/fabrics', methods=['POST'])
def trigger_build(id):
    fabric = Fabric.query.get_or_404(id)
    
    # We pass the 'app' object explicitly to the thread function
    # This captures the real application instance to pass to the ingestion script
    thread = threading.Thread(target=process_fabric_build, args=(id, app))
    thread.start()
    
    return jsonify({"status": "Ingesting", "message": "Build started"})
def create_fabric():
    data = request.json
    
    # Pass dictionaries directly to JSONB columns
    # No json.dumps() required
    new_fabric = Fabric(
        name=data['name'],
        description=data.get('description', ''),
        domain=data['domain'],
        sources_config=data['sources'], # Dictionary
        rag_config={                    # Dictionary
            'chunkSize': data['chunkSize'],
            'chunkOverlap': data['chunkOverlap'],
            'embeddingModel': data['embeddingModel'],
            'chromaCollection': data['chromaCollection']
        }
    )
    
    db.session.add(new_fabric)
    db.session.commit()
    
    fabric_dir = os.path.join(Config.UPLOAD_FOLDER, new_fabric.id)
    if not os.path.exists(fabric_dir):
        os.makedirs(fabric_dir)
        
    return jsonify(new_fabric.to_dict()), 201

# ... (GET, DELETE, UPLOAD routes remain largely same as before) ...

@app.route('/api/chat', methods=['POST'])
def chat():
    data = request.json
    fabric_id = data.get('fabricId')
    messages = data.get('messages', [])
    
    fabric = Fabric.query.get(fabric_id)
    if not fabric:
        return jsonify({"error": "Fabric not found"}), 404
        
    # Direct dictionary access
    rag_config = fabric.rag_config 
    collection_name = rag_config.get('chromaCollection')
    
    try:
        agent = ChatAgent(collection_name)
        result = agent.chat(messages[-1]['content'])
        
        return jsonify({
            "conversationId": "conv-1",
            "messages": messages + [{
                "role": "assistant",
                "content": result['answer'],
                "sources": result.get('sources', [])
            }]
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True, port=4000)