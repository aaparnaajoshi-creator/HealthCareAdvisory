import os
import re
import requests
import chromadb
from datetime import datetime
from models import db, Fabric, IngestionHistory, FabricDocument, GraphNode, GraphEdge
from config import Config
from langchain_community.document_loaders import PyPDFLoader, TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
#from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_openai import OpenAIEmbeddings
from langchain_chroma import Chroma
from langchain_core.documents import Document


def fetch_servicenow_data(instance, username, password, table, limit=100):
    """Fetch records from ServiceNow table"""
    if not instance or not username:
        return []
    
    url = f"{instance}/api/now/table/{table}"
    params = {
        'sysparm_limit': limit,
        'sysparm_fields': 'number,short_description,description,close_notes,sys_created_on,priority,category,state',
        'sysparm_query': 'active=false^ORDERBYDESCsys_created_on'
    }
    
    try:
        response = requests.get(url, auth=(username, password), params=params)
        if response.status_code != 200:
            return []
        
        data = response.json().get('result', [])
        docs = []
        
        for record in data:
            page_content = f"""Ticket: {record.get('number')}
Issue: {record.get('short_description')}
Description: {record.get('description')}
Resolution: {record.get('close_notes')}"""
            
            metadata = {
                "source": record.get('number'),
                "type": table,
                "created_at": record.get('sys_created_on'),
                "priority": record.get('priority'),
                "category": record.get('category'),
                "state": record.get('state'),
            }
            
            docs.append(Document(page_content=page_content, metadata=metadata))
        
        return docs
    except Exception as e:
        print(f"ServiceNow fetch error: {e}")
        return []


def extract_entities_from_text(text):
    """
    Simple entity extraction using regex patterns.
    Extracts: Incident IDs, KB Article IDs, Error codes, Product names
    """
    entities = {
        'incidents': [],
        'kb_articles': [],
        'error_codes': [],
        'categories': []
    }
    
    # Extract incident numbers (INC followed by digits)
    incidents = re.findall(r'\b(INC\d{7,})\b', text)
    entities['incidents'] = list(set(incidents))
    
    # Extract KB article numbers
    kb_articles = re.findall(r'\b(KB\d{7,})\b', text)
    entities['kb_articles'] = list(set(kb_articles))
    
    # Extract error codes (ERR_ or ERROR_ followed by text)
    error_codes = re.findall(r'\b(ERR_[A-Z_]+|ERROR_[A-Z_]+)\b', text)
    entities['error_codes'] = list(set(error_codes))
    
    # Extract common IT categories (simple pattern matching)
    category_patterns = [
        'VPN', 'Authentication', 'Password', 'Network', 'Email',
        'Hardware', 'Software', 'Database', 'Server', 'Firewall'
    ]
    for category in category_patterns:
        if category.lower() in text.lower():
            entities['categories'].append(category)
    
    return entities


def build_knowledge_graph(fabric_id, documents):
    """
    Build knowledge graph from documents.
    Creates nodes and edges in SQLite.
    """
    print(f"Building knowledge graph for fabric {fabric_id}...")
    
    # Clear existing graph for this fabric
    GraphNode.query.filter_by(fabric_id=fabric_id).delete()
    GraphEdge.query.filter_by(fabric_id=fabric_id).delete()
    db.session.commit()
    
    # Track created nodes to avoid duplicates
    node_map = {}  # node_id -> GraphNode object
    
    # Process each document to extract entities
    for doc in documents:
        text = doc.page_content
        metadata = doc.metadata
        source_id = metadata.get('source', 'unknown')
        doc_type = metadata.get('type', 'document')
        
        # Extract entities from text
        entities = extract_entities_from_text(text)
        
        # Create node for the source document itself
        if source_id not in node_map:
            if doc_type == 'incident':
                node_type = 'incident'
                label = f"Incident {source_id}"
            elif doc_type == 'kb_knowledge':
                node_type = 'kb_article'
                label = f"KB Article {source_id}"
            else:
                node_type = 'document'
                label = source_id
            
            source_node = GraphNode(
                fabric_id=fabric_id,
                node_id=source_id,
                node_type=node_type,
                label=label,
                properties={
                    'priority': metadata.get('priority'),
                    'category': metadata.get('category'),
                    'state': metadata.get('state'),
                }
            )
            db.session.add(source_node)
            db.session.flush()  # Get the ID
            node_map[source_id] = source_node
        
        # Create nodes for extracted entities
        # Incidents
        for incident_id in entities['incidents']:
            if incident_id not in node_map and incident_id != source_id:
                incident_node = GraphNode(
                    fabric_id=fabric_id,
                    node_id=incident_id,
                    node_type='incident',
                    label=f"Incident {incident_id}",
                    properties={}
                )
                db.session.add(incident_node)
                db.session.flush()
                node_map[incident_id] = incident_node
                
                # Create edge: source MENTIONS incident
                edge = GraphEdge(
                    fabric_id=fabric_id,
                    source_node_id=node_map[source_id].id,
                    target_node_id=incident_node.id,
                    relationship_type='MENTIONS',
                    properties={}
                )
                db.session.add(edge)
        
        # KB Articles
        for kb_id in entities['kb_articles']:
            if kb_id not in node_map and kb_id != source_id:
                kb_node = GraphNode(
                    fabric_id=fabric_id,
                    node_id=kb_id,
                    node_type='kb_article',
                    label=f"KB {kb_id}",
                    properties={}
                )
                db.session.add(kb_node)
                db.session.flush()
                node_map[kb_id] = kb_node
                
                # Create edge: source REFERENCES kb_article
                edge = GraphEdge(
                    fabric_id=fabric_id,
                    source_node_id=node_map[source_id].id,
                    target_node_id=kb_node.id,
                    relationship_type='REFERENCES',
                    properties={}
                )
                db.session.add(edge)
        
        # Error Codes
        for error_code in entities['error_codes']:
            if error_code not in node_map:
                error_node = GraphNode(
                    fabric_id=fabric_id,
                    node_id=error_code,
                    node_type='error_code',
                    label=error_code,
                    properties={}
                )
                db.session.add(error_node)
                db.session.flush()
                node_map[error_code] = error_node
                
                # Create edge: source HAS_ERROR
                edge = GraphEdge(
                    fabric_id=fabric_id,
                    source_node_id=node_map[source_id].id,
                    target_node_id=error_node.id,
                    relationship_type='HAS_ERROR',
                    properties={}
                )
                db.session.add(edge)
        
        # Categories
        for category in entities['categories']:
            category_id = f"CAT_{category.upper()}"
            if category_id not in node_map:
                category_node = GraphNode(
                    fabric_id=fabric_id,
                    node_id=category_id,
                    node_type='category',
                    label=category,
                    properties={}
                )
                db.session.add(category_node)
                db.session.flush()
                node_map[category_id] = category_node
            
            # Create edge: source BELONGS_TO category
            edge = GraphEdge(
                fabric_id=fabric_id,
                source_node_id=node_map[source_id].id,
                target_node_id=node_map[category_id].id,
                relationship_type='BELONGS_TO',
                properties={}
            )
            db.session.add(edge)
    
    db.session.commit()
    
    # Count nodes and edges
    node_count = GraphNode.query.filter_by(fabric_id=fabric_id).count()
    edge_count = GraphEdge.query.filter_by(fabric_id=fabric_id).count()
    
    print(f"Knowledge graph built: {node_count} nodes, {edge_count} edges")
    return node_count, edge_count


def process_fabric_build(fabric_id, app):
    """
    Enhanced background task to run the RAG pipeline with detailed tracking
    """
    with app.app_context():
        fabric = Fabric.query.get(fabric_id)
        if not fabric:
            return
        
        # Create ingestion history record
        ingestion_record = IngestionHistory(
            fabric_id=fabric_id,
            status='started',
            started_at=datetime.utcnow()
        )
        db.session.add(ingestion_record)
        db.session.commit()
        
        start_time = datetime.utcnow()
        
        try:
            # 1. UPDATE STATUS
            fabric.status = "Ingesting"
            db.session.commit()
            
            sources = fabric.sources_config
            rag_config = fabric.rag_config
            documents = []
            
            # Initialize detailed tracking
            ingestion_stats = {
                "uploads": {
                    "file_count": 0,
                    "document_count": 0,
                    "files": {}
                },
                "servicenow": {
                    "total_records": 0,
                    "by_table": {}
                },
                "total_documents": 0,
                "total_chunks": 0
            }
            
            source_breakdown = {
                "uploads": 0,
                "servicenow": 0,
                "sharepoint": 0
            }
            
            sources_ingested = []
            
            # Clear existing fabric documents
            FabricDocument.query.filter_by(fabric_id=fabric_id).delete()
            
            # 2. INGEST UPLOADS (WITH DETAILED TRACKING)
            if sources.get('uploads') and sources['uploads'].get('fileNames'):
                sources_ingested.append('uploads')
                for filename in sources['uploads']['fileNames']:
                    file_path = os.path.join(Config.UPLOAD_FOLDER, fabric_id, filename)
                    if os.path.exists(file_path):
                        file_docs = []
                        file_size = os.path.getsize(file_path)
                        file_type = filename.split('.')[-1] if '.' in filename else 'unknown'
                        
                        if filename.endswith('.pdf'):
                            loader = PyPDFLoader(file_path)
                            file_docs = loader.load()
                        elif filename.endswith('.txt'):
                            loader = TextLoader(file_path)
                            file_docs = loader.load()
                        
                        # Track per file
                        doc_count = len(file_docs)
                        documents.extend(file_docs)
                        ingestion_stats["uploads"]["files"][filename] = doc_count
                        ingestion_stats["uploads"]["document_count"] += doc_count
                        ingestion_stats["uploads"]["file_count"] += 1
                        source_breakdown["uploads"] += doc_count
                        
                        # Create FabricDocument record
                        fabric_doc = FabricDocument(
                            fabric_id=fabric_id,
                            source_type='upload',
                            source_name=filename,
                            document_count=doc_count,
                            file_size=file_size,
                            file_type=file_type,
                            meta_data={}
                        )
                        db.session.add(fabric_doc)
            
            # 3. INGEST SERVICENOW (WITH DETAILED TRACKING)
            sn_config = sources.get('serviceNow')
            if sn_config and sn_config.get('enabled'):
                sources_ingested.append('servicenow')
                for table in sn_config.get('tables', []):
                    sn_docs = fetch_servicenow_data(
                        sn_config['instanceUrl'],
                        Config.SERVICENOW_USER,
                        Config.SERVICENOW_PASS,
                        table
                    )
                    
                    # Track per table
                    doc_count = len(sn_docs)
                    documents.extend(sn_docs)
                    ingestion_stats["servicenow"]["by_table"][table] = doc_count
                    ingestion_stats["servicenow"]["total_records"] += doc_count
                    source_breakdown["servicenow"] += doc_count
                    
                    # Create FabricDocument record for this table
                    if doc_count > 0:
                        fabric_doc = FabricDocument(
                            fabric_id=fabric_id,
                            source_type=f'servicenow_{table}',
                            source_name=table,
                            document_count=doc_count,
                            meta_data={
                                'instance_url': sn_config['instanceUrl']
                            }
                        )
                        db.session.add(fabric_doc)
            
            # Update total documents
            ingestion_stats["total_documents"] = len(documents)
            fabric.documents_count = len(documents)
            db.session.commit()
            
            # 4. CHUNKING
            fabric.status = "Chunking"
            db.session.commit()
            
            text_splitter = RecursiveCharacterTextSplitter(
                chunk_size=rag_config.get('chunkSize', 512),
                chunk_overlap=rag_config.get('chunkOverlap', 64)
            )
            splits = text_splitter.split_documents(documents)
            
            ingestion_stats["total_chunks"] = len(splits)
            fabric.chunks_count = len(splits)
            
            # Update chunk counts in FabricDocument records
            # (Simplified: distribute chunks proportionally)
            if len(documents) > 0:
                for fabric_doc in FabricDocument.query.filter_by(fabric_id=fabric_id).all():
                    fabric_doc.chunk_count = int(
                        (fabric_doc.document_count / len(documents)) * len(splits)
                    )
            
            db.session.commit()
            
            # 5. VECTORIZING
            fabric.status = "Vectorizing"
            db.session.commit()
            
            if splits:
                #embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")
                embeddings = OpenAIEmbeddings(
                                                model="text-embedding-3-large",
                                                openai_api_key=Config.OPENAI_API_KEY
                                                )
                collection_name = rag_config.get('chromaCollection', f"fabric_{fabric_id}")
                
                chroma_client = chromadb.PersistentClient(path=Config.CHROMA_DB_PATH)
                
                # Delete existing collection if rebuilding
                try:
                    chroma_client.delete_collection(collection_name)
                except:
                    pass
                
                vectorstore = Chroma(
                    client=chroma_client,
                    collection_name=collection_name,
                    embedding_function=embeddings,
                )
                
                # Batch add
                batch_size = 50
                for i in range(0, len(splits), batch_size):
                    batch = splits[i:i+batch_size]
                    vectorstore.add_documents(documents=batch)
            
            # 6. BUILD KNOWLEDGE GRAPH
            fabric.status = "GraphBuilding"
            db.session.commit()
            
            node_count, edge_count = build_knowledge_graph(fabric_id, documents)
            fabric.graph_nodes = node_count
            fabric.graph_edges = edge_count
            
            # 7. FINISH
            fabric.status = "Ready"
            fabric.ingestion_stats = ingestion_stats
            fabric.source_breakdown = source_breakdown
            fabric.last_synced_at = datetime.utcnow()
            db.session.commit()
            
            # Update ingestion history
            end_time = datetime.utcnow()
            duration = (end_time - start_time).total_seconds()
            
            ingestion_record.status = 'completed'
            ingestion_record.completed_at = end_time
            ingestion_record.sources_ingested = sources_ingested
            ingestion_record.documents_ingested = len(documents)
            ingestion_record.chunks_created = len(splits)
            ingestion_record.duration_seconds = int(duration)
            ingestion_record.details = ingestion_stats
            db.session.commit()
            
            print(f"Build complete for {fabric_id} in {duration:.2f}s")

        except Exception as e:
            print(f"Build failed: {e}")
            fabric.status = "Error"
            fabric.description = f"{fabric.description} -- Error: {str(e)}"
            db.session.commit()
            
            # Update ingestion history with error
            end_time = datetime.utcnow()
            duration = (end_time - start_time).total_seconds()
            
            ingestion_record.status = 'failed'
            ingestion_record.completed_at = end_time
            ingestion_record.error_message = str(e)
            ingestion_record.duration_seconds = int(duration)
            db.session.commit()
