// =============================================================================
// ChatContext.tsx - Fixed with Robust State Management
// =============================================================================

import React, { createContext, useContext, useState, useCallback, ReactNode, useEffect, useRef } from "react";
import { ChatMessage, ArticleSource } from "../types/chat";
import { useFabricContext } from "./FabricContext";
import { getConversation, getConversations, Conversation } from "../api/conversationApi";
import axiosClient from "../api/axiosClient";

// =============================================================================
// TYPES
// =============================================================================

interface ConversationHistoryItem {
  role: "user" | "assistant";
  content: string;
}

interface ChatContextType {
  messages: ChatMessage[];
  conversationId: string | null;
  conversationHistory: ConversationHistoryItem[];
  conversations: Conversation[];
  isSending: boolean;
  isLoadingConversations: boolean;
  isLoadingMessages: boolean;
  
  sendMessage: (message: string) => Promise<void>;
  clearConversation: () => void;
  startNewConversation: () => void;
  loadConversation: (conversationId: string) => Promise<void>;
  refreshConversations: () => Promise<void>;
  deleteConversation: (conversationId: string) => Promise<void>;
}

// =============================================================================
// CONTEXT
// =============================================================================

const ChatContext = createContext<ChatContextType | undefined>(undefined);

// =============================================================================
// PROVIDER
// =============================================================================

interface ChatProviderProps {
  children: ReactNode;
}

export const ChatProvider: React.FC<ChatProviderProps> = ({ children }) => {
  const { fabrics, selectedFabricId, selectFabric } = useFabricContext();
  
  // Message state
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [conversationHistory, setConversationHistory] = useState<ConversationHistoryItem[]>([]);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  
  // Loading state
  const [isSending, setIsSending] = useState(false);
  const [isLoadingConversations, setIsLoadingConversations] = useState(false);
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);

  // Ref to track current fabric for async operations
  const fabricIdRef = useRef(selectedFabricId);
  useEffect(() => {
    fabricIdRef.current = selectedFabricId;
  }, [selectedFabricId]);

  // Auto-select fabric if only one exists
  useEffect(() => {
    const readyFabrics = fabrics.filter(f => f.status === "Ready");
    if (readyFabrics.length === 1 && !selectedFabricId) {
      selectFabric(readyFabrics[0].id);
    }
  }, [fabrics, selectedFabricId, selectFabric]);

  // Refresh conversations list
  const refreshConversations = useCallback(async () => {
    const fabricId = fabricIdRef.current;
    if (!fabricId) {
      console.log("[ChatContext] No fabric selected, skipping refresh");
      return;
    }
    
    console.log("[ChatContext] Refreshing conversations for fabric:", fabricId);
    setIsLoadingConversations(true);
    
    try {
      const response = await getConversations(fabricId, 100, 0);
      console.log("[ChatContext] Loaded conversations:", response.conversations.length);
      setConversations(response.conversations);
    } catch (error) {
      console.error("[ChatContext] Failed to load conversations:", error);
    } finally {
      setIsLoadingConversations(false);
    }
  }, []);

  // Load conversations when fabric is selected
  useEffect(() => {
    if (selectedFabricId) {
      console.log("[ChatContext] Fabric selected, loading conversations");
      refreshConversations();
    } else {
      setConversations([]);
    }
  }, [selectedFabricId, refreshConversations]);

  // Load an existing conversation with its messages
  const loadConversation = useCallback(async (convId: string) => {
    console.log("[ChatContext] Loading conversation:", convId);
    setIsLoadingMessages(true);
    
    try {
      const conversation = await getConversation(convId);
      console.log("[ChatContext] Loaded conversation data:", conversation);
      console.log("[ChatContext] Messages in conversation:", conversation.messages?.length || 0);
      
      if (!conversation.messages || conversation.messages.length === 0) {
        console.warn("[ChatContext] No messages found in conversation");
        setMessages([]);
        setConversationHistory([]);
        setConversationId(convId);
        return;
      }
      
      // Convert to ChatMessage format
      const loadedMessages: ChatMessage[] = conversation.messages.map((msg) => {
        console.log("[ChatContext] Processing message:", msg.id, msg.role);
        return {
          id: msg.id,
          role: msg.role as "user" | "assistant",
          content: msg.content,
          sources: (msg.sources || []) as ArticleSource[],
          createdAt: msg.createdAt,
        };
      });
      
      // Build conversation history for context
      const history: ConversationHistoryItem[] = conversation.messages.map((msg) => ({
        role: msg.role as "user" | "assistant",
        content: msg.content,
      }));
      
      console.log("[ChatContext] Setting messages:", loadedMessages.length);
      console.log("[ChatContext] Setting history:", history.length);
      
      // Update state
      setMessages(loadedMessages);
      setConversationHistory(history.slice(-10));
      setConversationId(convId);
      
    } catch (error) {
      console.error("[ChatContext] Failed to load conversation:", error);
      throw error;
    } finally {
      setIsLoadingMessages(false);
    }
  }, []);

  // Send message
  const sendMessage = useCallback(async (message: string) => {
    if (!selectedFabricId) {
      throw new Error("No fabric selected");
    }
    
    console.log("[ChatContext] Sending message, conversationId:", conversationId);
    
    // Add user message to UI immediately
    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: "user",
      content: message,
      createdAt: new Date().toISOString(),
    };
    
    setMessages((prev) => [...prev, userMessage]);
    setIsSending(true);

    try {
      const response = await axiosClient.post("/api/chat", {
        fabricId: selectedFabricId,
        message: message,
        conversationId: conversationId,
        conversationHistory: conversationHistory,
        llmId: "gpt-4",
        temperature: 0.7,
        maxTokens: 2000,
      });

      const data = response.data;
      console.log("[ChatContext] Chat response:", data);
      console.log("[ChatContext] New conversationId:", data.conversationId);

      // Create assistant message
      const assistantMessage: ChatMessage = {
        id: data.id || `assistant-${Date.now()}`,
        role: "assistant",
        content: data.content,
        createdAt: data.createdAt || new Date().toISOString(),
        sources: data.sources?.map((src: any) => ({
          id: src.id,
          title: src.title,
          snippet: src.snippet,
          link: src.link,
        })) as ArticleSource[],
      };

      // Update messages
      setMessages((prev) => [...prev, assistantMessage]);

      // Update conversation ID if new conversation was created
      if (data.conversationId) {
        console.log("[ChatContext] Setting conversationId to:", data.conversationId);
        setConversationId(data.conversationId);
      }

      // Update conversation history
      const newHistory = [
        ...conversationHistory,
        { role: "user" as const, content: message },
        { role: "assistant" as const, content: data.content },
      ].slice(-10);
      setConversationHistory(newHistory);

      // Refresh conversations list after a short delay to ensure DB is updated
      console.log("[ChatContext] Refreshing conversations after message");
      setTimeout(() => {
        refreshConversations();
      }, 500);

    } catch (error: any) {
      console.error("[ChatContext] Chat error:", error);
      
      const errorMessage: ChatMessage = {
        id: `error-${Date.now()}`,
        role: "assistant",
        content: `Sorry, I encountered an error: ${error.response?.data?.error || error.message || "Unknown error"}. Please try again.`,
        createdAt: new Date().toISOString(),
      };
      
      setMessages((prev) => [...prev, errorMessage]);
      throw error;
    } finally {
      setIsSending(false);
    }
  }, [selectedFabricId, conversationId, conversationHistory, refreshConversations]);

  // Clear current conversation
  const clearConversation = useCallback(() => {
    console.log("[ChatContext] Clearing conversation");
    setMessages([]);
    setConversationHistory([]);
    setConversationId(null);
  }, []);

  // Start a new conversation
  const startNewConversation = useCallback(() => {
    console.log("[ChatContext] Starting new conversation");
    setMessages([]);
    setConversationHistory([]);
    setConversationId(null);
    // Refresh to show any pending conversations
    refreshConversations();
  }, [refreshConversations]);

  // Delete a conversation
  const deleteConversation = useCallback(async (convId: string) => {
    console.log("[ChatContext] Deleting conversation:", convId);
    try {
      await axiosClient.delete(`/api/conversations/${convId}`);
      
      // If we deleted the current conversation, clear it
      if (convId === conversationId) {
        clearConversation();
      }
      
      // Refresh the list
      await refreshConversations();
    } catch (error) {
      console.error("[ChatContext] Failed to delete conversation:", error);
      throw error;
    }
  }, [conversationId, clearConversation, refreshConversations]);

  // Context value
  const value: ChatContextType = {
    messages,
    conversationId,
    conversationHistory,
    conversations,
    isSending,
    isLoadingConversations,
    isLoadingMessages,
    sendMessage,
    clearConversation,
    startNewConversation,
    loadConversation,
    refreshConversations,
    deleteConversation,
  };

  return (
    <ChatContext.Provider value={value}>
      {children}
    </ChatContext.Provider>
  );
};

// =============================================================================
// HOOK
// =============================================================================

export const useChatContext = (): ChatContextType => {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error("useChatContext must be used within a ChatProvider");
  }
  return context;
};

export { ChatContext };
