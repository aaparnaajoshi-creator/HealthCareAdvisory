// changed this code for v 0.5
// =============================================================================
// UPDATED feedbackApi.ts - With KB Source Tracking
// =============================================================================
// Replace your existing frontend/src/api/feedbackApi.ts with this file

import axiosClient from "./axiosClient";

// =============================================================================
// TYPES
// =============================================================================

export interface FeedbackPayload {
  messageId: string;
  fabricId: string;
  llmId: string;
  rating: "up" | "down";
  comments?: string;
  conversationId: string;
  timestamp: string;
  sourceIds?: string[];  // NEW: Track which sources were shown
}

export interface FeedbackResponse {
  success: boolean;
  id: string;
  message?: string;
}

export interface FeedbackStats {
  totalFeedback: number;
  positiveCount: number;
  negativeCount: number;
  positiveRate: number;
  bySource: {
    [sourceId: string]: {
      positive: number;
      negative: number;
      total: number;
      rating: number;
    };
  };
}

// =============================================================================
// API FUNCTIONS
// =============================================================================

/**
 * Submit feedback for a chat response
 */
export const submitFeedback = async (payload: FeedbackPayload): Promise<FeedbackResponse> => {
  const res = await axiosClient.post<FeedbackResponse>("/api/feedback", payload);
  return res.data;
};

/**
 * Get feedback statistics for a fabric
 */
export const getFeedbackStats = async (fabricId: string): Promise<FeedbackStats> => {
  const res = await axiosClient.get<FeedbackStats>(`/api/fabrics/${fabricId}/feedback-stats`);
  return res.data;
};

/**
 * Get all feedback for a fabric (for admin/analysis)
 */
export const getFeedbackList = async (
  fabricId: string, 
  options?: {
    limit?: number;
    offset?: number;
    rating?: "up" | "down";
  }
): Promise<{
  feedback: FeedbackPayload[];
  total: number;
}> => {
  const params = new URLSearchParams();
  if (options?.limit) params.append("limit", options.limit.toString());
  if (options?.offset) params.append("offset", options.offset.toString());
  if (options?.rating) params.append("rating", options.rating);
  
  const res = await axiosClient.get(`/api/fabrics/${fabricId}/feedback?${params.toString()}`);
  return res.data;
};

/**
 * Get KB articles that need attention (low ratings)
 */
export const getKBArticlesNeedingAttention = async (fabricId: string): Promise<{
  articles: Array<{
    id: string;
    title: string;
    positiveCount: number;
    negativeCount: number;
    rating: number;
    lastFeedback: string;
  }>;
}> => {
  const res = await axiosClient.get(`/api/fabrics/${fabricId}/kb-attention`);
  return res.data;
};
