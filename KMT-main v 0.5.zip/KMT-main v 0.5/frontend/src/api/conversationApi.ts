// =============================================================================
// CONVERSATION API - frontend/src/api/conversationApi.ts
// =============================================================================
// API functions for managing chat conversation history

import axiosClient from "./axiosClient";

// =============================================================================
// TYPES
// =============================================================================

export interface ConversationMessage {
  id: string;
  conversationId: string;
  role: "user" | "assistant";
  content: string;
  sources?: Array<{
    id: string;
    title: string;
    snippet: string;
    link: string;
  }>;
  createdAt: string;
}

export interface Conversation {
  id: string;
  fabricId: string;
  title: string;
  llmId: string | null;
  temperature: number;
  maxTokens: number;
  createdAt: string;
  updatedAt: string;
  messageCount: number;
  messages?: ConversationMessage[];
}

export interface ConversationListResponse {
  conversations: Conversation[];
  total: number;
}

// =============================================================================
// API FUNCTIONS
// =============================================================================

/**
 * List all conversations, optionally filtered by fabric
 */
export const getConversations = async (
  fabricId?: string,
  limit: number = 50,
  offset: number = 0
): Promise<ConversationListResponse> => {
  const params = new URLSearchParams();
  if (fabricId) params.append("fabricId", fabricId);
  params.append("limit", limit.toString());
  params.append("offset", offset.toString());

  const res = await axiosClient.get<ConversationListResponse>(
    `/api/conversations?${params.toString()}`
  );
  return res.data;
};

/**
 * Get a single conversation with all messages
 */
export const getConversation = async (conversationId: string): Promise<Conversation> => {
  const res = await axiosClient.get<Conversation>(`/api/conversations/${conversationId}`);
  return res.data;
};

/**
 * Create a new conversation
 */
export const createConversation = async (data: {
  fabricId: string;
  llmId?: string;
  temperature?: number;
  maxTokens?: number;
  title?: string;
}): Promise<Conversation> => {
  const res = await axiosClient.post<Conversation>("/api/conversations", data);
  return res.data;
};

/**
 * Update conversation metadata
 */
export const updateConversation = async (
  conversationId: string,
  data: {
    title?: string;
    llmId?: string;
    temperature?: number;
    maxTokens?: number;
  }
): Promise<Conversation> => {
  const res = await axiosClient.patch<Conversation>(
    `/api/conversations/${conversationId}`,
    data
  );
  return res.data;
};

/**
 * Delete a conversation
 */
export const deleteConversation = async (conversationId: string): Promise<void> => {
  await axiosClient.delete(`/api/conversations/${conversationId}`);
};

/**
 * Add a message to a conversation
 */
export const addMessageToConversation = async (
  conversationId: string,
  data: {
    role: "user" | "assistant";
    content: string;
    sources?: any[];
  }
): Promise<ConversationMessage> => {
  const res = await axiosClient.post<ConversationMessage>(
    `/api/conversations/${conversationId}/messages`,
    data
  );
  return res.data;
};
