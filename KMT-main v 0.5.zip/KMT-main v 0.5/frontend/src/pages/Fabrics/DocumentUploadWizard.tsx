import React, { useState } from "react";
import { useFabricContext } from "../../context/FabricContext";
import { useToast } from "../../components/toast/ToastProvider";
import { Stepper } from "../../components/common/Stepper";
import { CreateFabricPayload, uploadDocuments } from "../../api/fabricsApi";
import { XMarkIcon, DocumentArrowUpIcon } from "@heroicons/react/24/outline";

interface DocumentUploadWizardProps {
  isOpen: boolean;
  onClose: () => void;
}

const STEPS = [
  "Fabric Basics",
  "Upload Documents",
  "RAG Configuration",
  "Review & Create",
];

export const DocumentUploadWizard: React.FC<DocumentUploadWizardProps> = ({
  isOpen,
  onClose,
}) => {
  const { createNewFabric, triggerBuild, reloadFabrics } = useFabricContext();
  const { showToast } = useToast();
  const [currentStep, setCurrentStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);

  // Step 1: Basics
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [domain, setDomain] = useState("Incident Management");

  // Step 2: Documents
  const [uploadFiles, setUploadFiles] = useState<File[]>([]);

  // Step 3: RAG Configuration
  const [chunkSize, setChunkSize] = useState(512);
  const [chunkOverlap, setChunkOverlap] = useState(64);
  const [embeddingModel, setEmbeddingModel] = useState("text-embedding-3-large");
  const [chromaCollection, setChromaCollection] = useState("");

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const validFiles = files.filter(
      (file) =>
        file.type === "application/pdf" ||
        file.type === "text/plain" ||
        file.type ===
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
        file.name.endsWith(".docx") ||
        file.name.endsWith(".pdf") ||
        file.name.endsWith(".txt")
    );
    setUploadFiles([...uploadFiles, ...validFiles]);
  };

  const handleRemoveFile = (index: number) => {
    setUploadFiles(uploadFiles.filter((_, i) => i !== index));
  };

  const handleCreate = async () => {
    if (!name || !chromaCollection) {
      showToast("Please fill in all required fields", "error");
      return;
    }

    if (uploadFiles.length === 0) {
      showToast("Please upload at least one document", "error");
      return;
    }

    setLoading(true);
    try {
      // Step 1: Create fabric
      const payload: CreateFabricPayload = {
        name,
        description,
        domain,
        sources: {
          uploads: {
            fileNames: uploadFiles.map((f) => f.name),
          },
        },
        chunkSize,
        chunkOverlap,
        embeddingModel,
        chromaCollection,
      };

      const newFabric = await createNewFabric(payload);
      showToast("Fabric created. Uploading documents and building RAG architecture...", "info");

      // Step 2: Upload documents
      setUploading(true);
      try {
        await uploadDocuments(newFabric.id, uploadFiles);
        showToast("Documents uploaded successfully", "success");
      } catch (uploadError: any) {
        showToast(uploadError.message || "Failed to upload documents", "error");
        throw uploadError;
      } finally {
        setUploading(false);
      }

      // Step 3: Trigger RAG architecture build
      // Backend will:
      // 1. Parse uploaded documents (PDF/DOCX)
      // 2. Chunk documents (size: chunkSize, overlap: chunkOverlap)
      // 3. Generate embeddings (model: embeddingModel)
      // 4. Store vectors in Chroma DB (collection: chromaCollection)
      // 5. Build Knowledge Graph (extract entities/relationships)
      // 6. Mark fabric as "Ready" for RAG-powered chat
      await triggerBuild(newFabric.id);
      
      // Reload fabrics to show the new one in the list
      await reloadFabrics();
      
      showToast(
        "Knowledge Fabric created! RAG architecture build started. Status will update automatically.",
        "success"
      );
      handleClose();
    } catch (error: any) {
      showToast(error.message || "Failed to create fabric", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setCurrentStep(1);
    setName("");
    setDescription("");
    setDomain("Incident Management");
    setUploadFiles([]);
    setChunkSize(512);
    setChunkOverlap(64);
    setEmbeddingModel("text-embedding-3-large");
    setChromaCollection("");
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex">
      <div className="fixed inset-0 bg-black/50" onClick={handleClose} />
      <div className="fixed right-0 top-0 h-full w-full lg:w-2/5 bg-slate-900 border-l border-slate-800 shadow-2xl overflow-y-auto">
        <div className="sticky top-0 bg-slate-900 border-b border-slate-800 p-6 flex items-center justify-between z-10">
          <div className="flex items-center space-x-3">
            <DocumentArrowUpIcon className="w-6 h-6 text-blue-400" />
            <h2 className="text-xl font-bold text-slate-100">Document Upload Fabric</h2>
          </div>
          <button onClick={handleClose} className="text-slate-400 hover:text-white">
            <XMarkIcon className="w-6 h-6" />
          </button>
        </div>
        <div className="p-6">
          <Stepper currentStep={currentStep} totalSteps={4} steps={STEPS} />

          {currentStep === 1 && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Fabric Name *
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:ring-2 focus:ring-brand-600"
                  placeholder="e.g., Incident Resolution Knowledge Base"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Description
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={4}
                  className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:ring-2 focus:ring-brand-600"
                  placeholder="Describe the purpose and scope of this knowledge fabric..."
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Business Domain
                </label>
                <select
                  value={domain}
                  onChange={(e) => setDomain(e.target.value)}
                  className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:ring-2 focus:ring-brand-600"
                >
                  <option>Incident Management</option>
                  <option>Problem Management</option>
                  <option>Change Management</option>
                  <option>Other</option>
                </select>
              </div>
              <div className="flex justify-end space-x-2 pt-4">
                <button onClick={handleClose} className="btn-secondary">
                  Cancel
                </button>
                <button
                  onClick={() => setCurrentStep(2)}
                  disabled={!name}
                  className="btn-primary"
                >
                  Next
                </button>
              </div>
            </div>
          )}

          {currentStep === 2 && (
            <div className="space-y-4">
              <div className="card p-6 border-2 border-dashed border-slate-700">
                <input
                  type="file"
                  multiple
                  accept=".pdf,.docx,.doc,.txt"
                  onChange={handleFileSelect}
                  className="hidden"
                  id="file-upload"
                />
                <label
                  htmlFor="file-upload"
                  className="flex flex-col items-center justify-center cursor-pointer"
                >
                  <DocumentArrowUpIcon className="w-12 h-12 text-slate-400 mb-4" />
                  <span className="text-slate-300 font-medium mb-2">
                    Click to upload documents
                  </span>
                  <span className="text-sm text-slate-500">
                    Supports PDF, DOCX, TXT files
                  </span>
                </label>
              </div>

              {uploadFiles.length > 0 && (
                <div className="space-y-2">
                  <h3 className="text-sm font-semibold text-slate-300">
                    Selected Files ({uploadFiles.length})
                  </h3>
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {uploadFiles.map((file, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-3 bg-slate-800 rounded-lg"
                      >
                        <div className="flex items-center space-x-3">
                          <DocumentArrowUpIcon className="w-5 h-5 text-slate-400" />
                          <div>
                            <div className="text-sm text-slate-100">{file.name}</div>
                            <div className="text-xs text-slate-500">
                              {(file.size / 1024 / 1024).toFixed(2)} MB
                            </div>
                          </div>
                        </div>
                        <button
                          onClick={() => handleRemoveFile(index)}
                          className="text-red-400 hover:text-red-300"
                        >
                          <XMarkIcon className="w-5 h-5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex justify-end space-x-2 pt-4">
                <button onClick={() => setCurrentStep(1)} className="btn-secondary">
                  Back
                </button>
                <button
                  onClick={() => setCurrentStep(3)}
                  disabled={uploadFiles.length === 0}
                  className="btn-primary"
                >
                  Next
                </button>
              </div>
            </div>
          )}

          {currentStep === 3 && (
            <div className="space-y-6">
              <div className="card p-4">
                <h3 className="font-semibold text-slate-100 mb-4">Chunking Settings</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Chunk Size (tokens)
                    </label>
                    <input
                      type="number"
                      value={chunkSize}
                      onChange={(e) => setChunkSize(parseInt(e.target.value) || 512)}
                      className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:ring-2 focus:ring-brand-600"
                    />
                    <p className="text-xs text-slate-500 mt-1">
                      Recommended: 512-1024 tokens per chunk
                    </p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Chunk Overlap (tokens)
                    </label>
                    <input
                      type="number"
                      value={chunkOverlap}
                      onChange={(e) => setChunkOverlap(parseInt(e.target.value) || 64)}
                      className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:ring-2 focus:ring-brand-600"
                    />
                    <p className="text-xs text-slate-500 mt-1">
                      Recommended: 10-20% of chunk size
                    </p>
                  </div>
                </div>
              </div>

              <div className="card p-4">
                <h3 className="font-semibold text-slate-100 mb-4">Embedding Model</h3>
                <select
                  value={embeddingModel}
                  onChange={(e) => setEmbeddingModel(e.target.value)}
                  className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:ring-2 focus:ring-brand-600"
                >
                  <option>text-embedding-3-large</option>
                  <option>text-embedding-3-small</option>
                  <option>azure-openai-embedding-1</option>
                  <option>custom-embedding</option>
                </select>
              </div>

              <div className="card p-4">
                <h3 className="font-semibold text-slate-100 mb-4">Chroma Collection Name *</h3>
                <input
                  type="text"
                  value={chromaCollection}
                  onChange={(e) => setChromaCollection(e.target.value)}
                  className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:ring-2 focus:ring-brand-600"
                  placeholder="knowledge-fabric-collection"
                />
                <p className="text-xs text-slate-500 mt-1">
                  Collection name in Chroma DB for storing vectorized chunks (free & open source)
                </p>
              </div>

              <div className="card p-4 bg-blue-600/10 border border-blue-600/20">
                <h3 className="font-semibold text-slate-100 mb-3">RAG Architecture Pipeline</h3>
                <div className="space-y-2 text-sm text-slate-300">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span>1. Document Ingestion & Parsing</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span>2. Text Chunking (Size: {chunkSize}, Overlap: {chunkOverlap})</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span>3. Vectorization ({embeddingModel})</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span>4. Store in Chroma DB ({chromaCollection})</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span>5. Build Knowledge Graph</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span>6. Ready for RAG-powered Chat</span>
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <button onClick={() => setCurrentStep(2)} className="btn-secondary">
                  Back
                </button>
                <button onClick={() => setCurrentStep(4)} className="btn-primary">
                  Next
                </button>
              </div>
            </div>
          )}

          {currentStep === 4 && (
            <div className="space-y-6">
              <div className="card p-6">
                <h3 className="font-semibold text-slate-100 mb-4">Summary</h3>
                <div className="space-y-3 text-sm">
                  <div>
                    <span className="text-slate-400">Name:</span>{" "}
                    <span className="text-slate-100">{name}</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Description:</span>{" "}
                    <span className="text-slate-100">{description || "None"}</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Domain:</span>{" "}
                    <span className="text-slate-100">{domain}</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Documents:</span>{" "}
                    <span className="text-slate-100">{uploadFiles.length} files</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Chunk Size:</span>{" "}
                    <span className="text-slate-100">{chunkSize}</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Chunk Overlap:</span>{" "}
                    <span className="text-slate-100">{chunkOverlap}</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Embedding Model:</span>{" "}
                    <span className="text-slate-100">{embeddingModel}</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Chroma Collection:</span>{" "}
                    <span className="text-slate-100">{chromaCollection}</span>
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <button onClick={() => setCurrentStep(3)} className="btn-secondary">
                  Back
                </button>
                <button
                  onClick={handleCreate}
                  disabled={loading || uploading || !name || !chromaCollection}
                  className="btn-primary"
                >
                  {loading || uploading
                    ? uploading
                      ? "Uploading & Building RAG..."
                      : "Creating..."
                    : "Create Fabric with RAG"}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

