// =============================================================================
// ChatPage.tsx - With Loading States and Better Debugging
// =============================================================================

import React, { useState, useRef, useEffect } from "react";
import { useFabricContext } from "../../context/FabricContext";
import { useChatContext } from "../../context/ChatContext";
import { useToast } from "../../components/toast/ToastProvider";
import { MessageBubble } from "./MessageBubble";
import { SourcePanel } from "./SourcePanel";
import { ConversationHistory } from "./ConversationHistory";
import { LoadingSpinner } from "../../components/common/LoadingSpinner";
import { EmptyState } from "../../components/common/EmptyState";
import { ArticleSource } from "../../types/chat";
import { 
  ChatBubbleLeftRightIcon, 
  PlusIcon,
} from "@heroicons/react/24/outline";

const SUGGESTED_QUESTIONS = [
  "How do I reset my VPN password?",
  "What are the steps to request a new laptop?",
  "How do I configure email on my mobile device?",
  "What's the process for reporting a security incident?",
];

export const ChatPage: React.FC = () => {
  const { fabrics, selectedFabricId } = useFabricContext();
  const {
    messages,
    conversationId,
    conversationHistory,
    conversations,
    isSending,
    isLoadingConversations,
    isLoadingMessages,
    sendMessage,
    startNewConversation,
    loadConversation,
    deleteConversation,
  } = useChatContext();
  const { showToast } = useToast();
  
  const [inputValue, setInputValue] = useState("");
  const [selectedSource, setSelectedSource] = useState<ArticleSource | null>(null);
  const [showSourcePanel, setShowSourcePanel] = useState(false);
  const [historyCollapsed, setHistoryCollapsed] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const selectedFabric = fabrics.find((f) => f.id === selectedFabricId);

  // Debug logging
  useEffect(() => {
    console.log("[ChatPage] State updated:", {
      messagesCount: messages.length,
      conversationId,
      conversationsCount: conversations.length,
      isLoadingMessages,
    });
  }, [messages, conversationId, conversations, isLoadingMessages]);

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isSending]);

  const handleSend = async () => {
    if (!inputValue.trim()) {
      showToast("Please enter a message", "warning");
      return;
    }

    if (!selectedFabricId) {
      showToast("No fabric available. Please create a fabric first.", "warning");
      return;
    }

    const messageToSend = inputValue;
    setInputValue("");

    try {
      await sendMessage(messageToSend);
    } catch (error: any) {
      showToast(error.message || "Failed to send message", "error");
      setInputValue(messageToSend);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSuggestedQuestion = (question: string) => {
    setInputValue(question);
  };

  const handleNewConversation = () => {
    console.log("[ChatPage] Starting new conversation");
    startNewConversation();
    setSelectedSource(null);
    showToast("Started new conversation", "success");
  };

  const handleSelectConversation = async (conversationId: string) => {
    console.log("[ChatPage] Selected conversation:", conversationId);
    try {
      await loadConversation(conversationId);
      setSelectedSource(null);
      console.log("[ChatPage] Conversation loaded successfully");
    } catch (error: any) {
      console.error("[ChatPage] Failed to load conversation:", error);
      showToast("Failed to load conversation", "error");
    }
  };

  const handleDeleteConversation = async (convId: string) => {
    try {
      await deleteConversation(convId);
      showToast("Conversation deleted", "success");
    } catch (error: any) {
      showToast("Failed to delete conversation", "error");
    }
  };

  const statusText = isSending ? "Thinking..." : isLoadingMessages ? "Loading..." : "Ready";
  const statusColor = isSending || isLoadingMessages ? "text-blue-400" : "text-green-400";

  return (
    <div className="flex h-[calc(100vh-8rem)]">
      {/* Conversation History Sidebar */}
      <ConversationHistory
        conversations={conversations}
        currentConversationId={conversationId}
        isLoading={isLoadingConversations}
        onSelectConversation={handleSelectConversation}
        onDeleteConversation={handleDeleteConversation}
        onNewConversation={handleNewConversation}
        isCollapsed={historyCollapsed}
        onToggleCollapse={() => setHistoryCollapsed(!historyCollapsed)}
      />

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Bar */}
        <div className="card p-4 mb-4 mx-4 mt-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <span className="px-3 py-1 bg-slate-800 rounded-full text-slate-300 text-sm">
                {selectedFabric?.name || "Loading..."} · <span className={statusColor}>{statusText}</span>
              </span>
              {conversationHistory.length > 0 && (
                <span className="px-2 py-1 bg-purple-900/30 text-purple-300 rounded-full text-xs">
                  {Math.floor(conversationHistory.length / 2)} exchanges
                </span>
              )}
              {conversationId && (
                <span className="px-2 py-1 bg-slate-700 text-slate-400 rounded-full text-xs">
                  ID: {conversationId.substring(0, 8)}...
                </span>
              )}
            </div>
            
            <button
              onClick={handleNewConversation}
              className="flex items-center px-3 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg text-sm transition-colors"
              title="Start new conversation"
            >
              <PlusIcon className="w-4 h-4 mr-1" />
              New Chat
            </button>
          </div>
        </div>

        {/* Chat Messages */}
        <div className="flex-1 card p-6 mx-4 overflow-y-auto mb-4">
          {isLoadingMessages ? (
            <div className="h-full flex flex-col items-center justify-center">
              <LoadingSpinner size="lg" />
              <p className="text-slate-400 mt-4">Loading conversation...</p>
            </div>
          ) : messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center">
              <EmptyState
                icon={<ChatBubbleLeftRightIcon className="w-16 h-16" />}
                title="Start a Conversation"
                message="Ask a question about Service Operations to get started."
              />
              
              {selectedFabricId && (
                <div className="mt-8 w-full max-w-2xl">
                  <p className="text-sm text-slate-400 mb-3 text-center">
                    Try asking:
                  </p>
                  <div className="flex flex-wrap gap-2 justify-center">
                    {SUGGESTED_QUESTIONS.map((question, index) => (
                      <button
                        key={index}
                        onClick={() => handleSuggestedQuestion(question)}
                        className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm rounded-lg border border-slate-700 hover:border-slate-600 transition-colors"
                      >
                        {question}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div>
              {messages.map((message, index) => (
                <MessageBubble
                  key={message.id || index}
                  message={message}
                  onSourceClick={(source) => {
                    setSelectedSource(source);
                    setShowSourcePanel(true);
                  }}
                />
              ))}
              
              {isSending && (
                <div className="flex justify-start mb-6">
                  <div className="bg-slate-800 text-slate-100 rounded-2xl rounded-tl-sm p-4">
                    <div className="flex items-center space-x-2">
                      <LoadingSpinner size="sm" />
                      <span className="text-sm text-slate-400">
                        Assistant is thinking...
                      </span>
                    </div>
                  </div>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Message Input */}
        <div className="card p-4 mx-4 mb-4">
          <div className="flex space-x-2">
            <textarea
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder={
                conversationHistory.length > 0
                  ? "Ask a follow-up question..."
                  : "Describe your issue or ask a question about Service Operations..."
              }
              rows={3}
              disabled={isSending || isLoadingMessages || !selectedFabricId}
              className="flex-1 px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-brand-600 resize-none disabled:opacity-50"
            />
            <button
              onClick={handleSend}
              disabled={!inputValue.trim() || !selectedFabricId || isSending || isLoadingMessages}
              className="btn-primary self-end disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSending ? <LoadingSpinner size="sm" /> : "Send"}
            </button>
          </div>
          
          {conversationHistory.length > 0 && !isSending && (
            <p className="text-xs text-slate-500 mt-2">
              💡 I remember our conversation. Feel free to ask follow-up questions!
            </p>
          )}
        </div>
      </div>

      {/* Source Panel - Desktop */}
      <div className="hidden lg:block">
        <SourcePanel selectedSource={selectedSource} />
      </div>

      {/* Source Panel - Mobile */}
      {showSourcePanel && (
        <div className="lg:hidden">
          <SourcePanel
            selectedSource={selectedSource}
            onClose={() => setShowSourcePanel(false)}
            isMobile={true}
          />
        </div>
      )}
    </div>
  );
};
