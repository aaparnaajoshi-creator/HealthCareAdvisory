// =============================================================================
// MessageBubble.tsx - Fixed (No selectedLLMId dependency)
// =============================================================================

import React, { useState } from "react";
import ReactMarkdown from "react-markdown";
import { ChatMessage, ArticleSource } from "../../types/chat";
import { submitFeedback, FeedbackPayload } from "../../api/feedbackApi";
import { useToast } from "../../components/toast/ToastProvider";
import { useChatContext } from "../../context/ChatContext";
import { useFabricContext } from "../../context/FabricContext";
import {
  HandThumbUpIcon,
  HandThumbDownIcon,
  ClipboardIcon,
  CheckIcon,
  ArrowPathIcon,
} from "@heroicons/react/24/outline";

interface MessageBubbleProps {
  message: ChatMessage;
  onSourceClick?: (source: ArticleSource) => void;
  onRegenerate?: () => void;
}

export const MessageBubble: React.FC<MessageBubbleProps> = ({ 
  message, 
  onSourceClick,
  onRegenerate 
}) => {
  const { conversationId } = useChatContext();
  const { selectedFabricId } = useFabricContext();
  const { showToast } = useToast();
  
  const [showFeedbackForm, setShowFeedbackForm] = useState(false);
  const [rating, setRating] = useState<"up" | "down" | null>(null);
  const [comments, setComments] = useState("");
  const [submittingFeedback, setSubmittingFeedback] = useState(false);
  const [copied, setCopied] = useState(false);
  const [feedbackSubmitted, setFeedbackSubmitted] = useState(false);

  const isUser = message.role === "user";
  const isAssistant = message.role === "assistant";

  // Handle copy to clipboard
  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message.content);
      setCopied(true);
      showToast("Copied to clipboard", "success");
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      showToast("Failed to copy", "error");
    }
  };

  // Handle feedback button click
  const handleFeedbackClick = (selectedRating: "up" | "down") => {
    if (feedbackSubmitted) return;
    setRating(selectedRating);
    setShowFeedbackForm(true);
  };

  // Submit feedback
  const handleSubmitFeedback = async () => {
    if (!rating || !conversationId || !selectedFabricId) {
      return;
    }

    setSubmittingFeedback(true);
    try {
      const payload: FeedbackPayload = {
        messageId: message.id,
        fabricId: selectedFabricId,
        llmId: "gpt-4", // Default LLM
        rating,
        comments: comments || undefined,
        conversationId,
        timestamp: new Date().toISOString(),
        sourceIds: message.sources?.map(s => s.id),
      };
      await submitFeedback(payload);
      showToast("Thanks for your feedback!", "success");
      setShowFeedbackForm(false);
      setFeedbackSubmitted(true);
    } catch (error: any) {
      showToast(error.message || "Failed to submit feedback", "error");
    } finally {
      setSubmittingFeedback(false);
    }
  };

  // Parse content for citation references [1], [2], etc.
  const renderContentWithCitations = (content: string) => {
    const sources = message.sources || [];
    const citationRegex = /\[(\d+)\]/g;
    const parts = content.split(citationRegex);
    
    return parts.map((part, index) => {
      const citationIndex = parseInt(part);
      if (!isNaN(citationIndex) && citationIndex >= 1 && citationIndex <= sources.length) {
        const source = sources[citationIndex - 1];
        return (
          <button
            key={index}
            onClick={() => onSourceClick?.(source)}
            className="inline-flex items-center justify-center w-5 h-5 mx-0.5 text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white rounded-full cursor-pointer transition-colors"
            title={`${source.id}: ${source.title}`}
          >
            {citationIndex}
          </button>
        );
      }
      return <span key={index}>{part}</span>;
    });
  };

  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"} mb-6`}>
      <div
        className={`max-w-3xl ${
          isUser
            ? "bg-brand-600 text-white rounded-2xl rounded-tr-sm"
            : "bg-slate-800 text-slate-100 rounded-2xl rounded-tl-sm"
        } p-4`}
      >
        {isAssistant ? (
          <div className="space-y-3">
            {/* Main Content */}
            <div className="prose prose-invert max-w-none prose-p:my-2 prose-li:my-1">
              <ReactMarkdown
                components={{
                  p: ({ children }) => {
                    if (typeof children === 'string') {
                      return <p>{renderContentWithCitations(children)}</p>;
                    }
                    return <p>{children}</p>;
                  },
                  code: ({ node, className, children, ...props }) => {
                    const isCodeBlock = className?.includes('language-') || 
                                        (node?.position?.start.line !== node?.position?.end.line);
                    
                    if (isCodeBlock) {
                      return (
                        <code 
                          className={`block p-3 bg-slate-900 rounded-lg text-sm overflow-x-auto ${className || ''}`} 
                          {...props}
                        >
                          {children}
                        </code>
                      );
                    }
                    
                    return (
                      <code className="px-1 py-0.5 bg-slate-700 rounded text-sm" {...props}>
                        {children}
                      </code>
                    );
                  },
                  pre: ({ children }) => (
                    <pre className="bg-slate-900 rounded-lg overflow-x-auto my-2">
                      {children}
                    </pre>
                  ),
                  ul: ({ children }) => (
                    <ul className="list-disc list-inside space-y-1">{children}</ul>
                  ),
                  ol: ({ children }) => (
                    <ol className="list-decimal list-inside space-y-1">{children}</ol>
                  ),
                }}
              >
                {message.content}
              </ReactMarkdown>
            </div>

            {/* Sources Section */}
            {message.sources && message.sources.length > 0 && (
              <div className="pt-3 border-t border-slate-700">
                <div className="text-xs font-semibold text-slate-400 mb-2">
                  📚 Sources ({message.sources.length}):
                </div>
                <div className="flex flex-wrap gap-2">
                  {message.sources.map((source: ArticleSource, index: number) => (
                    <SourceChip 
                      key={source.id} 
                      source={source} 
                      index={index + 1}
                      onSourceClick={onSourceClick} 
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="pt-3 border-t border-slate-700">
              <div className="flex items-center justify-between">
                {/* Left: Feedback */}
                <div className="flex items-center space-x-3">
                  <span className="text-xs text-slate-400">Was this helpful?</span>
                  <div className="flex items-center space-x-1">
                    <button
                      onClick={() => handleFeedbackClick("up")}
                      disabled={feedbackSubmitted}
                      className={`p-1.5 rounded transition-colors ${
                        feedbackSubmitted && rating === "up"
                          ? "bg-green-600 text-white"
                          : feedbackSubmitted
                          ? "text-slate-600 cursor-not-allowed"
                          : "text-slate-400 hover:text-green-400 hover:bg-slate-700"
                      }`}
                      title="Helpful"
                    >
                      <HandThumbUpIcon className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleFeedbackClick("down")}
                      disabled={feedbackSubmitted}
                      className={`p-1.5 rounded transition-colors ${
                        feedbackSubmitted && rating === "down"
                          ? "bg-red-600 text-white"
                          : feedbackSubmitted
                          ? "text-slate-600 cursor-not-allowed"
                          : "text-slate-400 hover:text-red-400 hover:bg-slate-700"
                      }`}
                      title="Not helpful"
                    >
                      <HandThumbDownIcon className="w-4 h-4" />
                    </button>
                  </div>
                  {feedbackSubmitted && (
                    <span className="text-xs text-green-400">Thanks!</span>
                  )}
                </div>

                {/* Right: Copy & Regenerate */}
                <div className="flex items-center space-x-1">
                  <button
                    onClick={handleCopy}
                    className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-700 rounded transition-colors"
                    title="Copy to clipboard"
                  >
                    {copied ? (
                      <CheckIcon className="w-4 h-4 text-green-400" />
                    ) : (
                      <ClipboardIcon className="w-4 h-4" />
                    )}
                  </button>
                  {onRegenerate && (
                    <button
                      onClick={onRegenerate}
                      className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-700 rounded transition-colors"
                      title="Regenerate response"
                    >
                      <ArrowPathIcon className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* Feedback Form */}
              {showFeedbackForm && !feedbackSubmitted && (
                <div className="mt-3 p-3 bg-slate-900 rounded-lg space-y-2">
                  <div className="text-xs text-slate-300">
                    You selected: {rating === "up" ? "👍 Helpful" : "👎 Not helpful"}
                  </div>
                  <textarea
                    value={comments}
                    onChange={(e) => setComments(e.target.value)}
                    placeholder={
                      rating === "up"
                        ? "What was helpful about this response? (optional)"
                        : "What could be improved? (optional)"
                    }
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-brand-600"
                    rows={3}
                  />
                  <div className="flex space-x-2">
                    <button
                      onClick={handleSubmitFeedback}
                      disabled={submittingFeedback}
                      className="btn-primary text-xs px-3 py-1"
                    >
                      {submittingFeedback ? "Submitting..." : "Submit Feedback"}
                    </button>
                    <button
                      onClick={() => {
                        setShowFeedbackForm(false);
                        setRating(null);
                        setComments("");
                      }}
                      className="btn-secondary text-xs px-3 py-1"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="whitespace-pre-wrap">{message.content}</div>
        )}
      </div>
    </div>
  );
};

// =============================================================================
// SOURCE CHIP COMPONENT
// =============================================================================

interface SourceChipProps {
  source: ArticleSource;
  index: number;
  onSourceClick?: (source: ArticleSource) => void;
}

const SourceChip: React.FC<SourceChipProps> = ({ source, index, onSourceClick }) => {
  const getSourceStyle = () => {
    const id = source.id?.toUpperCase() || "";
    if (id.startsWith("KB")) {
      return "bg-green-900/50 border-green-700 hover:bg-green-800/50";
    }
    if (id.startsWith("INC")) {
      return "bg-blue-900/50 border-blue-700 hover:bg-blue-800/50";
    }
    if (id.startsWith("PRB")) {
      return "bg-orange-900/50 border-orange-700 hover:bg-orange-800/50";
    }
    return "bg-slate-700 border-slate-600 hover:bg-slate-600";
  };

  const truncatedTitle = source.title && source.title.length > 40
    ? source.title.substring(0, 40) + "..."
    : source.title;

  return (
    <button
      onClick={() => onSourceClick?.(source)}
      className={`flex items-center text-xs px-2 py-1 border rounded text-slate-200 transition-colors ${getSourceStyle()}`}
      title={`${source.id}: ${source.title}\n\nClick to view details`}
    >
      <span className="flex items-center justify-center w-4 h-4 mr-1.5 bg-slate-600 rounded-full text-[10px] font-bold">
        {index}
      </span>
      <span className="font-medium">{source.id}</span>
      {truncatedTitle && (
        <>
          <span className="mx-1 text-slate-500">|</span>
          <span className="text-slate-400">{truncatedTitle}</span>
        </>
      )}
    </button>
  );
};
