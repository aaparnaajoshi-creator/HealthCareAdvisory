import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getDashboardMetrics, DashboardMetrics } from "../../api/analyticsApi";
import { LoadingSpinner } from "../../components/common/LoadingSpinner";
import {
  ChartBarIcon,
  ClockIcon,
  CheckCircleIcon,
  CubeIcon,
  DocumentTextIcon,
  CubeTransparentIcon,
} from "@heroicons/react/24/outline";

export const AnalyticsPage: React.FC = () => {
  const navigate = useNavigate();
  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadMetrics();
  }, []);

  const loadMetrics = async () => {
    setLoading(true);
    try {
      const data = await getDashboardMetrics();
      setMetrics(data);
      setError(null);
    } catch (err: any) {
      setError(err.message || "Failed to load analytics");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  if (error || !metrics) {
    return (
      <div className="text-center py-12">
        <p className="text-red-400">{error || "No data available"}</p>
        <button onClick={loadMetrics} className="btn-primary mt-4">
          Retry
        </button>
      </div>
    );
  }

  const { summary, ingestionMetrics, recentFabrics, recentIngestions } = metrics;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-slate-100 mb-2">
          Analytics Dashboard
        </h1>
        <p className="text-slate-400">
          Aggregate metrics and insights across all knowledge fabrics
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Total Fabrics"
          value={summary.totalFabrics}
          icon={<CubeIcon className="w-6 h-6" />}
          color="bg-blue-600"
        />
        <MetricCard
          title="Total Documents"
          value={summary.totalDocuments.toLocaleString()}
          icon={<DocumentTextIcon className="w-6 h-6" />}
          color="bg-purple-600"
        />
        <MetricCard
          title="Total Chunks"
          value={summary.totalChunks.toLocaleString()}
          icon={<ChartBarIcon className="w-6 h-6" />}
          color="bg-green-600"
        />
        <MetricCard
          title="Graph Nodes"
          value={summary.totalGraphNodes.toLocaleString()}
          icon={<CubeTransparentIcon className="w-6 h-6" />}
          color="bg-indigo-600"
        />
      </div>

      {/* Ingestion Metrics */}
      <div className="card p-6">
        <h2 className="text-xl font-semibold text-slate-100 mb-4">
          Ingestion Performance
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <div className="text-sm text-slate-400 mb-1">Total Attempts</div>
            <div className="text-2xl font-bold text-slate-100">
              {ingestionMetrics.totalAttempts}
            </div>
          </div>
          <div>
            <div className="text-sm text-slate-400 mb-1">Successful</div>
            <div className="text-2xl font-bold text-green-400">
              {ingestionMetrics.successfulAttempts}
            </div>
          </div>
          <div>
            <div className="text-sm text-slate-400 mb-1">Success Rate</div>
            <div className="text-2xl font-bold text-slate-100">
              {ingestionMetrics.successRate.toFixed(1)}%
            </div>
          </div>
          <div>
            <div className="text-sm text-slate-400 mb-1">Avg Duration</div>
            <div className="text-2xl font-bold text-slate-100">
              {Math.round(ingestionMetrics.avgDurationSeconds)}s
            </div>
          </div>
        </div>
      </div>

      {/* Fabrics by Status */}
      <div className="card p-6">
        <h2 className="text-xl font-semibold text-slate-100 mb-4">
          Fabrics by Status
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Object.entries(summary.fabricsByStatus).map(([status, count]) => (
            <div key={status} className="text-center">
              <div className="text-3xl font-bold text-slate-100">{count}</div>
              <div className="text-sm text-slate-400 mt-1">{status}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Source Distribution */}
      <div className="card p-6">
        <h2 className="text-xl font-semibold text-slate-100 mb-4">
          Source Type Distribution
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <SourceCard
            title="Uploads"
            count={summary.sourceDistribution.uploads || 0}
            color="bg-blue-600"
          />
          <SourceCard
            title="ServiceNow"
            count={summary.sourceDistribution.servicenow || 0}
            color="bg-purple-600"
          />
          <SourceCard
            title="SharePoint"
            count={summary.sourceDistribution.sharepoint || 0}
            color="bg-green-600"
          />
        </div>
      </div>

      {/* Recent Fabrics */}
      <div className="card p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-slate-100">
            Recent Fabrics
          </h2>
          <button
            onClick={() => navigate("/available-fabrics")}
            className="text-brand-400 hover:text-brand-300 text-sm"
          >
            View All →
          </button>
        </div>
        <div className="space-y-3">
          {recentFabrics.map((fabric) => (
            <div
              key={fabric.id}
              className="flex items-center justify-between p-3 bg-slate-800 rounded-lg hover:bg-slate-750 cursor-pointer transition-colors"
              onClick={() => navigate("/available-fabrics")}
            >
              <div>
                <div className="font-medium text-slate-100">{fabric.name}</div>
                <div className="text-sm text-slate-400">
                  {fabric.documentsCount} documents · {fabric.chunksCount} chunks
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <span
                  className={`text-xs px-2 py-1 rounded ${
                    fabric.status === "Ready"
                      ? "bg-green-600 text-white"
                      : fabric.status === "Error"
                      ? "bg-red-600 text-white"
                      : "bg-blue-600 text-white"
                  }`}
                >
                  {fabric.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Ingestions */}
      <div className="card p-6">
        <h2 className="text-xl font-semibold text-slate-100 mb-4">
          Recent Ingestion Activity
        </h2>
        <div className="space-y-3">
          {recentIngestions.map((ingestion) => (
            <div
              key={ingestion.id}
              className="flex items-center justify-between p-3 bg-slate-800 rounded-lg"
            >
              <div className="flex items-center space-x-3">
                {ingestion.status === "completed" ? (
                  <CheckCircleIcon className="w-5 h-5 text-green-400" />
                ) : ingestion.status === "failed" ? (
                  <div className="w-5 h-5 text-red-400">✕</div>
                ) : (
                  <ClockIcon className="w-5 h-5 text-blue-400" />
                )}
                <div>
                  <div className="text-sm text-slate-100">
                    {ingestion.documentsIngested} documents · {ingestion.chunksCreated} chunks
                  </div>
                  <div className="text-xs text-slate-400">
                    {new Date(ingestion.startedAt).toLocaleString()}
                    {ingestion.durationSeconds && (
                      <span> · {ingestion.durationSeconds}s</span>
                    )}
                  </div>
                </div>
              </div>
              <div className="text-xs text-slate-400">
                {ingestion.sourcesIngested?.join(", ")}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

interface MetricCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  color: string;
}

const MetricCard: React.FC<MetricCardProps> = ({ title, value, icon, color }) => {
  return (
    <div className="card p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="text-sm font-medium text-slate-400">{title}</div>
        <div className={`${color} p-2 rounded-lg text-white`}>{icon}</div>
      </div>
      <div className="text-3xl font-bold text-slate-100">{value}</div>
    </div>
  );
};

interface SourceCardProps {
  title: string;
  count: number;
  color: string;
}

const SourceCard: React.FC<SourceCardProps> = ({ title, count, color }) => {
  return (
    <div className="text-center">
      <div className={`${color} w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-2`}>
        <span className="text-white font-bold text-lg">{count}</span>
      </div>
      <div className="text-sm text-slate-400">{title}</div>
    </div>
  );
};
