from langgraph.graph import StateGraph, END
from typing import TypedDict, List, Optional
import asyncio

from app.agents import requirements_agent, design_agent, coding_agent, testing_agent, deployment_agent, critic_agent

# Define a custom exception for pausing the graph
class HumanInputRequired(Exception):
    pass

class AgentState(TypedDict):
    project_id: int
    project_name: str
    start_phase: str
    end_phase: str
    current_phase: str
    artifacts: dict
    logs: List[str]
    last_output: str
    human_input: Optional[str]
    review_cycles: int

# Mapping from phase name to agent function
AGENT_MAP = {
    "Requirements": requirements_agent,
    "Design": design_agent,
    "Coding": coding_agent,
    "Testing": testing_agent,
    "Deployment": deployment_agent,
}
PHASES = list(AGENT_MAP.keys())

def get_agent_graph(human_in_loop_steps: List[str]):
    workflow = StateGraph(AgentState)

    async def run_agent(state: AgentState):
        """Generic node to run the agent for the current phase."""
        phase = state["current_phase"]
        agent_func = AGENT_MAP[phase]
        
        print(f"Running agent for phase: {phase}")
        output = await agent_func(state)
        
        state["last_output"] = output
        state["artifacts"][phase] = output
        state["review_cycles"] = 0 # Reset for next phase
        return state

    async def run_critic(state: AgentState):
        """Node to run the critic agent."""
        print("Running Critic Agent...")
        feedback = await critic_agent(state)
        state["last_output"] = feedback # Critic's feedback is the new "last output"
        state["review_cycles"] = state.get("review_cycles", 0) + 1
        return state

    def should_continue(state: AgentState):
        """Decision node to determine the next step."""
        current_phase = state["current_phase"]
        
        # Check if critic loop should continue
        if "feedback" in state["last_output"].lower() and state["review_cycles"] < 2:
            return "run_critic"

        # Check for human-in-the-loop
        if current_phase in human_in_loop_steps:
            # This is a simplified way to signal a pause.
            # In a real system, you might use a more robust mechanism.
            raise HumanInputRequired(f"Paused for human input at {current_phase}")

        # Check if the workflow is complete
        if current_phase == state["end_phase"]:
            return END

        # Move to the next phase
        return "next_phase"

    async def move_to_next_phase(state: AgentState):
        """Node to transition to the next phase."""
        current_idx = PHASES.index(state["current_phase"])
        next_idx = current_idx + 1
        if next_idx < len(PHASES):
            state["current_phase"] = PHASES[next_idx]
        return state

    # Define the nodes
    workflow.add_node("run_agent", run_agent)
    workflow.add_node("run_critic", run_critic)
    workflow.add_node("next_phase", move_to_next_phase)

    # Define the edges
    workflow.set_entry_point("run_agent")
    
    workflow.add_conditional_edges(
        "run_agent",
        should_continue,
        {
            "run_critic": "run_critic",
            "next_phase": "next_phase",
            END: END,
        },
    )
    
    # After critic runs, it goes back to the agent for refinement
    workflow.add_edge("run_critic", "run_agent")
    
    # After moving to the next phase, run the agent for that phase
    workflow.add_edge("next_phase", "run_agent")

    return workflow.compile()

