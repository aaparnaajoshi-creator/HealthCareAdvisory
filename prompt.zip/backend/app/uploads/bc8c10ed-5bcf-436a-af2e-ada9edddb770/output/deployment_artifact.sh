```markdown
++[
--- FILE: README.md ---

# Pharma Inc. Corporate Website

This repository contains the source code and deployment artifacts for the Pharma Inc. corporate website.

## 1. Overview

This is a simple client-server application built with Python Flask on the backend and standard HTML/CSS/JS on the frontend. The backend serves the static web pages and provides a single API endpoint for the contact form.

## 2. Technology Stack

-   **Frontend:** HTML5, CSS3, Vanilla JavaScript
-   **Backend:** Python 3, Flask

## 3. Project Structure

```
.
├── .github/
│   └── workflows/
│       └── ci-cd.yml       # CI/CD Pipeline for automation
├── static/
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── main.js
├── templates/
│   ├── index.html
│   ├── about.html
│   ├── products.html
│   └── contact.html
├── app.py                  # Main Flask application
├── Dockerfile              # Container definition
├── requirements.txt        # Python dependencies
└── README.md               # This file
```
*Note: The HLD specifies HTML files at the root, but serving them from a `templates` directory is a standard Flask convention.*

## 4. Running Locally

### Prerequisites

-   Python 3.8+
-   `pip` and `venv`

### Setup & Execution

1.  **Clone the repository:**
    ```sh
    git clone <repository-url>
    cd pharma-inc-website
    ```

2.  **Create and activate a virtual environment:**
    ```sh
    python -m venv venv
    source venv/bin/activate  # On Windows, use `venv\Scripts\activate`
    ```

3.  **Install dependencies:**
    ```sh
    pip install -r requirements.txt
    ```

4.  **Run the application:**
    ```sh
    flask run
    ```
    The application will be available at `http://127.0.0.1:5000`.

## 5. Building and Running with Docker

### Prerequisites

-   Docker Desktop

### Build the Image

```sh
docker build -t pharma-inc-website .
```

### Run the Container

```sh
docker run -p 5000:5000 pharma-inc-website
```
The application will be available at `http://localhost:5000`.
]++

++[
--- FILE: requirements.txt ---

Flask==2.3.2
]++

++[
--- FILE: Dockerfile ---

# Use an official Python runtime as a parent image
FROM python:3.11-slim

# Set the working directory in the container
WORKDIR /app

# Copy the dependencies file to the working directory
COPY requirements.txt .

# Install any needed packages specified in requirements.txt
RUN pip install --no-cache-dir -r requirements.txt

# Copy the rest of the application code to the working directory
# Note: We assume static files are in 'static/' and templates in 'templates/'
COPY . .

# Make port 5000 available to the world outside this container
EXPOSE 5000

# Define environment variables
ENV FLASK_APP=app.py
ENV FLASK_RUN_HOST=0.0.0.0

# Run app.py when the container launches
CMD ["flask", "run"]
]++

++[
--- FILE: .github/workflows/ci-cd.yml ---

name: CI/CD Pipeline for Pharma Inc. Website

on:
  push:
    branches: [ "main" ]
  pull_request:
    branches: [ "main" ]

jobs:
  build:
    name: Build and Test
    runs-on: ubuntu-latest
    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'

      - name: Install dependencies
        run: |
          python -m pip install --upgrade pip
          pip install -r requirements.txt
          pip install flake8

      - name: Lint with flake8
        run: |
          # stop the build if there are Python syntax errors or undefined names
          flake8 . --count --select=E9,F63,F7,F82 --show-source --statistics
          # exit-zero treats all errors as warnings. The GitHub editor is 127 chars wide
          flake8 . --count --exit-zero --max-complexity=10 --max-line-length=127 --statistics

  build-and-push-docker:
    name: Build and Push Docker Image
    runs-on: ubuntu-latest
    needs: build
    if: github.ref == 'refs/heads/main' && github.event_name == 'push' # Only run on push to main
    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Log in to Docker Hub
        uses: docker/login-action@v3
        with:
          username: ${{ secrets.DOCKERHUB_USERNAME }}
          password: ${{ secrets.DOCKERHUB_TOKEN }}

      - name: Set up Docker Buildx
        uses: docker/setup-buildx-action@v3

      - name: Build and push Docker image
        uses: docker/build-push-action@v5
        with:
          context: .
          push: true
          tags: ${{ secrets.DOCKERHUB_USERNAME }}/pharma-inc-website:latest,${{ secrets.DOCKERHUB_USERNAME }}/pharma-inc-website:${{ github.sha }}
]++
```