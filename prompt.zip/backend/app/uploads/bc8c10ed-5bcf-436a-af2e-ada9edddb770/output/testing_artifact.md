--- FILE: Requirements.docx ---

Corporate Website - Software Requirements Specification
1. Introduction
This document outlines the requirements for the Pharma Inc. corporate website. The website will serve as a digital presence for the company, providing information about its mission, products, and contact details.
2. User Stories
Home Page
US-001: As a visitor, I want to see a welcoming home page with a clear mission statement so that I understand the company's purpose.
Acceptance Criteria:
The main heading should be "Welcome to Pharma Inc."
A mission statement must be clearly visible below the main heading.
The page must load in under 3 seconds.
US-002: As a visitor, I want to easily navigate to other sections of the site (About, Products, Contact) from the home page.
Acceptance Criteria:
A navigation bar must be present at the top of the page.
The navigation bar must contain links for "Home," "About Us," "Products," and "Contact Us."
All navigation links must be functional.
About Us Page
US-003: As a potential partner, I want to read about the company's history and values on an "About Us" page to determine if they are a good fit for collaboration.
Acceptance Criteria:
The page must have a section for "Our History."
The page must have a section for "Our Values."
Products Page
US-004: As a healthcare professional, I want to view a list of the company's products to understand their offerings.
Acceptance Criteria:
The page must display a bulleted list of at least three products.
Each product in the list must have a brief description.
Contact Us Page
US-005: As a potential customer, I want a "Contact Us" page so that I can send inquiries to the company.
Acceptance Criteria:
The page must contain a contact form.
The page must display the company's contact email address.
US-006: The page must have a contact form with fields for Name, Email, and Message.
Acceptance Criteria:
The form must contain an input field for "Name" (text type).
The form must contain an input field for "Email" (email type).
The form must contain a textarea for "Message."
All fields must be marked as required.
US-007: The page must display the company's contact email address: contact@pharma-inc.com.
Acceptance Criteria:
The email address must be visible in the page footer.
The email address must be a clickable mailto: link.
US-008: Submitting the form should send the inquiry to the contact email address.
Acceptance Criteria:
A successful form submission must trigger a POST request to the /api/contact endpoint.
A success message must be displayed to the user upon successful submission.

---
--- FILE: Testing.docx ---

Test Plan: Corporate Website
1. Test Strategy
--[Manual testing will be performed across major browsers (Chrome, Firefox) to verify the functionality of all pages. The focus will be on navigation, content display, and form submission, including validation.]--
++[A hybrid testing approach will be used. Manual testing will be performed for exploratory checks across major browsers (Chrome, Firefox). Automated testing will be the primary method for regression checking. The automation suite will use Selenium for UI/end-to-end tests and a library like 'requests' for API-level tests. The focus will be on navigation, content verification, form submission logic, and API endpoint validation.]++
2. Test Cases
TC-NAV-001:
Description: Verify that the main navigation links on the home page work correctly.
Steps: 1. Load the home page. 2. Click on each link in the navigation bar.
Expected Result: Each link navigates to the correct page (/about, /products, /contact).
--[TC-CONTENT-001:]--
--[Description: Verify that the content on all pages displays correctly.]--
--[Steps: 1. Navigate to each page. 2. Check for text, headings, and lists.]--
--[Expected Result: All static content is present and legible as per the requirements.]--
++[TC-HOME-001:]++
++[Description: Verify that the Home page content is displayed correctly as per US-001.]++
++[Steps: 1. Navigate to the home page. 2. Inspect the main heading and the text below it.]++
++[Expected Result: The main heading is "Welcome to Pharma Inc." and a mission statement is clearly visible.]++
++[TC-ABOUT-001:]++
++[Description: Verify that the About Us page contains the required content sections as per US-003.]++
++[Steps: 1. Navigate to the About Us page. 2. Check for the presence of specific sections.]++
++[Expected Result: The page contains sections for "Our History" and "Our Values".]++
++[TC-PROD-001:]++
++[Description: Verify that the Products page displays a list of products as per US-004.]++
++[Steps: 1. Navigate to the Products page. 2. Inspect the product list.]++
++[Expected Result: The page displays a bulleted list of at least three products, each with a brief description.]++
TC-CONTACT-001:
Description: Verify that the contact email address is correct.
Steps: 1. Navigate to the Contact Us page. 2. Locate the footer section.
Expected Result: The email "--[contact@pharma-inc.com]--++[inquiries@pharma-corp.com]++" is displayed and is a clickable mailto: link.
TC-CONTACT-002 (Positive):
Description: Verify successful form submission with valid data.
Steps: 1. Fill all form fields with valid data. 2. Click "Send."
Expected Result: A success message is displayed, and the form fields are cleared.
TC-CONTACT-003 (Negative):
Description: Verify that the form cannot be submitted with an empty required field.
Steps: 1. Leave the "Name" field blank. 2. Fill other fields. 3. Click "Send."
--[Expected Result: The form does not submit. An HTML5 validation message appears.]--
++[Expected Result: The form does not submit. The blank "Name" field displays an HTML5 validation message (e.g., "Please fill out this field.").]++
++[TC-API-CONTACT-001 (API):]++
++[Description: Verify that the contact form submission API endpoint works correctly as per US-008.]++
++[Steps: 1. Construct a JSON payload with valid name, email, and message data. 2. Send a POST request to the /api/contact endpoint.]++
++[Expected Result: The API returns a 200 OK status code, indicating successful receipt of the data.]++
++[TC-API-CONTACT-002 (Negative API):]++
++[Description: Verify that the /api/contact endpoint handles invalid data correctly as per the Design Document.]++
++[Steps: 1. Construct a JSON payload with a valid name and message, but missing the email field. 2. Send a POST request to the /api/contact endpoint.]++
++[Expected Result: The API returns a 400 Bad Request status code.]++
++[TC-E2E-CONTACT-001 (Manual):]++
++[Description: Verify that a successful form submission results in an email being received at the target inbox.]++
++[Pre-requisite: Access to the test email inbox for inquiries@pharma-corp.com (e.g., via a tool like MailHog).]++
++[Steps: 1. Navigate to the Contact Us page. 2. Fill the form with unique, traceable information (e.g., Name: "TestEmail-123"). 3. Submit the form. 4. Check the test email inbox.]++
++[Expected Result: A new email is received at inquiries@pharma-corp.com containing the submitted data (Name: "TestEmail-123").]++

---
--- FILE: test_automation.py ---

# test_contact_page.py

import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
--[import time]--
++[import requests]++

# --- Test Setup ---

@pytest.fixture
def browser():
    """Initializes and quits the browser for each test function."""
    driver = webdriver.Chrome()
    driver.implicitly_wait(10)
    yield driver
    driver.quit()

# --- Test Cases ---

def test_page_titles(browser):
    """
    Test Case TC-NAV-001: Verify that the main navigation links work correctly
    and lead to pages with the correct titles.
    """
    base_url = "http://127.0.0.1:5000"
    pages = {
        "/": "Pharma Inc. - Home",
        "/about": "About - Pharma Inc.",
        "/products": "Products - Pharma Inc.",
        "/contact": "Contact - Pharma Inc."
    }

    for path, title in pages.items():
        browser.get(base_url + path)
        assert title in browser.title

++[def test_home_page_content(browser):]++
++[    """]++
++[    Test Case TC-HOME-001: Verify home page content.]++
++[    """]++
++[    browser.get("http://127.0.0.1:5000/")]++
++[    ]++
++[    heading = browser.find_element(By.TAG_NAME, "h1").text]++
++[    assert heading == "Welcome to Pharma Inc."]++
++[    ]++
++[    mission_statement = browser.find_element(By.ID, "mission-statement")]++
++[    assert mission_statement.is_displayed()]++
++[    assert len(mission_statement.text) > 0]++

++[def test_about_page_content(browser):]++
++[    """]++
++[    Test Case TC-ABOUT-001: Verify About Us page content.]++
++[    """]++
++[    browser.get("http://127.0.0.1:5000/about")]++
++[    ]++
++[    history_section = browser.find_element(By.XPATH, "//h2[text()='Our History']")]++
++[    values_section = browser.find_element(By.XPATH, "//h2[text()='Our Values']")]++
++[    assert history_section.is_displayed()]++
++[    assert values_section.is_displayed()]++

++[def test_products_page_content(browser):]++
++[    """]++
++[    Test Case TC-PROD-001: Verify Products page content.]++
++[    """]++
++[    browser.get("http://127.0.0.1:5000/products")]++
++[    ]++
++[    product_items = browser.find_elements(By.CSS_SELECTOR, "ul > li")]++
++[    assert len(product_items) >= 3]++
++[    # Check that each product item has a description (e.g., in a <p> tag)]++
++[    for item in product_items:]++
++[        description = item.find_element(By.TAG_NAME, "p")]++
++[        assert len(description.text) > 10]++

def test_contact_email_display(browser):
    """
    Test Case TC-CONTACT-001: Verify that the contact email address is displayed correctly.
    """
    browser.get("http://127.0.0.1:5000/contact")
    
    email_link = WebDriverWait(browser, 10).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, "footer a"))
    )
    
    assert email_link.text == "--[contact@pharma-inc.com]--++[inquiries@pharma-corp.com]++"
    assert email_link.get_attribute("href") == "mailto:--[contact@pharma-inc.com]--++[inquiries@pharma-corp.com]++"

def test_contact_form_submission_success(browser):
    """
    Test Case TC-CONTACT-002 (Positive): Verify successful form submission with valid data.
    """
    browser.get("http://127.0.0.1:5000/contact")
    
    # Fill out the form
    browser.find_element(By.ID, "name").send_keys("John Doe")
    browser.find_element(By.ID, "email").send_keys("john.doe@example.com")
    browser.find_element(By.ID, "message").send_keys("This is a test inquiry.")
    
    # Submit the form
    browser.find_element(By.CSS_SELECTOR, "button[type='submit']").click()
    
    # Wait for the success message
    success_message = WebDriverWait(browser, 10).until(
        EC.text_to_be_present_in_element((By.ID, "form-status"), "Your inquiry has been sent!")
    )
    assert success_message

def test_contact_form_submission_failure(browser):
    """
    Test Case TC-CONTACT-003 (Negative): Verify form does not submit with an empty required field.
    """
    browser.get("http://127.0.0.1:5000/contact")
    
    # Leave name field blank
    name_field = browser.find_element(By.ID, "name")
    browser.find_element(By.ID, "email").send_keys("jane.doe@example.com")
    browser.find_element(By.ID, "message").send_keys("This is another test.")
    
    # Submit the form
    browser.find_element(By.CSS_SELECTOR, "button[type='submit']").click()
    
    --[# Check that the success message does not appear]--
    --[status_element = browser.find_element(By.ID, "form-status")]--
    --[time.sleep(1) # Give a moment to see if text appears]--
    --[assert status_element.text == ""]--
    ++[# Check for the HTML5 validation message on the required field]++
    ++[validation_message = name_field.get_attribute("validationMessage")]++
    ++[assert "Please fill out this field" in validation_message]++

++[def test_contact_form_api_call():]++
++[    """]++
++[    Test Case TC-API-CONTACT-001 (API): Verify the contact form submission API endpoint.]++
++[    """]++
++[    url = "http://127.0.0.1:5000/api/contact"]++
++[    payload = {]++
++[        "name": "API Tester",]++
++[        "email": "api.test@example.com",]++
++[        "message": "This is a test from the API." ]++
++[    }]++
++[    ]++
++[    response = requests.post(url, json=payload)]++
++[    ]++
++[    assert response.status_code == 200]++
++[    assert response.json()["status"] == "success"]++

++[def test_contact_form_api_call_invalid_data():]++
++[    """]++
++[    Test Case TC-API-CONTACT-002 (Negative API): Verify the API returns 400 for invalid data.]++
++[    """]++
++[    url = "http://127.0.0.1:5000/api/contact"]++
++[    # Payload is missing the required 'email' field]++
++[    payload = {]++
++[        "name": "API Tester Invalid",]++
++[        "message": "This should fail." ]++
++[    }]++
++[    ]++
++[    response = requests.post(url, json=payload)]++
++[    ]++
++[    assert response.status_code == 400]++