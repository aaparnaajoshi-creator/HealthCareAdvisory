### Test Strategy
- **Scope:** The scope of testing covers the entire Product Catalog Management System, encompassing the user interface (UI) for product managers and customers, the backend API services, and the underlying database interactions. This includes all functionalities related to adding, viewing, updating, deleting products, as well as customer-facing search and product detail viewing.
- **Objectives:**
    - To ensure all specified functional requirements and acceptance criteria are met.
    - To verify the system's reliability, stability, and performance under expected load.
    - To validate the security measures, especially authentication and authorization for product management roles.
    - To confirm the system's usability for both product managers and customers.
    - To ensure seamless integration between different system components (frontend, backend, database).
    - To facilitate early detection and resolution of defects, reducing the cost of quality.
- **Testing Types:**
    - **Unit Testing:** Focus on individual functions, methods, and components (e.g., React components, Node.js service functions) to ensure they work as expected in isolation.
    - **Integration Testing:** Verify the interaction and communication between different modules or services (e.g., frontend-backend API calls, backend-database interactions, authentication service integration).
    - **API Testing:** Directly test the RESTful endpoints of the Node.js backend to ensure correct data processing, validation, and response handling for all CRUD operations and queries.
    - **Functional Testing (End-to-End):** Validate complete user flows from the UI perspective, covering all user stories and acceptance criteria. This will be driven by the BDD feature files.
    - **Security Testing:** Evaluate the system's resilience against unauthorized access, data breaches, and common web vulnerabilities (e.g., input validation, role-based access control for Product Managers).
    - **Performance Testing:** Assess the system's responsiveness and stability under various load conditions, focusing on critical API endpoints like product listing and search.
    - **Usability Testing:** (Informal) Evaluate the ease of use and user-friendliness of the Product Manager's dashboard and the Customer's product browsing experience.
    - **Deployment/Smoke Testing:** A quick set of tests performed after each deployment to a new environment to ensure the critical functionalities are working as expected.

### BDD Feature File (`project_tests.feature`)

```gherkin
Feature: Product Management
  As a Product Manager
  I want to manage products in the catalog
  So that product information is accurate and available for customers

  Scenario: Successfully add a new product to the catalog
    Given I am authenticated as a "Product Manager"
    And I am on the "Add Product" page
    When I enter product details:
      | Field       | Value                |
      | Name        | Laptop Pro           |
      | Description | High-performance laptop |
      | Price       | 1200.00              |
      | SKU         | LPT-PRO-001          |
      | Quantity    | 50                   |
    And I click the "Add Product" button
    Then I should see a success message "Product 'Laptop Pro' added successfully."
    And The product "Laptop Pro" with SKU "LPT-PRO-001" should be in the catalog

  Scenario Outline: Prevent adding a product with invalid price
    Given I am authenticated as a "Product Manager"
    And I am on the "Add Product" page
    When I enter product details:
      | Field       | Value                |
      | Name        | Test Product         |
      | Description | A test product       |
      | Price       | <Price>              |
      | SKU         | TEST-SKU-<SKU_Suffix>|
      | Quantity    | 10                   |
    And I click the "Add Product" button
    Then I should see an error message "Price must be a positive number."
    And The product "Test Product" should not be in the catalog
    Examples:
      | Price  | SKU_Suffix |
      | 0      | 001        |
      | -10.50 | 002        |
      | invalid| 003        |

  Scenario: Prevent adding a product with a duplicate SKU
    Given I am authenticated as a "Product Manager"
    And a product with SKU "DUPLICATE-SKU-001" already exists in the catalog
    And I am on the "Add Product" page
    When I enter product details:
      | Field       | Value                |
      | Name        | Another Product      |
      | Description | Another description  |
      | Price       | 150.00               |
      | SKU         | DUPLICATE-SKU-001    |
      | Quantity    | 20                   |
    And I click the "Add Product" button
    Then I should see an error message "Product with this SKU already exists."
    And The product "Another Product" should not be added to the catalog

  Scenario: Prevent an unauthenticated user from adding a product
    Given I am not authenticated
    When I try to access the "Add Product" page
    Then I should be redirected to the "Login" page
    And I should see an error message "You need to be logged in to access this page."

  Scenario: Successfully update an existing product
    Given I am authenticated as a "Product Manager"
    And a product with SKU "LPT-PRO-001" and name "Laptop Pro" exists in the catalog with price 1200.00 and quantity 50
    When I navigate to the "Edit Product" page for "LPT-PRO-001"
    And I update the product details:
      | Field       | Value                |
      | Name        | Laptop Pro Max       |
      | Description | Ultra-performance laptop |
      | Price       | 1500.00              |
      | Quantity    | 45                   |
    And I click the "Save Changes" button
    Then I should see a success message "Product 'Laptop Pro Max' updated successfully."
    And The product "LPT-PRO-001" should have name "Laptop Pro Max", price 1500.00 and quantity 45

  Scenario: Prevent updating a product with an invalid price
    Given I am authenticated as a "Product Manager"
    And a product with SKU "LPT-PRO-001" exists in the catalog
    When I navigate to the "Edit Product" page for "LPT-PRO-001"
    And I update the product price to "-50.00"
    And I click the "Save Changes" button
    Then I should see an error message "Price must be a positive number."
    And The product "LPT-PRO-001" price should remain unchanged

  Scenario: Prevent updating the SKU of an existing product
    Given I am authenticated as a "Product Manager"
    And a product with SKU "LPT-PRO-001" exists in the catalog
    When I navigate to the "Edit Product" page for "LPT-PRO-001"
    And I try to update the SKU to "LPT-PRO-002"
    And I click the "Save Changes" button
    Then I should see an error message "SKU cannot be updated."
    And The product "LPT-PRO-001" SKU should remain "LPT-PRO-001"

  Scenario: Prevent an unauthorized user from updating a product
    Given I am authenticated as a "Customer"
    And a product with SKU "LPT-PRO-001" exists in the catalog
    When I try to access the "Edit Product" page for "LPT-PRO-001"
    Then I should be redirected to the "Login" page
    And I should see an error message "You do not have permission to perform this action."

  Scenario: Handle update of a non-existent product
    Given I am authenticated as a "Product Manager"
    When I try to update product with SKU "NON-EXISTENT-SKU"
    Then I should see an error message "Product with SKU 'NON-EXISTENT-SKU' not found."
    And No product should be updated

  Scenario: Successfully remove an existing product
    Given I am authenticated as a "Product Manager"
    And a product with SKU "LPT-PRO-001" and name "Laptop Pro" exists in the catalog
    When I navigate to the "Product List" page
    And I select the product "LPT-PRO-001" for removal
    And I confirm the removal
    Then I should see a success message "Product 'Laptop Pro' removed successfully."
    And The product "LPT-PRO-001" should no longer be in the catalog

  Scenario: Prevent an unauthorized user from removing a product
    Given I am authenticated as a "Customer"
    And a product with SKU "LPT-PRO-001" exists in the catalog
    When I try to access the "Remove Product" functionality for "LPT-PRO-001"
    Then I should be redirected to the "Login" page
    And I should see an error message "You do not have permission to perform this action."

  Scenario: Handle removal of a non-existent product
    Given I am authenticated as a "Product Manager"
    When I try to remove product with SKU "NON-EXISTENT-SKU"
    Then I should see an error message "Product with SKU 'NON-EXISTENT-SKU' not found."
    And No product should be removed

Feature: Product Catalog Viewing
  As a Product Manager
  I want to view and manage the product list
  So that I can keep track of inventory and product information

  Scenario: View all products as a Product Manager
    Given I am authenticated as a "Product Manager"
    And the catalog contains products:
      | Name       | SKU         | Price  | Quantity |
      | Laptop Pro | LPT-PRO-001 | 1200.00| 50       |
      | Mouse      | MSE-001     | 25.00  | 100      |
    When I navigate to the "Product List" page
    Then I should see a list of products including:
      | Name       | SKU         | Price  | Quantity |
      | Laptop Pro | LPT-PRO-001 | 1200.00| 50       |
      | Mouse      | MSE-001     | 25.00  | 100      |
    And The list should be sortable by "Name", "SKU", "Price"
    And The list should have pagination controls

  Scenario Outline: Filter products by name or SKU
    Given I am authenticated as a "Product Manager"
    And the catalog contains products:
      | Name       | SKU         | Price  | Quantity |
      | Laptop Pro | LPT-PRO-001 | 1200.00| 50       |
      | Gaming Mouse| MSE-G-001  | 50.00  | 75       |
      | Keyboard   | KBD-001     | 75.00  | 60       |
    When I filter the product list by "<FilterType>" with value "<FilterValue>"
    Then I should see the following products in the list:
      | Name          | SKU          |
      | <ExpectedName1> | <ExpectedSKU1> |
      | <ExpectedName2> | <ExpectedSKU2> |
    And I should not see any other products
    Examples:
      | FilterType | FilterValue | ExpectedName1 | ExpectedSKU1 | ExpectedName2 | ExpectedSKU2 |
      | Name       | Laptop      | Laptop Pro    | LPT-PRO-001  |               |              |
      | SKU        | MSE         | Gaming Mouse  | MSE-G-001    |               |              |
      | Name       | Mouse       | Gaming Mouse  | MSE-G-001    |               |              |
      | Name       | keyboard    | Keyboard      | KBD-001      |               |              |

  Scenario Outline: Sort products by different criteria
    Given I am authenticated as a "Product Manager"
    And the catalog contains products:
      | Name        | SKU         | Price  | Quantity |
      | Apple       | APP-001     | 1.00   | 100      |
      | Banana      | BAN-001     | 0.50   | 150      |
      | Cherry      | CHY-001     | 2.00   | 75       |
    When I sort the product list by "<SortCriterion>" in "<SortOrder>" order
    Then the products should be displayed in the following order:
      | Name          |
      | <Product1>    |
      | <Product2>    |
      | <Product3>    |
    Examples:
      | SortCriterion | SortOrder | Product1 | Product2 | Product3 |
      | Name          | Ascending | Apple    | Banana   | Cherry   |
      | Name          | Descending| Cherry   | Banana   | Apple    |
      | Price         | Ascending | Banana   | Apple    | Cherry   |
      | Price         | Descending| Cherry   | Apple    | Banana   |

Feature: Customer Product Search
  As a Customer
  I want to search for products
  So that I can find what I'm looking for easily

  Scenario Outline: Search for products by name or description (case-insensitive)
    Given the product catalog contains:
      | Name             | Description                    | Price  |
      | Wireless Mouse   | Ergonomic design for comfort   | 30.00  |
      | Mechanical Keyboard| Gaming keyboard with RGB lights| 120.00 |
      | USB Hub          | 4-port USB 3.0 hub             | 15.00  |
    When I search for "<SearchTerm>"
    Then I should see the following products in the search results:
      | Name             | Description                    | Price  |
      | <ExpectedName1>  | <ExpectedDescription1>         | <ExpectedPrice1>|
      | <ExpectedName2>  | <ExpectedDescription2>         | <ExpectedPrice2>|
    And I should not see any other products
    Examples:
      | SearchTerm        | ExpectedName1      | ExpectedDescription1           | ExpectedPrice1 | ExpectedName2        | ExpectedDescription2           | ExpectedPrice2 |
      | mouse             | Wireless Mouse     | Ergonomic design for comfort   | 30.00          | Mechanical Keyboard  | Gaming keyboard with RGB lights| 120.00         |
      | keyboard          | Mechanical Keyboard| Gaming keyboard with RGB lights| 120.00         |                      |                                |                |
      | ergonomic         | Wireless Mouse     | Ergonomic design for comfort   | 30.00          |                      |                                |                |
      | USB               | USB Hub            | 4-port USB 3.0 hub             | 15.00          |                      |                                |                |

  Scenario: Display "No products found" when search yields no results
    Given the product catalog contains:
      | Name             | Description                    | Price  |
      | Wireless Mouse   | Ergonomic design for comfort   | 30.00  |
    When I search for "NonExistentProduct"
    Then I should see the message "No products found."
    And I should not see any product listings

Feature: Customer Product Viewing
  As a Customer
  I want to view details of a specific product
  So that I can make an informed purchase decision

  Scenario: View details of an available product
    Given a product named "Laptop Pro" with SKU "LPT-PRO-001", description "High-performance laptop", price 1200.00 and quantity 50 exists in the catalog
    When I navigate to the product detail page for "LPT-PRO-001"
    Then I should see the product details:
      | Field       | Value                    |
      | Name        | Laptop Pro               |
      | Description | High-performance laptop  |
      | Price       | 1200.00                  |
      | SKU         | LPT-PRO-001              |
      | Quantity    | 50                       |
    And I should see "In Stock" indicator

  Scenario: View details of an out-of-stock product
    Given a product named "Limited Edition Watch" with SKU "LEW-001", description "Exclusive timepiece", price 500.00 and quantity 0 exists in the catalog
    When I navigate to the product detail page for "LEW-001"
    Then I should see the product details:
      | Field       | Value                    |
      | Name        | Limited Edition Watch    |
      | Description | Exclusive timepiece      |
      | Price       | 500.00                   |
      | SKU         | LEW-001                  |
      | Quantity    | 0                        |
    And I should see "Out of Stock" indicator

  Scenario: Handle viewing details of a non-existent product
    When I navigate to the product detail page for "NON-EXISTENT-PROD"
    Then I should see an error message "Product not found."
    And I should not see any product details
```