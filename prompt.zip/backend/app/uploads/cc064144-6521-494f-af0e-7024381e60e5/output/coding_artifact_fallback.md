```markdown
# .env

```
DATABASE_URL=postgresql://user:password@host:port/database
AWS_ACCESS_KEY_ID=YOUR_AWS_ACCESS_KEY_ID
AWS_SECRET_ACCESS_KEY=YOUR_AWS_SECRET_ACCESS_KEY
AWS_S3_BUCKET_NAME=your-s3-bucket-name
HASH_SALT=your_random_hash_salt
```

```markdown
# backend/database.py
```python
import os
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

DATABASE_URL = os.environ.get("DATABASE_URL")
if not DATABASE_URL:
    raise ValueError("DATABASE_URL environment variable not set")

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

def get_db():
    """
    Dependency to get a database session.
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
```

```markdown
# backend/models.py
```python
import uuid
from sqlalchemy import Column, String, Text, DateTime, Boolean, JSON
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from backend.database import Base

class ProductModel(Base):
    """
    Represents a product in the database.
    """
    __tablename__ = "products"

    product_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String, nullable=False)
    description = Column(Text)
    indications = Column(Text)
    dosage = Column(Text)
    administration = Column(Text)
    contraindications = Column(Text)
    warnings = Column(Text)
    precautions = Column(Text)
    adverse_reactions = Column(Text)
    pi_document_url = Column(String)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

class ContactFormSubmission(Base):
    """
    Represents a contact form submission in the database.
    """
    __tablename__ = "contact_form_submissions"

    submission_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String, nullable=False)
    email = Column(String, nullable=False)
    subject = Column(String)
    message = Column(Text)
    submitted_at = Column(DateTime(timezone=True), server_default=func.now())


class NewsletterSubscription(Base):
    """
    Represents a newsletter subscription in the database.
    """
    __tablename__ = "newsletter_subscriptions"

    subscription_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String, nullable=False, unique=True)
    subscribed_at = Column(DateTime(timezone=True), server_default=func.now())
    consent = Column(Boolean, nullable=False)


class CookieConsent(Base):
    """
    Represents cookie consent information in the database.
    """
    __tablename__ = "cookie_consents"

    consent_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_identifier = Column(String, nullable=False)  # Session ID or Hashed IP Address
    consent_preferences = Column(JSON)
    consent_given_at = Column(DateTime(timezone=True), server_default=func.now())
```

```markdown
# backend/schemas.py
```python
from pydantic import BaseModel, EmailStr
from typing import Dict, Optional
import uuid
from datetime import datetime

class Product(BaseModel):
    """
    Represents a product.
    """
    product_id: uuid.UUID
    name: str
    description: Optional[str] = None

    class Config:
        orm_mode = True


class ProductDetail(BaseModel):
    """
    Represents detailed information about a product.
    """
    product_id: uuid.UUID
    name: str
    description: Optional[str] = None
    indications: Optional[str] = None
    dosage: Optional[str] = None
    administration: Optional[str] = None
    contraindications: Optional[str] = None
    warnings: Optional[str] = None
    precautions: Optional[str] = None
    adverse_reactions: Optional[str] = None
    pi_document_url: Optional[str] = None

    class Config:
        orm_mode = True


class ContactForm(BaseModel):
    """
    Represents a contact form submission.
    """
    name: str
    email: EmailStr
    subject: Optional[str] = None
    message: str


class NewsletterSubscriptionCreate(BaseModel):
    """
    Represents a newsletter subscription request.
    """
    email: EmailStr
    consent: bool


class NewsletterSubscription(BaseModel):
    """
    Represents a newsletter subscription.
    """
    subscription_id: uuid.UUID
    email: EmailStr
    subscribed_at: datetime
    consent: bool

    class Config:
        orm_mode = True

class CookieConsentCreate(BaseModel):
    """
    Represents a cookie consent request.
    """
    user_identifier: str
    consent_preferences: Dict


class CookieConsent(BaseModel):
    """
    Represents cookie consent information.
    """
    consent_id: uuid.UUID
    user_identifier: str
    consent_preferences: Dict
    consent_given_at: datetime

    class Config:
        orm_mode = True

class SearchResult(BaseModel):
    """
    Represents a search result.
    """
    title: str
    description: str
    url: str

class HomePageContent(BaseModel):
    """
    Represents the content for the home page.
    """
    logo_url: str
    tagline: str
    navigation: list[dict]

class PresignedURL(BaseModel):
    """
    Represents a presigned URL for downloading a file.
    """
    presigned_url: str
```

```markdown
# backend/utils.py
```python
import hashlib
import os
import boto3
from botocore.exceptions import ClientError
from fastapi import HTTPException

def hash_user_identifier(user_identifier: str) -> str:
    """
    Hashes the user identifier (e.g., IP address) using SHA-256.
    """
    salt = os.environ.get("HASH_SALT")
    if not salt:
        raise ValueError("HASH_SALT environment variable not set")
    salted_identifier = user_identifier + salt
    hashed_identifier = hashlib.sha256(salted_identifier.encode()).hexdigest()
    return hashed_identifier

def generate_presigned_url(bucket_name: str, object_name: str, expiration: int = 3600) -> str:
    """Generate a presigned URL to access an S3 object.

    Args:
        bucket_name: The name of the S3 bucket.
        object_name: The name of the S3 object.
        expiration: The number of seconds the presigned URL is valid for.

    Returns:
        A presigned URL as a string. Raises HTTPException if an error occurs.
    """
    s3_client = boto3.client('s3',
                           aws_access_key_id=os.environ.get("AWS_ACCESS_KEY_ID"),
                           aws_secret_access_key=os.environ.get("AWS_SECRET_ACCESS_KEY"))

    try:
        response = s3_client.generate_presigned_url('get_object',
                                                    Params={'Bucket': bucket_name,
                                                            'Key': object_name},
                                                    ExpiresIn=expiration)
    except ClientError as e:
        raise HTTPException(status_code=500, detail=str(e))

    # The response contains the presigned URL
    return response
```

```markdown
# backend/main.py
```python
import os
import uuid
from typing import List

import boto3
from botocore.exceptions import ClientError
from fastapi import FastAPI, Depends, HTTPException, status, Request
from fastapi.middleware import Middleware
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

from backend import models, schemas
from backend.database import get_db, engine
from backend.utils import hash_user_identifier, generate_presigned_url

models.Base.metadata.create_all(bind=engine)

app = FastAPI()

# CORS configuration
origins = [
    "http://localhost:3000",  # or whatever port your frontend runs on
    "http://localhost",
    "*",  # allow all origins (for development only!)
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Rate limiting configuration
limiter = Limiter(key_func=get_remote_address, storage_uri="memory://")
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# Security Headers
@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    """
    Adds security headers to the response.
    """
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    return response

@app.get("/")
async def read_root():
    """
    Root endpoint.
    """
    return {"message": "Welcome to PharmaCorp API"}

@app.get("/api/content/home", response_model=schemas.HomePageContent)
@limiter.limit("5/minute")
async def get_home_page_content(request: Request):
    """
    Retrieves the content for the home page.
    """
    try:
        home_page_data = {
            "logo_url": "/images/logo.png",
            "tagline": "PharmaCorp: Improving Lives Through Innovation",
            "navigation": [
                {"label": "About Us", "url": "/about"},
                {"label": "Products", "url": "/products"},
                {"label": "Contact Us", "url": "/contact"}
            ]
        }
        return home_page_data
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/products", response_model=List[schemas.Product])
@limiter.limit("5/minute")
async def read_products(request: Request, db: Session = Depends(get_db)):
    """
    Retrieves a list of products.
    """
    try:
        products = db.query(models.ProductModel).all()
        return products
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/products/{product_id}", response_model=schemas.ProductDetail)
@limiter.limit("5/minute")
async def read_product(request: Request, product_id: uuid.UUID, db: Session = Depends(get_db)):
    """
    Retrieves detailed information about a specific product.
    """
    try:
        product = db.query(models.ProductModel).filter(models.ProductModel.product_id == product_id).first()
        if product is None:
            raise HTTPException(status_code=404, detail="Product not found")
        return product
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/products/{product_id}/pi", response_model=schemas.PresignedURL)
@limiter.limit("5/minute")
async def get_product_pi(request: Request, product_id: uuid.UUID, db: Session = Depends(get_db)):
    """
    Generates a presigned URL for downloading the Prescribing Information (PI) document for a product.
    """
    try:
        product = db.query(models.ProductModel).filter(models.ProductModel.product_id == product_id).first()
        if not product:
            raise HTTPException(status_code=404, detail="Product not found")

        if not product.pi_document_url:
            raise HTTPException(status_code=404, detail="PI document not found for this product")

        bucket_name = os.environ.get("AWS_S3_BUCKET_NAME")
        if not bucket_name:
            raise ValueError("AWS_S3_BUCKET_NAME environment variable not set")

        presigned_url = generate_presigned_url(bucket_name=bucket_name, object_name=product.pi_document_url)
        return {"presigned_url": presigned_url}

    except ValueError as ve:
        raise HTTPException(status_code=500, detail=str(ve))
    except ClientError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/contact", status_code=status.HTTP_201_CREATED)
@limiter.limit("10/minute")
async def create_contact_form_submission(request: Request, contact_form: schemas.ContactForm, db: Session = Depends(get_db)):
    """
    Creates a new contact form submission.
    """
    try:
        # Input validation
        if not contact_form.name or not contact_form.email or not contact_form.message:
            raise HTTPException(status_code=400, detail="Name, email, and message are required")

        db_contact_form = models.ContactFormSubmission(**contact_form.dict())
        db.add(db_contact_form)
        db.commit()
        db.refresh(db_contact_form)
        return {"status": "success", "message": "Your message has been received."}
    except HTTPException as http_exception:
        raise http_exception
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/newsletter", status_code=status.HTTP_201_CREATED)
@limiter.limit("10/minute")
async def create_newsletter_subscription(request: Request, newsletter_subscription: schemas.NewsletterSubscriptionCreate, db: Session = Depends(get_db)):
    """
    Creates a new newsletter subscription.
    """
    try:
        # Input validation
        if not newsletter_subscription.email or not newsletter_subscription.consent:
            raise HTTPException(status_code=400, detail="Email and consent are required")

        db_newsletter_subscription = models.NewsletterSubscription(**newsletter_subscription.dict())
        db.add(db_newsletter_subscription)
        db.commit()
        db.refresh(db_newsletter_subscription)
        return {"status": "success", "message": "You have been subscribed to our newsletter."}
    except HTTPException as http_exception:
        raise http_exception
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/cookie_consent", status_code=status.HTTP_201_CREATED)
@limiter.limit("20/minute")
async def create_cookie_consent(request: Request, cookie_consent: schemas.CookieConsentCreate, db: Session = Depends(get_db)):
    """
    Creates a new cookie consent record.
    """
    try:
        # Input validation
        if not cookie_consent.user_identifier or not cookie_consent.consent_preferences:
            raise HTTPException(status_code=400, detail="User identifier and consent preferences are required")

        hashed_user_identifier = hash_user_identifier(cookie_consent.user_identifier)
        db_cookie_consent = models.CookieConsent(user_identifier=hashed_user_identifier, consent_preferences=cookie_consent.consent_preferences)
        db.add(db_cookie_consent)
        db.commit()
        db.refresh(db_cookie_consent)
        return {"status": "success", "message": "Cookie consent saved."}
    except HTTPException as http_exception:
        raise http_exception
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/search", response_model=List[schemas.SearchResult])
@limiter.limit("5/minute")
async def search_website(request: Request, query: str, db: Session = Depends(get_db)):
    """
    Searches the website for content matching the given query.
    """
    try:
        # Perform the search in the database
        products = db.query(models.ProductModel).filter(models.ProductModel.name.ilike(f"%{query}%") | models.ProductModel.description.ilike(f"%{query}%")).all()

        # Prepare the search results
        results = []
        for product in products:
            results.append({
                "title": product.name,
                "description": product.description if product.description else "No description available.",
                "url": f"/products/{product.product_id}"
            })

        # Add a dummy search result for the "About Us" page
        results.append({
            "title": "About Us",
            "description": "Information about PharmaCorp's mission and values.",
            "url": "/about"
        })

        return results
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
```

```markdown
# backend/tests/test_main.py
```python
import os
import uuid
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from backend.database import Base, get_db
from backend.main import app
from backend import models

# Use an in-memory SQLite database for testing
DATABASE_URL = "sqlite:///:memory:"

engine = create_engine(
    DATABASE_URL, connect_args={"check_same_thread": False}, poolclass=StaticPool
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def override_get_db():
    """
    Overrides the get_db dependency for testing.
    """
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db

client = TestClient(app)


def setup_database():
    """
    Sets up the database for testing.
    """
    Base.metadata.create_all(bind=engine)
    db = TestingSessionLocal()
    try:
        # Create a test product
        product = models.ProductModel(
            name="Test Product",
            description="This is a test product.",
            indications="Test indications",
            dosage="Test dosage",
            administration="Test administration",
            contraindications="Test contraindications",
            warnings="Test warnings",
            precautions="Test precautions",
            adverse_reactions="Test adverse reactions",
            pi_document_url="test_pi.pdf",
        )
        db.add(product)

        # Create another test product
        product2 = models.ProductModel(
            name="Another Test Product",
            description="This is another test product.",
            indications="Test indications 2",
            dosage="Test dosage 2",
            administration="Test administration 2",
            contraindications="Test contraindications 2",
            warnings="Test warnings 2",
            precautions="Test precautions 2",
            adverse_reactions="Test adverse reactions 2",
            pi_document_url="test_pi2.pdf",
        )
        db.add(product2)

        db.commit()
    finally:
        db.close()


def teardown_database():
    """
    Tears down the database after testing.
    """
    Base.metadata.drop_all(bind=engine)


def test_read_main():
    """
    Tests the root endpoint.
    """
    response = client.get("/")
    assert response.status_code == 200
    assert response.json() == {"message": "Welcome to PharmaCorp API"}


def test_read_products():
    """
    Tests the read_products endpoint.
    """
    setup_database()
    response = client.get("/api/products")
    assert response.status_code == 200
    assert isinstance(response.json(), list)
    teardown_database()


def test_read_product():
    """
    Tests the read_product endpoint.
    """
    setup_database()
    db = TestingSessionLocal()
    product = db.query(models.ProductModel).first()
    db.close()
    response = client.get(f"/api/products/{product.product_id}")
    assert response.status_code == 200
    assert response.json()["name"] == "Test Product"
    teardown_database()


def test_read_product_not_found():
    """
    Tests the read_product endpoint with an invalid product ID.
    """
    response = client.get(f"/api/products/{uuid.uuid4()}")
    assert response.status_code == 404
    assert response.json()["detail"] == "Product not found"


def test_create_contact_form_submission():
    """
    Tests the create_contact_form_submission endpoint.
    """
    data = {
        "name": "John Doe",
        "email": "john.doe@example.com",
        "subject": "Test Subject",
        "message": "Test Message",
    }
    response = client.post("/api/contact", json=data)
    assert response.status_code == 201
    assert response.json() == {"status": "success", "message": "Your message has been received."}


def test_create_newsletter_subscription():
    """
    Tests the create_newsletter_subscription endpoint.
    """
    data = {"email": "john.doe@example.com", "consent": True}
    response = client.post("/api/newsletter", json=data)
    assert response.status_code == 201
    assert response.json() == {"status": "success", "message": "You have been subscribed to our newsletter."}


def test_create_cookie_consent():
    """
    Tests the create_cookie_consent endpoint.
    """
    # Mock the environment variable
    os.environ["HASH_SALT"] = "test_salt"

    data = {"user_identifier": "session_123", "consent_preferences": {"analytics": True, "marketing": False}}
    response = client.post("/api/cookie_consent", json=data)
    assert response.status_code == 201
    assert response.json() == {"status": "success", "message": "Cookie consent saved."}

    # Clean up the mock environment variable
    del os.environ["HASH_SALT"]

def test_search_website():
    """
    Tests the search_website endpoint.
    """
    setup_database()
    response = client.get("/api/search?query=Test")
    assert response.status_code == 200
    assert isinstance(response.json(), list)
    teardown_database()

def test_get_home_page_content():
    """
    Tests the get_home_page_content endpoint.
    """
    response = client.get("/api/content/home")
    assert response.status_code == 200
    assert response.json() == {
        "logo_url": "/images/logo.png",
        "tagline": "PharmaCorp: Improving Lives Through Innovation",
        "navigation": [
            {"label": "About Us", "url": "/about"},
            {"label": "Products", "url": "/products"},
            {"label": "Contact Us", "url": "/contact"}
        ]
    }

def test_get_product_pi():
    """
    Tests the get_product_pi endpoint.
    """
    # Mock the environment variables
    os.environ["AWS_ACCESS_KEY_ID"] = "test_access_key"
    os.environ["AWS_SECRET_ACCESS_KEY"] = "test_secret_key"
    os.environ["AWS_S3_BUCKET_NAME"] = "test_bucket"

    setup_database()
    db = TestingSessionLocal()
    product = db.query(models.ProductModel).first()
    db.close()
    response = client.get(f"/api/products/{product.product_id}/pi")
    assert response.status_code == 500  # Expecting 500 because boto3 is mocked and cannot generate a real presigned URL
    teardown_database()

    # Clean up the mock environment variables
    del os.environ["AWS_ACCESS_KEY_ID"]
    del os.environ["AWS_SECRET_ACCESS_KEY"]
    del os.environ["AWS_S3_BUCKET_NAME"]
```

```markdown
# frontend/package.json
```json
{
  "name": "pharmacon-frontend",
  "version": "0.1.0",
  "private": true,
  "dependencies": {
    "@testing-library/jest-dom": "^5.17.0",
    "@testing-library/react": "^13.4.0",
    "@testing-library/user-event": "^13.5.0",
    "axios": "^1.6.7",
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.22.1",
    "react-scripts": "5.0.1",
    "web-vitals": "^2.1.4"
  },
  "scripts": {
    "start": "react-scripts start",
    "build": "react-scripts build",
    "test": "react-scripts test",
    "eject": "react-scripts eject"
  },
  "eslintConfig": {
    "extends": [
      "react-app",
      "react-app/jest"
    ]
  },
  "browserslist": {
    "production": [
      ">0.2%",
      "not dead",
      "not op_mini all"
    ],
    "development": [
      "last 1 chrome version",
      "last 1 firefox version",
      "last 1 safari version"
    ]
  },
  "devDependencies": {
    "jest-environment-jsdom": "^29.7.0"
  }
}
```

```markdown
# frontend/src/App.js
```javascript
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import HomePage from './components/HomePage';
import AboutUs from './components/AboutUs';
import ProductsPage from './components/ProductsPage';
import ProductDetail from './components/ProductDetail';
import ContactUs from './components/ContactUs';
import SearchResults from './components/SearchResults';
import CookieConsent from './components/CookieConsent';
import Footer from './components/Footer';
import './App.css';

function App() {
  return (
    <Router>
      <div className="App">
        <CookieConsent />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutUs />} />
          <Route path="/products" element={<ProductsPage />} />
          <Route path="/products/:productId" element={<ProductDetail />} />
          <Route path="/contact" element={<ContactUs />} />
          <Route path="/search" element={<SearchResults />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
```

```markdown
# frontend/src/components/AboutUs.js
```javascript
import React from 'react';

function AboutUs() {
  return (
    <div className="about-us">
      <h2>About Us</h2>
      <p>PharmaCorp is dedicated to improving lives through innovative pharmaceutical solutions.</p>
      <p>Our mission is to provide high-quality, accessible medicines to patients worldwide.</p>
    </div>
  );
}

export default AboutUs;
```

```markdown
# frontend/src/components/ContactUs.js
```javascript
import React, { useState } from 'react';
import axios from 'axios';

function ContactUs() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [confirmationMessage, setConfirmationMessage] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('/api/contact', {
        name,
        email,
        subject,
        message,
      });

      if (response.status === 201) {
        setConfirmationMessage('Your message has been received.');
        setName('');
        setEmail('');
        setSubject('');
        setMessage('');
      }
    } catch (error) {
      console.error('Error submitting form:', error);
      setConfirmationMessage('There was an error submitting your message. Please try again.');
    }
  };

  return (
    <div className="contact-us">
      <h2>Contact Us</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="name">Name:</label>
          <input
            type="text"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="subject">Subject:</label>
          <input
            type="text"
            id="subject"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
          />
        </div>
        <div>
          <label htmlFor="message">Message:</label>
          <textarea
            id="message"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            required
          />
        </div>
        <button type="submit">Submit</button>
      </form>
      {confirmationMessage && <p>{confirmationMessage}</p>}
    </div>
  );
}

export default ContactUs;
```

```markdown
# frontend/src/components/CookieConsent.js
```javascript
import React, { useState, useEffect } from 'react';
import axios from 'axios';

function CookieConsent() {
  const [consent, setConsent] = useState(localStorage.getItem('cookieConsent') === 'true');
  const [showBanner, setShowBanner] = useState(!consent);

  useEffect(() => {
    if (consent) {
      localStorage.setItem('cookieConsent', 'true');
    } else {
      localStorage.setItem('cookieConsent', 'false');
    }
  }, [consent]);

  const handleAcceptAll = async () => {
    setConsent(true);
    setShowBanner(false);
    await saveConsent({ analytics: true, marketing: true });
  };

  const handleRejectAll = async () => {
    setConsent(false);
    setShowBanner(false);
    await saveConsent({ analytics: false, marketing: false });
  };

  const saveConsent = async (preferences) => {
    try {
      // Replace with a method to generate a session id or hash the IP
      const userIdentifier = 'session_id_123';
      await axios.post('/api/cookie_consent', {
        user_identifier: userIdentifier,
        consent_preferences: preferences,
      });
    } catch (error) {
      console.error('Error saving cookie consent:', error);
    }
  };

  if (!showBanner) {
    return null;
  }

  return (
    <div className="cookie-consent-banner">
      <p>We use cookies to improve your experience. Do you accept our use of cookies?</p>
      <button onClick={handleAcceptAll}>Accept All</button>
      <button onClick={handleRejectAll}>Reject All</button>
    </div>
  );
}

export default CookieConsent;
```

```markdown
# frontend/src/components/Footer.js
```javascript
import React from 'react';

function Footer() {
  return (
    <footer>
      <p>&copy; {new Date().getFullYear()} PharmaCorp. All rights reserved.</p>
      <a href="/privacy-policy">Privacy Policy</a> | <a href="/terms-of-use">Terms of Use</a>
    </footer>
  );
}

export default Footer;
```

```markdown
# frontend/src/components/HomePage.js
```javascript
import React from 'react';
import { Link } from 'react-router-dom';
import SearchBar from './SearchBar';

function HomePage() {
  return (
    <div className="home-page">
      <h1>PharmaCorp</h1>
      <p>Improving Lives Through Innovation</p>
      <SearchBar />
      <nav>
        <ul>
          <li><Link to="/about">About Us</Link></li>
          <li><Link to="/products">Products</Link></li>
          <li><Link to="/contact">Contact Us</Link></li>
        </ul>
      </nav>
    </div>
  );
}

export default HomePage;
```

```markdown
# frontend/src/components/ProductDetail.js
```