```markdown
# Dockerfile (Backend)

```dockerfile
FROM python:3.9-slim-buster

WORKDIR /app

COPY ./backend .

RUN pip install --no-cache-dir --upgrade -r requirements.txt

CMD ["uvicorn", "backend.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

```markdown
# requirements.txt (Backend)

```
fastapi==0.109.2
uvicorn==0.27.0
SQLAlchemy==2.0.27
psycopg2-binary==2.9.9
python-jose==3.3.0
passlib==1.7.4
python-multipart==0.0.6
fastapi-limiter==0.1.6
boto3==1.34.55
```

```markdown
# Dockerfile (Frontend)

```dockerfile
FROM node:16-alpine as builder

WORKDIR /app

COPY ./frontend ./

RUN npm install

RUN npm run build

# Stage 2: Serve the app with Nginx
FROM nginx:alpine

# Copy built assets from builder stage
COPY --from=builder /app/build /usr/share/nginx/html

# Copy custom Nginx configuration
COPY nginx.conf /etc/nginx/conf.d/default.conf

EXPOSE 80
```

```markdown
# nginx.conf

```nginx
server {
    listen 80;
    server_name localhost;

    root /usr/share/nginx/html;
    index index.html index.htm;

    location / {
        try_files $uri $uri/ /index.html;
    }

    # Static files are served directly by Nginx.  No proxy needed.
    # location /static {
    #    proxy_pass http://frontend/static;
    # }

    # API requests are proxied to the backend.
    location /api {
        proxy_pass http://backend:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

```markdown
# docker-compose.yml

```yaml
version: "3.8"
services:
  db:
    image: postgres:13
    volumes:
      - db_data:/var/lib/postgresql/data
    restart: always
    environment:
      POSTGRES_USER: ${POSTGRES_USER:-user}
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD:-password}
      POSTGRES_DB: ${POSTGRES_DB:-database}
    ports:
      - "5432:5432"
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${POSTGRES_USER:-user} -d ${POSTGRES_DB:-database}"]
      interval: 10s
      timeout: 5s
      retries: 5

  backend:
    build:
      context: .
      dockerfile: Dockerfile
    ports:
      - "8000:8000"
    depends_on:
      db:
        condition: service_healthy
    restart: always
    environment:
      DATABASE_URL: postgresql://${POSTGRES_USER:-user}:${POSTGRES_PASSWORD:-password}@db:5432/${POSTGRES_DB:-database}
      AWS_ACCESS_KEY_ID: ${AWS_ACCESS_KEY_ID}
      AWS_SECRET_ACCESS_KEY: ${AWS_SECRET_ACCESS_KEY}
      AWS_S3_BUCKET_NAME: ${AWS_S3_BUCKET_NAME}
      HASH_SALT: ${HASH_SALT}
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000"]
      interval: 10s
      timeout: 5s
      retries: 5

  frontend:
    build:
      context: .
      dockerfile: Dockerfile
    ports:
      - "3000:80" # Expose port 80, as it's what Nginx listens on inside the container
    depends_on:
      - backend
    restart: always
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost"]
      interval: 10s
      timeout: 5s
      retries: 5

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
    volumes:
      - ./nginx.conf:/etc/nginx/conf.d/default.conf
    depends_on:
      - frontend
      - backend
    restart: always
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost"]
      interval: 10s
      timeout: 5s
      retries: 5

volumes:
  db_data:
```

```markdown
# README.md

```markdown
# PharmaCorp Commercial Website - Deployment Instructions

## Overview

This document provides instructions for building, configuring, and deploying the PharmaCorp commercial website using Docker and Docker Compose.

## Prerequisites

*   Docker: [https://docs.docker.com/get-docker/](https://docs.docker.com/get-docker/)
*   Docker Compose: [https://docs.docker.com/compose/install/](https://docs.docker.com/compose/install/)

## Building the Application

1.  **Clone the repository:**

    ```bash
    git clone <repository_url>
    cd <repository_directory>
    ```

2.  **Build the Docker images:**

    ```bash
    docker-compose build
    ```

    This command builds the Docker images for the backend, frontend, and Nginx services.

## Configuration

1.  **Environment Variables:**

    The application relies on several environment variables for configuration. These variables are defined in the `docker-compose.yml` file and can be overridden using a `.env` file or by setting them directly in your environment.

    *   `POSTGRES_USER`: The username for the PostgreSQL database (default: `user`).
    *   `POSTGRES_PASSWORD`: The password for the PostgreSQL database (default: `password`).
    *   `POSTGRES_DB`: The name of the PostgreSQL database (default: `database`).
    *   `AWS_ACCESS_KEY_ID`: Your AWS access key ID for accessing the S3 bucket.
    *   `AWS_SECRET_ACCESS_KEY`: Your AWS secret access key for accessing the S3 bucket.
    *   `AWS_S3_BUCKET_NAME`: The name of the AWS S3 bucket where the PI documents are stored.
    *   `HASH_SALT`: A random salt used for hashing user identifiers for cookie consent.  **This value MUST be changed to a strong, randomly generated string in production.**

    **Important:**  For production deployments, it is highly recommended to secure these environment variables using Docker secrets or a dedicated secrets management solution.  Avoid storing sensitive information directly in the `docker-compose.yml` file or in plain text `.env` files.

2.  **Nginx Configuration:**

    The Nginx configuration file (`nginx.conf`) is located in the root directory of the repository. This file configures Nginx to serve the static files from the frontend's build output directory (`/usr/share/nginx/html` inside the container) and proxy API requests to the backend service.  The frontend's build output is located in the `/frontend/build` directory relative to the repository root, but in the container, it's copied to `/usr/share/nginx/html`.

## Database Migrations

The backend application uses SQLAlchemy for interacting with the PostgreSQL database. The models are defined in `backend/models.py`. The `backend/main.py` file includes the line `models.Base.metadata.create_all(bind=engine)` which *attempts* to create the tables if they don't exist on startup. However, this is not a robust solution for managing database schema changes.

**Recommended Approach:**

Use Alembic for managing database migrations.

1.  **Install Alembic:**

    Add `alembic` to the `requirements.txt` file in the `backend` directory and run `pip install -r requirements.txt`.

2.  **Initialize Alembic:**

    ```bash
    alembic init alembic
    ```

3.  **Configure Alembic:**

    Modify the `alembic.ini` file to point to your database URL.  Specifically, update the `sqlalchemy.url` setting to match your `DATABASE_URL` environment variable.

4.  **Create Migrations:**

    Use the following command to generate a new migration based on changes to your models:

    ```bash
    alembic revision --autogenerate -m "Add products table"
    ```

5.  **Apply Migrations:**

    Use the following command to apply the latest migrations to your database:

    ```bash
    alembic upgrade head
    ```

    You can incorporate these commands into your Dockerfile or entrypoint script to automatically apply migrations during deployment.

## Deployment

1.  **Start the application:**

    ```bash
    docker-compose up -d
    ```

    This command starts the application in detached mode.

2.  **Access the website:**

    Open your web browser and navigate to `http://localhost`.

## Healthchecks

Each service in the `docker-compose.yml` file has a healthcheck defined. Docker will automatically restart any service that fails its healthcheck. This improves the reliability of the application.