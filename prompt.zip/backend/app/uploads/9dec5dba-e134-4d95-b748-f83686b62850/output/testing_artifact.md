# PharmaCorp Commercial Website - Comprehensive Testing Document

## 1. PharmaCorp Commercial Website - Test Strategy

### 1.1 Introduction

This Test Strategy document outlines the approach to testing the PharmaCorp Commercial Website, ensuring it meets the functional, non-functional, security, and accessibility requirements as defined in the Project Requirements (SRS) and High-Level Design (HLD) documents. The goal is to deliver a high-quality, reliable, secure, and user-friendly platform for patients and Healthcare Professionals (HCPs).

### 1.2 Scope of Testing

The testing scope encompasses all components of the PharmaCorp Commercial Website, including:
*   **Frontend:** User Interface (UI), client-side logic, responsiveness across devices, accessibility, and user experience.
*   **Backend API:** RESTful endpoints, business logic, data validation, rate limiting, and integration with the database and object storage.
*   **Database (PostgreSQL):** Data storage, retrieval, integrity, and adherence to GDPR/CCPA principles.
*   **Object Storage:** Storage and retrieval of binary assets (e.g., PDFs).
*   **CDN/WAF:** Performance optimization, security filtering, and HTTPS enforcement.
*   **Security & Compliance:** Adherence to GDPR/CCPA, HTTPS, CSP, input validation, and rate limiting.
*   **Performance:** Page load times (LCP), API response times, and system scalability.

Out of scope: Third-party integrations not explicitly mentioned (e.g., external analytics beyond basic tracking, payment gateways).

### 1.3 Test Objectives

The primary objectives of testing are to:
*   Verify that all user stories and their acceptance criteria are fully met.
*   Ensure the website's functionality is robust, reliable, and performs as expected.
*   Confirm the website is responsive and usable across various devices and browsers.
*   Validate adherence to WCAG 2.2 AA accessibility standards.
*   Ensure the website's security features (HTTPS, input validation, rate limiting, CSP) are effectively implemented and protect user data.
*   Verify compliance with GDPR/CCPA regulations, especially concerning data handling and cookie consent.
*   Identify and report defects early in the development lifecycle.
*   Ensure optimal performance, including fast page load times (LCP < 2.5 seconds).
*   Provide confidence in the software quality before deployment to production.

### 1.4 Test Types and Approach

A multi-faceted testing approach will be employed, combining various test types throughout the development lifecycle.

#### 1.4.1 Functional Testing

*   **Unit Testing:** Developers will write unit tests for individual functions, components, and modules in both frontend (e.g., React components, JavaScript functions) and backend (e.g., API endpoints, database interactions, utility functions).
*   **Integration Testing:**
    *   **Frontend-Backend Integration:** Verify correct communication and data exchange between the UI and the Backend API.
    *   **Backend-Database Integration:** Test that the Backend API correctly stores, retrieves, and manipulates data in PostgreSQL.
    *   **Backend-Object Storage Integration:** Verify successful uploading and downloading of documents (e.g., PDFs) from object storage.
*   **API Testing:** Direct testing of all RESTful API endpoints using tools like Postman/Insomnia or automated scripts to verify request/response formats, status codes, data validation, and error handling.
*   **System Testing (End-to-End):** Comprehensive testing of complete user flows, simulating real-world scenarios from user interaction to backend processing and data persistence. This covers all user stories.
*   **Regression Testing:** Automated and manual tests will be executed after each major code change, bug fix, or new feature deployment to ensure existing functionalities are not negatively impacted.

#### 1.4.2 Non-Functional Testing

*   **Performance Testing:**
    *   **Load Testing:** Simulate expected user loads to assess system behavior under normal conditions.
    *   **Stress Testing:** Push the system beyond its normal operating capacity to identify breaking points and evaluate stability.
    *   **Response Time Testing:** Measure API response times and page load times (e.g., LCP for homepage) under various conditions.
*   **Security Testing:**
    *   **Vulnerability Scanning:** Use automated tools to scan for known vulnerabilities (e.g., OWASP Top 10).
    *   **Penetration Testing:** Ethical hackers will attempt to exploit vulnerabilities to identify weaknesses.
    *   **Input Validation Testing:** Rigorously test all form inputs and API parameters for injection attacks (SQL injection, XSS).
    *   **Rate Limiting Testing:** Verify that rate limits on API endpoints (e.g., contact form, newsletter) are enforced correctly.
    *   **HTTPS Enforcement:** Confirm all traffic is over HTTPS.
    *   **Content Security Policy (CSP) Validation:** Verify CSP headers are correctly configured and effective.
    *   **GDPR/CCPA Compliance Testing:**
        *   Verify cookie consent banner functionality and adherence to user preferences.
        *   Confirm data minimization for personal data (e.g., no raw IP in `contact_submissions`).
        *   Check for clear privacy policy and terms of use links.
        *   Verify secure storage practices (e.g., encryption at rest).
        *   Test data retention policies (if applicable, for IP address logs).

#### 1.4.3 Accessibility Testing

*   **WCAG 2.2 AA Compliance:**
    *   **Keyboard Navigation:** Ensure all interactive elements (links, forms, buttons, navigation) are fully navigable and usable via keyboard only.
    *   **Screen Reader Compatibility:** Test with popular screen readers (e.g., JAWS, NVDA, VoiceOver) to ensure content is correctly announced and navigable.
    *   **Semantic HTML & ARIA Attributes:** Verify correct use of HTML semantic elements and ARIA attributes for enhanced accessibility.
    *   **Color Contrast:** Check for sufficient color contrast ratios.
    *   **Responsive Design:** Visual inspection and testing on various screen sizes and orientations to ensure layout and elements remain usable.

#### 1.4.4 Compatibility Testing

*   **Browser Compatibility:** Test across leading browsers (Chrome, Firefox, Safari, Edge) on desktop and mobile platforms.
*   **Device Compatibility:** Test on a range of devices including desktops, laptops, tablets, and smartphones with varying screen resolutions and operating systems (iOS, Android).

### 1.5 Test Environments

*   **Development Environment:** Individual developer machines for local testing and unit testing.
*   **Staging Environment:** A replica of the production environment for comprehensive system testing, integration testing, performance testing, security testing, and UAT. This environment will be used for final QA sign-off.
*   **Production Environment:** The live environment. Post-deployment smoke tests and health checks will be performed.

### 1.6 Test Tools

*   **Test Management:** Jira, TestRail (or similar) for test case management, execution, and defect tracking.
*   **UI Automation:** Playwright (Python) for end-to-end UI tests.
*   **API Testing:** Pytest with `requests` library (Python) for automated API tests; Postman/Insomnia for manual API exploration.
*   **Performance Testing:** Apache JMeter, K6, or Locust for load and stress testing; Google Lighthouse/PageSpeed Insights for LCP and general web performance metrics.
*   **Accessibility Testing:** Axe Core (automated scans), manual checks with screen readers (JAWS, NVDA, VoiceOver), keyboard navigation.
*   **Security Testing:** OWASP ZAP, Burp Suite (for penetration testing), manual input validation.
*   **Code Quality:** Linters (Flake8, Pylint), SonarQube for static code analysis.

### 1.7 Roles and Responsibilities

*   **QA Automation Engineer (You):** Develop test strategy, create test plans, design and execute manual test cases, develop and maintain automation scripts, analyze test results, report defects, lead accessibility and performance testing efforts.
*   **Development Team:** Write unit tests, assist with integration testing, fix defects, provide technical support to QA.
*   **DevOps Team:** Manage test environments, CI/CD pipeline, performance monitoring, security configurations (WAF, CDN, CSP).
*   **Product Owner/Business Analyst:** Provide clarification on requirements, perform User Acceptance Testing (UAT).

### 1.8 Test Data Management

*   Test data will be created and managed to cover various scenarios, including valid, invalid, boundary, and edge cases.
*   For sensitive data (e.g., contact form submissions), realistic but non-identifiable dummy data will be used in staging environments.
*   Database seeding scripts will be used to populate test environments with consistent and sufficient data.

### 1.9 Test Automation Strategy

*   **Early Automation:** Prioritize automation of unit and API tests early in the development cycle.
*   **UI Automation Focus:** Automate critical, stable, and high-risk user journeys (e.g., navigation, form submissions, product viewing) using Playwright.
*   **Regression Suite:** Build a robust automated regression suite to ensure quick feedback on code changes.
*   **CI/CD Integration:** Integrate automated tests into the CI/CD pipeline to enable continuous testing and rapid feedback on code quality.
*   **Maintainability:** Write modular, readable, and maintainable automation scripts with clear naming conventions and proper test data handling.

### 1.10 Defect Management

*   All identified defects will be logged in a defect tracking system (e.g., Jira).
*   Defects will include detailed descriptions, steps to reproduce, actual results, expected results, screenshots/videos, and environment details.
*   Defects will be prioritized based on severity and impact.
*   Regular defect triage meetings will be held with the development team.

### 1.11 Test Reporting

*   Regular test execution reports will be generated, summarizing test progress, pass/fail rates, defect trends, and overall quality status.
*   A final test summary report will be provided before release, detailing test coverage, remaining risks, and release recommendation.

### 1.12 Entry and Exit Criteria

#### 1.12.1 Test Entry Criteria

*   All requirements (SRS) and design (HLD) documents are finalized and approved.
*   Test environment is set up and stable.
*   Test data is prepared and available.
*   Development build is deployed to the staging environment.
*   Critical defects from previous cycles (if any) are resolved.
*   Smoke tests on the new build pass.

#### 1.12.2 Test Exit Criteria

*   All high-priority and critical defects are resolved and verified.
*   Test coverage goals are met (e.g., 90% functional coverage).
*   All planned test cases (manual and automated) are executed.
*   Automated regression suite passes with acceptable thresholds.
*   Performance, security, and accessibility tests meet defined benchmarks.
*   User Acceptance Testing (UAT) is completed and signed off.
*   Overall quality is deemed acceptable for release.

### 1.13 Risks and Contingencies

| Risk                               | Mitigation Strategy                                                                                             | Contingency Plan                                                                      |
| :--------------------------------- | :-------------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------ |
| Unstable Test Environment          | Dedicated DevOps support, environment monitoring, early setup and validation.                                   | Delay testing until environment is stable; use mock services if backend is unstable.  |
| Scope Creep                        | Strict change control process, clear communication with stakeholders.                                           | Prioritize features, defer non-critical items to future releases.                     |
| Inadequate Test Data               | Comprehensive test data strategy, automated test data generation, database seeding.                              | Manual creation of missing data, mock data for specific scenarios.                    |
| Performance Bottlenecks            | Early performance testing, continuous monitoring, performance baselining.                                       | Optimize problematic areas, scale infrastructure, defer non-critical features.        |
| Late Defect Discovery              | Shift-left testing, continuous integration, early automation, thorough code reviews.                            | Allocate additional resources for defect fixing, re-prioritize testing efforts.      |
| WCAG 2.2 AA Compliance Issues      | Integrate accessibility checks into CI/CD, early involvement of accessibility experts, design reviews.          | Prioritize fixes for critical accessibility violations, phased rollout for non-critical. |
| GDPR/CCPA Non-Compliance           | Legal review of data handling, privacy-by-design approach, regular audits.                                      | Consult legal counsel, implement necessary data protection measures immediately.      |

---

## 2. PharmaCorp Commercial Website - Manual Test Cases

### 2.1 Test Case Template

| Field           | Description                                                                 |
| :-------------- | :-------------------------------------------------------------------------- |
| **Test Case ID**  | Unique identifier for the test case (e.g., TC-HP-001)                       |
| **Test Case Name** | A concise, descriptive name for the test.                                   |
| **Description** | Detailed explanation of what the test case verifies.                        |
| **Preconditions** | Any conditions that must be met before executing the test case.             |
| **Test Steps**    | Numbered list of actions to perform.                                        |
| **Expected Result** | The anticipated outcome after executing the test steps.                     |
| **Status**        | Pass/Fail/Blocked (to be filled during execution)                           |
| **Remarks**       | Any additional notes, observations, or actual results if different from expected. |

### 2.2 Home Page View Test Cases (User Story 1)

**User Story:** As a patient or Healthcare Professional (HCP), I want to view the PharmaCorp commercial website's homepage, So that I can get an overview of the company and navigate to key sections.

#### Test Case 1.1: Verify Homepage Elements and Navigation
*   **Test Case ID:** TC-HP-001
*   **Test Case Name:** Verify Core Homepage Elements and Primary Navigation
*   **Description:** This test verifies the presence of essential elements on the homepage including the logo, navigation menu, hero section, and main content links.
*   **Preconditions:**
    *   Website is deployed and accessible.
*   **Test Steps:**
    1.  Open a web browser.
    2.  Navigate to the website's root URL (e.g., `www.pharmacorpsite.com`).
    3.  Wait for the page to fully load.
*   **Expected Result:**
    *   PharmaCorp logo is prominently displayed in the header.
    *   A persistent primary navigation menu is visible, containing links: "Home", "About Us", "Products", "Contact Us".
    *   A prominent hero section with a clear message is displayed.
    *   Links to main content areas (e.g., "Learn about our mission", "Explore our products") are visible.
*   **Status:**
*   **Remarks:**

#### Test Case 1.2: Verify Homepage Responsiveness Across Devices
*   **Test Case ID:** TC-HP-002
*   **Test Case Name:** Verify Homepage Layout Responsiveness
*   **Description:** This test verifies that the homepage layout and elements adapt correctly to different screen sizes and devices.
*   **Preconditions:**
    *   Homepage (TC-HP-001) loads successfully.
*   **Test Steps:**
    1.  Load the homepage on a desktop browser.
    2.  Resize the browser window gradually from wide to narrow (desktop to mobile viewport).
    3.  (Optional) Open the homepage on a tablet device (e.g., iPad) and a mobile device (e.g., iPhone).
*   **Expected Result:**
    *   The layout of the page (header, hero, content sections) gracefully adjusts to the available screen width.
    *   Navigation menu transforms appropriately (e.g., into a hamburger menu on smaller screens).
    *   Images and text resize and reflow without overflow or truncation.
    *   All elements remain visible, clickable, and usable.
*   **Status:**
*   **Remarks:**

#### Test Case 1.3: Verify Homepage Accessibility (Keyboard Navigation)
*   **Test Case ID:** TC-HP-003
*   **Test Case Name:** Verify Homepage Keyboard Navigability
*   **Description:** This test ensures all interactive elements on the homepage are navigable using only the keyboard.
*   **Preconditions:**
    *   Homepage (TC-HP-001) loads successfully.
*   **Test Steps:**
    1.  Load the homepage.
    2.  Press the `Tab` key repeatedly to navigate through all interactive elements (links, buttons, search bar if present).
    3.  Use `Shift + Tab` to navigate backward.
    4.  Use `Enter` or `Spacebar` to activate links/buttons.
*   **Expected Result:**
    *   A clear visual focus indicator appears around the currently focused element.
    *   All interactive elements are reachable via `Tab` key.
    *   `Enter` or `Spacebar` activates the focused element as expected.
    *   Navigation order is logical and intuitive.
*   **Status:**
*   **Remarks:**

#### Test Case 1.4: Verify Homepage HTTPS Enforcement
*   **Test Case ID:** TC-HP-004
*   **Test Case Name:** Verify HTTPS Protocol Enforcement
*   **Description:** This test confirms that all communication on the homepage occurs over HTTPS.
*   **Preconditions:**
    *   Website is deployed and accessible.
*   **Test Steps:**
    1.  Navigate to the website's root URL.
    2.  Observe the browser's address bar.
*   **Expected Result:**
    *   The URL in the address bar starts with `https://`.
    *   A padlock icon or "Secure" indicator is displayed next to the URL, indicating a secure connection.
    *   No mixed content warnings are observed in the browser console.
*   **Status:**
*   **Remarks:**

### 2.3 Product Detail Page View Test Cases (User Story 4)

**User Story:** As a patient or HCP, I want to view detailed information for a specific PharmaCorp product and access its regulatory documents, So that I can understand its uses, dosage, and important safety information.

#### Test Case 4.1: Verify Product Detail Page Elements
*   **Test Case ID:** TC-PDP-001
*   **Test Case Name:** Verify Product Detail Page Content and ISI Section
*   **Description:** This test verifies the presence of detailed product information and the Important Safety Information (ISI) section on a product detail page.
*   **Preconditions:**
    *   Website is deployed and accessible.
    *   At least one product exists and is accessible via the Products List page.
*   **Test Steps:**
    1.  Navigate to the "Products" page from the main navigation.
    2.  Click on a specific product link (e.g., "Product A").
    3.  Wait for the Product Detail page to load.
*   **Expected Result:**
    *   The product's name is prominently displayed.
    *   Detailed description, indications, and dosage information are visible.
    *   A distinct "Important Safety Information (ISI)" section is present.
    *   Links to download "Prescribing Information (PI) PDF" and "Medication Guide (MedGuide) PDF" are present.
*   **Status:**
*   **Remarks:**

#### Test Case 4.2: Verify Sticky Important Safety Information (ISI) Section
*   **Test Case ID:** TC-PDP-002
*   **Test Case Name:** Verify ISI Section Sticky Behavior
*   **Description:** This test verifies that the Important Safety Information (ISI) section remains visible as the user scrolls down the product detail page.
*   **Preconditions:**
    *   Product Detail page (TC-PDP-001) loads successfully and has enough content to enable scrolling.
*   **Test Steps:**
    1.  Load a Product Detail page.
    2.  Scroll down the page slowly.
*   **Expected Result:**
    *   The "Important Safety Information (ISI)" section remains fixed or sticky in a designated area of the viewport (e.g., sidebar, bottom of screen) while other content scrolls.
    *   The ISI content is fully readable and accessible at all times while scrolling.
*   **Status:**
*   **Remarks:**

#### Test Case 4.3: Verify PDF Document Download from Object Storage
*   **Test Case ID:** TC-PDP-003
*   **Test Case Name:** Verify PI/MedGuide PDF Download Functionality
*   **Description:** This test verifies that clicking the PDF links correctly initiates the download of the corresponding documents from object storage.
*   **Preconditions:**
    *   Product Detail page (TC-PDP-001) loads successfully.
    *   Valid PDF URLs are configured for the product.
*   **Test Steps:**
    1.  Load a Product Detail page.
    2.  Click on the "Prescribing Information (PI) PDF" link.
    3.  Click on the "Medication Guide (MedGuide) PDF" link.
*   **Expected Result:**
    *   Upon clicking the PI PDF link, the browser initiates the download of the PI PDF file.
    *   Upon clicking the MedGuide PDF link, the browser initiates the download of the MedGuide PDF file.
    *   The downloaded files are valid PDF documents and open correctly.
*   **Status:**
*   **Remarks:** (Note: Actual file content verification might require additional tools or manual review)

### 2.4 Contact Us Page & Form Submission Test Cases (User Story 5)

**User Story:** As a patient or HCP, I want to contact PharmaCorp with questions or feedback, So that I can get a response from the company.

#### Test Case 5.1: Verify Contact Us Page Elements
*   **Test Case ID:** TC-CU-001
*   **Test Case Name:** Verify Contact Us Page Form Fields and Info
*   **Description:** This test verifies the presence of all required form fields and general contact information on the Contact Us page.
*   **Preconditions:**
    *   Website is deployed and accessible.
*   **Test Steps:**
    1.  Navigate to the "Contact Us" page from the main navigation.
    2.  Observe the page content.
*   **Expected Result:**
    *   A contact form is displayed with fields for "Name", "Email", "Subject", and "Message".
    *   All form fields are clearly labeled.
    *   PharmaCorp's general contact information (e.g., address, phone number, email address) is displayed.
    *   A "Submit" button is present.
*   **Status:**
*   **Remarks:**

#### Test Case 5.2: Verify Contact Form Submission with Valid Data
*   **Test Case ID:** TC-CU-002
*   **Test Case Name:** Verify Successful Contact Form Submission
*   **Description:** This test verifies that the contact form can be successfully submitted with valid data and a success message is displayed.
*   **Preconditions:**
    *   Contact Us page (TC-CU-001) loads successfully.
*   **Test Steps:**
    1.  Go to the Contact Us page.
    2.  Enter valid data into all fields:
        *   Name: `Test User`
        *   Email: `test.user@example.com`
        *   Subject: `Inquiry about Products`
        *   Message: `This is a test message for product inquiry.`
    3.  Click the "Submit" button.
*   **Expected Result:**
    *   A success message (e.g., "Your message has been sent successfully!") is displayed on the page.
    *   The form fields are cleared or reset.
    *   (Backend Verification) The submitted data is securely stored in the PostgreSQL `contact_submissions` table.
*   **Status:**
*   **Remarks:**

#### Test Case 5.3: Verify Contact Form Validation (Missing Required Fields)
*   **Test Case ID:** TC-CU-003
*   **Test Case Name:** Verify Contact Form Validation for Missing Required Fields
*   **Description:** This test verifies that appropriate inline validation error messages are displayed when required fields are left empty.
*   **Preconditions:**
    *   Contact Us page (TC-CU-001) loads successfully.
*   **Test Steps:**
    1.  Go to the Contact Us page.
    2.  Leave all fields empty.
    3.  Click the "Submit" button.
*   **Expected Result:**
    *   Inline validation error messages are displayed for "Name", "Email", "Subject", and "Message" fields, indicating they are required.
    *   The form is *not* submitted to the backend.
*   **Status:**
*   **Remarks:**

#### Test Case 5.4: Verify Contact Form Validation (Invalid Email Format)
*   **Test Case ID:** TC-CU-004
*   **Test Case Name:** Verify Contact Form Validation for Invalid Email Format
*   **Description:** This test verifies that an appropriate inline validation error message is displayed for an invalid email format.
*   **Preconditions:**
    *   Contact Us page (TC-CU-001) loads successfully.
*   **Test Steps:**
    1.  Go to the Contact Us page.
    2.  Enter valid data for Name, Subject, and Message.
    3.  Enter an invalid email format (e.g., `invalid-email`, `user@.com`) into the "Email" field.
    4.  Click the "Submit" button.
*   **Expected Result:**
    *   An inline validation error message is displayed specifically for the "Email" field, indicating an invalid format.
    *   The form is *not* submitted to the backend.
*   **Status:**
*   **Remarks:**

#### Test Case 5.5: Verify Contact Form Rate Limiting
*   **Test Case ID:** TC-CU-005
*   **Test Case Name:** Verify Contact Form Submission Rate Limiting
*   **Description:** This test verifies that the backend API applies rate limiting to the contact form submission endpoint.
*   **Preconditions:**
    *   Contact Us page (TC-CU-001) loads successfully.
    *   Rate limiting is configured on the backend (e.g., 5 requests per minute from the same IP).
*   **Test Steps:**
    1.  Go to the Contact Us page.
    2.  Repeatedly fill out the form with valid data and click "Submit" quickly (e.g., 6-7 times within a minute).
*   **Expected Result:**
    *   For the first few submissions (within the rate limit), a success message is displayed.
    *   Subsequent submissions within the rate limit period result in an error message indicating "Too Many Requests" (e.g., HTTP 429 status code, message like "Rate limit exceeded. Please try again later.").
    *   The backend `api_request_logs` table records hashed IP addresses for these requests.
*   **Status:**
*   **Remarks:** (This test might require coordination with DevOps to configure and observe rate limits)

### 2.5 Cookie Consent Management Test Cases (User Story 10)

**User Story:** As a website visitor, I want to understand and manage my cookie preferences, So that my privacy choices are respected in compliance with GDPR/CCPA.

#### Test Case 10.1: Verify Cookie Consent Banner on First Visit
*   **Test Case ID:** TC-CC-001
*   **Test Case Name:** Verify Initial Cookie Consent Banner Display
*   **Description:** This test verifies that the cookie consent banner is displayed prominently on a user's first visit to the website.
*   **Preconditions:**
    *   Website is deployed and accessible.
    *   Browser cookies and cache are cleared.
*   **Test Steps:**
    1.  Clear browser cookies and cache.
    2.  Navigate to the website's root URL.
*   **Expected Result:**
    *   A prominent cookie consent banner or pop-up is displayed (e.g., at the bottom of the screen).
    *   The banner clearly explains the use of cookies.
    *   Options to "Accept All", "Decline All", or "Customize Preferences" are visible and clickable.
*   **Status:**
*   **Remarks:**

#### Test Case 10.2: Verify "Accept All" Functionality
*   **Test Case ID:** TC-CC-002
*   **Test Case Name:** Verify "Accept All" Cookies Option
*   **Description:** This test verifies that clicking "Accept All" enables all non-essential cookies and dismisses the banner.
*   **Preconditions:**
    *   Cookie consent banner is displayed (TC-CC-001).
*   **Test Steps:**
    1.  On the cookie consent banner, click the "Accept All" button.
    2.  Refresh the page or navigate to another page.
    3.  Check browser's cookie storage (Developer Tools -> Application -> Cookies).
*   **Expected Result:**
    *   The cookie consent banner disappears.
    *   Non-essential cookies (e.g., analytics, marketing) are set in the browser.
    *   The banner does *not* reappear on subsequent visits (unless expiration or policy change).
*   **Status:**
*   **Remarks:**

#### Test Case 10.3: Verify "Decline All" Functionality
*   **Test Case ID:** TC-CC-003
*   **Test Case Name:** Verify "Decline All" Cookies Option
*   **Description:** This test verifies that clicking "Decline All" enables only strictly necessary cookies and dismisses the banner.
*   **Preconditions:**
    *   Cookie consent banner is displayed (TC-CC-001).
    *   Browser cookies and cache are cleared before starting this test.
*   **Test Steps:**
    1.  Clear browser cookies and cache.
    2.  Navigate to the website.
    3.  On the cookie consent banner, click the "Decline All" button (or equivalent).
    4.  Refresh the page or navigate to another page.
    5.  Check browser's cookie storage.
*   **Expected Result:**
    *   The cookie consent banner disappears.
    *   Only strictly necessary cookies are set in the browser; non-essential cookies are *not* set.
    *   The banner does *not* reappear on subsequent visits.
*   **Status:**
*   **Remarks:**

#### Test Case 10.4: Verify "Customize Preferences" Functionality
*   **Test Case ID:** TC-CC-004
*   **Test Case Name:** Verify Cookie Preference Center Functionality
*   **Description:** This test verifies that clicking "Customize Preferences" displays a detailed preference center, allowing granular control over cookie categories.
*   **Preconditions:**
    *   Cookie consent banner is displayed (TC-CC-001).
    *   Browser cookies and cache are cleared before starting this test.
*   **Test Steps:**
    1.  Clear browser cookies and cache.
    2.  Navigate to the website.
    3.  On the cookie consent banner, click "Customize Preferences" or "Manage Cookies".
    4.  Observe the preference center.
    5.  Toggle specific cookie categories (e.g., enable analytics, disable marketing).
    6.  Click "Save Preferences" or equivalent.
    7.  Refresh the page and check browser cookie storage.
*   **Expected Result:**
    *   A detailed preference center is displayed with toggle options for different cookie categories (e.g., strictly necessary, analytics, marketing).
    *   Each category has a clear description.
    *   Strictly necessary cookies are pre-enabled and cannot be disabled.
    *   Toggling categories and saving preferences correctly sets/unsets the corresponding cookies.
    *   The banner disappears, and choices are remembered on subsequent visits.
*   **Status:**
*   **Remarks:**

---

## 3. PharmaCorp Commercial Website - Automation Test Scripts (Python Playwright)

We will use Python with Playwright for UI automation. Playwright provides a robust, fast, and reliable way to automate browser interactions.

### 3.1 Setup Instructions

1.  **Install Python:** Ensure Python 3.8+ is installed.
2.  **Create a Virtual Environment (Recommended):**
    ```bash
    python -m venv venv
    source venv/bin/activate  # On Windows: venv\Scripts\activate
    ```
3.  **Install Playwright:**
    ```bash
    pip install playwright
    ```
4.  **Install Playwright Browsers:**
    ```bash
    playwright install
    ```
5.  **Create a `requirements.txt` file:**
    ```
    playwright
    ```
6.  **Directory Structure:**
    ```
    pharma_tests/
    ├── tests/
    │   ├── test_homepage.py
    │   └── test_contact_form.py
    ├── conftest.py  # For shared fixtures (e.g., browser setup)
    └── playwright.config.py # Playwright configuration (optional, for more complex setups)
    ```
7.  **`conftest.py` (Optional, but good practice for shared browser fixture):**
    ```python
    import pytest
    from playwright.sync_api import sync_playwright

    @pytest.fixture(scope="session")
    def browser():
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True) # Set headless=False for visual debugging
            yield browser
            browser.close()

    @pytest.fixture(scope="function")
    def page(browser):
        page = browser.new_page()
        yield page
        page.close()
    ```

### 3.2 `test_homepage.py` (for User Story 1: Home Page View)

This script automates checks for the presence of key elements on the homepage and basic navigation.

```python
import pytest
from playwright.sync_api import Page, expect

BASE_URL = "http://localhost:8000" # Replace with your actual website URL

@pytest.mark.homepage
def test_homepage_elements_and_navigation(page: Page):
    """
    Verify the presence of core elements and primary navigation on the homepage.
    Corresponds to Manual Test Case TC-HP-001.
    """
    page.goto(BASE_URL)

    # 1. Verify PharmaCorp logo is displayed
    # Assuming logo has an alt text or a specific selector
    logo = page.locator("header img[alt*='PharmaCorp Logo']")
    expect(logo).to_be_visible()

    # 2. Verify primary navigation menu is present and links are visible
    nav_menu = page.locator("nav.primary-navigation") # Adjust selector based on actual HTML
    expect(nav_menu).to_be_visible()

    # Verify specific navigation links
    expect(nav_menu.locator("a[href='/']")).to_have_text("Home")
    expect(nav_menu.locator("a[href='/about-us']")).to_have_text("About Us")
    expect(nav_menu.locator("a[href='/products']")).to_have_text("Products")
    expect(nav_menu.locator("a[href='/contact-us']")).to_have_text("Contact Us")

    # 3. Verify prominent hero section
    hero_section = page.locator(".hero-section") # Adjust selector
    expect(hero_section).to_be_visible()
    expect(hero_section).to_have_text(/.*clear message.*/) # Check for some text presence

    # 4. Verify links to main content areas (example)
    # Assuming there are links like "Learn more" or "Explore products"
    expect(page.locator("a", has_text="Learn about our mission")).to_be_visible()
    expect(page.locator("a", has_text="Explore our products")).to_be_visible()

@pytest.mark.homepage
def test_homepage_https_enforcement(page: Page):
    """
    Verify that the homepage loads over HTTPS.
    Corresponds to Manual Test Case TC-HP-004.
    Note: This test assumes the browser is configured to follow redirects.
    For a strict check, you might need to use a proxy or API call.
    """
    page.goto(BASE_URL)
    # Playwright's page.url will reflect the final URL after redirects
    assert page.url.startswith("https://"), f"Page did not load over HTTPS. Actual URL: {page.url}"
    # Optionally, check for a secure context using JS
    is_secure_context = page.evaluate("window.isSecureContext")
    assert is_secure_context, "Browser context is not secure (not HTTPS)."

# Example of a basic responsiveness check (can be expanded)
@pytest.mark.homepage
def test_homepage_basic_responsiveness(page: Page):
    """
    Verify basic responsive behavior by checking element visibility at different viewports.
    Corresponds to parts of Manual Test Case TC-HP-002.
    Full responsiveness requires visual regression testing or manual review.
    """
    page.goto(BASE_URL)

    # Test desktop view
    page.set_viewport_size({"width": 1280, "height": 720})
    expect(page.locator("nav.primary-navigation a[href='/products']")).to_be_visible() # Desktop nav item visible

    # Test mobile view
    page.set_viewport_size({"width": 375, "height": 667}) # iPhone SE size
    # Assuming a hamburger menu appears on mobile
    hamburger_menu_button = page.locator("button.hamburger-menu-icon") # Adjust selector
    expect(hamburger_menu_button).to_be_visible()
    expect(page.locator("nav.primary-navigation a[href='/products']")).not_to_be_visible() # Desktop nav item hidden

    # Click hamburger and check nav items are now visible
    hamburger_menu_button.click()
    expect(page.locator("nav.mobile-navigation a[href='/products']")).to_be_visible() # Mobile nav item visible
```

**How to run `test_homepage.py`:**
1.  Ensure your website is running at `http://localhost:8000` (or update `BASE_URL`).
2.  Navigate to the `pharma_tests` directory in your terminal.
3.  Run: `pytest tests/test_homepage.py`

### 3.3 `test_contact_form.py` (for User Story 5: Contact Us Page & Form Submission)

This script automates successful form submission, validation error checks, and a basic check for rate limiting.

```python
import pytest
from playwright.sync_api import Page, expect

BASE_URL = "http://localhost:8000" # Replace with your actual website URL

@pytest.mark.contact_form
def test_contact_form_success(page: Page):
    """
    Verify successful submission of the contact form with valid data.
    Corresponds to Manual Test Case TC-CU-002.
    """
    page.goto(f"{BASE_URL}/contact-us") # Adjust URL if different

    # Fill the form
    page.fill("input[name='name']", "Automation Test User")
    page.fill("input[name='email']", "automation.test@example.com")
    page.fill("input[name='subject']", "Automated Inquiry")
    page.fill("textarea[name='message']", "This is an automated test message for PharmaCorp.")

    # Click submit button
    page.click("button[type='submit']")

    # Verify success message
    success_message = page.locator(".success-message") # Adjust selector for your success message
    expect(success_message).to_be_visible()
    expect(success_message).to_have_text("Your message has been sent successfully!")

    # Verify form fields are cleared (optional, depending on implementation)
    expect(page.locator("input[name='name']")).to_have_value("")
    expect(page.locator("input[name='email']")).to_have_value("")

@pytest.mark.contact_form
def test_contact_form_validation_empty_fields(page: Page):
    """
    Verify validation errors for empty required fields.
    Corresponds to Manual Test Case TC-CU-003.
    """
    page.goto(f"{BASE_URL}/contact-us")

    # Click submit without filling any fields
    page.click("button[type='submit']")

    # Verify error messages for each field
    # Adjust selectors based on how your validation messages are displayed
    expect(page.locator(".error-message.name-field")).to_be_visible()
    expect(page.locator(".error-message.email-field")).to_be_visible()
    expect(page.locator(".error-message.subject-field")).to_be_visible()
    expect(page.locator(".error-message.message-field")).to_be_visible()

    # Ensure no success message is displayed
    expect(page.locator(".success-message")).not_to_be_visible()

@pytest.mark.contact_form
def test_contact_form_validation_invalid_email(page: Page):
    """
    Verify validation error for invalid email format.
    Corresponds to Manual Test Case TC-CU-004.
    """
    page.goto(f"{BASE_URL}/contact-us")

    # Fill with valid data for others, invalid for email
    page.fill("input[name='name']", "Test User")
    page.fill("input[name='email']", "invalid-email") # Invalid email
    page.fill("input[name='subject']", "Subject")
    page.fill("textarea[name='message']", "Message")

    page.click("button[type='submit']")

    # Verify specific error message for email
    expect(page.locator(".error-message.email-field")).to_be_visible()
    expect(page.locator(".error-message.email-field")).to_have_text(/.*valid email address.*/i) # Check for text like "invalid email"

    # Ensure no success message is displayed
    expect(page.locator(".success-message")).not_to_be_visible()

@pytest.mark.contact_form
def test_contact_form_rate_limiting(page: Page):
    """
    Verify rate limiting on contact form submissions.
    Corresponds to Manual Test Case TC-CU-005.
    This test will be slow as it needs to hit the rate limit.
    Rate limit configuration on backend is assumed (e.g., 5 requests per minute).
    """
    page.goto(f"{BASE_URL}/contact-us")

    # Attempt multiple submissions to trigger rate limit (e.g., 6 attempts for a 5-req/min limit)
    for i in range(7):
        page.fill("input[name='name']", f"Rate Limit Test {i+1}")
        page.fill("input[name='email']", f"rate.limit.{i+1}@example.com")
        page.fill("input[name='subject']", f"Rate Limit Test {i+1}")
        page.fill("textarea[name='message']", f"Message {i+1} to test rate limiting.")
        page.click("button[type='submit']")

        if i < 5: # Assuming rate limit is 5 requests
            success_message = page.locator(".success-message")
            expect(success_message).to_be_visible()
            expect(success_message).to_have_text("Your message has been sent successfully!")
            # Clear form for next submission (if your form doesn't clear automatically)
            page.reload() # Or clear fields directly
        else:
            # For the 6th request onwards, expect a rate limit error
            error_message = page.locator(".error-message.api-error") # Adjust selector for API error message
            expect(error_message).to_be_visible(timeout=10000) # Give more time for API response
            expect(error_message).to_have_text(/.*Rate limit exceeded.*/)
            break # Stop after hitting the limit

# How to run `test_contact_form.py`:
# 1. Ensure your website is running at `http://localhost:8000` (or update `BASE_URL`).
# 2. Ensure your backend API has rate limiting enabled for the contact endpoint.
# 3. Navigate to the `pharma_tests` directory in your terminal.
# 4. Run: `pytest tests/test_contact_form.py`
```