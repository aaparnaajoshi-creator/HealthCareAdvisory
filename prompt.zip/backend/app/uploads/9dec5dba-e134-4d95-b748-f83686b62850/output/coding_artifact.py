```
pharmacorpsite/
├── backend/
│   ├── app/
│   │   ├── __init__.py
│   │   ├── main.py
│   │   ├── database.py
│   │   ├── models.py
│   │   ├── schemas.py
│   │   ├── crud.py
│   │   ├── dependencies.py
│   │   └── config.py
│   ├── tests/
│   │   ├── __init__.py
│   │   └── test_api.py
│   ├── Dockerfile
│   └── requirements.txt
├── frontend/
│   ├── public/
│   │   ├── index.html
│   │   ├── css/
│   │   │   └── style.css
│   │   ├── js/
│   │   │   ├── main.js
│   │   │   ├── router.js
│   │   │   ├── api.js
│   │   │   ├── components/
│   │   │   │   ├── header.js
│   │   │   │   ├── footer.js
│   │   │   │   └── cookieConsent.js
│   │   │   ├── pages/
│   │   │   │   ├── home.js
│   │   │   │   ├── aboutUs.js
│   │   │   │   ├── productsList.js
│   │   │   │   ├── productDetail.js
│   │   │   │   ├── contactUs.js
│   │   │   │   ├── privacyPolicy.js
│   │   │   │   ├── termsOfUse.js
│   │   │   │   └── searchResults.js
│   │   │   └── utils.js
│   ├── tests/
│   │   └── frontend.test.js
│   ├── Dockerfile
│   └── package.json
├── database/
│   └── init.sql
└── README.md