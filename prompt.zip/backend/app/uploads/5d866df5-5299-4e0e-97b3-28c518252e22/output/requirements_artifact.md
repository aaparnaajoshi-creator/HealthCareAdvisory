# Epic: Patient Enrollment Automation

**Description:** To streamline the patient onboarding process by developing an automated integration that securely captures new patient enrollment data from a portal, validates it, and creates a corresponding record in the core Healthcare Patient Database.

---

### User Story 1: Successful Patient Record Creation via API

**ID:** US-101
**Title:** Successful Patient Record Creation via API
**As a:** Healthcare Administrator,
**I want:** a new patient's enrollment form data to be automatically and securely processed and saved into the Patient Management Database,
**so that:** patient records are created efficiently and accurately without manual data entry.

**Acceptance Criteria:**

*   **Given** a new patient enrollment form is submitted from the Patient Enrollment Portal
*   **And** the API call includes a valid JWT token for authentication
*   **When** the Patient Management API receives the HTTPS POST request at the `/patients` endpoint
*   **Then** the API must validate the request and the JWT token.
*   **And** the API must transform the incoming JSON payload, mapping the source fields to the target database schema as follows:
    *   `Patient Full Name` → `patient_name`
    *   `Patient ID` (system-generated) → `patient_id`
    *   `Date of Birth` → `dob`
    *   `Gender` → `gender`
    *   `Address` → `address_line1`
    *   `City` → `city`
    *   `State/Region` → `state`
    *   `Postal Code` → `postal_code`
    *   `Phone Number` → `contact_phone`
    *   `Insurance Policy Number` → `insurance_id`
*   **And** a new record with the mapped data must be successfully inserted into the `Patients` table in the Healthcare Patient DB.
*   **And** the API must return a `201 Created` HTTP status code to the portal.
*   **And** the response body must contain the newly created `patient_id`.

---

### User Story 2: Handle Failed Patient Record Creation

**ID:** US-102
**Title:** Handle Failed Patient Record Creation
**As an:** IT Support Engineer,
**I want:** to be notified immediately via email when a patient record fails to be created in the database,
**so that:** I can investigate and resolve the issue promptly to ensure data integrity.

**Acceptance Criteria:**

*   **Given** the Patient Management API receives a valid request to create a new patient
*   **When** the database insertion operation fails for any reason (e.g., database is unavailable, data validation constraint fails, duplicate `patient_id`)
*   **Then** the system must trigger the global error handler.
*   **And** the failure event must be logged with a unique transaction ID, error details, and a timestamp.
*   **And** an email notification must be automatically sent to the configured "Healthcare IT Support" distribution list.
*   **And** the email subject line must be: `CRITICAL ALERT: Patient Enrollment Failure`.
*   **And** the email body must contain the transaction ID, timestamp, and a clear error message (e.g., "Database connection failed," "Duplicate key violation").
*   **And** the email body and system logs must NOT contain any sensitive Protected Health Information (PHI).
*   **And** the API must return an appropriate server-side error code (e.g., `500 Internal Server Error`, `503 Service Unavailable`) to the calling portal.

---

### User Story 3: Secure API Endpoint with Authentication

**ID:** US-103
**Title:** Secure API Endpoint with Authentication
**As an:** IT Security Officer,
**I want:** the Patient Management API endpoint to be secured,
**so that:** only authorized source systems can submit patient data, protecting patient privacy and data integrity.

**Acceptance Criteria:**

*   **Given** the Patient Management API is deployed and running
*   **When** a request is sent to the API endpoint with a valid, unexpired JWT token in the authorization header
*   **Then** the API must validate the token and allow the request to be processed.
*   ---
*   **Given** the Patient Management API is deployed and running
*   **When** a request is sent to the API endpoint with an invalid, malformed, or expired JWT token
*   **Then** the API must reject the request.
*   **And** the API must return a `401 Unauthorized` HTTP status code.
*   **And** the request must not be processed further.
*   ---
*   **Given** the Patient Management API is deployed and running
*   **When** a request is sent to the API endpoint without a JWT token
*   **Then** the API must reject the request.
*   **And** the API must return a `401 Unauthorized` HTTP status code.

---

### User Story 4: Secure Logging and Data Masking

**ID:** US-104
**Title:** Secure Logging and Data Masking
**As an:** IT Compliance Officer,
**I want:** all API transaction logs to mask sensitive patient data,
**so that:** we can perform system diagnostics and troubleshooting while remaining compliant with PHI regulations.

**Acceptance Criteria:**

*   **Given** any transaction (successful or failed) is processed by the Patient Management API
*   **When** the system writes an entry to the log files
*   **Then** the log entry must include a transaction ID and timestamp for traceability.
*   **And** any field identified as PHI (e.g., `insurance_id`, `patient_name`, `dob`, `address`) within the logged payload must be masked.
*   **Example Masking:**
    *   `"insurance_id": "********5678"`
    *   `"patient_name": "J*** S****"`
*   **And** the log entry for a successful transaction must clearly indicate success.
*   **And** the log entry for a failed transaction must include the non-sensitive error details and stack trace.