# PharmaCorp Website Testing Document

## 1. Test Strategy

**1.1 Scope:** This document outlines the testing strategy for the PharmaCorp website, encompassing functional, performance, security, accessibility, and regression testing.  The scope includes all user stories outlined in the Software Requirements Specification (SRS) and covers both frontend and backend functionalities.

**1.2 Objectives:**

* Verify that the website meets all functional requirements specified in the SRS.
* Ensure the website performs efficiently under various load conditions.
* Identify and mitigate security vulnerabilities.
* Confirm the website's accessibility for users with disabilities.
* Establish a robust regression testing process to prevent regressions during future development cycles.

**1.3 Testing Types:**

* **Functional Testing:** Verify that all features and functionalities work as expected.  This includes unit, integration, and end-to-end testing.
* **Performance Testing:** Evaluate website speed, scalability, and stability under different load conditions.  This includes load testing and stress testing.
* **Security Testing:** Identify and mitigate potential security vulnerabilities, such as cross-site scripting (XSS), SQL injection, and cross-site request forgery (CSRF).
* **Accessibility Testing:** Ensure the website meets WCAG 2.2 AA accessibility guidelines.  This includes both automated testing and manual review.
* **Regression Testing:** Verify that new code changes do not introduce regressions into existing functionalities.
* **Usability Testing:** (Future Consideration) Evaluate the ease of use and user experience of the website.


## 2. Test Plan

**2.1 Test Environment:**

* **Development Environment:**  Used for initial testing and debugging.
* **Staging Environment:**  A replica of the production environment used for final testing before deployment.
* **Production Environment:**  Live website environment.

**2.2 Test Data:**  Test data will include realistic user inputs, product information, and contact form submissions.  Sensitive data will be anonymized or masked.

**2.3 Test Schedule:**

| Phase             | Duration (Days) | Activities                                                                |
|----------------------|-----------------|----------------------------------------------------------------------------|
| Test Planning       | 2                | Define test strategy, create test cases, set up test environment            |
| Test Case Development | 3                | Develop and review manual and automated test cases                          |
| Test Execution       | 7                | Execute test cases, log defects, and track progress                       |
| Defect Resolution   | 3                | Address and retest identified defects                                     |
| Regression Testing  | 2                | Execute regression tests to ensure no new defects were introduced           |
| Sign-off            | 1                | Final review and approval of test results                                |
| **Total**           | **18**           |                                                                            |


**2.4 Test Cases:**

**User Story 1: Home Page Access**

| Test Case ID | Description                                        | Steps                                                                                                 | Expected Result                                                                          |
|--------------|----------------------------------------------------|------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------|
| TC_Home_001  | Home page load time                               | Access the home page. Measure the Largest Contentful Paint (LCP).                                | LCP < 2.5 seconds                                                                            |
| TC_Home_002  | Responsive design (desktop)                        | Access the home page on a desktop browser.                                                          | Page renders correctly.                                                                       |
| TC_Home_003  | Responsive design (tablet)                         | Access the home page on a tablet emulator/device.                                                   | Page renders correctly.                                                                       |
| TC_Home_004  | Responsive design (mobile)                        | Access the home page on a mobile emulator/device.                                                  | Page renders correctly.                                                                       |
| TC_Home_005  | WCAG 2.2 AA Compliance                             | Run automated accessibility tests (axe-core) and perform manual review.                            | No critical or major accessibility errors.                                                  |
| TC_Home_006  | Navigation links                                  | Verify navigation links to "About Us," "Products," and "Contact Us" are functional and visible. | Links navigate to the correct pages.                                                         |
| TC_Home_007  | Introduction and mission statement               | Verify the presence of a brief introduction to PharmaCorp and its mission.                       | Introduction and mission statement are present and clear.                                    |
| TC_Home_008  | Visually appealing design                          | Subjective assessment of visual appeal and informativeness.                                         | Design is visually appealing and informative.                                                 |


**User Story 2: Product Information Access**

| Test Case ID | Description                                                | Steps                                                                                                                        | Expected Result                                                                                                  |
|--------------|------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------|
| TC_Prod_001  | Product listing page display                              | Navigate to the product listing page.                                                                                       | All products are displayed with name, brief description, and image.                                                    |
| TC_Prod_002  | Product detail page display                              | Select a product from the listing page.                                                                                     | Product detail page displays comprehensive description, images, and a downloadable PI (Prescribing Information) PDF. |
| TC_Prod_003  | PI PDF download                                            | Download the PI PDF.                                                                                                        | PDF downloads successfully and opens correctly.                                                                        |
| TC_Prod_004  | Product page responsiveness (desktop, tablet, mobile)     | Access product pages on various devices.                                                                                     | Pages render correctly on all devices.                                                                                  |
| TC_Prod_005  | Product page WCAG 2.2 AA Compliance                      | Run automated accessibility tests (axe-core) and perform manual review.                                                   | No critical or major accessibility errors.                                                                            |
| TC_Prod_006  | Sticky ISI section                                         | Scroll down on the product detail page.                                                                                    | The ISI section remains visible while scrolling.                                                                       |


**User Story 3: About Us Page**

| Test Case ID | Description                               | Steps                                                                          | Expected Result                                                              |
|--------------|-------------------------------------------|------------------------------------------------------------------------------|-------------------------------------------------------------------------------|
| TC_About_001 | About Us page accessibility               | Access the "About Us" page via main navigation.                               | Page loads correctly.                                                        |
| TC_About_002 | About Us page content                    | Verify the content of the "About Us" page.                                   | Comprehensive information about PharmaCorp's history, mission, and values. |
| TC_About_003 | About Us page responsiveness             | Access the "About Us" page on various devices.                               | Page renders correctly on all devices.                                        |
| TC_About_004 | About Us page WCAG 2.2 AA Compliance     | Run automated accessibility tests (axe-core) and perform manual review.       | No critical or major accessibility errors.                                      |


**User Story 4: Contact Form**

| Test Case ID | Description                                     | Steps                                                                                                                               | Expected Result                                                                                                     |
|--------------|-------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------|
| TC_Contact_001 | Contact form submission                       | Submit a valid contact form.                                                                                                      | Form submission is successful, and a confirmation message is displayed.                                                   |
| TC_Contact_002 | Contact form data storage                     | Verify that the submitted data is stored in the PostgreSQL database.                                                              | Data is correctly stored in the database.                                                                                |
| TC_Contact_003 | Contact form responsiveness                   | Submit a contact form on various devices.                                                                                           | Form works correctly on all devices.                                                                                      |
| TC_Contact_004 | Contact form WCAG 2.2 AA Compliance           | Run automated accessibility tests (axe-core) and perform manual review.                                                          | No critical or major accessibility errors.                                                                                |
| TC_Contact_005 | Contact form input validation (missing fields) | Submit the form with missing fields.                                                                                             | Appropriate error messages are displayed for missing fields.                                                              |
| TC_Contact_006 | Contact form input validation (invalid email)  | Submit the form with an invalid email address.                                                                                     | Appropriate error message is displayed for invalid email format.                                                          |


**User Story 5: Search Functionality**

| Test Case ID | Description                                  | Steps                                                                                                       | Expected Result                                                                       |
|--------------|---------------------------------------------|------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------|
| TC_Search_001 | Search functionality                         | Perform various searches using different keywords.                                                        | Relevant search results are displayed.                                                   |
| TC_Search_002 | Search result format                          | Verify the format of search results.                                                                       | Results are displayed in a clear and user-friendly format.                               |
| TC_Search_003 | Search responsiveness                       | Perform searches on various devices.                                                                        | Search functionality works correctly on all devices.                                     |
| TC_Search_004 | Search WCAG 2.2 AA Compliance               | Run automated accessibility tests (axe-core) and perform manual review.                                      | No critical or major accessibility errors.                                            |
| TC_Search_005 | Search error handling (no results found)   | Perform a search with keywords that yield no results.                                                       | Appropriate message is displayed indicating no results found.                               |


**User Story 6: Privacy Policy and Terms of Use**

| Test Case ID | Description                                      | Steps                                                                                             | Expected Result                                                                     |
|--------------|---------------------------------------------------|--------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------|
| TC_Legal_001 | Privacy Policy and Terms of Use accessibility     | Access the "Privacy Policy" and "Terms of Use" pages from the footer.                               | Pages load correctly.                                                                  |
| TC_Legal_002 | Privacy Policy and Terms of Use content          | Review the content of the "Privacy Policy" and "Terms of Use" pages.                               | Content is clear, concise, and legally compliant.                                     |
| TC_Legal_003 | Privacy Policy and Terms of Use responsiveness  | Access the pages on various devices.                                                              | Pages render correctly on all devices.                                                |
| TC_Legal_004 | Privacy Policy and Terms of Use WCAG 2.2 AA Compliance | Run automated accessibility tests (axe-core) and perform manual review.                              | No critical or major accessibility errors.                                             |


**User Story 7: Newsletter Signup**

| Test Case ID | Description                                       | Steps                                                                                                                                 | Expected Result                                                                                                         |
|--------------|---------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------|
| TC_News_001 | Newsletter subscription                           | Subscribe to the newsletter using a valid email address.                                                                               | Confirmation email is received.                                                                                            |
| TC_News_002 | Newsletter unsubscription                          | Unsubscribe from the newsletter using the link in the confirmation email.                                                              | Unsubscription is successful.                                                                                             |
| TC_News_003 | Newsletter signup form responsiveness             | Subscribe to the newsletter on various devices.                                                                                       | Form works correctly on all devices.                                                                                         |
| TC_News_004 | Newsletter signup form WCAG 2.2 AA Compliance    | Run automated accessibility tests (axe-core) and perform manual review.                                                              | No critical or major accessibility errors.                                                                                 |
| TC_News_005 | Newsletter signup with invalid email address      | Attempt to subscribe with an invalid email address.                                                                                 | Appropriate error message is displayed.                                                                                     |


**User Story 8: Cookie Consent Banner**

| Test Case ID | Description                                    | Steps                                                                                                               | Expected Result                                                                                             |
|--------------|------------------------------------------------|--------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------|
| TC_Cookie_001 | Cookie consent banner display                   | Access the website and observe the cookie consent banner.                                                             | Cookie consent banner is displayed.                                                                        |
| TC_Cookie_002 | Cookie consent banner functionality (accept all) | Accept all cookies.                                                                                                    | Cookies are accepted, and the banner disappears.                                                            |
| TC_Cookie_003 | Cookie consent banner functionality (reject all) | Reject all cookies.                                                                                                    | Cookies are rejected, and the banner disappears.                                                            |
| TC_Cookie_004 | Cookie consent banner functionality (customize) | Customize cookie preferences.                                                                                              | User preferences are stored and respected across the website.                                                 |
| TC_Cookie_005 | Cookie consent banner responsiveness            | Access the website and observe the banner on various devices.                                                        | Banner renders correctly on all devices.                                                                   |
| TC_Cookie_006 | Cookie consent banner WCAG 2.2 AA Compliance   | Run automated accessibility tests (axe-core) and perform manual review.                                                  | No critical or major accessibility errors.                                                                  |
| TC_Cookie_007 | GDPR and CCPA Compliance                        | Verify that the implementation complies with GDPR and CCPA regulations (manual review and legal consultation required). | Implementation complies with GDPR and CCPA regulations.                                                        |


**2.5 Accessibility Testing Methods:**

* **Automated Testing:** axe-core will be used to scan web pages for accessibility violations.  This will be integrated into the CI/CD pipeline.
* **Manual Review:**  Accessibility experts will manually review the website to identify any issues not detected by automated tools.  This will focus on keyboard navigation, screen reader compatibility, and color contrast.

**2.6 Security Testing Approach:**

* **Static Application Security Testing (SAST):**  Tools like SonarQube will be used to analyze the codebase for potential vulnerabilities.
* **Dynamic Application Security Testing (DAST):**  Tools like OWASP ZAP will be used to scan the running application for vulnerabilities.
* **Penetration Testing:** (Future Consideration)  Professional penetration testers will be engaged to perform a more thorough security assessment.
* **Vulnerabilities to be tested:** XSS, SQL injection, CSRF, session management, authentication, authorization, and data protection.

**2.7 Regression Testing Strategy:**

* **Scope:**  All critical functionalities and user flows will be included in the regression test suite.  This includes all test cases from User Stories 1-8.
* **Frequency:** Regression tests will be run after each major code release and before deployment to the staging environment.
* **Automation:**  A significant portion of regression testing will be automated using Selenium and API testing frameworks (e.g., pytest with requests).


## 3. Automation Test Scripts (Python with Selenium and Requests)

These scripts are examples and may require adjustments based on the actual website implementation.

**Example: Test for Home Page Load Time (Python with Selenium)**

```python
import time
from selenium import webdriver
from selenium.webdriver.common.by import By

def test_home_page_load_time():
    driver = webdriver.Chrome()  # Or other webdriver
    driver.get("https://www.pharmacorp.com") # Replace with actual URL
    start_time = time.time()
    # Wait for page to load (adjust as needed)
    driver.implicitly_wait(10)
    end_time = time.time()
    load_time = end_time - start_time
    assert load_time < 2.5, f"Home page load time exceeded 2.5 seconds: {load_time} seconds"
    driver.quit()

```

**Example: Test for Contact Form Submission (Python with Requests)**

```python
import requests

def test_contact_form_submission():
    url = "https://www.pharmacorp.com/api/contact" # Replace with actual API endpoint
    data = {
        "name": "Test User",
        "email": "test@example.com",
        "message": "This is a test message."
    }
    response = requests.post(url, json=data)
    assert response.status_code == 200, f"Contact form submission failed: {response.status_code}"
    assert response.json()["status"] == "success", f"Contact form submission failed: {response.json()}"
```


## 4. Performance Testing Criteria

* **Target Response Times:**  Home page load time < 2.5 seconds, API call response times < 500ms (for most calls).
* **Load Testing:**  Simulate 100, 500, and 1000 concurrent users to assess website scalability.
* **Stress Testing:**  Simulate significantly higher loads than expected to determine the breaking point of the website.
* **Tools:**  JMeter or k6 will be used for performance testing.