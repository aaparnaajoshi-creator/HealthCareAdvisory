```markdown
## User Stories for Patient Enrollment Processing

### User Story 1: Patient Enrollment Submission Trigger

*   **As a** Patient Enrollment Portal
*   **I want to** submit a new patient enrollment form via an API endpoint
*   **So that** the patient's data can be securely processed and added to the healthcare database.

**Acceptance Criteria:**

*   **GIVEN** a new patient enrollment form is successfully completed on the Patient Enrollment Portal
*   **WHEN** the portal submits the form data to the dedicated API endpoint
*   **THEN** the API endpoint (accessible via HTTPS) must receive and acknowledge the request.
*   **AND** the API must validate the incoming request payload against the expected schema.
*   **AND** the API must authenticate the Patient Enrollment Portal using a valid JWT token.
*   **AND** all Protected Health Information (PHI) within the request payload must be encrypted in transit.
*   **AND** upon successful receipt and initial validation, the system must trigger the subsequent patient data processing flow.

### User Story 2: Patient Data Mapping and Transformation

*   **As a** System (MuleSoft API)
*   **I want to** accurately map and transform submitted patient enrollment data to the Healthcare Patient Database schema
*   **So that** the data is correctly formatted and ready for insertion into the `Patients` table.

**Acceptance Criteria:**

*   **GIVEN** a valid patient enrollment request payload is received
*   **WHEN** the system processes the payload for database insertion
*   **THEN** the system must map `Patient Full Name` from the form to `patient_name` in the database.
*   **AND** the system must map `Date of Birth` from the form to `dob` in the database.
*   **AND** the system must map `Gender` from the form to `gender` in the database.
*   **AND** the system must map `Address` from the form to `address_line1` in the database.
*   **AND** the system must map `City` from the form to `city` in the database.
*   **AND** the system must map `State/Region` from the form to `state` in the database.
*   **AND** the system must map `Postal Code` from the form to `postal_code` in the database.
*   **AND** the system must map `Phone Number` from the form to `contact_phone` in the database.
*   **AND** the system must map `Insurance Policy Number` from the form to `insurance_id` in the database.
*   **AND** the system must generate a unique `patient_id` for the new patient record.
*   **AND** any unmapped or unexpected fields in the input payload must be handled gracefully (e.g., ignored or logged without causing an error).

### User Story 3: New Patient Record Creation

*   **As a** System (MuleSoft API)
*   **I want to** insert a new, mapped patient record into the Healthcare Patient Database
*   **So that** new patients are officially registered and their information is securely stored for healthcare operations.

**Acceptance Criteria:**

*   **GIVEN** patient data has been successfully mapped and transformed (as per US2)
*   **WHEN** the system attempts to persist the data
*   **THEN** a new record must be successfully inserted into the `Patients` table in the target database.
*   **AND** the `patient_id` field in the new record must contain the system-generated unique identifier.
*   **AND** all mapped fields (patient_name, dob, gender, address_line1, city, state, postal_code, contact_phone, insurance_id) must be correctly populated in the new record.
*   **AND** the database connection must utilize securely stored credentials for authentication.

### User Story 4: Database Insertion Failure Notification & Logging

*   **As a** System (MuleSoft API)
*   **I want to** log any database insertion failures and notify IT support
*   **So that** operational issues with patient data persistence can be quickly identified, diagnosed, and resolved.

**Acceptance Criteria:**

*   **GIVEN** an attempt to insert a new patient record into the database occurs
*   **WHEN** the database insertion fails due to the target database being unavailable
*   **THEN** the failure must be logged with a timestamp and relevant error details.
*   **AND** an email notification must be sent to the configured `Healthcare IT support group`.
*   **WHEN** the database insertion fails due to a data validation error (e.g., invalid data type, missing required field)
*   **THEN** the failure must be logged with a timestamp and relevant error details.
*   **AND** an email notification must be sent to the configured `Healthcare IT support group`.
*   **WHEN** the database insertion fails due to a constraint violation (e.g., a duplicate patient_id, if not system-generated robustly, or other unique constraint)
*   **THEN** the failure must be logged with a timestamp and relevant error details.
*   **AND** an email notification must be sent to the configured `Healthcare IT support group`.
*   **AND** all logs containing sensitive patient data (e.g., Insurance ID) must mask or redact that information.
*   **AND** email notifications must *not* contain sensitive patient data, only operational error details.