import React, { useState, useEffect } from 'react';
import {
    Typography,
    Container,
    Grid,
    Card,
    CardContent,
    CardMedia,
    Button,
    Box,
    TextField,
    InputLabel,
    MenuItem,
    FormControl,
    Select,
} from '@mui/material';
import { Link } from 'react-router-dom';
import axios from 'axios';

const ProductList = () => {
    const [products, setProducts] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [therapeuticAreaFilter, setTherapeuticAreaFilter] = useState('');
    const [productTypeFilter, setProductTypeFilter] = useState('');

    useEffect(() => {
        const fetchProducts = async () => {
            try {
                const response = await axios.get('/api/products');
                setProducts(response.data);
            } catch (error) {
                console.error('Error fetching products:', error);
            }
        };

        fetchProducts();
    }, []);

    const handleSearchChange = (event) => {
        setSearchTerm(event.target.value);
    };

    const handleTherapeuticAreaFilterChange = (event) => {
        setTherapeuticAreaFilter(event.target.value);
    };

    const handleProductTypeFilterChange = (event) => {
        setProductTypeFilter(event.target.value);
    };

    const filteredProducts = products.filter((product) => {
        const searchRegex = new RegExp(searchTerm, 'i');
        const matchesSearch = searchRegex.test(product.name) || searchRegex.test(product.description);

        const matchesTherapeuticArea =
            therapeuticAreaFilter === '' || product.therapeutic_area === therapeuticAreaFilter;
        const matchesProductType = productTypeFilter === '' || product.product_type === productTypeFilter;

        return matchesSearch && matchesTherapeuticArea && matchesProductType;
    });

    const therapeuticAreas = [...new Set(products.map((product) => product.therapeutic_area))];
    const productTypes = [...new Set(products.map((product) => product.product_type))];

    return (
        <Container>
            <Typography variant="h4" component="h2" gutterBottom>
                Our Products
            </Typography>

            <Box sx={{ display: 'flex', gap: 2, mb: 3, flexDirection: { xs: 'column', md: 'row' } }}>
                <TextField
                    label="Search Products"
                    variant="outlined"
                    fullWidth
                    value={searchTerm}
                    onChange={handleSearchChange}
                />

                <FormControl fullWidth>
                    <InputLabel id="therapeutic-area-filter-label">Therapeutic Area</InputLabel>
                    <Select
                        labelId="therapeutic-area-filter-label"
                        id="therapeutic-area-filter"
                        value={therapeuticAreaFilter}
                        label="Therapeutic Area"
                        onChange={handleTherapeuticAreaFilterChange}
                    >
                        <MenuItem value="">All</MenuItem>
                        {therapeuticAreas.map((area) => (
                            <MenuItem key={area} value={area}>
                                {area}
                            </MenuItem>
                        ))}
                    </Select>
                </FormControl>

                <FormControl fullWidth>
                    <InputLabel id="product-type-filter-label">Product Type</InputLabel>
                    <Select
                        labelId="product-type-filter-label"
                        id="product-type-filter"
                        value={productTypeFilter}
                        label="Product Type"
                        onChange={handleProductTypeFilterChange}
                    >
                        <MenuItem value="">All</MenuItem>
                        {productTypes.map((type) => (
                            <MenuItem key={type} value={type}>
                                {type}
                            </MenuItem>
                        ))}
                    </Select>
                </FormControl>
            </Box>

            <Grid container spacing={3}>
                {filteredProducts.map((product) => (
                    <Grid item xs={12} sm={6} md={4} key={product.id}>
                        <Card>
                            <CardMedia component="img" height="140" image={product.image_url} alt={product.name} />
                            <CardContent>
                                <Typography variant="h6" component="div">
                                    {product.name}
                                </Typography>
                                <Typography variant="body2" color="text.secondary">
                                    {product.description}
                                </Typography>
                                <Box mt={2}>
                                    <Button component={Link} to={`/products/${product.id}`} variant="contained">
                                        Learn More
                                    </Button>
                                </Box>
                            </CardContent>
                        </Card>
                    </Grid>
                ))}
            </Grid>
        </Container>
    );
};

export default ProductList;