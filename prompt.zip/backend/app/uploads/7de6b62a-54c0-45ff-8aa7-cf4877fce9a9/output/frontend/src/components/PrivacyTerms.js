import React, { useState, useEffect } from 'react';
import { Typography, Container } from '@mui/material';
import axios from 'axios';

const PrivacyTerms = () => {
    const [content, setContent] = useState('');

    useEffect(() => {
        const fetchPrivacyTermsContent = async () => {
            try {
                const response = await axios.get('/api/content-pages/privacy-terms');
                setContent(response.data.content);
            } catch (error) {
                console.error('Error fetching Privacy & Terms content:', error);
                setContent('Failed to load Privacy & Terms content.');
            }
        };

        fetchPrivacyTermsContent();
    }, []);

    return (
        <Container>
            <Typography variant="h4" component="h2" gutterBottom>
                Privacy Policy and Terms of Use
            </Typography>
            <div dangerouslySetInnerHTML={{ __html: content }} />
        </Container>
    );
};

export default PrivacyTerms;