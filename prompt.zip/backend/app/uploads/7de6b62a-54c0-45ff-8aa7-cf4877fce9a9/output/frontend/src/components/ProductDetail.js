import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import {
    Typography,
    Container,
    Grid,
    Paper,
    Button,
    Box,
    styled,
    useTheme,
    useMediaQuery,
} from '@mui/material';
import axios from 'axios';

const ProductDetail = () => {
    const { id } = useParams();
    const [product, setProduct] = useState(null);
    const [sticky, setSticky] = useState(false);
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

    useEffect(() => {
        const fetchProduct = async () => {
            try {
                const response = await axios.get(`/api/products/${id}`);
                setProduct(response.data);
            } catch (error) {
                console.error('Error fetching product:', error);
            }
        };

        fetchProduct();
    }, [id]);

    useEffect(() => {
        const handleScroll = () => {
            if (window.scrollY > 200) {
                setSticky(true);
            } else {
                setSticky(false);
            }
        };

        window.addEventListener('scroll', handleScroll);

        return () => {
            window.removeEventListener('scroll', handleScroll);
        };
    }, []);

    const ISISection = styled(Paper)(({ theme }) => ({
        padding: theme.spacing(2),
        backgroundColor: theme.palette.background.default,
        position: sticky ? 'fixed' : 'static',
        top: sticky ? (isMobile ? '56px' : '64px') : 'auto', // Adjust top value based on AppBar height
        width: '100%',
        zIndex: 1000,
        transition: 'top 0.2s ease-in-out',
    }));

    if (!product) {
        return <Typography>Loading...</Typography>;
    }

    return (
        <Container>
            <Grid container spacing={3}>
                <Grid item xs={12} md={8}>
                    <Typography variant="h4" component="h2" gutterBottom>
                        {product.name}
                    </Typography>
                    <img src={product.image_url} alt={product.name} style={{ width: '100%', marginBottom: '16px' }} />
                    <Typography variant="body1">{product.description}</Typography>
                </Grid>
                <Grid item xs={12} md={4}>
                    <ISISection elevation={3}>
                        <Typography variant="h6" gutterBottom>
                            Important Safety Information
                        </Typography>
                        <Typography variant="body2">
                            This is the Important Safety Information. Please consult the full Prescribing Information
                            for complete details.
                        </Typography>
                    </ISISection>
                    <Box mt={2}>
                        <Button variant="contained" color="primary" href={product.pi_pdf_url} target="_blank">
                            Download PI PDF
                        </Button>
                    </Box>
                </Grid>
            </Grid>
        </Container>
    );
};

export default ProductDetail;