import React, { useState } from 'react';
import { TextField, Button, Typography, Box } from '@mui/material';
import axios from 'axios';

const NewsletterSignup = () => {
    const [email, setEmail] = useState('');
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');

    const handleSubmit = async (event) => {
        event.preventDefault();
        setMessage('');
        setError('');

        try {
            const response = await axios.post('/api/newsletter-signups', { email });
            if (response.status === 200) {
                setMessage('Successfully signed up for the newsletter! Please check your email to confirm.');
                setEmail('');
            } else {
                setError('Failed to sign up. Please try again.');
            }
        } catch (err) {
            console.error('Signup error:', err);
            setError('Failed to sign up. Please check your email and try again.');
        }
    };

    return (
        <Box component="form" onSubmit={handleSubmit} sx={{ mt: 3, textAlign: 'center' }}>
            <Typography variant="h6" gutterBottom>
                Sign up for our Newsletter
            </Typography>
            {message && (
                <Typography variant="body2" color="success.main" sx={{ mb: 1 }}>
                    {message}
                </Typography>
            )}
            {error && (
                <Typography variant="body2" color="error.main" sx={{ mb: 1 }}>
                    {error}
                </Typography>
            )}
            <TextField
                label="Email Address"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                margin="normal"
                variant="outlined"
                sx={{ width: '100%', maxWidth: '300px' }}
            />
            <Button type="submit" variant="contained" color="primary" sx={{ mt: 2 }}>
                Subscribe
            </Button>
        </Box>
    );
};

export default NewsletterSignup;