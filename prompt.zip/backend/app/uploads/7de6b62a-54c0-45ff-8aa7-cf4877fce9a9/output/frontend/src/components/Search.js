import React, { useState, useEffect, useRef } from 'react';
import { TextField, List, ListItem, ListItemText, Paper, ClickAwayListener } from '@mui/material';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import Fuse from 'fuse.js';

const Search = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const [searchResults, setSearchResults] = useState([]);
    const [open, setOpen] = useState(false);
    const navigate = useNavigate();
    const anchorRef = useRef(null);
    const [contentPages, setContentPages] = useState([]);

    useEffect(() => {
        const fetchContentPages = async () => {
            try {
                const response = await axios.get('/api/content-pages');
                setContentPages(response.data);
            } catch (error) {
                console.error('Error fetching content pages:', error);
            }
        };

        fetchContentPages();
    }, []);

    const fuse = new Fuse(contentPages, {
        keys: ['title', 'content'],
        threshold: 0.3,
    });

    const handleSearchChange = (event) => {
        const { value } = event.target;
        setSearchTerm(value);

        if (value) {
            const results = fuse.search(value).map((result) => result.item);
            setSearchResults(results);
            setOpen(true);
        } else {
            setSearchResults([]);
            setOpen(false);
        }
    };

    const handleResultClick = (slug) => {
        navigate(`/content/${slug}`);
        setSearchTerm('');
        setSearchResults([]);
        setOpen(false);
    };

    const handleClose = (event) => {
        if (anchorRef.current && anchorRef.current.contains(event.target)) {
            return;
        }

        setOpen(false);
    };

    return (
        <div>
            <TextField
                inputRef={anchorRef}
                size="small"
                label="Search"
                variant="outlined"
                value={searchTerm}
                onChange={handleSearchChange}
                onClick={() => {
                    if (contentPages.length > 0) {
                        setOpen(true);
                    }
                }}
                onBlur={(event) => {
                    if (!event.currentTarget.contains(event.relatedTarget)) {
                        setOpen(false);
                    }
                }}
            />
            {open && (
                <ClickAwayListener onClickAway={handleClose}>
                    <Paper
                        sx={{
                            position: 'absolute',
                            width: 200,
                            mt: 1,
                            zIndex: 1,
                        }}
                    >
                        <List>
                            {searchResults.length > 0 ? (
                                searchResults.map((page) => (
                                    <ListItem
                                        button
                                        key={page.id}
                                        onClick={() => handleResultClick(page.slug)}
                                        component={Link}
                                        to={`/content/${page.slug}`}
                                    >
                                        <ListItemText primary={page.title} />
                                    </ListItem>
                                ))
                            ) : (
                                <ListItem>
                                    <ListItemText primary="No results found" />
                                </ListItem>
                            )}
                        </List>
                    </Paper>
                </ClickAwayListener>
            )}
        </div>
    );
};

export default Search;