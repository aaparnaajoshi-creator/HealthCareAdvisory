import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, Link, useLocation } from 'react-router-dom';
import { AppBar, Toolbar, IconButton, Typography, Box, Container, Button } from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import Home from './components/Home';
import AboutUs from './components/AboutUs';
import ProductList from './components/ProductList';
import ProductDetail from './components/ProductDetail';
import ContactUs from './components/ContactUs';
import PrivacyTerms from './components/PrivacyTerms';
import Search from './components/Search';
import CookieConsent from './components/CookieConsent';
import NewsletterSignup from './components/NewsletterSignup';
import Footer from './components/Footer';
import AccessibilitySettings from './components/AccessibilitySettings';
import './App.css';

const App = () => {
    const [menuOpen, setMenuOpen] = useState(false);
    const [isCookieConsentGiven, setIsCookieConsentGiven] = useState(localStorage.getItem('cookieConsent') === 'true');
    const [fontSize, setFontSize] = useState('16px');
    const [highContrast, setHighContrast] = useState(false);

    const handleCookieConsent = (consent) => {
        setIsCookieConsentGiven(consent);
        localStorage.setItem('cookieConsent', consent.toString());
    };

    const toggleMenu = () => {
        setMenuOpen(!menuOpen);
    };

    const closeMenu = () => {
        setMenuOpen(false);
    };

    const applyAccessibilitySettings = (newFontSize, newHighContrast) => {
        setFontSize(newFontSize);
        setHighContrast(newHighContrast);
    };

    useEffect(() => {
        document.body.style.fontSize = fontSize;
        if (highContrast) {
            document.body.classList.add('high-contrast');
        } else {
            document.body.classList.remove('high-contrast');
        }

        return () => {
            document.body.classList.remove('high-contrast');
        };
    }, [fontSize, highContrast]);

    return (
        <Router>
            <div className={`App ${highContrast ? 'high-contrast' : ''}`} style={{ fontSize: fontSize }}>
                <CookieConsent onConsent={handleCookieConsent} />
                <AppBar position="static">
                    <Toolbar>
                        <IconButton
                            size="large"
                            edge="start"
                            color="inherit"
                            aria-label="menu"
                            sx={{ mr: 2, display: { xs: 'block', md: 'none' } }}
                            onClick={toggleMenu}
                        >
                            <MenuIcon />
                        </IconButton>
                        <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                            PharmaCorp
                        </Typography>
                        <Box sx={{ display: { xs: 'none', md: 'flex' }, gap: 2 }}>
                            <Button color="inherit" component={Link} to="/">
                                Home
                            </Button>
                            <Button color="inherit" component={Link} to="/about">
                                About Us
                            </Button>
                            <Button color="inherit" component={Link} to="/products">
                                Products
                            </Button>
                            <Button color="inherit" component={Link} to="/contact">
                                Contact Us
                            </Button>
                            <Search />
                        </Box>
                    </Toolbar>
                </AppBar>

                <Box
                    sx={{
                        display: { xs: menuOpen ? 'block' : 'none', md: 'none' },
                        width: '100%',
                        bgcolor: 'primary.main',
                        textAlign: 'center',
                        padding: 2,
                    }}
                    onClick={closeMenu}
                >
                    <Button color="inherit" component={Link} to="/" sx={{ display: 'block', margin: 1 }}>
                        Home
                    </Button>
                    <Button color="inherit" component={Link} to="/about" sx={{ display: 'block', margin: 1 }}>
                        About Us
                    </Button>
                    <Button color="inherit" component={Link} to="/products" sx={{ display: 'block', margin: 1 }}>
                        Products
                    </Button>
                    <Button color="inherit" component={Link} to="/contact" sx={{ display: 'block', margin: 1 }}>
                        Contact Us
                    </Button>
                </Box>

                <Container>
                    <AccessibilitySettings applySettings={applyAccessibilitySettings} />
                    <Routes>
                        <Route path="/" element={<Home />} />
                        <Route path="/about" element={<AboutUs />} />
                        <Route path="/products" element={<ProductList />} />
                        <Route path="/products/:id" element={<ProductDetail />} />
                        <Route path="/contact" element={<ContactUs />} />
                        <Route path="/privacy-terms" element={<PrivacyTerms />} />
                        <Route path="/content/:slug" element={<ContentPage />} />
                        <Route path="/search" element={<SearchPage />} />
                    </Routes>
                </Container>
                <Footer>
                    <NewsletterSignup />
                </Footer>
            </div>
        </Router>
    );
};

const ContentPage = () => {
    const { slug } = useLocation();
    const [content, setContent] = useState(null);

    useEffect(() => {
        const fetchContent = async () => {
            try {
                const response = await fetch(`/api/content-pages${slug}`);
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                const data = await response.json();
                setContent(data);
            } catch (error) {
                console.error("Could not fetch content:", error);
                setContent({ title: "Error", content: "Failed to load content." });
            }
        };

        fetchContent();
    }, [slug]);

    if (!content) {
        return <Typography>Loading...</Typography>;
    }

    return (
        <Container>
            <Typography variant="h4" gutterBottom>
                {content.title}
            </Typography>
            <Typography dangerouslySetInnerHTML={{ __html: content.content }} />
        </Container>
    );
};

const SearchPage = () => {
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const searchTerm = searchParams.get('query');

    return (
        <Container>
            <Typography variant="h4" gutterBottom>
                Search Results for "{searchTerm}"
            </Typography>
            {/* Display search results here */}
        </Container>
    );
};

export default App;