import React, { useState, useEffect } from 'react';
import { Typography, Container } from '@mui/material';
import axios from 'axios';

const AboutUs = () => {
    const [content, setContent] = useState('');

    useEffect(() => {
        const fetchAboutUsContent = async () => {
            try {
                const response = await axios.get('/api/content-pages/about-us');
                setContent(response.data.content);
            } catch (error) {
                console.error('Error fetching About Us content:', error);
                setContent('Failed to load About Us content.');
            }
        };

        fetchAboutUsContent();
    }, []);

    return (
        <Container>
            <Typography variant="h4" component="h2" gutterBottom>
                About Us
            </Typography>
            <div dangerouslySetInnerHTML={{ __html: content }} />
        </Container>
    );
};

export default AboutUs;