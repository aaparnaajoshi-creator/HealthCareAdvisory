# PharmaCorp Commercial Website: Test Strategy & Plan

**Document Version:** 1.0
**Date:** 2023-10-27
**Author:** QA Automation Engineer

---

## 1. Test Strategy

### 1.1. Introduction
This document outlines the comprehensive testing strategy for the PharmaCorp Commercial Website. The strategy defines the scope, objectives, methodologies, and resources required to ensure the website meets the specified requirements (SRS), design specifications (HLD), and overall quality standards before its release.

### 1.2. Scope

#### 1.2.1. In-Scope Features
The testing will cover all functionalities defined in the user stories, including:
*   **Core Pages:** Homepage, About Us, Privacy Policy, Terms of Use.
*   **Product Information:** Product Listing Page, Product Detail Page, Sticky ISI, and PI PDF downloads.
*   **User Engagement:** Contact Us Form and Newsletter Signup.
*   **Site-wide Functionality:** Site Search, Cookie Consent Banner.
*   **Non-Functional Requirements:** Responsiveness, Accessibility (WCAG 2.2 AA), Performance (LCP < 2.5s), and Security (HTTPS, CSP, Rate Limiting).
*   **API Testing:** All backend API endpoints defined in the HLD will be tested for functionality, security, and performance.
*   **Database Testing:** Verification of data integrity for form submissions and content storage.

#### 1.2.2. Out-of-Scope Features
*   Internal Content Management System (CMS) administration interface.
*   Third-party marketing automation platforms and their internal workings.
*   Load and Stress testing beyond basic performance benchmarks.
*   Underlying cloud infrastructure configuration and provider-specific testing.

### 1.3. Test Objectives
*   To verify that all functional requirements outlined in the user stories are implemented correctly.
*   To ensure the website provides a seamless and intuitive user experience across supported devices and browsers.
*   To validate that the website meets specified performance, security, and accessibility standards.
*   To identify and report defects early in the development lifecycle.
*   To ensure the backend API functions as per the design contract and handles data securely and efficiently.
*   To build a robust suite of automated regression tests to ensure long-term quality and stability.

### 1.4. Testing Levels & Types

| Testing Type | Description | Approach & Tools |
| :--- | :--- | :--- |
| **Component/Unit Testing** | Testing individual frontend components and backend functions in isolation. | **Responsibility:** Development Team. <br/> **Tools:** Jest/Vitest (Frontend), Pytest (Backend). |
| **API Testing** | Testing the backend API endpoints directly to verify business logic, data validation, error handling, and security. | **Responsibility:** QA Team. <br/> **Tools:** Postman, Pytest with `requests` library. |
| **Integration Testing** | Testing the interaction between the frontend application, backend API, and the database. | **Responsibility:** QA & Dev Teams. <br/> **Tools:** Pytest, Selenium, Cypress. |
| **System (End-to-End) Testing** | Testing the complete, integrated system from the user's perspective, simulating real-world user flows. | **Responsibility:** QA Team. <br/> **Tools:** Selenium, Cypress. |
| **Cross-Browser/Device Testing** | Ensuring the website functions and displays correctly on various browsers (Chrome, Firefox, Safari) and devices (desktop, tablet, mobile). | **Responsibility:** QA Team. <br/> **Tools:** BrowserStack/Sauce Labs, Browser DevTools. |
| **Performance Testing** | Validating the website's speed, responsiveness, and stability. Focus on LCP metric. | **Responsibility:** QA Team. <br/> **Tools:** Google Lighthouse, WebPageTest. |
| **Accessibility Testing** | Verifying compliance with WCAG 2.2 AA standards. | **Responsibility:** QA Team. <br/> **Tools:** Axe DevTools, WAVE, Manual testing with screen readers (NVDA, VoiceOver). |
| **Security Testing** | Identifying and mitigating security vulnerabilities. | **Responsibility:** QA & Security Teams. <br/> **Tools:** OWASP ZAP, Browser DevTools (for checking headers like CSP), manual penetration testing. |
| **Regression Testing** | Re-running tests after code changes to ensure new features haven't broken existing functionality. | **Responsibility:** QA Team. <br/> **Tools:** Automated scripts using Selenium/Pytest. |

### 1.5. Test Environments
*   **Development:** Local developer machines for unit and component testing.
*   **Staging:** A production-like environment where all integration and system testing will be performed. This environment will be connected to a staging database.
*   **Production:** The live environment. Smoke testing will be performed here after each deployment.

### 1.6. Test Tools & Frameworks
*   **Test Management:** Jira, TestRail
*   **UI Automation:** Python with Selenium & Pytest
*   **API Testing:** Postman, Python with `requests`
*   **Performance:** Google Lighthouse
*   **Accessibility:** Axe DevTools
*   **CI/CD:** GitHub Actions / Jenkins

### 1.7. Entry & Exit Criteria

#### 1.7.1. Entry Criteria
*   Software Requirements Specification (SRS) and High-Level Design (HLD) are approved.
*   The test environment is stable and accessible.
*   A testable build is deployed to the Staging environment.
*   All unit tests have passed.

#### 1.7.2. Exit Criteria
*   All planned test cases have been executed.
*   100% of Critical and High severity defects are closed.
*   No more than 5% of Medium severity defects remain open (with a documented plan for resolution).
*   The automated regression suite passes with 95% success rate.
*   All NFRs (Performance, Accessibility, Security) have met their acceptance criteria.

---

## 2. Manual Test Cases

### Epic: Core Website Structure & Pages

| ID | User Story | Title | Preconditions | Test Steps | Expected Results | Priority | Type |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **PCW-TC-001** | US-1 | Verify Homepage Elements, Responsiveness, and Performance | User is on the website's homepage. | 1. Verify a prominent hero section is visible. <br/> 2. Verify the header contains links: Home, About Us, Products, Contact Us. <br/> 3. Scroll down and verify a "featured products or therapeutic areas" section is present. <br/> 4. Scroll to the bottom and verify the footer contains links: Privacy Policy, Terms of Use, Contact Us. <br/> 5. Resize browser to mobile, tablet, and desktop widths. <br/> 6. Use a performance tool (Lighthouse) to measure LCP. | 1. Hero section is clear and engaging. <br/> 2. All specified header links are present and clickable. <br/> 3. The featured products section is visible and contains content. <br/> 4. Footer and its links are present on all pages. <br/> 5. The layout adjusts correctly without breaking or overlapping content. <br/> 6. LCP is under 2.5 seconds. | High | Functional, UI, Performance |
| **PCW-TC-002** | US-2 | Verify About Us Page Content and Structure | User is on the website's homepage. | 1. Click the "About Us" link in the header. <br/> 2. Verify the page title is "About Us". <br/> 3. Verify the presence of sections for mission, history, and leadership. <br/> 4. Verify the standard header and footer are present. <br/> 5. Resize the browser to check responsiveness. | 1. User is navigated to the `/about-us` page. <br/> 2. Page title is correct. <br/> 3. Content sections are displayed as specified. <br/> 4. Header and footer are identical to the homepage. <br/> 5. The layout remains usable and well-formatted. | Medium | Functional, UI |
| **PCW-TC-003** | US-3 | Verify Legal & Compliance Page Navigation and Content | User is on any page with a footer. | 1. In the footer, click the "Privacy Policy" link. <br/> 2. Verify the page URL is `/privacy-policy` and it displays legal text. <br/> 3. Navigate back. <br/> 4. In the footer, click the "Terms of Use" link. <br/> 5. Verify the page URL is `/terms-of-use` and it displays legal text. <br/> 6. Check that content on both pages is well-formatted. | 1. User is taken to the correct page. <br/> 2. The URL and content are correct. <br/> 3. Navigation is successful. <br/> 4. User is taken to the correct page. <br/> 5. The URL and content are correct. <br/> 6. Text uses proper headings and paragraphs for readability. | High | Functional |

### Epic: Product Information

| ID | User Story | Title | Preconditions | Test Steps | Expected Results | Priority | Type |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **PCW-TC-004** | US-4 | Verify Product Listing Page | User is on the website's homepage. | 1. Click the "Products" link in the header. <br/> 2. Verify a grid/list of products is displayed. <br/> 3. For each product, verify it shows a name, image, and short description. <br/> 4. Click on a product entry. | 1. User is navigated to the `/products` page. <br/> 2. Products are displayed correctly. <br/> 3. All required elements are present for each product. <br/> 4. User is navigated to the corresponding Product Detail Page. | High | Functional |
| **PCW-TC-005** | US-5, US-6 | Verify Product Detail Page and Sticky ISI Behavior | User has navigated to a Product Detail Page. | 1. Verify the product name, images, and description are displayed. <br/> 2. Verify a prominent link to download the PI PDF is visible. <br/> 3. Scroll down the page. <br/> 4. If ISI content is long, hover/focus on the ISI container. <br/> 5. On a mobile viewport, scroll the page. <br/> 6. Using the keyboard, tab to the ISI container and use arrow keys. | 1. All product details are correct. <br/> 2. The link is present and clear. <br/> 3. The ISI container remains fixed ("sticky") in the viewport. <br/> 4. A vertical scrollbar appears, allowing the user to scroll within the container. <br/> 5. The sticky ISI does not obstruct main content and is readable. <br/> 6. The ISI container becomes focused and is scrollable using the keyboard. | High | Functional, UI |
| **PCW-TC-006** | US-7 | Verify PI PDF Download | User is on a Product Detail Page. | 1. Click the "Download PI" or "Full Prescribing Information" link. | 1. The associated PDF document opens in a new browser tab. <br/> 2. (Technical Verification) The PDF URL points to a secure object storage service (e.g., S3, Azure Blob) and not directly from the web server. | High | Functional |

### Epic: User Engagement & Communication

| ID | User Story | Title | Preconditions | Test Steps | Expected Results | Priority | Type |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **PCW-TC-007a** | US-8 | Verify Contact Us Form Submission and Validation | User is on the `/contact-us` page. | 1. Leave "Full Name" and "Message" fields blank and click "Submit". <br/> 2. Enter an invalid email format (e.g., "test@test") and click "Submit". <br/> 3. Fill out all required fields with valid data and click "Submit". <br/> 4. (Backend) Check the `contact_submissions` table in the database. | 1. Inline error messages appear for "Full Name" and "Message". <br/> 2. An inline error message appears for the "Email Address" field. <br/> 3. A success message ("Thank you for your message!") is displayed. <br/> 4. A new record exists with the submitted data. | High | Functional, API |
| **PCW-TC-007b** | US-8 | Verify Contact Us Form Server Error Handling | User is on the `/contact-us` page. The backend API is configured to return a 500 error for the `/contact` endpoint. | 1. Fill out all required fields with valid data. <br/> 2. Click "Submit". | 1. A user-friendly error message is displayed (e.g., "Sorry, something went wrong. Please try again later."). <br/> 2. The form data is not cleared. | High | Functional |
| **PCW-TC-008a** | US-9 | Verify Newsletter Signup Happy Path | User is on any page with a footer. | 1. In the footer, enter a valid email address into the newsletter field. <br/> 2. If present, check the consent checkbox. <br/> 3. Click "Subscribe". <br/> 4. (Backend) Check the `newsletter_subscriptions` table. | 1. A success message is displayed near the form. <br/> 2. The form submits successfully. <br/> 3. The email is not cleared from the field. <br/> 4. A new record exists with the submitted email and consent status. | Medium | Functional |
| **PCW-TC-008b** | US-9 | Verify Newsletter Signup Validation | User is on any page with a footer. | 1. Enter an invalid email (e.g., "invalid-email") and click "Subscribe". | 1. An inline error message is displayed. | Medium | Functional |
| **PCW-TC-008c** | US-9 | Verify Newsletter Signup GDPR/CCPA Consent | User is on any page with a footer. The site is configured for a GDPR region. | 1. Verify a consent checkbox is visible next to the email field. <br/> 2. Enter a valid email but leave the checkbox unchecked. <br/> 3. Click "Subscribe". | 1. The checkbox is present with appropriate text. <br/> 2. Submission is blocked, and an error message is shown indicating consent is required. | High | Functional, Legal |

### Epic: Site-wide Functionality & Compliance

| ID | User Story | Title | Preconditions | Test Steps | Expected Results | Priority | Type |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **PCW-TC-009a** | US-10 | Verify Site Search with Results | User is on any page with a header. | 1. Enter a known keyword (e.g., a product name) into the search bar and press Enter. <br/> 2. Verify the user is on the `/search` results page. <br/> 3. Verify the URL contains the query parameter (e.g., `/search?q=my-query`). <br/> 4. Verify a list of relevant results is displayed. <br/> 5. Click on a result link. | 1. The search is executed. <br/> 2. The user is navigated to the search results page. <br/> 3. The URL reflects the search query. <br/> 4. Each result shows a title, snippet, and link. <br/> 5. User is navigated to the correct page. | High | Functional |
| **PCW-TC-009b** | US-10 | Verify Site Search with No Results | User is on any page with a header. | 1. Enter a nonsensical string (e.g., "xyz123abc") into the search bar and press Enter. | 1. The user is navigated to the search results page. <br/> 2. A message is displayed: "No results found for 'xyz123abc'". | Medium | Functional |
| **PCW-TC-010** | US-11 | Verify Cookie Consent Banner Functionality | Clear all site cookies and cache. | 1. Visit the website for the first time. <br/> 2. Verify a cookie banner is displayed. <br/> 3. Check browser cookies. <br/> 4. Click "Accept All". <br/> 5. Verify the banner is dismissed. <br/> 6. Refresh the page. <br/> 7. Clear cookies again, revisit, and click "Reject All". <br/> 8. Check browser cookies. | 1. Banner appears. <br/> 2. Banner contains text, a link to Privacy Policy, and "Accept All", "Reject All", "Customize" buttons. <br/> 3. No non-essential cookies are set. <br/> 4. Analytics/marketing cookies are now set. <br/> 5. Banner is gone. <br/> 6. The banner does not reappear. <br/> 7. Banner is dismissed. <br/> 8. Only strictly necessary cookies are set. | High | Functional, Legal |
| **PCW-TC-011a** | US-12 | Verify Foundational Security - HTTPS Redirect | None. | 1. Navigate to the website using `http://` (e.g., `http://www.pharmacorp.com`). | 1. The browser is automatically redirected to the `https://` version of the site. <br/> 2. A padlock icon is visible in the address bar. | Critical | Security |
| **PCW-TC-011b** | US-12 | Verify Foundational Security - CSP Header | User is on any page of the website. | 1. Open Browser Developer Tools. <br/> 2. Go to the "Network" tab. <br/> 3. Refresh the page and select the main document request. <br/> 4. Inspect the "Response Headers" section. | 1. A `Content-Security-Policy` header is present. <br/> 2. The policy is restrictive and does not contain unsafe values like `'unsafe-inline'` or `'unsafe-eval'` for scripts. | High | Security |

---

## 3. Test Automation Scripts

This section provides sample automation scripts using Python, Selenium, and Pytest. The structure assumes a Page Object Model (POM) for maintainability.

### 3.1. Project Structure

```
/tests/
├── conftest.py
├── /pages/
│   ├── __init__.py
│   ├── base_page.py
│   ├── contact_us_page.py
│   ├── home_page.py
│   └── search_results_page.py
└── /test_suites/
    ├── test_contact_us.py
    └── test_search.py
requirements.txt
```

### 3.2. Dependencies (`requirements.txt`)
```
selenium==4.15.2
pytest==7.4.3
webdriver-manager==4.0.1
```

### 3.3. Setup (`conftest.py`)
```python
import pytest
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager

@pytest.fixture(scope="function")
def driver():
    """Sets up and tears down the WebDriver for each test function."""
    driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))
    driver.implicitly_wait(10)
    driver.maximize_window()
    yield driver
    driver.quit()
```

### 3.4. Page Objects

#### `pages/base_page.py`
```python
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class BasePage:
    """Base class for all page objects."""
    def __init__(self, driver: WebDriver):
        self.driver = driver
        self.base_url = "https://www.pharmacorp-example.com" # Replace with actual base URL

    def find_element(self, locator: tuple, timeout: int = 10) -> WebElement:
        """Finds and returns a web element."""
        return WebDriverWait(self.driver, timeout).until(EC.visibility_of_element_located(locator))

    def click(self, locator: tuple):
        """Clicks on a web element."""
        self.find_element(locator).click()

    def type_text(self, locator: tuple, text: str):
        """Types text into a web element."""
        element = self.find_element(locator)
        element.clear()
        element.send_keys(text)

    def get_text(self, locator: tuple) -> str:
        """Gets the text of a web element."""
        return self.find_element(locator).text
```

#### `pages/contact_us_page.py`
```python
from selenium.webdriver.common.by import By
from pages.base_page import BasePage

class ContactUsPage(BasePage):
    """Page object for the Contact Us page."""
    URL_PATH = "/contact-us"
    
    # Locators
    FULL_NAME_INPUT = (By.ID, "full-name")
    EMAIL_INPUT = (By.ID, "email")
    MESSAGE_INPUT = (By.ID, "message")
    SUBMIT_BUTTON = (By.CSS_SELECTOR, "button[type='submit']")
    SUCCESS_MESSAGE = (By.ID, "success-message")
    EMAIL_ERROR_MESSAGE = (By.ID, "email-error")

    def open(self):
        self.driver.get(self.base_url + self.URL_PATH)
    
    def submit_form(self, name: str, email: str, message: str):
        self.type_text(self.FULL_NAME_INPUT, name)
        self.type_text(self.EMAIL_INPUT, email)
        self.type_text(self.MESSAGE_INPUT, message)
        self.click(self.SUBMIT_BUTTON)

    def get_success_message(self) -> str:
        return self.get_text(self.SUCCESS_MESSAGE)

    def get_email_error_message(self) -> str:
        return self.get_text(self.EMAIL_ERROR_MESSAGE)
```

#### `pages/home_page.py`
```python
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from pages.base_page import BasePage

class HomePage(BasePage):
    """Page object for the Home page."""
    # Locators
    SEARCH_INPUT = (By.ID, "search-input")
    
    def open(self):
        self.driver.get(self.base_url)

    def perform_search(self, query: str):
        self.type_text(self.SEARCH_INPUT, query)
        self.find_element(self.SEARCH_INPUT).send_keys(Keys.RETURN)
```

### 3.5. Test Scripts

#### `test_suites/test_contact_us.py` (US-8)
```python
import pytest
from pages.contact_us_page import ContactUsPage

@pytest.mark.usefixtures("driver")
class TestContactUs:

    def test_successful_submission(self, driver):
        """
        Test Case PCW-TC-007a: Verifies successful form submission.
        """
        contact_page = ContactUsPage(driver)
        contact_page.open()
        
        contact_page.submit_form(
            name="John Doe",
            email="johndoe@example.com",
            message="This is a test message."
        )
        
        success_text = contact_page.get_success_message()
        assert "Thank you for your message!" in success_text, "Success message not found or incorrect."

    def test_invalid_email_validation(self, driver):
        """
        Test Case PCW-TC-007a: Verifies inline validation for an invalid email.
        """
        contact_page = ContactUsPage(driver)
        contact_page.open()

        contact_page.submit_form(
            name="Jane Doe",
            email="invalid-email",
            message="Another test message."
        )

        error_text = contact_page.get_email_error_message()
        assert "Please enter a valid email address" in error_text, "Email validation error not displayed."
```

#### `test_suites/test_search.py` (US-10)
```python
import pytest
from pages.home_page import HomePage
from pages.search_results_page import SearchResultsPage # Assume this page object exists

@pytest.mark.usefixtures("driver")
class TestSearch:

    def test_search_with_results(self, driver):
        """
        Test Case PCW-TC-009a: Verifies search functionality with expected results.
        """
        home_page = HomePage(driver)
        home_page.open()
        
        search_query = "Product A"
        home_page.perform_search(search_query)

        search_results_page = SearchResultsPage(driver)
        
        # 1. Verify URL contains the query parameter
        current_url = driver.current_url
        assert f"q={search_query.replace(' ', '+')}" in current_url, "Search query parameter is missing from URL."
        
        # 2. Verify results are displayed
        results_count = search_results_page.get_results_count()
        assert results_count > 0, "Search returned no results when some were expected."
        
        # 3. Verify the heading confirms the search
        heading = search_results_page.get_results_heading()
        assert search_query in heading, "Search query is not reflected in the results page heading."

    def test_search_with_no_results(self, driver):
        """
        Test Case PCW-TC-009b: Verifies the message for a search with no results.
        """
        home_page = HomePage(driver)
        home_page.open()

        search_query = "xyz123abc"
        home_page.perform_search(search_query)

        search_results_page = SearchResultsPage(driver)
        
        no_results_message = search_results_page.get_no_results_message()
        assert f"No results found for '{search_query}'" in no_results_message, "No results message is incorrect or not found."
```