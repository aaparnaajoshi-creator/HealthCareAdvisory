# High-Level Design (HLD) Document: CTMS Subject Enrollment to CDW Sync Service

**Project Name:** CTMS Subject Enrollment to CDW Sync API
**Version:** 1.0
**Date:** 2025-09-02

## 1. Introduction

This High-Level Design (HLD) document outlines the architecture for the CTMS Subject Enrollment to CDW Sync Service. The primary objective of this service is to facilitate the near real-time synchronization of new subject enrollment data from the Clinical Trial Management System (CTMS) to a central Clinical Data Warehouse (CDW). This will be achieved through a secure, event-driven integration developed on the MuleSoft Anypoint Platform.

The service will expose a robust HTTP webhook endpoint to receive enrollment events from the CTMS, ensuring data integrity, security, and compliance through strict validation, data transformation, and comprehensive error handling with notification capabilities.

## 2. Overall Architecture

The architecture centers around a MuleSoft System API deployed on CloudHub. This API acts as a secure intermediary, receiving subject enrollment events from the CTMS and pushing them into the Clinical Data Warehouse (CDW).

The core components and their interactions are as follows:

1.  **Clinical Trial Management System (CTMS):** The source system responsible for managing clinical trial subjects. It initiates the synchronization process by sending an HTTP POST request to the MuleSoft API's webhook endpoint upon a new subject enrollment.
2.  **MuleSoft Anypoint Platform (CloudHub):** The integration platform hosting the MuleSoft application.
    *   **MuleSoft Application (CTMS-CDW-Sync-API):** A Mule 4.4+ application deployed on CloudHub (0.1 vCores). It exposes an HTTP Listener endpoint, processes incoming requests, applies security, transforms data, and interacts with the CDW.
    *   **Anypoint Monitoring:** Provides centralized logging, monitoring, and alerting capabilities for the MuleSoft application, capturing transaction details and error information.
3.  **Clinical Data Warehouse (CDW) - PostgreSQL:** The target database where synchronized subject enrollment records are stored. The MuleSoft application connects to this database using the Database Connector to perform INSERT operations.
4.  **Email Service:** Used by the MuleSoft application via the Email Connector to send urgent notifications to the Clinical IT Support team in case of processing failures.

```mermaid
graph LR
    CTMS["Clinical Trial Management System (CTMS)"] -- HTTP POST /subject-enrollment --> CloudHub["MuleSoft Anypoint Platform (CloudHub)"]
    subgraph CloudHub
        MuleApp["MuleSoft Application (CTMS-CDW-Sync-API)"]
        AnypointMonitoring["Anypoint Monitoring"]
    end
    CloudHub --> AnypointMonitoring
    MuleApp -- JDBC --> PostgreSQL["Clinical Data Warehouse (CDW) - PostgreSQL"]
    MuleApp -- SMTP --> EmailService["Email Service (for Notifications)"]
```

## 3. Data Models

### 3.1. CTMS Subject Enrollment Payload (Incoming)

The CTMS will send subject enrollment data in a JSON format. Below is an example structure based on the user stories:

```json
{
  "subjectIdentifier": "SUB-001234",
  "protocolId": "PROT-XYZ-001",
  "siteId": "SITE-ABC-05",
  "enrollmentDate": "2023-10-26T10:30:00Z",
  "dateOfBirth": "1990-05-15",
  "sex": "Female",
  "additionalData": {
    "race": "Asian",
    "ethnicity": "Non-Hispanic or Latino",
    "studyArm": "Control Group"
  }
}
```

### 3.2. CDW `Subjects` Table Schema (Target)

The target `Subjects` table in the PostgreSQL-based Clinical Data Warehouse will have the following schema, designed to store the transformed CTMS subject data:

```sql
CREATE TABLE Subjects (
    subject_id VARCHAR(255) PRIMARY KEY,
    protocol_identifier VARCHAR(255) NOT NULL,
    clinical_site_id VARCHAR(255) NOT NULL,
    date_of_enrollment TIMESTAMP WITH TIME ZONE NOT NULL,
    subject_dob DATE NOT NULL,
    gender VARCHAR(50) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
```

**Mapping between CTMS Payload and CDW Schema:**

| CTMS Payload Field      | CDW Table Column      | Data Type (CDW)          | Notes                                     |
| :---------------------- | :-------------------- | :----------------------- | :---------------------------------------- |
| `subjectIdentifier`     | `subject_id`          | `VARCHAR(255)`           | Primary key                               |
| `protocolId`            | `protocol_identifier` | `VARCHAR(255)`           |                                           |
| `siteId`                | `clinical_site_id`    | `VARCHAR(255)`           |                                           |
| `enrollmentDate`        | `date_of_enrollment`  | `TIMESTAMP WITH TIME ZONE` | Requires format conversion                |
| `dateOfBirth`           | `subject_dob`         | `DATE`                   | Requires format conversion, PHI field     |
| `sex`                   | `gender`              | `VARCHAR(50)`            |                                           |
| *(Auto-generated)*      | `created_at`          | `TIMESTAMP WITH TIME ZONE` | Default to current timestamp on insertion |
| *(Auto-generated)*      | `updated_at`          | `TIMESTAMP WITH TIME ZONE` | Default to current timestamp on insertion |

## 4. API Endpoints

The MuleSoft System API will expose a single HTTP POST endpoint for receiving subject enrollment data. The API will be defined using RAML 1.0.

**Endpoint:** `/subject-enrollment`

*   **Method:** `POST`
*   **Description:** Receives subject enrollment data from the CTMS.
*   **Request Headers:**
    *   `Content-Type`: `application/json` (Mandatory)
    *   `X-API-KEY`: `[Secure API Key/Token]` (Mandatory for authentication)
*   **Request Body:** A JSON object conforming to the "CTMS Subject Enrollment Payload" structure defined in Section 3.1.
*   **Response (Success - 202 Accepted):**
    *   **Status:** `202 Accepted`
    *   **Body:**
        ```json
        {
          "message": "Subject enrollment data received for processing",
          "transactionId": "a1b2c3d4-e5f6-7890-1234-567890abcdef"
        }
        ```
*   **Response (Authentication Failure - 401 Unauthorized):**
    *   **Status:** `401 Unauthorized`
    *   **Body:**
        ```json
        {
          "message": "Unauthorized: Invalid or missing API Key"
        }
        ```
*   **Response (Bad Request - 400 Bad Request):**
    *   **Status:** `400 Bad Request`
    *   **Body:**
        ```json
        {
          "message": "Invalid request payload",
          "details": "..."
        }
        ```
*   **Response (Internal Server Error - 500 Internal Server Error):**
    *   **Status:** `500 Internal Server Error`
    *   **Body:**
        ```json
        {
          "message": "An internal error occurred during processing. Please contact support.",
          "transactionId": "a1b2c3d4-e5f6-7890-1234-567890abcdef"
        }
        ```

## 5. System Components & Design Details

The MuleSoft application will be designed as a single flow, orchestrating the steps from webhook reception to CDW insertion.

### 5.1. Webhook Listener

*   **Component:** HTTP Listener
*   **Configuration:** Configured to listen on the `/subject-enrollment` path for `POST` requests.
*   **Initial Action:** Upon receiving a request, a unique `transactionId` will be generated and logged to mark the start of the transaction.

### 5.2. Security (API Key Validation)

*   **Mechanism:** An API key/token will be required in the `X-API-KEY` header of incoming requests.
*   **Storage:** The valid API key will be stored securely in MuleSoft's `secure properties`.
*   **Validation Logic:** A custom validation step (e.g., using a Choice Router or a custom policy) will compare the incoming `X-API-KEY` with the stored value.
    *   **Success:** Processing continues.
    *   **Failure:** The request is rejected with a `401 Unauthorized` HTTP status, and the failed authentication attempt (including originating IP if available) is logged.

### 5.3. Data Transformation

*   **Component:** Transform Message
*   **Language:** DataWeave 2.0
*   **Logic:** Maps the incoming CTMS JSON payload to the CDW `Subjects` table schema. This includes:
    *   Renaming fields (e.g., `subjectIdentifier` to `subject_id`).
    *   Applying data type conversions (e.g., `enrollmentDate` string to `TIMESTAMP WITH TIME ZONE`, `dateOfBirth` string to `DATE`).
    *   Ensuring all mandatory fields are present and correctly formatted.

### 5.4. CDW Insertion

*   **Component:** Database Connector
*   **Configuration:** Configured for PostgreSQL, using JDBC connection details (username/password) stored in `secure properties`.
*   **Operation:** Performs an `INSERT` operation into the `Subjects` table using the transformed data.
*   **Success Handling:** Logs the successful insertion, including the CDW `subject_id` and the `transactionId`, and then logs the end of the transaction.
*   **Failure Handling:** If the insertion fails (e.g., due to database unavailability, connection errors, constraint violations, or data format errors), it triggers specific error handling as described in Section 5.5.

### 5.5. Error Handling

A robust error handling strategy will be implemented, combining specific error handling for database failures and a global error handler for all unhandled exceptions.

*   **Database Insertion Failure (Specific Error Handling):**
    *   **Trigger:** Any error occurring during the Database Connector's `INSERT` operation.
    *   **Logging:** The failure event, including the full error stack trace and the payload that caused the failure, will be logged to Anypoint Monitoring.
    *   **Notification:** An email notification will be sent to the configured Clinical IT Support team email address (via the Email Connector). The email will contain the `transactionId`, nature of the error, and relevant payload details.
    *   **Response:** The service will return a `500 Internal Server Error` to the CTMS.
    *   **Logging:** The end of the transaction will be logged, indicating failure.

*   **Global Error Handling:**
    *   **Trigger:** Any unhandled error occurring at any point in the flow (e.g., during webhook reception, authentication, transformation, or other unexpected issues).
    *   **Logging:** The full error stack trace and the relevant incoming payload (with PHI masked) will be logged to Anypoint Monitoring.
    *   **Notification:** An email notification will be sent to the Clinical IT Support team (via the Email Connector), including details of the error, the `transactionId`, and the time of the error.
    *   **Response:** The service will return a `500 Internal Server Error` to the CTMS.
    *   **Logging:** The end of the transaction will be logged, indicating a global failure.

### 5.6. Logging & Compliance

*   **Anypoint Monitoring:** All key events and errors will be logged to Anypoint Monitoring for centralized visibility and auditing.
*   **Transaction Logging:**
    *   Start of each webhook transaction (with `transactionId`).
    *   End of each webhook transaction (success or failure).
    *   Success/failure of database insertion.
*   **PHI Masking:**
    *   Any logging of the incoming CTMS payload or intermediate data containing Protected Health Information (PHI) will have the PHI fields masked (e.g., `Date of Birth` will be replaced with `***MASKED***` or a non-identifiable value).
    *   This will be implemented using DataWeave or a custom logging component to ensure compliance with privacy regulations. Non-PHI fields will be logged as-is.

### 5.7. Notifications

*   **Component:** Email Connector
*   **Purpose:** To send critical alerts to the Clinical IT Support team for database insertion failures and unhandled global errors.
*   **Configuration:** SMTP connection details will be stored in `secure properties`.
*   **Content:** Emails will include `transactionId`, error description, stack trace, and relevant payload information (PHI masked).

## 6. Security Considerations

*   **API Key Authentication:** Ensures only authorized CTMS systems can invoke the webhook. The key is stored in `secure properties`.
*   **Secure Properties:** All sensitive information (API keys, database credentials, email credentials) will be externalized and stored securely using MuleSoft's `secure properties` mechanism, preventing hardcoding and exposure.
*   **PHI Masking:** Crucial for maintaining patient privacy in logs, complying with regulations like HIPAA.
*   **HTTPS/TLS:** All communication between CTMS and the MuleSoft endpoint on CloudHub will be secured using HTTPS/TLS, which is standard for CloudHub deployments.
*   **Least Privilege:** Database connection will be configured with minimum necessary permissions (e.g., only `INSERT` on the `Subjects` table).

## 7. Monitoring & Alerting

*   **Anypoint Monitoring:** Will be the primary tool for monitoring the application's health, performance, and transaction logs. Custom alerts can be configured based on log patterns or error thresholds.
*   **Email Notifications:** Serve as a critical alerting mechanism for immediate notification of IT Support in case of processing failures.

## 8. Deployment Strategy

*   **Environment:** CloudHub
*   **Workers:** The application will be deployed on a single worker with 0.1 vCores, as specified. This configuration is suitable for the expected near real-time, event-driven workload with moderate volume.
*   **CI/CD:** A Continuous Integration/Continuous Deployment pipeline (not detailed in this HLD) would be used to automate deployment to CloudHub.

## 9. Data Flow Diagram

```mermaid
graph TD
    A[CTMS: New Subject Enrollment] --> B(HTTP POST /subject-enrollment);
    B --> C{MuleSoft API Gateway: HTTP Listener};
    C -- Generate transactionId --> D[Log: Transaction Start (Anypoint Monitoring)];
    C -- Request Header: X-API-KEY --> E{Security Policy: Validate API Key (Secure Properties)};
    E -- Valid Key --> F[Proceed to Processing];
    E -- Invalid Key --> G[Log: Auth Failure (Anypoint Monitoring)] & H{Return 401 Unauthorized};
    F --> I[DataWeave 2.0: Map & Transform Data];
    I -- Mask PHI for Logs --> J[Log: Masked Payload (Anypoint Monitoring)];
    J --> K{Database Connector: INSERT into CDW.Subjects (PostgreSQL)};
    K -- Success --> L[Log: DB Insert Success (Anypoint Monitoring)] & M{Return 202 Accepted};
    K -- Failure (DB Error) --> N[Log: DB Insert Failure (Anypoint Monitoring)] & O[Email Connector: Notify IT Support] & P{Return 500 Internal Server Error};
    L --> Q[Log: Transaction End Success (Anypoint Monitoring)];
    P --> R[Log: Transaction End Failure (Anypoint Monitoring)];
    H --> S[Log: Transaction End Failure (Anypoint Monitoring)];

    subgraph Global Error Handling
        T[Any Unhandled Error] --> U[Global Error Handler];
        U --> V[Log: Global Error (Anypoint Monitoring, Masked Payload)];
        U --> W[Email Connector: Notify IT Support];
        U --> X{Return 500 Internal Server Error};
        X --> R;
    end
```