```sql
-- path/to/db/schema.sql

-- Drop table if it exists to allow for clean re-creation during development/testing
DROP TABLE IF EXISTS customers CASCADE;

-- Create the customers table
CREATE TABLE customers (
    id BIGSERIAL PRIMARY KEY,
    hubspot_company_id BIGINT UNIQUE NOT NULL,
    company_name VARCHAR(255) NOT NULL,
    company_domain VARCHAR(255) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Index for efficient lookups on HubSpot Company ID
CREATE INDEX idx_customers_hubspot_company_id ON customers (hubspot_company_id);

-- Trigger to automatically update 'updated_at' on record modification (if updates were in scope, for future extension)
-- CREATE OR REPLACE FUNCTION update_updated_at_column()
-- RETURNS TRIGGER AS $$
-- BEGIN
--    NEW.updated_at = NOW();
--    RETURN NEW;
-- END;
-- $$ language 'plpgsql';
--
-- CREATE TRIGGER update_customer_updated_at
-- BEFORE UPDATE ON customers
-- FOR EACH ROW
-- EXECUTE FUNCTION update_updated_at_column();

-- Optional: Insert a dummy record for testing
-- INSERT INTO customers (hubspot_company_id, company_name, company_domain)
-- VALUES (12345, 'Test Company', 'testcompany.com');
```

```xml
<!-- pom.xml -->
<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/maven-v4_0_0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.company.hubspot</groupId>
    <artifactId>hubspot-customer-sync</artifactId>
    <version>1.0.0-SNAPSHOT</version>
    <packaging>mule-application</packaging>

    <name>hubspot-customer-sync</name>

    <properties>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <project.reporting.outputEncoding>UTF-8</project.reporting.outputEncoding>

        <app.runtime>4.4.0-20230220</app.runtime>
        <mule.extensions.version>1.9.0</mule.extensions.version>
        <mule.db.connector.version>1.16.0</mule.db.connector.version>
        <mule.email.connector.version>1.7.0</mule.email.connector.version>
        <mule.secure.properties.version>1.2.6</mule.secure.properties.version>
        <mule.http.connector.version>1.7.1</mule.http.connector.version>
        <mule.sockets.connector.version>1.2.2</mule.sockets.connector.version>
        <postgresql.driver.version>42.7.3</postgresql.driver.version>
        <app.name>hubspot-customer-sync</app.name>
    </properties>

    <build>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-clean-plugin</artifactId>
                <version>3.2.0</version>
            </plugin>
            <plugin>
                <groupId>org.mule.tools.maven</groupId>
                <artifactId>mule-maven-plugin</artifactId>
                <version>${mule.extensions.version}</version>
                <extensions>true</extensions>
                <configuration>
                    <sharedLibraries>
                        <sharedLibrary>
                            <groupId>org.postgresql</groupId>
                            <artifactId>postgresql</artifactId>
                        </sharedLibrary>
                    </sharedLibraries>
                    <classifier>mule-application</classifier>
                </configuration>
            </plugin>
        </plugins>
    </build>

    <dependencies>
        <dependency>
            <groupId>org.mule.connectors</groupId>
            <artifactId>mule-http-connector</artifactId>
            <version>${mule.http.connector.version}</version>
            <classifier>mule-plugin</classifier>
        </dependency>
        <dependency>
            <groupId>org.mule.connectors</groupId>
            <artifactId>mule-sockets-connector</artifactId>
            <version>${mule.sockets.connector.version}</version>
            <classifier>mule-plugin</classifier>
        </dependency>
        <dependency>
            <groupId>org.mule.connectors</groupId>
            <artifactId>mule-db-connector</artifactId>
            <version>${mule.db.connector.version}</version>
            <classifier>mule-plugin</classifier>
        </dependency>
        <dependency>
            <groupId>org.mule.modules</groupId>
            <artifactId>mule-secure-properties-connector</artifactId>
            <version>${mule.secure.properties.version}</version>
            <classifier>mule-plugin</classifier>
        </dependency>
        <dependency>
            <groupId>org.mule.connectors</groupId>
            <artifactId>mule-email-connector</artifactId>
            <version>${mule.email.connector.version}</version>
            <classifier>mule-plugin</classifier>
        </dependency>
        <dependency>
            <groupId>org.postgresql</groupId>
            <artifactId>postgresql</artifactId>
            <version>${postgresql.driver.version}</version>
        </dependency>
        <dependency>
            <groupId>org.mule.modules</groupId>
            <artifactId>mule-module-validation</artifactId>
            <version>2.0.0</version>
            <classifier>mule-plugin</classifier>
        </dependency>
    </dependencies>

    <repositories>
        <repository>
            <id>anypoint-exchange-v3</id>
            <name>Anypoint Exchange</name>
            <url>https://maven.anypoint.mulesoft.com/api/v3/maven</url>
            <layout>default</layout>
        </repository>
        <repository>
            <id>mulesoft-releases</id>
            <name>MuleSoft Releases Repository</name>
            <url>https://repository.mulesoft.org/releases/</url>
            <layout>default</layout>
        </repository>
    </repositories>

    <pluginRepositories>
        <pluginRepository>
            <id>mulesoft-releases</id>
            <name>MuleSoft Releases Repository</name>
            <url>https://repository.mulesoft.org/releases/</url>
            <layout>default</layout>
        </pluginRepository>
    </pluginRepositories>

</project>
```

```xml
<!-- src/main/mule/hubspot-customer-sync.xml -->
<?xml version="1.0" encoding="UTF-8"?>
<mule xmlns:email="http://www.mulesoft.org/schema/mule/email"
    xmlns:db="http://www.mulesoft.org/schema/mule/db"
    xmlns:secure-properties="http://www.mulesoft.org/schema/mule/secure-properties"
    xmlns:http="http://www.mulesoft.org/schema/mule/http"
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xmlns="http://www.mulesoft.org/schema/mule/core"
    xmlns:validation="http://www.mulesoft.org/schema/mule/validation"
    xsi:schemaLocation="http://www.mulesoft.org/schema/mule/core http://www.mulesoft.org/schema/mule/core/current/mule.xsd
http://www.mulesoft.org/schema/mule/http http://www.mulesoft.org/schema/mule/http/current/mule-http.xsd
http://www.mulesoft.org/schema/mule/secure-properties http://www.mulesoft.org/schema/mule/secure-properties/current/mule-secure-properties.xsd
http://www.mulesoft.org/schema/mule/db http://www.mulesoft.org/schema/mule/db/current/mule-db.xsd
http://www.mulesoft.org/schema/mule/email http://www.mulesoft.org/schema/mule/email/current/mule-email.xsd
http://www.mulesoft.org/schema/mule/validation http://www.mulesoft.org/schema/mule/validation/current/mule-validation.xsd">

    <flow name="hubspot-company-creation-webhook-flow" doc:id="10101010-1010-1010-1010-101010101010">
        <http:listener doc:name="HTTP Listener" doc:id="6c8b9d0b-2222-2222-2222-222222222222"
            config-ref="HTTP_Listener_config" path="/hubspot/company/created">
            <http:response statusCode="#[vars.httpStatus default 200]">
                <http:body>
                    <![CDATA[#[%dw 2.0
output application/json
---
{
    message: vars.responseMessage default "Webhook processed successfully",
    correlationId: correlationId
}]]]></http:body>
            </http:response>
            <http:error-response statusCode="#[vars.httpStatus default 500]">
                <http:body>
                    <![CDATA[#[%dw 2.0
output application/json
---
{
    message: vars.responseMessage default "An unexpected error occurred",
    details: error.description,
    correlationId: correlationId
}]]]></http:body>
            </http:error-response>
        </http:listener>

        <logger level="INFO" doc:name="Log Start Transaction" doc:id="f3c01c0b-3333-3333-3333-333333333333"
            message="[START] Received webhook for HubSpot company creation. Correlation ID: #[correlationId]" />

        <set-variable value="#[payload]" doc:name="Set Original Payload" doc:id="d9e8f7c6-4444-4444-4444-444444444444"
            variableName="originalPayload" />

        <logger level="INFO" doc:name="Log Inbound Payload" doc:id="e1a2b3c4-5555-5555-5555-555555555555"
            message="Inbound Payload (masked): #[write(Mule::p(payload, ['properties.*.newValue']), &quot;application/json&quot;)]" />

        <!-- User Story 2: Webhook Authenticity Validation -->
        <set-variable value="#[attributes.headers.'x-hubspot-signature']" doc:name="Set HubSpot Signature Header"
            doc:id="d7e8f9a0-6666-6666-6666-666666666666" variableName="hubspotSignature" />
        <set-variable value="#[attributes.method]" doc:name="Set HTTP Method" doc:id="c2d3e4f5-7777-7777-7777-777777777777"
            variableName="httpMethod" />
        <set-variable value="#[attributes.requestUri]" doc:name="Set Request URI" doc:id="a8b9c0d1-8888-8888-8888-888888888888"
            variableName="requestUri" />

        <try doc:name="Try - Signature Validation" doc:id="12345678-9999-9999-9999-999999999999">
            <raise-error doc:name="Raise Error if Signature Missing" doc:id="00000000-0000-0000-0000-000000000000"
                type="APP:SIGNATURE_MISSING"
                message="X-HubSpot-Signature header is missing. Cannot validate webhook authenticity."
                when="#[!vars.hubspotSignature?]" />

            <set-variable value="#[
                // Extract the actual signature value (remove 'sha256=')
                if (vars.hubspotSignature startsWith 'sha256=')
                    vars.hubspotSignature[('sha256=' as String).length to -1]
                else
                    vars.hubspotSignature
            ]" doc:name="Extract Raw Signature" doc:id="e1d2c3b4-aaaa-aaaa-aaaa-aaaaaaaaaaaa" variableName="rawHubspotSignature" />

            <set-variable value="#[
                // Construct the string to sign: AppSecret + HTTP_METHOD + URI + REQUEST_BODY
                p('hubspot.client.secret') ++ vars.httpMethod ++ vars.requestUri ++ write(vars.originalPayload, 'application/json')
            ]" doc:name="Set String to Sign" doc:id="f5e6d7c8-bbbb-bbbb-bbbb-bbbbbbbbbbbb" variableName="stringToSign" />

            <set-variable value="#[
                // Compute HMAC-SHA256
                crypto::HMACBinary(
                    vars.stringToSign,
                    p('hubspot.client.secret'),
                    'HmacSHA256'
                ) as String { encoding: 'hex' }
            ]" doc:name="Compute Signature" doc:id="a9b8c7d6-cccc-cccc-cccc-cccccccccccc" variableName="computedSignature" />

            <raise-error doc:name="Raise Error if Signature Invalid" doc:id="01010101-dddd-dddd-dddd-dddddddddddd"
                type="APP:INVALID_SIGNATURE"
                message="Webhook authenticity check failed: X-HubSpot-Signature does not match computed signature."
                when="#[vars.rawHubspotSignature != vars.computedSignature]" />

            <logger level="INFO" doc:name="Log Signature Valid" doc:id="fefefefe-eeee-eeee-eeee-eeeeeeeeeeee"
                message="Webhook authenticity validated successfully." />
            <error-handler>
                <on-error-continue enableNotifications="true" logException="true" doc:name="On Error Continue - Signature"
                    doc:id="11111111-2222-3333-4444-555555555555" type="APP:SIGNATURE_MISSING, APP:INVALID_SIGNATURE">
                    <set-variable value="401" doc:name="Set HTTP Status 401" doc:id="22222222-3333-4444-5555-666666666666"
                        variableName="httpStatus" />
                    <set-variable value="#[error.description]" doc:name="Set Response Message" doc:id="33333333-4444-5555-6666-777777777777"
                        variableName="responseMessage" />
                    <logger level="ERROR" doc:name="Log Signature Validation Error" doc:id="44444444-5555-6666-7777-888888888888"
                        message="[ERROR] Signature validation failed. Reason: #[error.description]" />
                </on-error-continue>
            </error-handler>
        </try>

        <!-- Only proceed if no signature error occurred -->
        <choice doc:name="Choice - Proceed if Signature Valid" doc:id="55555555-6666-7777-8888-999999999999">
            <when expression="#[!vars.httpStatus]">
                <!-- User Story 3: Inbound Payload Validation & Transformation -->
                <foreach collection="#[payload]" doc:name="For Each HubSpot Event" doc:id="d0d1d2d3-0101-0101-0101-010101010101"
                    counterVariable="eventIndex">
                    <set-variable value="#[payload]" doc:name="Set Current Event" doc:id="e0e1e2e3-0202-0202-0202-020202020202"
                        variableName="currentEvent" />

                    <logger level="INFO" doc:name="Log Processing Event" doc:id="f0f1f2f3-0303-0303-0303-030303030303"
                        message="Processing HubSpot event #[vars.currentEvent.objectId]" />

                    <try doc:name="Try - Payload Validation and Transformation" doc:id="a0a1a2a3-0404-0404-0404-040404040404">
                        <validation:is-not-null doc:name="Validate objectId" doc:id="b0b1b2b3-0505-0505-0505-050505050505"
                            value="#[vars.currentEvent.objectId]" message="Mandatory field 'objectId' is missing." />
                        <validation:is-not-null doc:name="Validate company name" doc:id="c0c1c2c3-0606-0606-0606-060606060606"
                            value="#[vars.currentEvent.properties.name.newValue]" message="Mandatory field 'properties.name.newValue' is missing." />
                        <validation:is-not-null doc:name="Validate company domain" doc:id="d0d1d2d3-0707-0707-0707-070707070707"
                            value="#[vars.currentEvent.properties.domain.newValue]" message="Mandatory field 'properties.domain.newValue' is missing." />

                        <set-variable value="#[vars.currentEvent.objectId]" doc:name="Set HubSpot Company ID"
                            doc:id="e0e1e2e3-0808-0808-0808-080808080808" variableName="hubspotCompanyId" />
                        <set-variable value="#[vars.currentEvent.properties.name.newValue]" doc:name="Set Company Name"
                            doc:id="f0f1f2f3-0909-0909-0909-090909090909" variableName="companyName" />

                        <logger level="INFO" doc:name="Log Payload Validated" doc:id="10111213-1010-1010-1010-101010101010"
                            message="Payload for HubSpot Company ID #[vars.hubspotCompanyId] validated successfully." />

                        <set-payload value="#[
                            {
                                hubspot_company_id: vars.currentEvent.objectId,
                                company_name: vars.currentEvent.properties.name.newValue,
                                company_domain: vars.currentEvent.properties.domain.newValue
                            }
                        ]" doc:name="Transform Payload to DB Schema" doc:id="20212223-1111-1111-1111-111111111111" />

                        <logger level="INFO" doc:name="Log Transformed Payload" doc:id="30313233-1212-1212-1212-121212121212"
                            message="Transformed payload for DB insertion: #[write(payload, &quot;application/json&quot;)]" />

                        <!-- User Story 4: Customer Record Creation in Internal DB -->
                        <db:insert doc:name="Insert Customer Record" doc:id="40414243-1313-1313-1313-131313131313"
                            config-ref="PostgreSQL_Database_Config">
                            <db:sql>
                                <![CDATA[INSERT INTO customers (hubspot_company_id, company_name, company_domain)
                                VALUES (:hubspot_company_id, :company_name, :company_domain)]]>
                            </db:sql>
                            <db:input-parameters>
                                <![CDATA[#[payload]]]>
                            </db:input-parameters>
                        </db:insert>

                        <logger level="INFO" doc:name="Log DB Insert Success" doc:id="50515253-1414-1414-1414-141414141414"
                            message="Successfully inserted customer record for HubSpot Company ID: #[vars.hubspotCompanyId] (Company Name: #[vars.companyName])." />

                        <error-handler>
                            <!-- Catch payload validation errors and DB errors for current event -->
                            <on-error-propagate enableNotifications="true" logException="true" doc:name="On Error Propagate - Event Processing"
                                doc:id="60616263-1515-1515-1515-151515151515"
                                type="VALIDATION:IS_NULL, DB:CONNECTIVITY, DB:QUERY_EXECUTION, MULE:TRANSFORMATION">
                                <!-- Set event-specific error details for global error handler -->
                                <set-variable value="#[vars.currentEvent.objectId]" doc:name="Set Error HubSpot ID"
                                    doc:id="70717273-1616-1616-1616-161616161616" variableName="errorHubspotId" />
                                <set-variable value="#[vars.companyName]" doc:name="Set Error Company Name"
                                    doc:id="80818283-1717-1717-1717-171717171717" variableName="errorCompanyName" />
                                <set-variable value="#[vars.currentEvent]" doc:name="Set Error Event Payload"
                                    doc:id="90919293-1818-1818-1818-181818181818" variableName="errorEventPayload" />
                            </on-error-propagate>
                        </error-handler>
                    </try>
                </foreach>
            </when>
        </choice>

        <logger level="INFO" doc:name="Log End Transaction" doc:id="a0a1a2a3-1919-1919-1919-191919191919"
            message="[END] Finished processing webhook transaction. Correlation ID: #[correlationId]" />

    </flow>

</mule>
```

```xml
<!-- src/main/mule/global-configs.xml -->
<?xml version="1.0" encoding="UTF-8"?>
<mule xmlns:email="http://www.mulesoft.org/schema/mule/email"
    xmlns:db="http://www.mulesoft.org/schema/mule/db"
    xmlns:secure-properties="http://www.mulesoft.org/schema/mule/secure-properties"
    xmlns:http="http://www.mulesoft.org/schema/mule/http"
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xmlns="http://www.mulesoft.org/schema/mule/core"
    xsi:schemaLocation="http://www.mulesoft.org/schema/mule/core http://www.mulesoft.org/schema/mule/core/current/mule.xsd
http://www.mulesoft.org/schema/mule/http http://www.mulesoft.org/schema/mule/http/current/mule-http.xsd
http://www.mulesoft.org/schema/mule/secure-properties http://www.mulesoft.org/schema/mule/secure-properties/current/mule-secure-properties.xsd
http://www.mulesoft.org/schema/mule/db http://www.mulesoft.org/schema/mule/db/current/mule-db.xsd
http://www.mulesoft.org/schema/mule/email http://www.mulesoft.org/schema/mule/email/current/mule-email.xsd">

    <!-- User Story 7: Secure Credential Management -->
    <secure-properties:config name="Secure_Properties_Config" doc:name="Secure Properties Config"
        doc:id="a0b1c2d3-1111-1111-1111-111111111111" file="config.yaml" key="${secure.key}" />

    <http:listener-config name="HTTP_Listener_config" doc:name="HTTP Listener config"
        doc:id="e4f5g6h7-2222-2222-2222-222222222222">
        <http:listener-connection host="0.0.0.0" port="${http.port}" />
    </http:listener-config>

    <db:config name="PostgreSQL_Database_Config" doc:name="PostgreSQL Database Config"
        doc:id="i8j9k0l1-3333-3333-3333-333333333333">
        <db:driver-connection driverClassName="org.postgresql.Driver"
            connectionUrl="${db.url}">
            <db:user value="${db.username}" />
            <db:password value="${db.password}" />
        </db:driver-connection>
    </db:config>

    <email:smtp-config name="Email_SMTP_Config" doc:name="Email SMTP Config"
        doc:id="m2n3o4p5-4444-4444-4444-444444444444">
        <email:smtp-connection host="${smtp.host}" port="${smtp.port}" user="${smtp.username}"
            password="${smtp.password}" />
    </email:smtp-config>

    <configuration-properties doc:name="Configuration properties" doc:id="f2a99d45-5555-5555-5555-555555555555"
        file="config.yaml" />

    <global-property name="app.name" value="hubspot-customer-sync" />

    <error-handler name="global-error-handler" doc:id="7d8e9f0a-6666-6666-6666-666666666666">
        <on-error-continue enableNotifications="true" logException="true" doc:name="On Error Continue"
            doc:id="0a1b2c3d-7777-7777-7777-777777777777">
            <logger level="ERROR" doc:name="Log Global Error Start" doc:id="e4f5g6h7-8888-8888-8888-888888888888"
                message="[GLOBAL ERROR HANDLER] Processing error: #[error.description]" />

            <set-variable value="#[now()]" doc:name="Set Timestamp" doc:id="i8j9k0l1-9999-9999-9999-999999999999"
                variableName="errorTimestamp" />
            <set-variable value="#[error.description]" doc:name="Set Error Message"
                doc:id="m2n3o4p5-aaaa-aaaa-aaaa-aaaaaaaaaaaa" variableName="errorMessage" />
            <set-variable value="#[error.detailedDescription]" doc:name="Set Error Details"
                doc:id="q6r7s8t9-bbbb-bbbb-bbbb-bbbbbbbbbbbb" variableName="errorDetails" />
            <set-variable value="#[error.errorType.identifier]" doc:name="Set Error Type"
                doc:id="u0v1w2x3-cccc-cccc-cccc-cccccccccccc" variableName="errorType" />

            <!-- User Story 5: Error Notification for Sync Failures -->
            <!-- Determine HTTP Status and Email Flag based on error type -->
            <choice doc:name="Error Type Choice" doc:id="y4z5a6b7-dddd-dddd-dddd-dddddddddddd">
                <when expression="#[error.errorType == APP:SIGNATURE_MISSING or error.errorType == APP:INVALID_SIGNATURE]">
                    <set-variable value="401" doc:name="Set HTTP Status 401" doc:id="e0e1e2e3-eeee-eeee-eeee-eeeeeeeeeeee"
                        variableName="httpStatus" />
                    <set-variable value="false" doc:name="Do Not Send Email" doc:id="f0f1f2f3-ffff-ffff-ffff-ffffffffffff"
                        variableName="sendEmailNotification" />
                    <set-variable value="Webhook signature validation failed. Please check the X-HubSpot-Signature header and client secret."
                        doc:name="Set Response Message" doc:id="10111213-1111-1111-1111-111111111111" variableName="responseMessage" />
                </when>
                <when expression="#[error.errorType == VALIDATION:IS_NULL]">
                    <set-variable value="400" doc:name="Set HTTP Status 400" doc:id="20212223-2222-2222-2222-222222222222"
                        variableName="httpStatus" />
                    <set-variable value="true" doc:name="Send Email" doc:id="30313233-3333-3333-3333-333333333333"
                        variableName="sendEmailNotification" />
                    <set-variable value="Inbound HubSpot payload is missing mandatory fields. Please check the payload structure."
                        doc:name="Set Response Message" doc:id="40414243-4444-4444-4444-444444444444" variableName="responseMessage" />
                </when>
                <otherwise>
                    <set-variable value="500" doc:name="Set HTTP Status 500" doc:id="50515253-5555-5555-5555-555555555555"
                        variableName="httpStatus" />
                    <set-variable value="true" doc:name="Send Email" doc:id="60616263-6666-6666-6666-666666666666"
                        variableName="sendEmailNotification" />
                    <set-variable value="An internal server error occurred during synchronization. An administrator has been notified."
                        doc:name="Set Response Message" doc:id="70717273-7777-7777-7777-777777777777" variableName="responseMessage" />
                </otherwise>
            </choice>

            <!-- Conditional Email Notification -->
            <choice doc:name="Choice - Send Email Notification" doc:id="80818283-8888-8888-8888-888888888888">
                <when expression="#[vars.sendEmailNotification]">
                    <logger level="INFO" doc:name="Log Sending Email Notification"
                        doc:id="90919293-9999-9999-9999-999999999999" message="Sending error notification email." />
                    <email:send doc:name="Send Error Notification Email" doc:id="a0a1a2a3-aaaa-aaaa-aaaa-aaaaaaaaaaaa"
                        config-ref="Email_SMTP_Config" fromAddress="${email.from}" toAddresses="${email.to}">
                        <email:subject>
                            <![CDATA[HubSpot Sync Failure: #[vars.errorType] for Company #[vars.errorHubspotId default 'N/A']]]>
                        </email:subject>
                        <email:body contentType="text/html">
                            <![CDATA[
                            <p><strong>HubSpot Company to Internal DB Sync Service - Error Notification</strong></p>
                            <p>An error occurred during the synchronization process.</p>
                            <ul>
                                <li><strong>Timestamp:</strong> #[vars.errorTimestamp]</li>
                                <li><strong>Error Type:</strong> #[vars.errorType]</li>
                                <li><strong>Error Message:</strong> #[vars.errorMessage]</li>
                                <li><strong>HubSpot Company ID:</strong> #[vars.errorHubspotId default 'N/A']</li>
                                <li><strong>Company Name:</strong> #[vars.errorCompanyName default 'N/A']</li>
                                <li><strong>Original Inbound Payload (masked):</strong><pre>#[write(Mule::p(vars.errorEventPayload default vars.originalPayload, ['properties.*.newValue']), &quot;application/json&quot;)]</pre></li>
                                <li><strong>Anypoint Monitoring Link:</strong> <a href="https://anypoint.mulesoft.com/runtimefabric/api/v1/organizations/YOUR_ORG_ID/applications/#[app.name]/logs?query=correlationId%3D#[correlationId]">View Logs in Anypoint Monitoring (replace YOUR_ORG_ID)</a></li>
                            </ul>
                            <p>Please investigate the logs for more details.</p>
                            <p>Full Error Stack Trace:<pre>#[error.stackTrace]</pre></p>
                            ]]>
                        </email:body>
                    </email:send>
                    <logger level="INFO" doc:name="Log Email Sent" doc:id="b0b1b2b3-bbbb-bbbb-bbbb-bbbbbbbbbbbb"
                        message="Error notification email sent successfully." />
                </when>
            </choice>

            <logger level="ERROR" doc:name="Log Global Error End" doc:id="c0c1c2c3-cccc-cccc-cccc-cccccccccccc"
                message="[GLOBAL ERROR HANDLER] Finished processing error. Responding with HTTP Status: #[vars.httpStatus]" />
        </on-error-continue>
    </error-handler>

</mule>
```

```yaml
# src/main/resources/config.yaml

http.port: 8081

# HubSpot Configuration
# The client secret should be securely encrypted.
# hubspot.client.secret: "encrypted_secret_value"

# PostgreSQL Database Configuration
# These credentials should be securely encrypted.
# db.url: "encrypted_db_url"
# db.username: "encrypted_db_username"
# db.password: "encrypted_db_password"

# Email Configuration for Error Notifications
# These credentials should be securely encrypted.
# smtp.host: "encrypted_smtp_host"
# smtp.port: "encrypted_smtp_port"
# smtp.username: "encrypted_smtp_username"
# smtp.password: "encrypted_smtp_password"
email.from: "noreply-hubspot-sync@company.com"
email.to: "salesops@company.com"

# Secure Properties Key (should be passed as environment variable 'secure.key' at runtime)
# secure.key: "YOUR_ENCRYPTION_KEY"
```

```yaml
# src/main/resources/secure-properties.yaml.example

# This file demonstrates how secure properties would look if encrypted.
# In a real deployment, you would encrypt your values using the MuleSoft Secure Configuration Properties tool
# and then add them to your config.yaml or a separate secure properties file.
# The encryption key should be passed as an environment variable (e.g., secure.key).

# Example of encrypted properties (DO NOT USE THESE VALUES AS IS):
# hubspot.client.secret: "![v/L/lqC45Pz/N+Xk7Q9R0S1t2u3v4w5x6y7z8a9b0c1d2e3f4g5h6i7j8k9l0m1n2o3p4q5r6s7t7Vw=]"
# db.url: "![k/L/lqC45Pz/N+Xk7Q9R0S1t2u3v4w5x6y7z8a9b0c1d2e3f4g5h6i7j8k9l0m1n2o3p4q5r6s7t7Vw=]"
# db.username: "![m/L/lqC45Pz/N+Xk7Q9R0S1t2u3v4w5x6y7z8a9b0c1d2e3f4g5h6i7j8k9l0m1n2o3p4q5r6s7t7Vw=]"
# db.password: "![n/L/lqC45Pz/N+Xk7Q9R0S1t2u3v4w5x6y7z8a9b0c1d2e3f4g5h6i7j8k9l0m1n2o3p4q5r6s7t7Vw=]"
# smtp.host: "![o/L/lqC45Pz/N+Xk7Q9R0S1t2u3v4w5x6y7z8a9b0c1d2e3f4g5h6i7j8k9l0m1n2o3p4q5r6s7t7Vw=]"
# smtp.port: "![p/L/lqC45Pz/N+Xk7Q9R0S1t2u3v4w5x6y7z8a9b0c1d2e3f4g5h6i7j8k9l0m1n2o3p4q5r6s7t7Vw=]"
# smtp.username: "![q/L/lqC45Pz/N+Xk7Q9R0S1t2u3v4w5x6y7z8a9b0c1d2e3f4g5h6i7j8k9l0m1n2o3p4q5r6s7t7Vw=]"
# smtp.password: "![r/L/lqC45Pz/N+Xk7Q9R0S1t2u3v4w5x6y7z8a9b0c1d2e3f4g5h6i7j8k9l0m1n2o3p4q5r6s7t7Vw=]"
```

```xml
<!-- src/main/resources/application-types.xml -->
<?xml version='1.0' encoding='UTF-8'?>
<types:mule xmlns:types="http://www.mulesoft.org/schema/mule/types">
  <types:catalog>
    <types:type name="hubspotCompanyWebhook" format="json">
      <types:shape format="weave">
        <types:array>
          <types:items>
            <types:object>
              <types:property name="objectId" type="number" />
              <types:property name="properties">
                <types:object>
                  <types:property name="name">
                    <types:object>
                      <types:property name="newValue" type="string" />
                    </types:object>
                  </types:property>
                  <types:property name="domain">
                    <types:object>
                      <types:property name="newValue" type="string" />
                    </types:object>
                  </types:property>
                </types:object>
              </types:property>
            </types:object>
          </types:items>
        </types:array>
      </types:shape>
    </types:type>
    <types:type name="customerDbSchema" format="java">
      <types:shape format="weave">
        <types:object>
          <types:property name="hubspot_company_id" type="number" />
          <types:property name="company_name" type="string" />
          <types:property name="company_domain" type="string" />
        </types:object>
      </types:shape>
    </types:type>
  </types:catalog>
</types:mule>
```

```xml
<!-- src/main/resources/log4j2.xml -->
<?xml version="1.0" encoding="UTF-8"?>
<Configuration status="INFO">
    <Appenders>
        <Console name="Console" target="SYSTEM_OUT">
            <PatternLayout pattern="[%d{MM-dd HH:mm:ss.SSS}] %-5p %c{1} [%t]: %m%n" />
        </Console>
        <RollingFile name="file" fileName="${sys:mule.home}/logs/${sys:app.name}.log"
            filePattern="${sys:mule.home}/logs/${sys:app.name}-%i.log">
            <PatternLayout pattern="[%d{MM-dd HH:mm:ss.SSS}] %-5p %c{1} [%t]: %m%n" />
            <SizeBasedTriggeringPolicy size="10 MB" />
            <DefaultRolloverStrategy max="10" />
        </RollingFile>
    </Appenders>
    <Loggers>
        <!-- Http Logger shows wire traffic on DEBUG -->
        <AsyncLogger name="org.mule.service.http.impl.service.HttpMessageLogger" level="INFO" />
        <AsyncLogger name="org.mule.extension.http" level="INFO" />
        <AsyncLogger name="org.mule.runtime.core.internal.processor.LoggerMessageProcessor" level="INFO" />
        <AsyncLogger name="org.mule.extensions.db" level="INFO" />
        <AsyncLogger name="org.mmulesoft.connectors.email" level="INFO" />
        <AsyncLogger name="com.company.hubspot.hubspot-customer-sync" level="INFO" />

        <AsyncRoot level="INFO">
            <AppenderRef ref="Console" />
            <AppenderRef ref="file" />
        </AsyncRoot>
    </Loggers>
</Configuration>
```

```markdown
# README.md

## HubSpot Company to Customer DB Sync Service

This MuleSoft application synchronizes new company records created in HubSpot with an internal PostgreSQL customer database. It acts as a secure webhook listener, validates incoming requests, transforms data, and inserts it into the database.

### 1. Project Structure

```
hubspot-customer-sync/
├── pom.xml                                  - Maven Project Object Model, dependencies.
├── src/main/mule/
│   ├── hubspot-customer-sync.xml            - Main Mule flow for webhook processing.
│   ├── global-configs.xml                   - Global configurations (HTTP listener, DB, Email, Secure Properties).
│   └── global-error-handler.xml             - Centralized error handling logic.
├── src/main/resources/
│   ├── application-types.xml                - DataWeave types for payload validation/transformation.
│   ├── log4j2.xml                           - Logging configuration.
│   ├── config.yaml                          - Application configuration properties.
│   └── secure-properties.yaml.example       - Example for securely encrypted properties.
└── path/to/db/schema.sql                    - PostgreSQL database schema definition.
```

### 2. Setup Instructions

#### 2.1. Database Setup (PostgreSQL)

1.  **Install PostgreSQL:** Ensure you have a PostgreSQL database server running.
2.  **Create Database:** Create a new database for this service (e.g., `hubspot_customers_db`).
3.  **Run Schema Script:** Execute the `path/to/db/schema.sql` script against your new database to create the `customers` table:
    ```bash
    psql -U your_db_user -d hubspot_customers_db -f path/to/db/schema.sql
    ```

#### 2.2. MuleSoft Application Configuration

This application uses secure properties for sensitive credentials. You will need to encrypt these values.

1.  **Install Secure Configuration Properties Tool:**
    If you don't have it, download the `secure-properties-tool.jar` from MuleSoft's GitHub or Exchange.

2.  **Generate Encryption Key:**
    Decide on a strong encryption key. This key will be passed as an environment variable (`secure.key`) at runtime.

3.  **Encrypt Sensitive Properties:**
    For each sensitive property listed below, use the `secure-properties-tool.jar` to encrypt its value.
    Example encryption command (using AES/CBC mode):
    ```bash
    java -jar secure-properties-tool.jar string encrypt AES CBC <YOUR_ENCRYPTION_KEY> "plain_text_value"
    ```
    The tool will output an encrypted string like `![AES 128/CBC/PKCS5Padding]...`.

    The properties to encrypt are:
    *   `hubspot.client.secret`: Your HubSpot Private App's Client Secret.
    *   `db.url`: Your PostgreSQL JDBC URL (e.g., `jdbc:postgresql://localhost:5432/hubspot_customers_db`).
    *   `db.username`: Your PostgreSQL database username.
    *   `db.password`: Your PostgreSQL database password.
    *   `smtp.host`: Your SMTP server host.
    *   `smtp.port`: Your SMTP server port (e.g., 587 for TLS).
    *   `smtp.username`: Your SMTP username.
    *   `smtp.password`: Your SMTP password.

4.  **Update `config.yaml`:**
    Replace the commented-out lines in `src/main/resources/config.yaml` with the encrypted values.
    Example:
    ```yaml
    # src/main/resources/config.yaml
    http.port: 8081

    hubspot.client.secret: "![AES 128/CBC/PKCS5Padding]encrypted_hubspot_secret_value"
    db.url: "![AES 128/CBC/PKCS5Padding]encrypted_db_url_value"
    db.username: "![AES 128/CBC/PKCS5Padding]encrypted_db_username_value"
    db.password: "![AES 128/CBC/PKCS5Padding]encrypted_db_password_value"

    smtp.host: "![AES 128/CBC/PKCS5Padding]encrypted_smtp_host_value"
    smtp.port: "![AES 128/CBC/PKCS5Padding]encrypted_smtp_port_value"
    smtp.username: "![AES 128/CBC/PKCS5Padding]encrypted_smtp_username_value"
    smtp.password: "![AES 128/CBC/PKCS5Padding]encrypted_smtp_password_value"

    email.from: "noreply-hubspot-sync@company.com"
    email.to: "salesops@company.com"
    ```

5.  **Environment Variables:**
    When deploying or running the application, ensure the following environment variable is set:
    *   `secure.key`: The encryption key you used in step 2.
    *   `http.port`: The port the HTTP listener will bind to (e.g., `8081`). This can also be set directly in `config.yaml`.

#### 2.3. Build and Run the Application

1.  **Build with Maven:**
    Navigate to the project root directory (`hubspot-customer-sync/`) and run:
    ```bash
    mvn clean package
    ```
    This will create a deployable `.jar` file in the `target/` directory.

2.  **Run Locally (Mule Runtime):**
    You can deploy the generated `.jar` file to a local Mule Runtime, or run directly from Anypoint Studio.
    When running locally, ensure the environment variables (`secure.key`, `http.port`) are set.

3.  **Deploy to CloudHub:**
    Deploy the `.jar` file to CloudHub via Anypoint Platform. Ensure the `secure.key` and `http.port` (if not default) environment variables are configured in the CloudHub application settings. The `http.port` will typically be managed by CloudHub's ingress, so you might only need to set it if you want the internal listener to use a specific port.

### 3. HubSpot Webhook Configuration

1.  **Create a Private App in HubSpot:**
    *   Go to your HubSpot Developer account.
    *   Create a "Private App".
    *   Under "Auth", copy your "Secret". This is your `hubspot.client.secret`.
    *   Under "Scopes", grant necessary permissions (e.g., `crm.objects.companies.read` and `crm.objects.companies.write` might be useful for other operations, but for webhooks, only the secret is strictly needed for validation).

2.  **Configure Webhook in HubSpot:**
    *   In your HubSpot account, navigate to **Settings > Integrations > Webhooks**.
    *   Click "Create webhook".
    *   **Subscription Type:** Select `Company` for Object Type, and `Creation` for Event Type.
    *   **Target URL:** This will be your deployed Mule application's URL: `https://<cloudhub-app-domain>/api/hubspot/company/created` (replace `<cloudhub-app-domain>` with your CloudHub application's public URL).
    *   **Secret:** Paste the "Secret" from your Private App here. HubSpot will use this to generate the `X-HubSpot-Signature` header.
    *   Save the webhook.

### 4. Testing

1.  **Create a new Company in HubSpot:**
    Go to your HubSpot CRM and create a new company record. This should trigger the webhook.

2.  **Monitor Logs:**
    Check your MuleSoft application logs (Anypoint Monitoring or local console) for entries indicating:
    *   Webhook reception.
    *   Signature validation.
    *   Payload validation.
    *   Database insertion success/failure.

3.  **Check PostgreSQL Database:**
    Verify that the new company record has been inserted into the `customers` table in your PostgreSQL database.

4.  **Test Error Scenarios:**
    *   **Invalid Signature:** Send a POST request to the webhook endpoint with a deliberately incorrect `X-HubSpot-Signature` header or no header at all. You should receive a 401 response and see security error logs.
    *   **Invalid Payload:** Send a POST request with a HubSpot-like payload, but omit mandatory fields like `objectId`, `properties.name.newValue`, or `properties.domain.newValue`. You should receive a 400 response, an error email, and corresponding logs.
    *   **Database Error:** Temporarily stop your PostgreSQL database or intentionally break the DB connection string in `config.yaml`. Send a valid webhook. You should receive a 500 response, an error email, and detailed DB error logs.