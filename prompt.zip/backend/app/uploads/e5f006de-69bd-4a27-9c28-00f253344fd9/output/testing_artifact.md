```markdown
# HubSpot Company to Customer DB Sync Service - Testing Document

## 1. Test Strategy

### 1.1. Introduction
This document outlines the test strategy for the HubSpot Company to Customer DB Sync Service. The service, implemented as a MuleSoft System API, aims to securely synchronize new company records from HubSpot CRM to an internal PostgreSQL customer database. This strategy defines the scope, objectives, types of testing, and approach to ensure the quality, reliability, and security of the integration.

### 1.2. Scope of Testing

**In Scope:**
*   **Functional Requirements:** All User Stories (US1-US7) detailed in the Project Requirements (SRS) will be thoroughly tested. This includes:
    *   Webhook reception and processing.
    *   `X-HubSpot-Signature` validation.
    *   Inbound payload validation and transformation.
    *   Customer record creation in PostgreSQL.
    *   Error handling and notification mechanisms.
    *   Comprehensive logging.
    *   Secure credential management (verification of usage).
*   **Integration Points:**
    *   HubSpot webhook interaction.
    *   MuleSoft application logic.
    *   PostgreSQL database interaction.
    *   Email notification system.
    *   Anypoint Monitoring for logs.
*   **Non-Functional Requirements:**
    *   **Security:** Verification of `X-HubSpot-Signature` validation, secure credential usage, and HTTPS communication.
    *   **Error Handling & Resilience:** Robust error handling for various failure scenarios and proper notification.
    *   **Logging & Monitoring:** Verification of detailed and accurate logging to Anypoint Monitoring.
    *   **Performance (Basic):** Basic sanity checks for response times under expected load (not full-scale performance testing).

**Out of Scope:**
*   HubSpot CRM internal functionality and UI testing.
*   Extensive load, stress, or soak testing (a dedicated performance testing phase would cover this).
*   Penetration testing (a dedicated security audit would cover this).
*   Testing of the Anypoint Monitoring platform itself.
*   Testing of the Email System's internal functionality.
*   Client-side UI testing if any were to be built on top of the internal DB.

### 1.3. Objectives of Testing

The primary objectives of testing are to:
*   Ensure that the MuleSoft System API correctly receives and processes HubSpot webhook notifications for new company creations.
*   Verify that only authentic requests from HubSpot are processed, by rigorously validating the `X-HubSpot-Signature`.
*   Confirm that inbound HubSpot payloads are correctly validated for mandatory fields and transformed accurately into the internal PostgreSQL schema.
*   Guarantee that new customer records are successfully created in the PostgreSQL database with correct data.
*   Validate the robust error handling mechanism, ensuring appropriate responses, detailed logging, and timely email notifications for all sync failures.
*   Confirm the presence and correctness of comprehensive log entries in Anypoint Monitoring for auditing, monitoring, and troubleshooting.
*   Verify that sensitive credentials are securely managed and utilized by the application.
*   Identify and report any defects or deviations from the Project Requirements (SRS) and High-Level Design (HLD).

### 1.4. Testing Phases and Types

Testing will be conducted across various phases and types to ensure comprehensive coverage.

#### 1.4.1. Functional Testing
This is the core of the testing effort, focusing on validating that the system performs exactly as specified by the user stories and acceptance criteria.

*   **Positive Testing:** Verify that the system behaves as expected when valid inputs are provided and conditions are met (e.g., successful end-to-end sync).
*   **Negative Testing:** Verify that the system gracefully handles invalid inputs, missing data, or unexpected conditions (e.g., invalid signature, missing mandatory fields, duplicate DB entries).
*   **Data Validation Testing:** Ensure all inbound data is validated against defined rules and transformed correctly according to the specified data mappings.
*   **Error Handling Testing:** Validate that all error paths defined in US5 and HLD are correctly implemented, including appropriate HTTP responses, detailed logging, and email notifications.
*   **Integration Testing:** Focus on the interaction between the MuleSoft application and external systems (HubSpot, PostgreSQL, Email System, Anypoint Monitoring).

#### 1.4.2. Non-Functional Testing

*   **Security Testing:**
    *   **Authentication/Authorization:** Verify `X-HubSpot-Signature` validation logic.
    *   **Data Security:** Confirm secure credential management (US7) and masking of sensitive data in logs (US6).
    *   **Communication Security:** Ensure HTTPS is used for all external communications.
*   **Logging and Monitoring Testing:**
    *   Verify that all required log entries are generated at appropriate points (start, end, success, failure) as per US6.
    *   Confirm log accessibility and searchability in Anypoint Monitoring.
    *   Ensure sensitive data masking in logs.
*   **Performance Testing (Basic):**
    *   Conduct basic smoke tests to ensure the application responds within acceptable timeframes for single requests. Full-scale performance testing is out of scope for this initial phase.
*   **Resilience Testing:** Verify the system's ability to recover from errors and continue operating, primarily through the robust error handling and notification mechanisms.

### 1.5. Test Environment
A dedicated, isolated test environment will be configured to closely mimic the production environment. This will include:
*   A MuleSoft CloudHub environment for deploying the API.
*   A dedicated HubSpot Developer account or sandbox for generating webhook events.
*   A dedicated PostgreSQL database instance (or schema) for testing, identical to the production schema.
*   An email service configured to send notifications to a test recipient list.
*   Anypoint Monitoring enabled for the deployed Mule application.

### 1.6. Test Data Management
*   **HubSpot Data:** Test companies will be created in the HubSpot sandbox environment to trigger webhooks.
*   **PostgreSQL Data:** The test database will be initialized with a clean state before each test run or specific test scenarios. Test data will be generated to cover various scenarios (valid, invalid, duplicate).
*   **Sensitive Data:** All sensitive data (Client Secret, DB credentials) will be managed securely using environment variables or MuleSoft Secure Configuration Properties in the test environment, replicating production practices.

### 1.7. Roles and Responsibilities
*   **QA Automation Engineer:** Develop test strategy, create manual test cases, design and implement automation scripts, execute tests, analyze results, report defects.
*   **Developers:** Conduct unit testing, fix defects, support QA with environment setup and troubleshooting.
*   **DevOps/Platform Team:** Provide and maintain test environments, support deployment.
*   **Product Owner/Business Analyst:** Review test cases, participate in UAT, confirm requirements.

### 1.8. Entry and Exit Criteria

#### 1.8.1. Test Entry Criteria
*   All user stories and HLD are finalized and approved.
*   Test environment is fully set up and stable.
*   Test data is prepared and available.
*   Test cases and automation scripts are reviewed and approved.
*   Latest stable build of the MuleSoft application is deployed to the test environment.
*   All critical dependencies (HubSpot, PostgreSQL, Email) are accessible from the test environment.

#### 1.8.2. Test Exit Criteria
*   All high-priority (P1/P2) test cases (manual and automated) are executed with a pass rate of at least 95%.
*   All critical defects (severity 1 & 2) are resolved and retested.
*   Remaining open defects are documented, understood, and accepted by stakeholders.
*   All functional requirements are verified.
*   Non-functional requirements (security, logging, error handling) are validated.
*   Test summary report is generated and approved.

### 1.9. Tools
*   **API Testing:** Postman, curl (for manual), Python `requests` library (for automation).
*   **Database Testing:** `psql` client (for manual), Python `psycopg2` library (for automation).
*   **Automation Framework:** Python `pytest`.
*   **Version Control:** Git.
*   **Monitoring/Logging:** Anypoint Monitoring.
*   **Defect Management:** Jira or similar.

---

## 2. Manual Test Cases

This section details the manual test cases derived from the User Stories and High-Level Design.

**Assumptions:**
*   The MuleSoft API is deployed and accessible at `https://<MULESOFT_APP_DOMAIN>/api/hubspot/company/created`.
*   A valid HubSpot Client Secret is known for signature generation.
*   An email inbox for `salesops@company.com` is accessible for verification.
*   Anypoint Monitoring is accessible for log verification.
*   Direct access to the PostgreSQL database is available for data verification.

---

**Test Case ID:** TC_US1_001
**User Story:** US1: HubSpot Webhook Listener
**Test Case Name:** Verify Webhook Listener Successfully Receives Valid Request
**Preconditions:**
*   MuleSoft API is deployed and running.
*   Network connectivity allows POST requests to `https://<MULESOFT_APP_DOMAIN>/api/hubspot/company/created`.
*   A valid HubSpot Client Secret is available for signature generation.
**Steps:**
1.  Construct a valid HubSpot webhook payload for a new company creation (refer to HLD example).
2.  Calculate the `X-HubSpot-Signature` using the payload and the valid HubSpot Client Secret (HMAC-SHA256).
3.  Send a POST request to `https://<MULESOFT_APP_DOMAIN>/api/hubspot/company/created` with:
    *   `Content-Type: application/json`
    *   `X-HubSpot-Signature: <calculated_signature>`
    *   The constructed valid JSON payload as the request body.
4.  Observe the HTTP response.
5.  Check Anypoint Monitoring logs for "Received webhook for HubSpot Company ID: [ID]" and "Finished processing for HubSpot Company ID: [ID]".
**Expected Result:**
*   **THEN** The HTTP response status code is `200 OK`.
*   **AND** The Mule flow is triggered and processes the request.
*   **AND** Logs indicating the start and end of the transaction are visible in Anypoint Monitoring.

---

**Test Case ID:** TC_US2_001
**User Story:** US2: Webhook Authenticity Validation
**Test Case Name:** Verify Authenticity Validation with Valid Signature (Positive)
**Preconditions:**
*   MuleSoft API is deployed and running.
*   A valid HubSpot Client Secret is available.
*   A valid HubSpot webhook payload is prepared.
**Steps:**
1.  Construct a valid HubSpot webhook payload (e.g., for company ID 5001).
2.  Calculate the `X-HubSpot-Signature` using the payload and the **correct** HubSpot Client Secret.
3.  Send a POST request to the API with the payload and the calculated `X-HubSpot-Signature`.
4.  Observe the HTTP response.
5.  Check Anypoint Monitoring logs.
**Expected Result:**
*   **THEN** The HTTP response status code is `200 OK`.
*   **AND** The request proceeds to the next processing step (payload validation/transformation).
*   **AND** No security rejection logs are found for this transaction.

---

**Test Case ID:** TC_US2_002
**User Story:** US2: Webhook Authenticity Validation
**Test Case Name:** Verify Authenticity Validation with Invalid Signature (Negative)
**Preconditions:**
*   MuleSoft API is deployed and running.
*   A valid HubSpot Client Secret is available.
*   A valid HubSpot webhook payload is prepared.
**Steps:**
1.  Construct a valid HubSpot webhook payload (e.g., for company ID 5002).
2.  Calculate the `X-HubSpot-Signature` using the payload and an **incorrect/tampered** HubSpot Client Secret (or slightly alter the generated signature).
3.  Send a POST request to the API with the payload and the intentionally invalid `X-HubSpot-Signature`.
4.  Observe the HTTP response.
5.  Check Anypoint Monitoring logs.
**Expected Result:**
*   **THEN** The HTTP response status code is `401 Unauthorized` or `403 Forbidden`.
*   **AND** The response body contains an error message like `{ "message": "Invalid X-HubSpot-Signature" }`.
*   **AND** A detailed log entry for the rejected request (security error) is created in Anypoint Monitoring.
*   **AND** No further processing (payload validation, DB insertion) occurs for this request.

---

**Test Case ID:** TC_US2_003
**User Story:** US2: Webhook Authenticity Validation
**Test Case Name:** Verify Authenticity Validation with Missing Signature Header (Negative)
**Preconditions:**
*   MuleSoft API is deployed and running.
*   A valid HubSpot webhook payload is prepared.
**Steps:**
1.  Construct a valid HubSpot webhook payload (e.g., for company ID 5003).
2.  Send a POST request to the API with the payload, but **omit** the `X-HubSpot-Signature` header entirely.
3.  Observe the HTTP response.
4.  Check Anypoint Monitoring logs.
**Expected Result:**
*   **THEN** The HTTP response status code is `401 Unauthorized` or `403 Forbidden`.
*   **AND** The response body contains an error message indicating missing or invalid signature.
*   **AND** A detailed log entry for the rejected request is created in Anypoint Monitoring.
*   **AND** No further processing occurs for this request.

---

**Test Case ID:** TC_US3_001_TC_US4_001_TC_US6_001
**User Story:** US3: Inbound Payload Validation & Transformation, US4: Customer Record Creation, US6: Comprehensive Logging
**Test Case Name:** End-to-End Success Path: Valid Payload, Successful DB Insertion & Logging
**Preconditions:**
*   MuleSoft API is deployed and running.
*   A valid HubSpot Client Secret is available.
*   The target PostgreSQL database is accessible and the `customers` table is empty or does not contain the `hubspot_company_id` for the test data.
**Steps:**
1.  Construct a valid HubSpot webhook payload for a new company (e.g., Company ID: `5004`, Name: `TestCorp One`, Domain: `testcorp-one.com`).
2.  Calculate and include the correct `X-HubSpot-Signature`.
3.  Send a POST request to the API with the valid payload and signature.
4.  Observe the HTTP response.
5.  Query the `customers` table in the PostgreSQL database for the inserted record using `hubspot_company_id = 5004`.
6.  Check Anypoint Monitoring for log entries.
**Expected Result:**
*   **THEN** The HTTP response status code is `200 OK`.
*   **AND** A new record is successfully inserted into the `customers` table in PostgreSQL with:
    *   `hubspot_company_id` = `5004`
    *   `company_name` = `TestCorp One`
    *   `company_domain` = `testcorp-one.com`
    *   `created_at` and `updated_at` are populated.
*   **AND** Anypoint Monitoring logs show:
    *   "Received webhook for HubSpot Company ID: 5004"
    *   The inbound payload (masked if any sensitive data).
    *   "Database insertion successful for HubSpot Company ID: 5004, Internal Customer ID: [newly_generated_id]"
    *   "Finished processing for HubSpot Company ID: 5004"

---

**Test Case ID:** TC_US3_002_TC_US5_001_TC_US6_002
**User Story:** US3: Inbound Payload Validation, US5: Error Notification, US6: Comprehensive Logging
**Test Case Name:** Verify Payload Validation Failure (Missing Mandatory Field - `name`)
**Preconditions:**
*   MuleSoft API is deployed and running.
*   A valid HubSpot Client Secret is available.
*   Email inbox for `salesops@company.com` is accessible.
**Steps:**
1.  Construct a HubSpot webhook payload for a new company (e.g., Company ID: `5005`, Domain: `testcorp-two.com`), but **omit** the `properties.name` field.
2.  Calculate and include the correct `X-HubSpot-Signature`.
3.  Send a POST request to the API with the malformed payload and signature.
4.  Observe the HTTP response.
5.  Check the `customers` table in PostgreSQL.
6.  Check the email inbox for `salesops@company.com`.
7.  Check Anypoint Monitoring logs.
**Expected Result:**
*   **THEN** The HTTP response status code is `400 Bad Request`.
*   **AND** The response body indicates "Invalid payload: Missing mandatory fields", specifically referencing "name".
*   **AND** No record is inserted into the `customers` table for HubSpot Company ID `5005`.
*   **AND** An email notification is sent to `salesops@company.com` with:
    *   Timestamp of the error.
    *   A concise error message (e.g., "Missing mandatory field: name").
    *   HubSpot Company ID: `5005` (if extractable before error).
    *   A link to Anypoint Monitoring logs.
*   **AND** Anypoint Monitoring logs show:
    *   "Received webhook for HubSpot Company ID: 5005" (if extractable).
    *   Detailed error log including the reason for rejection and the original (masked) inbound payload.
    *   Full error stack trace.

---

**Test Case ID:** TC_US3_003
**User Story:** US3: Inbound Payload Validation
**Test Case Name:** Verify Payload Validation Failure (Missing Mandatory Field - `domain`)
**Preconditions:**
*   MuleSoft API is deployed and running.
*   A valid HubSpot Client Secret is available.
**Steps:**
1.  Construct a HubSpot webhook payload for a new company (e.g., Company ID: `5006`, Name: `TestCorp Three`), but **omit** the `properties.domain` field.
2.  Calculate and include the correct `X-HubSpot-Signature`.
3.  Send a POST request to the API with the malformed payload and signature.
4.  Observe the HTTP response.
5.  Check the `customers` table in PostgreSQL.
6.  Check the email inbox for `salesops@company.com`.
7.  Check Anypoint Monitoring logs.
**Expected Result:**
*   **THEN** The HTTP response status code is `400 Bad Request`.
*   **AND** The response body indicates "Invalid payload: Missing mandatory fields", specifically referencing "domain".
*   **AND** No record is inserted into the `customers` table for HubSpot Company ID `5006`.
*   **AND** An email notification is sent to `salesops@company.com` with relevant error details.
*   **AND** Anypoint Monitoring logs show detailed error for missing `domain` field.

---

**Test Case ID:** TC_US4_002_TC_US5_002
**User Story:** US4: Customer Record Creation, US5: Error Notification
**Test Case Name:** Verify DB Insertion Failure (Duplicate `hubspot_company_id`) and Error Notification
**Preconditions:**
*   MuleSoft API is deployed and running.
*   A valid HubSpot Client Secret is available.
*   A record with `hubspot_company_id = 5007` already exists in the `customers` table.
*   Email inbox for `salesops@company.com` is accessible.
**Steps:**
1.  Construct a valid HubSpot webhook payload for a new company (e.g., Company ID: `5007`, Name: `TestCorp Four`, Domain: `testcorp-four.com`).
2.  Calculate and include the correct `X-HubSpot-Signature`.
3.  Send a POST request to the API with the valid payload and signature.
4.  Observe the HTTP response.
5.  Attempt to query the `customers` table for a *second* record with `hubspot_company_id = 5007`.
6.  Check the email inbox for `salesops@company.com`.
7.  Check Anypoint Monitoring logs.
**Expected Result:**
*   **THEN** The HTTP response status code is `500 Internal Server Error`.
*   **AND** The response body indicates an internal server error.
*   **AND** No new record is inserted; the count of records for `hubspot_company_id = 5007` remains one in the `customers` table.
*   **AND** An email notification is sent to `salesops@company.com` with:
    *   Timestamp of the error.
    *   A concise error message (e.g., "Database insertion failed: duplicate key value violates unique constraint 'customers_hubspot_company_id_key'").
    *   HubSpot Company ID: `5007`.
    *   A link to Anypoint Monitoring logs.
*   **AND** Anypoint Monitoring logs show:
    *   "Received webhook for HubSpot Company ID: 5007".
    *   Detailed error log for database insertion failure, including the SQL error and the transformed payload.
    *   Full error stack trace.

---

**Test Case ID:** TC_US7_001
**User Story:** US7: Secure Credential Management
**Test Case Name:** Verify Secure Credential Usage (Indirect)
**Preconditions:**
*   MuleSoft API is deployed and running.
*   HubSpot Client Secret and PostgreSQL credentials are configured using Secure Configuration Properties.
**Steps:**
1.  Execute TC_US2_001 (Valid Signature).
2.  Execute TC_US3_001_TC_US4_001_TC_US6_001 (Successful DB Insertion).
3.  Review the Mule application's deployment artifacts (e.g., `mule-artifact.json`, `config.yaml` if accessible) to confirm no plain-text credentials.
**Expected Result:**
*   **THEN** Both TC_US2_001 and TC_US3_001_TC_US4_001_TC_US6_001 pass successfully, indicating the application can correctly use the HubSpot Client Secret for validation and connect to the PostgreSQL database.
*   **AND** No sensitive credentials are found hardcoded or in plain text within the application's deployable archive or accessible configuration files.

---

## 3. Automation Test Scripts

These automation scripts are written in Python using `pytest` for testing, `requests` for API calls, `hmac` and `hashlib` for signature calculation, and `psycopg2` for database interaction.

**Setup Instructions:**
1.  Install Python (3.7+).
2.  Install required libraries:
    ```bash
    pip install pytest requests psycopg2-binary python-dotenv
    ```
3.  Create a `.env` file in the same directory as your test scripts with the following variables:
    ```
    MULESOFT_API_BASE_URL=https://<your-cloudhub-app-domain>/api
    HUBSPOT_CLIENT_SECRET=<your-hubspot-client-secret>
    PG_HOST=<your-pg-host>
    PG_PORT=5432
    PG_DBNAME=<your-pg-dbname>
    PG_USER=<your-pg-user>
    PG_PASSWORD=<your-pg-password>
    SALES_OPS_EMAIL_INBOX_URL=<url-to-check-email-e.g.-mailtrap.io-or-similar-for-testing>
    ```
    *Note: For `SALES_OPS_EMAIL_INBOX_URL`, a dedicated testing email service (like Mailtrap.io or a similar mock SMTP server) is highly recommended for automated email verification.*
4.  Ensure your MuleSoft application is deployed and running, and the PostgreSQL database is accessible.

```python
import pytest
import requests
import hmac
import hashlib
import json
import psycopg2
import os
import time
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# --- Configuration from Environment Variables ---
MULESOFT_API_BASE_URL = os.getenv("MULESOFT_API_BASE_URL")
HUBSPOT_CLIENT_SECRET = os.getenv("HUBSPOT_CLIENT_SECRET")
WEBHOOK_ENDPOINT = f"{MULESOFT_API_BASE_URL}/hubspot/company/created"

PG_HOST = os.getenv("PG_HOST")
PG_PORT = os.getenv("PG_PORT", "5432")
PG_DBNAME = os.getenv("PG_DBNAME")
PG_USER = os.getenv("PG_USER")
PG_PASSWORD = os.getenv("PG_PASSWORD")

# For email verification, this would be an API endpoint to check an inbox
SALES_OPS_EMAIL_INBOX_URL = os.getenv("SALES_OPS_EMAIL_INBOX_URL") 

# --- Helper Functions ---

def calculate_hubspot_signature(payload: dict, secret: str) -> str:
    """Calculates the X-HubSpot-Signature for a given payload."""
    payload_str = json.dumps(payload)
    hashed = hmac.new(secret.encode('utf-8'), payload_str.encode('utf-8'), hashlib.sha256).hexdigest()
    return hashed

def generate_hubspot_webhook_payload(company_id: int, company_name: str = None, company_domain: str = None) -> list:
    """Generates a sample HubSpot webhook payload for company creation."""
    payload = [
        {
            "eventId": int(time.time() * 1000), # Unique event ID
            "subscriptionId": 987654321,
            "portalId": 1234567,
            "appId": 7654321,
            "occurredAt": f"{time.strftime('%Y-%m-%dT%H:%M:%S.000Z', time.gmtime())}",
            "subscriptionType": "company.creation",
            "attemptNumber": 0,
            "objectId": company_id,
            "changeSource": "CRM",
            "properties": {},
            "propertyChanges": []
        }
    ]

    if company_name is not None:
        payload[0]["properties"]["name"] = {"newValue": company_name, "oldValue": None, "sourceType": "CRM", "sourceId": "USER_TEST", "updatedAt": payload[0]["occurredAt"]}
        payload[0]["propertyChanges"].append({"propertyName": "name", "newValue": company_name, "oldValue": None})
    
    if company_domain is not None:
        payload[0]["properties"]["domain"] = {"newValue": company_domain, "oldValue": None, "sourceType": "CRM", "sourceId": "USER_TEST", "updatedAt": payload[0]["occurredAt"]}
        payload[0]["propertyChanges"].append({"propertyName": "domain", "newValue": company_domain, "oldValue": None})
    
    return payload

def get_db_connection():
    """Establishes and returns a PostgreSQL database connection."""
    try:
        conn = psycopg2.connect(
            host=PG_HOST,
            port=PG_PORT,
            dbname=PG_DBNAME,
            user=PG_USER,
            password=PG_PASSWORD
        )
        return conn
    except psycopg2.Error as e:
        pytest.fail(f"Database connection failed: {e}")

def cleanup_db(hubspot_company_id: int):
    """Deletes a customer record from the DB based on hubspot_company_id."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("DELETE FROM customers WHERE hubspot_company_id = %s;", (hubspot_company_id,))
        conn.commit()
    except Exception as e:
        print(f"Error during DB cleanup for {hubspot_company_id}: {e}")
    finally:
        conn.close()

def check_email_notification(expected_subject_part: str, expected_body_part: str, max_retries: int = 5, delay: int = 5):
    """
    Simulates checking an email inbox for a specific notification.
    NOTE: This is a placeholder. In a real scenario, this would involve
    integrating with an email testing service (e.g., Mailtrap.io API, or a local SMTP server).
    """
    if not SALES_OPS_EMAIL_INBOX_URL:
        pytest.skip("SALES_OPS_EMAIL_INBOX_URL is not configured for email verification.")
    
    print(f"Attempting to check email inbox at {SALES_OPS_EMAIL_INBOX_URL}...")
    # This is a mock implementation. Replace with actual API calls to your email testing service.
    for i in range(max_retries):
        print(f"Checking email (attempt {i+1}/{max_retries})...")
        # In a real scenario, you'd call the email service API here to fetch emails
        # For demonstration, we'll just 'simulate' finding it.
        if i == max_retries - 1: # Simulate finding it on the last attempt or not at all
            print("Simulating email found for testing purposes.")
            return True # Assume email was found
        time.sleep(delay)
    print("Simulated email not found after retries.")
    return False

# --- Pytest Fixtures ---

@pytest.fixture(scope="function")
def db_cleanup_fixture():
    """Fixture to ensure database cleanup after each test that inserts data."""
    inserted_company_ids = []
    yield inserted_company_ids
    for company_id in inserted_company_ids:
        cleanup_db(company_id)

# --- Test Cases ---

def test_e2e_success_valid_webhook(db_cleanup_fixture):
    """
    Tests the end-to-end success path: valid webhook, signature, payload,
    successful DB insertion, and HTTP 200 OK response.
    (Corresponds to TC_US1_001, TC_US2_001, TC_US3_001, TC_US4_001, TC_US6_001)
    """
    company_id = int(time.time()) # Unique ID for this test run
    company_name = f"Automated Test Company {company_id}"
    company_domain = f"autotest-{company_id}.com"
    db_cleanup_fixture.append(company_id)

    payload = generate_hubspot_webhook_payload(company_id, company_name, company_domain)
    signature = calculate_hubspot_signature(payload, HUBSPOT_CLIENT_SECRET)

    headers = {
        "Content-Type": "application/json",
        "X-HubSpot-Signature": signature
    }

    print(f"\nSending valid webhook for Company ID: {company_id}")
    response = requests.post(WEBHOOK_ENDPOINT, headers=headers, data=json.dumps(payload))

    assert response.status_code == 200, f"Expected HTTP 200 OK, got {response.status_code}: {response.text}"
    print(f"Received HTTP 200 OK for Company ID: {company_id}")

    # Verify DB insertion
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT hubspot_company_id, company_name, company_domain FROM customers WHERE hubspot_company_id = %s;", (company_id,))
            record = cur.fetchone()
            assert record is not None, f"Company {company_id} not found in DB."
            assert record[0] == company_id
            assert record[1] == company_name
            assert record[2] == company_domain
        print(f"Verified DB record for Company ID: {company_id}")
    finally:
        conn.close()

    # Verification of logs in Anypoint Monitoring would require integration with Anypoint Platform APIs,
    # which is beyond the scope of a simple Python script. This would be a manual check or a separate
    # monitoring automation.
    print("Manual verification of Anypoint Monitoring logs is recommended for this test.")


def test_invalid_webhook_signature():
    """
    Tests that requests with an invalid X-HubSpot-Signature are rejected.
    (Corresponds to TC_US2_002)
    """
    company_id = int(time.time()) + 1 # Unique ID
    payload = generate_hubspot_webhook_payload(company_id, "Invalid Sig Test", "invalid-sig.com")
    invalid_signature = "invalid-signature-12345" # A clearly incorrect signature

    headers = {
        "Content-Type": "application/json",
        "X-HubSpot-Signature": invalid_signature
    }

    print(f"\nSending webhook with invalid signature for Company ID: {company_id}")
    response = requests.post(WEBHOOK_ENDPOINT, headers=headers, data=json.dumps(payload))

    assert response.status_code in [401, 403], f"Expected HTTP 401/403, got {response.status_code}: {response.text}"
    assert "Invalid X-HubSpot-Signature" in response.text or "Unauthorized" in response.text or "Forbidden" in response.text
    print(f"Received expected HTTP {response.status_code} for invalid signature.")

    # Verify no DB insertion
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT hubspot_company_id FROM customers WHERE hubspot_company_id = %s;", (company_id,))
            record = cur.fetchone()
            assert record is None, f"Company {company_id} should NOT be in DB with invalid signature."
    finally:
        conn.close()


def test_missing_webhook_signature():
    """
    Tests that requests missing the X-HubSpot-Signature header are rejected.
    (Corresponds to TC_US2_003)
    """
    company_id = int(time.time()) + 2 # Unique ID
    payload = generate_hubspot_webhook_payload(company_id, "Missing Sig Test", "missing-sig.com")

    headers = {
        "Content-Type": "application/json"
        # X-HubSpot-Signature header is intentionally omitted
    }

    print(f"\nSending webhook with missing signature for Company ID: {company_id}")
    response = requests.post(WEBHOOK_ENDPOINT, headers=headers, data=json.dumps(payload))

    assert response.status_code in [401, 403], f"Expected HTTP 401/403, got {response.status_code}: {response.text}"
    assert "Invalid X-HubSpot-Signature" in response.text or "Unauthorized" in response.text or "Forbidden" in response.text
    print(f"Received expected HTTP {response.status_code} for missing signature.")

    # Verify no DB insertion
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT hubspot_company_id FROM customers WHERE hubspot_company_id = %s;", (company_id,))
            record = cur.fetchone()
            assert record is None, f"Company {company_id} should NOT be in DB with missing signature."
    finally:
        conn.close()


def test_payload_validation_missing_name_field():
    """
    Tests that requests with missing mandatory 'name' field are rejected with 400 Bad Request,
    trigger error notification, and no DB insertion.
    (Corresponds to TC_US3_002, TC_US5_001, TC_US6_002)
    """
    company_id = int(time.time()) + 3 # Unique ID
    company_domain = f"no-name-{company_id}.com"

    # Generate payload missing the 'name' property
    payload = generate_hubspot_webhook_payload(company_id, company_name=None, company_domain=company_domain)
    signature = calculate_hubspot_signature(payload, HUBSPOT_CLIENT_SECRET)

    headers = {
        "Content-Type": "application/json",
        "X-HubSpot-Signature": signature
    }

    print(f"\nSending webhook with missing 'name' field for Company ID: {company_id}")
    response = requests.post(WEBHOOK_ENDPOINT, headers=headers, data=json.dumps(payload))

    assert response.status_code == 400, f"Expected HTTP 400 Bad Request, got {response.status_code}: {response.text}"
    assert "Missing mandatory fields" in response.text and "name is required" in response.text
    print(f"Received expected HTTP {response.status_code} for missing 'name' field.")

    # Verify no DB insertion
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT hubspot_company_id FROM customers WHERE hubspot_company_id = %s;", (company_id,))
            record = cur.fetchone()
            assert record is None, f"Company {company_id} should NOT be in DB with missing 'name' field."
    finally:
        conn.close()

    # Verify email notification (placeholder)
    # The subject and body parts should be configured to match the actual email content
    # For example: check_email_notification(f"Sync Failure for Company ID: {company_id}", "Missing mandatory field: name")
    # if check_email_notification(f"Sync Failure for Company ID: {company_id}", "Missing mandatory field: name"):
    #     print(f"Verified email notification for missing 'name' field for Company ID: {company_id}")
    # else:
    #     pytest.fail(f"Email notification for missing 'name' field for Company ID: {company_id} not found.")


def test_db_insertion_failure_duplicate_id(db_cleanup_fixture):
    """
    Tests that a duplicate hubspot_company_id results in DB insertion failure,
    HTTP 500, and error notification.
    (Corresponds to TC_US4_002, TC_US5_002)
    """
    company_id = int(time.time()) + 4 # Unique ID
    company_name = f"Duplicate Test Company {company_id}"
    company_domain = f"duplicate-{company_id}.com"
    db_cleanup_fixture.append(company_id)

    # First, successfully insert the company to create a duplicate scenario
    payload1 = generate_hubspot_webhook_payload(company_id, company_name, company_domain)
    signature1 = calculate_hubspot_signature(payload1, HUBSPOT_CLIENT_SECRET)
    headers = {
        "Content-Type": "application/json",
        "X-HubSpot-Signature": signature1
    }
    response1 = requests.post(WEBHOOK_ENDPOINT, headers=headers, data=json.dumps(payload1))
    assert response1.status_code == 200, f"Pre-condition failed: Initial insert for {company_id} failed."
    print(f"Successfully inserted initial record for Company ID: {company_id}")

    # Now, attempt to insert the same company_id again
    payload2 = generate_hubspot_webhook_payload(company_id, company_name, company_domain) # Same ID
    signature2 = calculate_hubspot_signature(payload2, HUBSPOT_CLIENT_SECRET)
    headers2 = {
        "Content-Type": "application/json",
        "X-HubSpot-Signature": signature2
    }

    print(f"\nAttempting duplicate insert for Company ID: {company_id}")
    response2 = requests.post(WEBHOOK_ENDPOINT, headers=headers2, data=json.dumps(payload2))

    assert response2.status_code == 500, f"Expected HTTP 500 Internal Server Error, got {response2.status_code}: {response2.text}"
    assert "An unexpected error occurred during processing" in response2.text or "database constraint violation" in response2.text
    print(f"Received expected HTTP {response2.status_code} for duplicate ID.")

    # Verify only one record exists in DB
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT COUNT(*) FROM customers WHERE hubspot_company_id = %s;", (company_id,))
            count = cur.fetchone()[0]
            assert count == 1, f"Expected 1 record for Company {company_id}, found {count}."
        print(f"Verified only one DB record exists for Company ID: {company_id}")
    finally:
        conn.close()

    # Verify email notification (placeholder)
    # if check_email_notification(f"Sync Failure for Company ID: {company_id}", "duplicate key value violates unique constraint"):
    #     print(f"Verified email notification for duplicate ID for Company ID: {company_id}")
    # else:
    #     pytest.fail(f"Email notification for duplicate ID for Company ID: {company_id} not found.")

```