```dockerfile
# Dockerfile

# Use a Mule Runtime base image matching the application's runtime version
FROM mulesoft/mule-runtime:4.4.0

# Set the working directory inside the container to the applications directory
WORKDIR ${MULE_HOME}/apps

# Define the application name and version for convenience
ARG APP_NAME=hubspot-customer-sync
ARG APP_VERSION=1.0.0-SNAPSHOT

# Copy the built Mule application JAR
# This assumes 'mvn clean package' has been run and the JAR is in the 'target' directory
COPY target/${APP_NAME}-${APP_VERSION}-mule-application.jar ${MULE_HOME}/apps/${APP_NAME}.jar

# Copy configuration files to the application's root directory within the runtime
# These files (config.yaml, log4j2.xml, application-types.xml) will be accessible
# by the Mule application at runtime for externalized configuration.
COPY src/main/resources/config.yaml ${MULE_HOME}/apps/config.yaml
COPY src/main/resources/log4j2.xml ${MULE_HOME}/apps/log4j2.xml
COPY src/main/resources/application-types.xml ${MULE_HOME}/apps/application-types.xml

# Expose the HTTP listener port
# As defined in config.yaml -> http.port
EXPOSE 8081

# Define default environment variables (can be overridden by docker run or docker-compose)
# These are crucial for the Mule application's configuration and secure properties.
ENV HTTP_PORT=8081 \
    SECURE_KEY=default_encryption_key_for_dev_only \
    MULE_ENV=docker \
    ANYPOINT_PLATFORM_CLIENT_ID= \
    ANYPOINT_PLATFORM_CLIENT_SECRET=

# The base image's entrypoint will start the Mule application automatically.
# No explicit CMD is needed unless specific startup parameters are required.
```

```yaml
# docker-compose.yml

version: '3.8'

services:
  db:
    image: postgres:13
    container_name: hubspot-postgres-db
    environment:
      POSTGRES_DB: hubspot_customers_db
      POSTGRES_USER: hubspot_user
      POSTGRES_PASSWORD: hubspot_password
    ports:
      - "5432:5432" # Expose PostgreSQL port to the host
    volumes:
      - db_data:/var/lib/postgresql/data # Persist database data
      - ./docker/postgres/init:/docker-entrypoint-initdb.d # Initialize schema on first start
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U hubspot_user -d hubspot_customers_db"]
      interval: 5s
      timeout: 5s
      retries: 5
      start_period: 10s # Give DB some time to start before checking

  mailhog:
    image: mailhog/mailhog
    container_name: mailhog-smtp
    ports:
      - "1025:1025" # SMTP server port for receiving emails
      - "8025:8025" # Web UI for viewing received emails
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8025"]
      interval: 10s
      timeout: 5s
      retries: 5
      start_period: 5s

  mule-app:
    build:
      context: . # Build context is the current directory (project root)
      dockerfile: Dockerfile
    container_name: hubspot-customer-sync-app
    ports:
      - "8081:8081" # Map host port 8081 to container port 8081 for the HTTP listener
    environment:
      # Encryption key for secure properties. IMPORTANT: Replace with your actual key.
      # This key must be the same as the one used to encrypt values in config.yaml.
      SECURE_KEY: your_super_secret_encryption_key_here_for_docker_compose
      HTTP_PORT: 8081 # Ensure this matches the exposed port and config.yaml
      # Anypoint Platform credentials are not strictly needed for local Docker runs,
      # but are placeholders if you later deploy to CloudHub/Runtime Fabric.
      # ANYPOINT_PLATFORM_CLIENT_ID: your_client_id
      # ANYPOINT_PLATFORM_CLIENT_SECRET: your_client_secret
    depends_on:
      db:
        condition: service_healthy # Ensure DB is healthy before starting the Mule app
      mailhog:
        condition: service_healthy # Ensure Mailhog is healthy before starting the Mule app
    # Optional: If you want to configure logging for Docker
    # logging:
    #   driver: "json-file"
    #   options:
    #     max-size: "10m"
    #     max-file: "5"

volumes:
  db_data: # Define a named volume for PostgreSQL data persistence
```

```markdown
# README.md

## HubSpot Company to Customer DB Sync Service

This MuleSoft application synchronizes new company records created in HubSpot with an internal PostgreSQL customer database. It acts as a secure webhook listener, validates incoming requests, transforms data, and inserts it into the database.

### 1. Project Structure

```
hubspot-customer-sync/
├── pom.xml                                  - Maven Project Object Model, dependencies.
├── src/main/mule/
│   ├── hubspot-customer-sync.xml            - Main Mule flow for webhook processing.
│   ├── global-configs.xml                   - Global configurations (HTTP listener, DB, Email, Secure Properties).
│   └── global-error-handler.xml             - Centralized error handling logic.
├── src/main/resources/
│   ├── application-types.xml                - DataWeave types for payload validation/transformation.
│   ├── log4j2.xml                           - Logging configuration.
│   ├── config.yaml                          - Application configuration properties.
│   └── secure-properties.yaml.example       - Example for securely encrypted properties.
├── path/to/db/schema.sql                    - Original PostgreSQL database schema definition.
├── Dockerfile                               - Dockerfile for containerizing the MuleSoft application.
├── docker-compose.yml                       - Docker Compose file to orchestrate the application, database, and email server.
└── docker/                                  - Directory for Docker-related assets.
    └── postgres/
        └── init/
            └── schema.sql                   - PostgreSQL schema script copied for Docker initialization.
```

### 2. Setup Instructions

#### 2.1. Prerequisites

Before proceeding, ensure you have the following installed:
*   **Java Development Kit (JDK) 8 or later**
*   **Maven 3.6.x or later**
*   **Docker Desktop** (includes Docker Engine and Docker Compose)

#### 2.2. Database Setup

For local development and testing, the PostgreSQL database will be provisioned and initialized automatically using Docker Compose.

1.  **Prepare Database Initialization Script:**
    Create the directory `docker/postgres/init` in the root of your project if it doesn't exist:
    ```bash
    mkdir -p docker/postgres/init
    ```
    Copy the database schema script from `path/to/db/schema.sql` into this new directory:
    ```bash
    cp path/to/db/schema.sql docker/postgres/init/schema.sql
    ```
    This `schema.sql` script will be executed by the PostgreSQL container on startup to create the `customers` table.

#### 2.3. MuleSoft Application Configuration (Secure Properties)

This application uses secure properties for sensitive credentials. You will need to encrypt these values.

1.  **Install Secure Configuration Properties Tool:**
    If you don't have it, download the `secure-properties-tool.jar` from MuleSoft's GitHub or Exchange.

2.  **Generate Encryption Key:**
    Decide on a strong encryption key. This key will be passed as an environment variable (`SECURE_KEY`) to the Mule application container. For local development, you'll set it in `docker-compose.yml`.

3.  **Encrypt Sensitive Properties:**
    For each sensitive property listed below, use the `secure-properties-tool.jar` to encrypt its value. The example encryption command uses AES/CBC mode, which is recommended.

    ```bash
    java -jar secure-properties-tool.jar string encrypt AES CBC <YOUR_ENCRYPTION_KEY> "plain_text_value"
    ```
    The tool will output an encrypted string like `![AES 128/CBC/PKCS5Padding]...`.

    The properties to encrypt, along with their plain text values for Docker Compose environment:
    *   `hubspot.client.secret`: Your HubSpot Private App's Client Secret.
        *   *Plain text value example:* `"YOUR_HUBSPOT_SECRET"`
    *   `db.url`: Your PostgreSQL JDBC URL, configured to connect to the `db` service within Docker Compose.
        *   *Plain text value example:* `"jdbc:postgresql://db:5432/hubspot_customers_db"`
    *   `db.username`: Your PostgreSQL database username, matching the `POSTGRES_USER` in `docker-compose.yml`.
        *   *Plain text value example:* `"hubspot_user"`
    *   `db.password`: Your PostgreSQL database password, matching the `POSTGRES_PASSWORD` in `docker-compose.yml`.
        *   *Plain text value example:* `"hubspot_password"`
    *   `smtp.host`: Your SMTP server host, configured to connect to the `mailhog` service within Docker Compose.
        *   *Plain text value example:* `"mailhog"`
    *   `smtp.port`: Your SMTP server port, matching Mailhog's SMTP port.
        *   *Plain text value example:* `"1025"`
    *   `smtp.username`: Your SMTP username (Mailhog typically doesn't require authentication, but the MuleSoft Email Connector might expect a value). Encrypt an empty string or a dummy value.
        *   *Plain text value example:* `""` (empty string) or `"mailhog_user"`
    *   `smtp.password`: Your SMTP password. Encrypt an empty string or a dummy value.
        *   *Plain text value example:* `""` (empty string) or `"mailhog_pass"`

4.  **Update `config.yaml`:**
    Open `src/main/resources/config.yaml`. Uncomment the lines for sensitive properties and replace the placeholder values with the *encrypted* strings you generated in the previous step.
    Example `src/main/resources/config.yaml` after updates:
    ```yaml
    # src/main/resources/config.yaml
    http.port: 8081

    # HubSpot Configuration
    hubspot.client.secret: "![AES 128/CBC/PKCS5Padding]encrypted_hubspot_secret_value"

    # PostgreSQL Database Configuration
    db.url: "![AES 128/CBC/PKCS5Padding]encrypted_db_url_value"
    db.username: "![AES 128/CBC/PKCS5Padding]encrypted_db_username_value"
    db.password: "![AES 128/CBC/PKCS5Padding]encrypted_db_password_value"

    # Email Configuration for Error Notifications
    smtp.host: "![AES 128/CBC/PKCS5Padding]encrypted_smtp_host_value"
    smtp.port: "![AES 128/CBC/PKCS5Padding]encrypted_smtp_port_value"
    smtp.username: "![AES 128/CBC/PKCS5Padding]encrypted_smtp_username_value"
    smtp.password: "![AES 128/CBC/PKCS5Padding]encrypted_smtp_password_value"
    email.from: "noreply-hubspot-sync@company.com"
    email.to: "salesops@company.com"

    # Secure Properties Key is passed via environment variable (e.g., SECURE_KEY in docker-compose.yml)
    # secure.key: "YOUR_ENCRYPTION_KEY"
    ```

5.  **Update `docker-compose.yml`:**
    Open `docker-compose.yml` and replace `your_super_secret_encryption_key_here_for_docker_compose` in the `mule-app` service's `environment` section with the actual encryption key you chose in step 2.

#### 2.4. Build and Run the Application with Docker Compose

1.  **Build the MuleSoft Application JAR:**
    Navigate to the project root directory (`hubspot-customer-sync/`) and run Maven to package the application:
    ```bash
    mvn clean package
    ```
    This will create a deployable `.jar` file in the `target/` directory.

2.  **Build and Start Services with Docker Compose:**
    From the project root directory, run:
    ```bash
    docker-compose up --build -d
    ```
    *   `--build`: Rebuilds the `mule-app` Docker image (useful if you change application code or configuration).
    *   `-d`: Runs the services in detached mode (in the background).

    This command will:
    *   Build the `mule-app` Docker image based on the `Dockerfile`.
    *   Start the `db` (PostgreSQL), `mailhog` (SMTP server), and `mule-app` containers.
    *   The `db` container will automatically execute `docker/postgres/init/schema.sql` to create the `customers` table on its first startup.

### 3. HubSpot Webhook Configuration

1.  **Create a Private App in HubSpot:**
    *   Go to your HubSpot Developer account.
    *   Create a "Private App".
    *   Under "Auth", copy your "Secret". This is your `hubspot.client.secret`.
    *   Under "Scopes", grant necessary permissions (e.g., `crm.objects.companies.read` might be useful for other operations, but for webhooks, only the secret is strictly needed for validation).

2.  **Configure Webhook in HubSpot:**
    *   In your HubSpot account, navigate to **Settings > Integrations > Webhooks**.
    *   Click "Create webhook".
    *   **Subscription Type:** Select `Company` for Object Type, and `Creation` for Event Type.
    *   **Target URL:** For local testing with Docker Compose, you'll need a publicly accessible URL that forwards to your `localhost:8081`. You can use tools like `ngrok` for this. If your local machine's IP is directly reachable, you might use: `http://<YOUR_LOCAL_IP>:8081/hubspot/company/created`
    *   **Secret:** Paste the "Secret" from your Private App here. HubSpot will use this to generate the `X-HubSpot-Signature` header.
    *   Save the webhook.

### 4. Testing

1.  **Verify Service Health:**
    Check the status of your Docker containers:
    ```bash
    docker-compose ps
    ```
    Ensure all services (`db`, `mailhog`, `mule-app`) are listed as `Up` and their health checks are passing (e.g., `(healthy)`).

2.  **Access Mailhog UI:**
    Open your web browser and navigate to `http://localhost:8025` to view the Mailhog email inbox. This is where error notifications will appear.

3.  **Create a new Company in HubSpot:**
    Go to your HubSpot CRM and create a new company record. This should trigger the webhook.

4.  **Monitor Logs:**
    Check your MuleSoft application logs (via `docker-compose logs mule-app` or Anypoint Monitoring if deployed to CloudHub) for entries indicating:
    *   Webhook reception.
    *   Signature validation.
    *   Payload validation.
    *   Database insertion success/failure.

5.  **Check PostgreSQL Database:**
    You can connect to the PostgreSQL database to verify the inserted record:
    ```bash
    docker-compose exec db psql -U hubspot_user -d hubspot_customers_db -c "SELECT * FROM customers;"
    ```
    Verify that the new company record has been inserted into the `customers` table.

6.  **Test Error Scenarios:**
    *   **Invalid Signature:** Send a POST request to the webhook endpoint (e.g., `http://localhost:8081/hubspot/company/created` via a tool like Postman) with a deliberately incorrect `X-HubSpot-Signature` header or no header at all. You should receive a 401 response and see security error logs in `docker-compose logs mule-app`. No email notification should be sent for this type of error.
    *   **Invalid Payload:** Send a POST request with a HubSpot-like payload, but omit mandatory fields like `objectId`, `properties.name.newValue`, or `properties.domain.newValue`. You should receive a 400 response, an error email in Mailhog (`http://localhost:8025`), and corresponding logs.
    *   **Database Error:** Temporarily stop the `db` service (`docker-compose stop db`) or intentionally break the DB connection string in `config.yaml` (you would need to rebuild and restart `mule-app` for config changes). Send a valid webhook. You should receive a 500 response, an error email in Mailhog, and detailed DB error logs. Remember to restart `db` with `docker-compose start db` when done.

### 5. Cleaning Up

To stop and remove all services, networks, and volumes created by Docker Compose:
```bash
docker-compose down -v
```
This will remove the containers, networks, and the `db_data` volume, ensuring a clean slate for the next run.