# High-Level Design (HLD): PharmaCorp Commercial Website

## 1. Introduction

This High-Level Design (HLD) document outlines the architectural blueprint for the PharmaCorp commercial website. It translates the provided user stories and technical constraints into a conceptual design, defining the system's core components, data models, API interfaces, and deployment strategy. The design prioritizes performance, security, accessibility, and maintainability, aligning with the specified technical stack and regulatory requirements.

## 2. Updated User Stories (SRS)

This section presents the refined user stories, incorporating feedback from previous reviews to ensure comprehensive coverage of requirements.

---

### I. Core Website Structure & Navigation

### User Story 1: Website Navigation & Core Pages

*   **As a:** Website visitor (patient or HCP)
*   **I want to:** Easily navigate to key sections of the PharmaCorp commercial website (Home, About Us, Products, Contact Us, Privacy Policy, Terms of Use)
*   **So that:** I can efficiently find the information relevant to my needs.
*   **Acceptance Criteria:**
    *   **Given** the website is loaded, **When** I view the header/footer, **Then** I see clear and clickable links to Home, About Us, Products, Contact Us, Privacy Policy, and Terms of Use pages.
    *   **Given** I click on any primary navigation link, **When** the page loads, **Then** the corresponding content for that page is displayed.
    *   **Given** I am on any page, **When** I click the company logo, **Then** I am redirected to the Home page.
    *   **Given** I am browsing on a mobile device, **When** I access the website, **Then** the navigation menu is accessible and functional (e.g., via a hamburger menu).
*   **Dependencies:** None.
*   **Priority:** High

### User Story 2: Responsive Website Layout

*   **As a:** Website visitor
*   **I want to:** View and interact with the PharmaCorp website seamlessly across various devices (desktop, tablet, mobile)
*   **So that:** I can access information and features regardless of my screen size or device type.
*   **Acceptance Criteria:**
    *   **Given** I access the website on a desktop, **When** I resize the browser window, **Then** the layout adjusts fluidly without horizontal scrolling.
    *   **Given** I access the website on a tablet (e.g., iPad portrait/landscape), **When** the page loads, **Then** content is appropriately scaled, readable, and interactive elements are easily tappable.
    *   **Given** I access the website on a mobile phone (e.g., iPhone/Android), **When** the page loads, **Then** the layout is optimized for small screens, text is legible without zooming, and navigation is mobile-friendly.
    *   **Given** the website uses HTML5 and JavaScript, **When** content is rendered, **Then** it adheres to responsive design principles.
*   **Dependencies:** User Story 1 (Core Pages).
*   **Priority:** High

## II. Content Pages & Interactive Features

### User Story 3: Homepage Display & Performance

*   **As a:** Website visitor
*   **I want to:** See a welcoming, informative, and fast-loading homepage
*   **So that:** I can quickly understand PharmaCorp's purpose and navigate to relevant sections.
*   **Acceptance Criteria:**
    *   **Given** I navigate to the homepage, **When** the page loads, **Then** the Largest Contentful Paint (LCP) is less than 2.5 seconds.
    *   **Given** the homepage is loaded, **When** I view the content, **Then** it includes a clear introduction to PharmaCorp, links to key product areas, and calls to action (e.g., "Learn More About Our Products").
    *   **Given** the homepage contains static content, **When** it loads, **Then** it utilizes efficient asset loading (e.g., optimized images, lazy loading where appropriate).
*   **Dependencies:** User Story 1, 2.
*   **Priority:** High

### User Story 4: Products Listing Page

*   **As a:** Patient or HCP
*   **I want to:** View a comprehensive list of PharmaCorp's products
*   **So that:** I can see an overview of available treatments and choose one to explore further.
*   **Acceptance Criteria:**
    *   **Given** I navigate to the Products page, **When** the page loads, **Then** it displays a list of all active PharmaCorp products.
    *   **Given** a product is listed, **When** I click on its entry, **Then** I am directed to the detailed Product page for that specific product.
    *   **Given** the product data is managed in the backend, **When** the Products page loads, **Then** the product list is dynamically fetched from the PostgreSQL database via a Python API.
*   **Dependencies:** User Story 1.
*   **Priority:** High

### User Story 5: Product Detail Page with ISI & PI Download

*   **As a:** Patient or HCP
*   **I want to:** Access detailed information for a specific PharmaCorp product, including Important Safety Information (ISI) and the Product Information (PI) PDF
*   **So that:** I can make informed decisions and understand all relevant details and risks.
*   **Acceptance Criteria:**
    *   **Given** I navigate to a Product Detail page, **When** the page loads, **Then** it displays comprehensive product-specific information (e.g., description, indications, dosage).
    *   **Given** I am viewing a Product Detail page, **When** I scroll the page, **Then** a "Sticky ISI" (Important Safety Information) section remains visible on the screen.
    *   **Given** I am on a Product Detail page, **When** I click the "Download PI PDF" link/button, **Then** the corresponding Product Information PDF is downloaded to my device.
    *   **Given** the PI PDF is served, **When** it is requested, **Then** it is retrieved from the designated object storage.
    *   **Given** the product data and ISI content are managed in the backend, **When** the Product Detail page loads, **Then** the data is dynamically fetched from the PostgreSQL database via a Python API.
*   **Dependencies:** User Story 4, Object Storage setup (technical).
*   **Priority:** High

### User Story 6: Contact Us Page & Form Submission

*   **As a:** Website visitor
*   **I want to:** Submit an inquiry or feedback to PharmaCorp via a contact form
*   **So that:** I can communicate directly with the company.
*   **Acceptance Criteria:**
    *   **Given** I navigate to the Contact Us page, **When** the page loads, **Then** it displays a contact form with fields for Name, Email, Subject, and Message.
    *   **Given** I fill out the form with valid information, **When** I click "Submit", **Then** I receive a confirmation message that my submission was successful.
    *   **Given** I submit the form, **When** the data is processed, **Then** the submission details are securely stored in the PostgreSQL database.
    *   **Given** I attempt to submit the form with invalid data (e.g., malformed email), **When** I click "Submit", **Then** appropriate client-side and server-side input validation errors are displayed, preventing submission.
    *   **Given** the form uses a Python backend (FastAPI/Flask), **When** a submission occurs, **Then** the backend API processes the request, validating and storing the data.
    *   **Given** multiple submissions are made from the same IP, **When** the system detects a high volume, **Then** rate limiting is applied to prevent abuse.
*   **Dependencies:** User Story 1, Backend/DB setup.
*   **Priority:** High

### User Story 7: Newsletter Signup

*   **As a:** Website visitor
*   **I want to:** Subscribe to PharmaCorp's newsletter
*   **So that:** I can receive updates, news, and relevant information directly to my email inbox.
*   **Acceptance Criteria:**
    *   **Given** I locate the newsletter signup section (e.g., in the footer or a dedicated page), **When** I view it, **Then** it contains an email input field and a "Subscribe" button.
    *   **Given** I enter a valid email address, **When** I click "Subscribe", **Then** I receive a confirmation message that my subscription was successful.
    *   **Given** I submit my email, **When** the data is processed, **Then** the email address is securely stored in the PostgreSQL database.
    *   **Given** I attempt to submit an invalid email address, **When** I click "Subscribe", **Then** an appropriate validation error is displayed.
    *   **Given** the signup uses a Python backend, **When** a submission occurs, **Then** the backend API processes the request, validating and storing the email.
*   **Dependencies:** Backend/DB setup.
*   **Priority:** Medium

### User Story 8: Site Search Functionality

*   **As a:** Website visitor
*   **I want to:** Search for specific content or keywords across the entire website
*   **So that:** I can quickly find relevant information without having to browse through multiple pages.
*   **Acceptance Criteria:**
    *   **Given** I am on any page, **When** I look for the search functionality, **Then** a prominent search bar or icon is visible (e.g., in the header).
    *   **Given** I enter a search query (e.g., "diabetes medication"), **When** I submit the search, **Then** a search results page is displayed showing relevant content (pages, products, articles) from the website.
    *   **Given** there are no results for my query, **When** the search results page loads, **Then** a "No results found" message is displayed.
    *   **Given** search results are displayed, **When** I click on a result, **Then** I am navigated to the corresponding page.
    *   **Given** the search is performed, **When** the backend processes the request, **Then** it utilizes the PostgreSQL database for content indexing and retrieval.
*   **Dependencies:** Content pages (all pages that can be searched).
*   **Priority:** High

### User Story 9: General Static Content Pages (New)

*   **As a:** Website visitor
*   **I want to:** Access informative static content pages like "About Us"
*   **So that:** I can learn more about PharmaCorp's mission, values, and history.
*   **Acceptance Criteria:**
    *   **Given** I navigate to the "About Us" page, **When** the page loads, **Then** it displays comprehensive information about PharmaCorp's background, mission, and values.
    *   **Given** the content is managed in the backend, **When** the page loads, **Then** the content is dynamically fetched from the PostgreSQL database via a Python API.
    *   **Given** the content is updated in the backend, **When** the page is reloaded, **Then** the changes are reflected on the frontend.
*   **Dependencies:** User Story 1, Backend/DB setup.
*   **Priority:** High

## III. Compliance & Non-Functional Requirements

### User Story 10: WCAG 2.2 AA Accessibility Compliance

*   **As a:** User with diverse abilities (e.g., visual impairment, motor limitations)
*   **I want to:** Access and interact with the PharmaCorp website in an accessible manner
*   **So that:** I can perceive, operate, understand, and robustly interact with all content, adhering to WCAG 2.2 AA standards.
*   **Acceptance Criteria:**
    *   **Given** I navigate the site using only a keyboard, **When** I interact with all clickable elements (links, buttons, form fields), **Then** they are tabbable and actionable, with clear focus indicators.
    *   **Given** images are present on any page, **When** they are rendered, **Then** all meaningful images have descriptive `alt` attributes.
    *   **Given** text content is displayed, **When** I view it, **Then** the color contrast ratio between text and its background meets WCAG 2.2 AA standards (minimum 4.5:1 for normal text, 3:1 for large text).
    *   **Given** any form field is displayed, **When** I view it, **Then** it has a clearly associated `label` element or `aria-label` for screen reader users.
    *   **Given** interactive elements (buttons, links) are present, **When** they are rendered, **Then** they have a minimum target size of 24x24 CSS pixels.
    *   **Given** the site uses HTML5 and JavaScript, **When** dynamic content changes, **Then** ARIA attributes are used appropriately to convey state and changes to assistive technologies.
*   **Dependencies:** All UI-related stories.
*   **Priority:** Critical

### User Story 11: GDPR/CCPA Compliant Cookie Consent

*   **As a:** Website visitor from a GDPR/CCPA regulated region
*   **I want to:** Be informed about the website's use of cookies and manage my consent preferences
*   **So that:** My privacy rights are respected and the website complies with relevant data protection regulations.
*   **Acceptance Criteria:**
    *   **Given** I visit the website for the first time, **When** the page loads, **Then** a prominent cookie consent banner/pop-up appears before any non-essential cookies are set.
    *   **Given** the cookie consent banner is displayed, **When** I view it, **Then** it clearly states that cookies are used and provides options to "Accept All", "Decline All" (for non-essential), and "Manage Preferences".
    *   **Given** I select "Manage Preferences", **When** the preference center opens, **Then** I can individually enable or disable categories of non-essential cookies (e.g., analytics, marketing).
    *   **Given** I make a choice (Accept/Decline/Manage), **When** I confirm my selection, **Then** the banner disappears, and my preferences are remembered for subsequent visits.
    *   **Given** I have declined non-essential cookies, **When** I browse the site, **Then** no non-essential cookies are set on my browser.
    *   **Given** the website stores user consent, **When** consent is provided, **Then** it is stored in a compliant manner (e.g., securely in a database or local storage).
*   **Dependencies:** All pages that might set cookies.
*   **Priority:** Critical

### User Story 12: Legal Content Pages (Privacy Policy and Terms of Use Content)

*   **As a:** Website visitor
*   **I want to:** Access comprehensive and legally compliant Privacy Policy and Terms of Use documents
*   **So that:** I can understand PharmaCorp's data handling practices and the rules governing my use of the website.
*   **Acceptance Criteria:**
    *   **Given** I navigate to the Privacy Policy page, **When** the page loads, **Then** it displays the full, up-to-date Privacy Policy content.
    *   **Given** I navigate to the Terms of Use page, **When** the page loads, **Then** it displays the full, up-to-date Terms of Use content.
    *   **Given** the content is managed in the backend, **When** the pages are rendered, **Then** they are served efficiently.
    *   **Given** the documents are updated, **When** content is changed in the backend, **Then** it is reflected on the frontend pages.
*   **Dependencies:** User Story 1, Backend/DB setup.
*   **Priority:** High

## IV. Underlying Technical Infrastructure (Enabling Stories)

### User Story 13: Secure Communication (HTTPS & CSP)

*   **As a:** Website developer/administrator
*   **I want to:** Ensure all communication between the user and the website is encrypted and protected against common web vulnerabilities
*   **So that:** User data is secure and the website integrity is maintained.
*   **Acceptance Criteria:**
    *   **Given** a user accesses any page of the website, **When** the connection is established, **Then** it uses HTTPS.
    *   **Given** the website serves content, **When** the browser receives the response, **Then** a strict Content Security Policy (CSP) header is present, preventing unauthorized script execution and resource loading.
    *   **Given** the backend APIs are deployed, **When** they are accessed, **Then** they enforce HTTPS.
*   **Dependencies:** Deployment infrastructure.
*   **Priority:** Critical

### User Story 14: CI/CD Pipeline for Deployment

*   **As a:** Developer/DevOps Engineer
*   **I want to:** Automate the build, test, and deployment process for the PharmaCorp website
*   **So that:** We can ensure consistent, reliable, and rapid delivery of new features and fixes across Dev, Staging, and Production environments.
*   **Acceptance Criteria:**
    *   **Given** code is pushed to the main branch, **When** the pipeline is triggered, **Then** automated tests (unit, integration) are executed.
    *   **Given** tests pass, **When** the pipeline proceeds, **Then** the application is automatically built and deployed to the Dev environment.
    *   **Given** a successful deployment to Dev, **When** a manual approval is given, **Then** the application can be deployed to the Staging environment.
    *   **Given** a successful deployment to Staging, **When** a final approval is given, **Then** the application can be deployed to the Production environment.
    *   **Given** a new version is deployed, **When** the process completes, **Then** downtime is minimized (e.g., zero-downtime deployment strategy).
*   **Dependencies:** Code repository, hosting environments.
*   **Priority:** High (Enabling)

---

## 3. High-Level Technical Requirements / Constraints

*   **Frontend:** HTML5 + JavaScript (responsive).
*   **Backend:** Python (FastAPI or Flask) for APIs.
*   **Database:** PostgreSQL for content & form submissions.
*   **Storage:** Object store for PI/MedGuide PDFs.
*   **Security:** HTTPS, CSP, rate limiting, input validation.
*   **Deployment:** Dev, Staging, Prod with CI/CD.

## 4. Architectural Design

### 4.1. Overview & Rationale

The PharmaCorp commercial website will adopt a decoupled architecture, separating the client-side user interface (Frontend) from the server-side business logic and data management (Backend). This approach offers several benefits:
*   **Scalability:** Frontend and Backend can scale independently.
*   **Performance:** Static frontend assets can be served efficiently via a Content Delivery Network (CDN), improving load times (especially LCP).
*   **Maintainability:** Clear separation of concerns simplifies development and debugging.
*   **Flexibility:** Allows for future expansion (e.g., mobile apps consuming the same APIs).

### 4.2. Core Components

*   **Client (User Browser):** Renders the HTML, CSS, and JavaScript, interacting with the user.
*   **Content Delivery Network (CDN):** Serves static frontend assets (HTML, CSS, JS, images) and potentially cached API responses. Essential for global reach and low latency.
*   **Web Application Firewall (WAF) / Load Balancer:** Protects the backend APIs from common web attacks (e.g., XSS, SQL injection) and distributes incoming traffic across backend instances. Handles SSL/TLS termination for HTTPS.
*   **Backend API Service:** Developed using Python (FastAPI/Flask). This service handles:
    *   Serving dynamic content (Product lists, Product details, About Us, Legal pages).
    *   Processing form submissions (Contact Us, Newsletter).
    *   Implementing business logic (e.g., data validation, rate limiting).
    *   Interacting with the database and object storage.
*   **PostgreSQL Database:** Relational database for storing structured content such as product information, ISI, contact form submissions, newsletter subscribers, and general static page content.
*   **Object Storage:** Stores large binary files like Product Information (PI) PDFs. Offers high availability and scalability for static file serving.
*   **CI/CD Pipeline:** Automates the build, test, and deployment of both frontend and backend components across Dev, Staging, and Production environments.
*   **Monitoring & Logging:** Tools for observing system health, performance, and capturing operational logs for debugging and auditing.

### 4.3. Technology Stack Mapping

| Component                 | Technology Stack                                      | Rationale                                                                        |
| :------------------------ | :---------------------------------------------------- | :------------------------------------------------------------------------------- |
| **Frontend**              | HTML5, CSS3, JavaScript (Vanilla JS or lightweight framework) | Meets responsive design, accessibility, and performance requirements.            |
| **Backend API**           | Python (FastAPI / Flask)                              | Specified in requirements. FastAPI offers high performance, Flask is lightweight. |
| **Database**              | PostgreSQL                                            | Specified in requirements. Robust, open-source, supports full-text search.       |
| **Object Storage**        | AWS S3 / Azure Blob Storage / Google Cloud Storage    | Specified in requirements. Highly scalable, durable, and cost-effective.         |
| **CDN**                   | Cloudflare / AWS CloudFront / Azure CDN               | Improves content delivery speed and reduces origin load.                         |
| **WAF / Load Balancer**   | AWS ALB + WAF / Nginx + ModSecurity / Cloudflare WAF  | Essential for security (rate limiting, input validation, DDoS protection) and traffic distribution. |
| **CI/CD**                 | GitHub Actions / GitLab CI / Jenkins                  | Automates deployment process across environments.                                |
| **Containerization (Optional but Recommended)** | Docker                                                | Ensures consistent environments from development to production.                  |
| **Orchestration (Optional but Recommended)**   | Kubernetes / AWS ECS / Azure AKS                      | Manages containerized applications for scalability and high availability.        |
| **Monitoring & Logging**  | Prometheus + Grafana / ELK Stack / Cloud-native tools | For system observability and operational insights.                               |

### 4.4. Non-Functional Considerations

*   **Performance:**
    *   **LCP (< 2.5s):** Achieved through CDN for static assets, optimized image delivery, efficient API responses, and client-side rendering optimizations. Target LCP < 2.5s for **all primary content pages**.
    *   **Caching:** CDN caching for static content, API response caching (where appropriate) at the CDN/Load Balancer layer.
*   **Security:**
    *   **HTTPS:** Enforced end-to-end via Load Balancer/CDN and Backend API.
    *   **Content Security Policy (CSP):** Strict CSP headers to mitigate XSS and data injection attacks.
    *   **Input Validation:** Robust server-side validation on all API endpoints (Contact Us, Newsletter, Search) in addition to client-side validation.
    *   **Rate Limiting:** Implemented at the WAF/Load Balancer level and/or within the Backend API to prevent abuse (e.g., Contact Form, Newsletter signup).
    *   **Database Security:** Least privilege access, encryption at rest and in transit, regular backups.
*   **Scalability:**
    *   **Horizontal Scaling:** Backend API designed for statelessness to allow easy horizontal scaling.
    *   **Database:** PostgreSQL can be scaled vertically initially, with options for read replicas or sharding for extreme loads.
    *   **CDN & Object Storage:** Inherently scalable services.
*   **Reliability & High Availability:**
    *   Redundant backend instances across multiple availability zones.
    *   Database replication (e.g., primary/standby).
    *   CDN for fault tolerance in content delivery.
    *   Zero-downtime deployment strategies via CI/CD.
*   **Observability:** Comprehensive logging, metrics, and tracing for proactive issue detection and troubleshooting.

## 5. Data Model Design

### 5.1. Entity Relationship Diagram (Conceptual)

```mermaid
erDiagram
    PRODUCTS ||--o{ ISI_CONTENT : "has"
    PRODUCTS ||--o{ PI_PDFS : "has"
    PAGES ||--o{ SEARCH_INDEX : "indexes"
    CONTACT_SUBMISSIONS ||--|| USERS : "submitted_by"
    NEWSLETTER_SUBSCRIBERS ||--|| USERS : "subscribed_by"

    PRODUCTS {
        UUID product_id PK
        VARCHAR name
        TEXT description
        TEXT indications
        TEXT dosage
        BOOLEAN is_active
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }

    ISI_CONTENT {
        UUID isi_id PK
        UUID product_id FK
        TEXT content_html
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }

    PI_PDFS {
        UUID pdf_id PK
        UUID product_id FK
        VARCHAR file_name
        VARCHAR s3_key
        VARCHAR url
        TIMESTAMP uploaded_at
    }

    PAGES {
        UUID page_id PK
        VARCHAR slug UNIQUE
        VARCHAR title
        TEXT content_html
        TIMESTAMP last_updated
    }

    CONTACT_SUBMISSIONS {
        UUID submission_id PK
        VARCHAR name
        VARCHAR email
        VARCHAR subject
        TEXT message
        INET ip_address
        TIMESTAMP submission_timestamp
    }

    NEWSLETTER_SUBSCRIBERS {
        UUID subscriber_id PK
        VARCHAR email UNIQUE
        INET ip_address
        TIMESTAMP subscription_timestamp
        BOOLEAN is_active
    }

    SEARCH_INDEX {
        UUID index_id PK
        UUID page_id FK
        TEXT searchable_content
        TSVECTOR search_vector
        TIMESTAMP indexed_at
    }

    USERS {
        UUID user_id PK "Hypothetical, for future authentication"
        VARCHAR email UNIQUE "For linking submissions/subscriptions to a user if authenticated"
    }
```

### 5.2. Schema Definitions (PostgreSQL)

```sql
-- Table for Products
CREATE TABLE products (
    product_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    indications TEXT,
    dosage TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Table for Important Safety Information (ISI)
CREATE TABLE isi_content (
    isi_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID NOT NULL REFERENCES products(product_id) ON DELETE CASCADE,
    content_html TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Table for Product Information PDFs (stores metadata, actual files in Object Storage)
CREATE TABLE pi_pdfs (
    pdf_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID NOT NULL REFERENCES products(product_id) ON DELETE CASCADE,
    file_name VARCHAR(255) NOT NULL,
    s3_key VARCHAR(512) NOT NULL UNIQUE, -- Key in the object storage
    url VARCHAR(1024), -- Pre-signed URL or direct public URL if applicable
    uploaded_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Table for General Static Pages (About Us, etc.) and Legal Pages (Privacy Policy, Terms of Use)
CREATE TABLE pages (
    page_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    slug VARCHAR(255) UNIQUE NOT NULL, -- e.g., 'about-us', 'privacy-policy', 'terms-of-use'
    title VARCHAR(255) NOT NULL,
    content_html TEXT NOT NULL,
    last_updated TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Table for Contact Form Submissions
CREATE TABLE contact_submissions (
    submission_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255),
    email VARCHAR(255) NOT NULL,
    subject VARCHAR(255),
    message TEXT NOT NULL,
    ip_address INET, -- For rate limiting and auditing
    submission_timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Table for Newsletter Subscribers
CREATE TABLE newsletter_subscribers (
    subscriber_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    ip_address INET, -- For rate limiting and auditing
    subscription_timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE -- Allows for opt-out/unsubscribe
);

-- Table for Search Index (for PostgreSQL Full-Text Search)
CREATE TABLE search_index (
    index_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    page_id UUID REFERENCES pages(page_id) ON DELETE CASCADE, -- Link to pages table
    product_id UUID REFERENCES products(product_id) ON DELETE CASCADE, -- Link to products table
    content_type VARCHAR(50) NOT NULL, -- 'page', 'product'
    searchable_content TEXT NOT NULL, -- Concatenated text from various fields
    search_vector TSVECTOR, -- For full-text search
    indexed_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Add index for full-text search
CREATE INDEX search_vector_idx ON search_index USING GIN (search_vector);

-- Trigger to update search_vector on insert/update of pages/products
-- (Example for pages, similar for products)
-- CREATE FUNCTION update_search_index_pages() RETURNS TRIGGER AS $$
-- BEGIN
--    INSERT INTO search_index (page_id, content_type, searchable_content, search_vector)
--    VALUES (NEW.page_id, 'page', NEW.title || ' ' || NEW.content_html, to_tsvector('english', NEW.title || ' ' || NEW.content_html))
--    ON CONFLICT (page_id) DO UPDATE SET
--        searchable_content = EXCLUDED.searchable_content,
--        search_vector = EXCLUDED.search_vector,
--        indexed_at = CURRENT_TIMESTAMP;
--    RETURN NEW;
-- END;
-- $$ LANGUAGE plpgsql;
--
-- CREATE TRIGGER update_search_index_pages_trigger
-- AFTER INSERT OR UPDATE ON pages
-- FOR EACH ROW EXECUTE FUNCTION update_search_index_pages();
```

## 6. API Design (Python Backend - FastAPI/Flask)

The backend API will be built using Python (FastAPI or Flask), providing RESTful endpoints for data retrieval and submission.

### 6.1. API Gateway / Backend Service

The Python backend will act as the API Gateway, exposing endpoints to the frontend. It will be responsible for:
*   Request routing and handling.
*   Data validation (client-side validation is a UX enhancement, server-side is critical for security).
*   Business logic execution.
*   Database interactions.
*   Integration with Object Storage.
*   Rate limiting (can be handled by WAF/Load Balancer or within the API).

### 6.2. Endpoint Specifications

All endpoints will be served over HTTPS. Responses will be in JSON format, unless specified (e.g., PDF downloads).

#### 6.2.1. Products API

*   **GET /api/products**
    *   **Description:** Retrieves a list of all active PharmaCorp products.
    *   **Request:** No parameters.
    *   **Response (200 OK):**
        ```json
        [
            {
                "product_id": "uuid-1",
                "name": "Product A",
                "description": "Short description of Product A.",
                "is_active": true
            },
            {
                "product_id": "uuid-2",
                "name": "Product B",
                "description": "Short description of Product B.",
                "is_active": true
            }
        ]
        ```

*   **GET /api/products/{product_id}**
    *   **Description:** Retrieves detailed information for a specific product, including its ISI.
    *   **Request:** `product_id` (UUID) as path parameter.
    *   **Response (200 OK):**
        ```json
        {
            "product_id": "uuid-1",
            "name": "Product A",
            "description": "Comprehensive description of Product A...",
            "indications": "Indications for Product A...",
            "dosage": "Recommended dosage for Product A...",
            "is_active": true,
            "isi_content": {
                "isi_id": "uuid-isi-1",
                "content_html": "<p>Important Safety Information for Product A...</p>"
            },
            "pi_pdf": {
                "pdf_id": "uuid-pdf-1",
                "file_name": "ProductA_PI.pdf",
                "url": "https://cdn.example.com/pdfs/ProductA_PI.pdf" // Direct link from Object Storage/CDN
            }
        }
        ```
    *   **Response (404 Not Found):** If `product_id` does not exist.

#### 6.2.2. Content Pages API

*   **GET /api/pages/{slug}**
    *   **Description:** Retrieves content for general static pages (e.g., About Us) and legal pages (Privacy Policy, Terms of Use).
    *   **Request:** `slug` (string, e.g., 'about-us', 'privacy-policy') as path parameter.
    *   **Response (200 OK):**
        ```json
        {
            "page_id": "uuid-page-1",
            "slug": "about-us",
            "title": "About PharmaCorp",
            "content_html": "<p>Learn more about PharmaCorp...</p>",
            "last_updated": "2023-10-27T10:00:00Z"
        }
        ```
    *   **Response (404 Not Found):** If `slug` does not exist.

#### 6.2.3. Contact Form API

*   **POST /api/contact**
    *   **Description:** Submits a contact inquiry.
    *   **Request Body (JSON):**
        ```json
        {
            "name": "John Doe",
            "email": "john.doe@example.com",
            "subject": "Inquiry about Products",
            "message": "I would like to know more about..."
        }
        ```
    *   **Response (201 Created):**
        ```json
        {
            "message": "Your inquiry has been submitted successfully.",
            "submission_id": "uuid-submission-1"
        }
        ```
    *   **Response (400 Bad Request):** If input validation fails.
    *   **Response (429 Too Many Requests):** If rate limit is exceeded.

#### 6.2.4. Newsletter API

*   **POST /api/newsletter/subscribe**
    *   **Description:** Subscribes an email address to the newsletter.
    *   **Request Body (JSON):**
        ```json
        {
            "email": "subscriber@example.com"
        }
        ```
    *   **Response (201 Created):**
        ```json
        {
            "message": "You have successfully subscribed to our newsletter.",
            "subscriber_id": "uuid-subscriber-1"
        }
        ```
    *   **Response (400 Bad Request):** If email is invalid or already subscribed.
    *   **Response (429 Too Many Requests):** If rate limit is exceeded.

#### 6.2.5. Search API

*   **GET /api/search?q={query}**
    *   **Description:** Performs a full-text search across website content (pages and products).
    *   **Request Parameters:** `q` (string, search query).
    *   **Response (200 OK):**
        ```json
        [
            {
                "type": "product",
                "id": "uuid-product-1",
                "title": "Product A: Diabetes Medication",
                "description": "Learn about Product A, our leading diabetes medication...",
                "url": "/products/product-a"
            },
            {
                "type": "page",
                "id": "uuid-page-2",
                "title": "About Us",
                "description": "PharmaCorp's mission in healthcare...",
                "url": "/about-us"
            }
        ]
        ```
    *   **Response (200 OK - No Results):** `[]` (empty array)

## 7. System Diagrams

### 7.1. High-Level Architecture Diagram

```mermaid
graph TD
    A[User Browser/Client] --> B{CDN / WAF / Load Balancer};

    subgraph Frontend Delivery
        B --> C[Static Frontend Assets (HTML, CSS, JS)];
    end

    subgraph Backend Services
        B --> D[Backend API Service (Python: FastAPI/Flask)];
        D --> E[PostgreSQL Database];
        D --> F[Object Storage (PI/MedGuide PDFs)];
    end

    subgraph CI/CD Pipeline
        G[Developer] --> H[Git Repository];
        H --> I[CI/CD Pipeline];
        I --> J{Dev Environment};
        I --> K{Staging Environment};
        I --> L{Production Environment};
        J --> D;
        K --> D;
        L --> D;
        I --> C;
    end

    M[Monitoring & Logging] <-- D;
    M <-- B;
```

### 7.2. Key Data Flow Diagram (Product Detail Page)

```mermaid
graph TD
    A[User Browser] -->|1. Request /products/product-a| B{CDN / WAF / Load Balancer};
    B -->|2. Serve Static Frontend| C[Frontend App (HTML, JS)];
    C -->|3. Fetch Product Data (API Call)| D[Backend API Service (Python)];
    D -->|4. Query Product Details| E[PostgreSQL Database];
    E -->|5. Return Product Data + ISI| D;
    D -->|6. Get PI PDF URL/Key| F[Object Storage];
    F -->|7. Return PDF URL| D;
    D -->|8. Return Product Data (JSON)| C;
    C -->|9. Render Product Page with ISI & Download Link| A;
    A -->|10. User Clicks 'Download PI PDF'| B;
    B -->|11. Direct Request for PDF| F;
    F -->|12. Serve PI PDF| A;
```

## 8. Future Considerations / Enhancements

*   **CMS Integration:** For managing content (products, pages, news) more efficiently by non-technical users.
*   **Analytics:** Integration with analytics platforms (e.g., Google Analytics, Matomo) for tracking user behavior.
*   **Email Service:** For sending confirmation emails (contact form, newsletter) and potentially the newsletter itself.
*   **User Accounts/Authentication:** If future requirements involve personalized content or restricted access.
*   **Caching Layer (Redis/Memcached):** For frequently accessed data (e.g., product lists, popular pages) to reduce database load and further improve API response times.
*   **Advanced Search:** For more complex search requirements, integrating a dedicated search engine like Elasticsearch or Solr.