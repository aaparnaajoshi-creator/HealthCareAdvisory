# User Stories for Patient Enrollment Integration

This document outlines the user stories and their acceptance criteria for the integration of the Patient Enrollment Portal with the Healthcare Patient Database.

---

## US-001: Receive New Patient Enrollment Submission

*   **As the Patient Enrollment System,**
*   **I want to automatically receive new patient enrollment forms submitted via the portal,**
*   **so that I can initiate the patient record creation process.**

### Acceptance Criteria

*   **GIVEN** a new patient enrollment form is successfully submitted through the Patient Enrollment Portal
*   **WHEN** the form submission triggers a call to the system's API endpoint (deployed on CloudHub/Private Healthcare Cloud)
*   **THEN** the system shall validate the API call using a JWT token.
*   **AND** the system shall decrypt any Protected Health Information (PHI) within the payload using encryption.
*   **AND** the system shall successfully receive and acknowledge the submission via its HTTPS endpoint.
*   **AND** the received payload shall adhere to the defined RAML/OpenAPI specification for patient enrollment.

---

## US-002: Map Patient Enrollment Data

*   **As the Patient Enrollment System,**
*   **I want to accurately map specific fields from the submitted enrollment form to the corresponding fields in the Patients database table,**
*   **so that patient data is correctly prepared for storage.**

### Acceptance Criteria

*   **GIVEN** a new patient enrollment submission has been successfully received and validated
*   **WHEN** the system processes the enrollment form data
*   **THEN** the system shall transform the payload using DataWeave (or equivalent transformation logic).
*   **AND** the following fields from the Enrollment Form shall be mapped to the Patients table:
    *   Patient Full Name → `patient_name`
    *   Date of Birth → `dob`
    *   Gender → `gender`
    *   Address → `address_line1`
    *   City → `city`
    *   State/Region → `state`
    *   Postal Code → `postal_code`
    *   Phone Number → `contact_phone`
    *   Insurance Policy Number → `insurance_id`
*   **AND** a unique, system-generated `patient_id` shall be created and assigned for the new patient record.
*   **AND** the mapped data shall conform to the data types and constraints of the target database fields.

---

## US-003: Insert New Patient Record into Database

*   **As the Patient Enrollment System,**
*   **I want to successfully insert the mapped patient data as a new record into the Healthcare Patient Database,**
*   **so that new patient information is permanently stored.**

### Acceptance Criteria

*   **GIVEN** patient enrollment data has been successfully mapped and validated
*   **WHEN** the system attempts to insert the data into the Healthcare Patient DB (e.g., PostgreSQL / Oracle Healthcare instance)
*   **THEN** a new record shall be successfully inserted into the `Patients` table.
*   **AND** the `patient_id` (system-generated), `patient_name`, `dob`, `gender`, `address_line1`, `city`, `state`, `postal_code`, `contact_phone`, and `insurance_id` fields shall be populated in the new record.
*   **AND** the database connection shall use securely stored credentials.
*   **AND** the system shall utilize the configured Database Connector for the insertion.

---

## US-004: Handle Database Insertion Failures and Notify IT Support

*   **As the Patient Enrollment System,**
*   **I want to robustly handle failures during patient record insertion, log the errors, and notify the Healthcare IT support group,**
*   **so that operational issues can be promptly addressed and data integrity maintained.**

### Acceptance Criteria

*   **GIVEN** the system attempts to insert a new patient record into the Healthcare Patient DB
*   **WHEN** the database insertion fails due to any reason, including but not limited to:
    *   Database unavailability
    *   Data validation error (e.g., incorrect data type, missing required field)
    *   Duplicate `patient_id` (if not pre-validated or handled by DB constraint)
    *   Any other technical error during insertion
*   **THEN** the failure shall be logged by the system's global error handler.
*   **AND** sensitive data (e.g., Insurance ID) shall be masked in the log entries.
*   **AND** an email notification shall be sent to the "Healthcare IT support group" using the Email Connector.
*   **AND** the email notification shall include relevant details of the failure (e.g., timestamp, error message, affected patient data - masked if sensitive) to aid in troubleshooting.
*   **AND** the system shall gracefully terminate processing for that specific patient enrollment upon insertion failure, without reattempting the insertion unless explicitly configured for retry.