### **Impact Assessment: INC-45892**

---

#### **1. Analysis Summary**

*   **Incident Classification:** **Bug**
*   **Justification:** The reported behavior contradicts the primary project goal of providing "clear, upfront shipping cost calculations." While existing user story **US-302** only explicitly requires the displayed address to update, the logical expectation of the checkout workflow is that all dependent costs (like shipping) recalculate when a fundamental input (the address) is changed. The provided code snippet from `CheckoutPage.js` further confirms this is an implementation error, as the effect hook responsible for fetching the shipping cost is configured to run only once on page load and not when the `shippingAddress` state changes.

#### **2. Detailed Impact Assessment**

*   **Functional Impact:**
    *   **User Workflow:** The "Standard Checkout" workflow, as described in the **Functional Screen Flow**, is significantly impaired. When a user changes their shipping address on the `/checkout` screen, the Order Summary fails to update. This presents the user with an incorrect total cost, leading to confusion, potential for incorrect billing, and a high risk of cart abandonment, directly opposing the project's primary goal.
    *   **Affected UI Components/Screens:**
        *   **Checkout Page (`/checkout`):** The core of the impact is on this page.
        *   **Order Summary Panel:** This component displays stale/incorrect shipping cost data.
        *   **Change Address Modal:** The action of selecting a new address in this modal triggers the bug.
    *   **Corrected Behavior:** After a user selects a new address, the frontend application must trigger an asynchronous call to fetch the updated shipping quote. Upon receiving the new quote, the "Order Summary" panel on the `/checkout` page must immediately refresh to display the correct shipping cost and the new order total.

*   **Design & Architectural Impact:**
    *   **Frontend (React App):** This is the primary component requiring modification. The state management logic within the `CheckoutPage.js` component must be updated. Specifically, the `useEffect` hook or a new handler function must be implemented to re-trigger the shipping cost calculation whenever the `shippingAddress` state is modified.
    *   **Checkout Orchestrator Service (Node.js):** No changes are required. The service already exposes the necessary logic for quoting, which the frontend can call.
    *   **Shipping Service (Java/Spring Boot):** No changes are required. The existing `POST /api/v1/shipping/quote` endpoint is sufficient and will be re-used.

*   **Data Flow Impact:**
    *   A new client-side initiated data flow will be introduced post-page-load.
    *   Currently, the shipping quote is only fetched once when the checkout page loads.
    *   The fix will introduce a new flow:
        1.  User changes address in the UI.
        2.  The **Frontend (React App)** sends a request with the new address and cart details to the **Shipping Service** (likely via an API Gateway or the **Checkout Orchestrator**).
        3.  The **Shipping Service** returns a new quote.
        4.  The **Frontend** updates the UI state, re-rendering the Order Summary panel.

*   **Database Impact:**
    *   No database impact identified.

#### **3. Recommendations**

*   **Affected User Stories:**
    *   This bug relates to **US-301 (Calculate Initial Shipping Cost)** and **US-302 (Change Shipping Address)**.
    *   It is recommended to update **US-302** with a new acceptance criterion to prevent future regressions: *"AC4: Upon selecting a new shipping address, the shipping cost in the Order Summary is automatically recalculated and updated."*

*   **Risks:**
    *   **Performance:** Rapidly changing the selected address could trigger numerous API calls. The frontend fix should include a debounce mechanism (e.g., 300ms) on the address change handler to prevent excessive load on the backend services.
    *   **API Latency:** A slow response from the Shipping Service could lead to a noticeable delay between the user changing their address and the price updating, causing a poor user experience. A loading indicator should be briefly displayed on the Order Summary panel while the new cost is being calculated.

*   **Estimated Effort:** **S (Small)**
    *   **Justification:** The required change is isolated to a single frontend component (`CheckoutPage.js`). No backend or database modifications are needed. The effort consists of modifying React state management logic, adding one API call, implementing a debounce, and associated unit/integration testing.