# High-Level Design (HLD) Document: PharmaCorp Commercial Website

## 1. Introduction

This High-Level Design (HLD) document outlines the architectural blueprint for the PharmaCorp Commercial Website. It details the system's components, their interactions, data models, and key API endpoints, addressing the provided user stories and technical constraints. The primary goal is to deliver a secure, performant, accessible, and compliant web presence for PharmaCorp, serving both patients and Healthcare Professionals (HCPs).

## 2. Architectural Overview

The PharmaCorp Commercial Website will adopt a decoupled, client-server architecture. The frontend will be a modern Single Page Application (SPA) or a set of static pages built with a JavaScript framework, served via a Content Delivery Network (CDN) for optimal performance. The backend will consist of a Python-based API service handling data interactions with a PostgreSQL database and an object storage solution.

### 2.1. High-Level Architecture Diagram

```mermaid
graph TD
    subgraph Client Tier
        A[Client Browser]
    end

    subgraph Web Tier
        B(CDN / Web Server)
    end

    subgraph Application Tier
        C{PharmaCorp Frontend App (HTML5 + JS)}
        D[Backend API Service (Python FastAPI)]
    end

    subgraph Data Tier
        E[PostgreSQL Database]
        F[Object Storage (e.g., S3-compatible)]
    end

    A -- Request --> B
    B -- Serves Static Assets --> C
    C -- API Calls (HTTPS) --> D
    D -- Queries / Stores --> E
    D -- Stores / Retrieves --> F

    style A fill:#f9f,stroke:#333,stroke-width:2px
    style B fill:#bbf,stroke:#333,stroke-width:2px
    style C fill:#ccf,stroke:#333,stroke-width:2px
    style D fill:#cfc,stroke:#333,stroke-width:2px
    style E fill:#ffc,stroke:#333,stroke-width:2px
    style F fill:#fcf,stroke:#333,stroke-width:2px
```

**Explanation of Components:**

*   **Client Browser:** The end-user's web browser, responsible for rendering the website.
*   **CDN / Web Server:** Serves static frontend assets (HTML, CSS, JavaScript, images) with low latency, leveraging caching for performance. It also handles HTTPS termination.
*   **PharmaCorp Frontend App (HTML5 + JS):** A responsive, accessible web application built using a modern JavaScript framework. It interacts with the Backend API for dynamic content and form submissions.
*   **Backend API Service (Python FastAPI):** A RESTful API built with Python FastAPI, responsible for serving dynamic content, processing form submissions, and interacting with the database and object storage. It enforces server-side validation and rate limiting.
*   **PostgreSQL Database:** The primary data store for all structured data, including product information, static page content, contact form submissions, and newsletter subscriptions.
*   **Object Storage:** Used for storing large binary assets such as Prescribing Information (PI) and Medication Guide (MedGuide) PDFs.

## 3. Component Deep Dive

### 3.1. Frontend Application

*   **Technology:** Modern JavaScript Framework (e.g., React, Vue, or similar) compiled into HTML5, CSS, and JavaScript. This approach facilitates responsiveness, component reusability, and maintainability.
*   **Responsibilities:**
    *   Rendering all website pages (Home, About Us, Products List, Product Detail, Contact Us, Legal pages).
    *   Handling user interactions (navigation, form submissions, search).
    *   Ensuring responsiveness across desktop, tablet, and mobile breakpoints.
    *   Implementing WCAG 2.2 AA accessibility standards (semantic HTML, sufficient color contrast, keyboard navigability).
    *   Client-side input validation for forms.
    *   Cookie consent management (US12).
    *   Displaying sticky Important Safety Information (ISI) (US9).
    *   Direct linking to PDFs stored in Object Storage for download (US10).
*   **Performance:** Leveraging optimized asset loading, image optimization, and potentially Server-Side Rendering (SSR) or Static Site Generation (SSG) for improved Largest Contentful Paint (LCP) performance, especially for the Home page (< 2.5 seconds).

### 3.2. Backend API Service

*   **Technology:** Python with FastAPI framework. FastAPI provides high performance, automatic OpenAPI documentation, and robust data validation features using Pydantic.
*   **Responsibilities:**
    *   Exposing RESTful API endpoints for all dynamic data needs.
    *   Processing requests for product data, static page content, search queries.
    *   Receiving and validating contact form and newsletter subscription submissions.
    *   Interacting with the PostgreSQL database for data retrieval and storage.
    *   Implementing server-side input validation, rate limiting (US7, US8), and other security measures.
    *   Handling potential errors gracefully and providing informative responses.

### 3.3. Database (PostgreSQL)

*   **Technology:** PostgreSQL. Chosen for its robustness, reliability, support for complex queries (e.g., full-text search), and open-source nature.
*   **Responsibilities:**
    *   Storing all structured data, ensuring data integrity and consistency.
    *   Providing efficient retrieval of data for the API.

#### 3.3.1. Database Schema Design

*   **`products` Table:**
    *   `product_id` (UUID/INT, PRIMARY KEY)
    *   `name` (VARCHAR(255), NOT NULL)
    *   `short_description` (TEXT)
    *   `full_description` (TEXT)
    *   `indications` (TEXT)
    *   `usage_info` (TEXT)
    *   `isi_content` (TEXT) - Important Safety Information
    *   `pi_pdf_url` (VARCHAR(512)) - URL to Prescribing Information PDF in Object Storage
    *   `medguide_pdf_url` (VARCHAR(512)) - URL to Medication Guide PDF in Object Storage
    *   `created_at` (TIMESTAMP WITH TIME ZONE, DEFAULT NOW())
    *   `updated_at` (TIMESTAMP WITH TIME ZONE, DEFAULT NOW())
    *   *Indexes:* `name`, `full_description` (for full-text search)

*   **`static_pages` Table:**
    *   `page_id` (UUID/INT, PRIMARY KEY)
    *   `slug` (VARCHAR(255), UNIQUE, NOT NULL) - e.g., 'about-us', 'contact-us', 'privacy-policy'
    *   `title` (VARCHAR(255), NOT NULL)
    *   `content` (TEXT)
    *   `created_at` (TIMESTAMP WITH TIME ZONE, DEFAULT NOW())
    *   `updated_at` (TIMESTAMP WITH TIME ZONE, DEFAULT NOW())
    *   *Indexes:* `slug`, `content` (for full-text search)

*   **`contact_submissions` Table:**
    *   `submission_id` (UUID/INT, PRIMARY KEY)
    *   `name` (VARCHAR(255), NOT NULL)
    *   `email` (VARCHAR(255), NOT NULL)
    *   `subject` (VARCHAR(255))
    *   `message` (TEXT, NOT NULL)
    *   `submission_timestamp` (TIMESTAMP WITH TIME ZONE, DEFAULT NOW())

*   **`newsletter_subscribers` Table:**
    *   `subscriber_id` (UUID/INT, PRIMARY KEY)
    *   `email` (VARCHAR(255), UNIQUE, NOT NULL)
    *   `consent_given` (BOOLEAN, NOT NULL) - For GDPR/CCPA
    *   `subscription_timestamp` (TIMESTAMP WITH TIME ZONE, DEFAULT NOW())

### 3.4. Object Storage

*   **Technology:** Any S3-compatible object storage solution.
*   **Responsibilities:**
    *   Securely storing large binary files such as PI and MedGuide PDFs (US10).
    *   Providing highly available and durable storage.
    *   Serving files directly to the client via secure, publicly accessible URLs (referenced in the `products` table).

### 3.5. Security & Compliance

*   **HTTPS:** All communication between the client, CDN, and Backend API will be encrypted using HTTPS.
*   **Content Security Policy (CSP):** Implemented on the frontend to mitigate Cross-Site Scripting (XSS) and data injection attacks by specifying approved sources of content.
*   **Rate Limiting:** Implemented on the Backend API for endpoints like contact form submission and newsletter signup (US7, US8) to prevent abuse and denial-of-service attacks.
*   **Input Validation:** Both client-side (for user experience) and server-side (for security) validation will be performed on all user inputs (e.g., contact forms, newsletter signups) to prevent injection attacks and ensure data integrity.
*   **WCAG 2.2 AA:** Frontend development will adhere to these guidelines for accessibility, including semantic HTML, keyboard navigability, sufficient color contrast, and ARIA attributes.
*   **GDPR & CCPA Compliance:**
    *   Cookie consent banner (US12) allowing granular control over cookie preferences.
    *   Clear statements on data usage for contact forms (US7) and newsletter signups (US8).
    *   Opt-in consent checkboxes for newsletter subscriptions (US8).
    *   Data minimization principles applied to collected data.
    *   Secure storage and transmission of personal data.

### 3.6. Deployment & Operations

*   **Environments:** Separate environments for Development, Staging, and Production.
*   **CI/CD Pipeline:** Automated Continuous Integration/Continuous Deployment pipelines for both frontend and backend applications.
    *   **CI:** Automated testing (unit, integration), code quality checks, and build processes.
    *   **CD:** Automated deployment to respective environments upon successful CI.
*   **Containerization (Optional but Recommended):** Docker containers for the Backend API and PostgreSQL can facilitate consistent deployments across environments.
*   **Monitoring & Logging:** Centralized logging and monitoring solutions to track application performance, errors, and security events.

## 4. API Design

The Backend API will expose RESTful endpoints, primarily serving JSON data.

| Endpoint                               | Method | Description                                                                   | User Story Covered |
| :------------------------------------- | :----- | :---------------------------------------------------------------------------- | :----------------- |
| `/api/products`                        | `GET`  | Retrieve a list of all PharmaCorp products with brief details.                | US3                |
| `/api/products/{id}`                   | `GET`  | Retrieve detailed information for a specific product, including ISI content.  | US4, US9           |
| `/api/pages/{slug}`                    | `GET`  | Retrieve content for a specific static page (e.g., 'about-us', 'privacy').    | US2, US5, US6      |
| `/api/contact`                         | `POST` | Submit a contact form inquiry.                                                | US7                |
| `/api/newsletter/subscribe`            | `POST` | Subscribe an email address to the newsletter.                                 | US8                |
| `/api/search?q={query}`                | `GET`  | Perform a site-wide search for content (products, static pages) based on query. | US11               |

### 4.1. Example API Request/Response Formats

#### 4.1.1. `GET /api/products/{id}`

*   **Request:**
    ```
    GET /api/products/123e4567-e89b-12d3-a456-426614174000
    ```
*   **Response (HTTP 200 OK):**
    ```json
    {
        "product_id": "123e4567-e89b-12d3-a456-426614174000",
        "name": "PharmaDrug X",
        "short_description": "A breakthrough medication for condition Y.",
        "full_description": "PharmaDrug X is indicated for...",
        "indications": "Treatment of chronic condition Y.",
        "usage_info": "Take one tablet daily with food.",
        "isi_content": "Important Safety Information: Do not use if pregnant...",
        "pi_pdf_url": "https://object-storage.example.com/pdfs/pharma-drug-x-pi.pdf",
        "medguide_pdf_url": "https://object-storage.example.com/pdfs/pharma-drug-x-medguide.pdf"
    }
    ```

#### 4.1.2. `POST /api/contact`

*   **Request (HTTP 200 OK):**
    ```json
    {
        "name": "John Doe",
        "email": "john.doe@example.com",
        "subject": "Inquiry about PharmaDrug X",
        "message": "I have a question regarding the dosage of PharmaDrug X."
    }
    ```
*   **Response (HTTP 201 Created):**
    ```json
    {
        "message": "Your inquiry has been successfully sent.",
        "submission_id": "a1b2c3d4-e5f6-7890-1234-567890abcdef"
    }
    ```
*   **Response (HTTP 400 Bad Request - Validation Error):**
    ```json
    {
        "detail": [
            {
                "loc": ["body", "email"],
                "msg": "value is not a valid email address",
                "type": "value_error.email"
            }
        ]
    }
    ```

## 5. Data Flow Diagrams

### 5.1. Product Detail Page Load Data Flow (US4, US9, US10)

```mermaid
sequenceDiagram
    participant C as Client Browser
    participant FE as Frontend App
    participant API as Backend API Service
    participant DB as PostgreSQL DB
    participant OS as Object Storage

    C->>FE: 1. Navigates to Product Detail Page (/products/{id})
    FE->>API: 2. GET /api/products/{id} (Request for product data)
    API->>DB: 3. SELECT * FROM products WHERE product_id = {id}
    DB-->>API: 4. Product Data (Name, Desc, ISI, PDF_URLs)
    API-->>FE: 5. Product Data JSON (HTTP 200 OK)
    FE->>C: 6. Renders Product Detail Page with Product Info and Sticky ISI
    FE->>C: 7. Presents Download Links for PI/MedGuide
    C->>OS: 8. User Clicks Download Link -> Direct Download from Object Storage
```

### 5.2. Contact Form Submission Data Flow (US7)

```mermaid
sequenceDiagram
    participant C as Client Browser
    participant FE as Frontend App
    participant API as Backend API Service
    participant DB as PostgreSQL DB

    C->>FE: 1. Navigates to Contact Us Page
    FE->>C: 2. Displays Contact Form
    C->>FE: 3. Fills Form, Clicks Submit (Client-side Validation)
    FE->>API: 4. POST /api/contact (HTTPS, Rate Limit Applied)
    API->>API: 5. Server-side Input Validation
    alt Validation Fails
        API-->>FE: 6. HTTP 400 Bad Request (Validation Errors)
        FE->>C: 7. Displays Validation Errors
    else Validation Succeeds
        API->>DB: 6. INSERT INTO contact_submissions (...)
        DB-->>API: 7. Success
        API-->>FE: 8. HTTP 201 Created (Confirmation Message)
        FE->>C: 9. Displays Confirmation Message
    end
```