# High-Level Design for Real-Time Bidding (RTB) System

**Version:** 2.0
**Date:** 2023-10-27

## 1. Introduction

This document outlines the high-level design for a Real-Time Bidding (RTB) system. The system allows advertisers to create and manage ad campaigns, bid on ad inventory in real-time, and serve ads to end-users. This document details the system's architecture, components, data models, and APIs.

## 2. Requirements

### 2.1 Functional Requirements

-   **FR1:** Advertisers must be able to create and manage ad campaigns.
-   **FR2:** Advertisers must be able to create and upload ad creatives, which are the actual ad content to be displayed.
-   **FR3:** The system must support --[image-based ad creatives]--`++[image and video-based ad creatives]++`.
-   `++[FR4: Advertisers must be able to upload video files for video ad creatives.]++`
-   `++[FR5: The system must transcode uploaded videos into multiple formats and resolutions to ensure broad device compatibility and optimize for bandwidth.]++`
-   **--[FR4]--`++[FR6]++`:** The system must provide a bidding component that can respond to bid requests from ad exchanges in under 100ms.
-   **--[FR5]--`++[FR7]++`:** The system must track key metrics for ad performance, such as impressions and clicks.
-   `++[FR8: The system must track video-specific metrics, such as view counts and completion rates.]++`

### 2.2 Non-Functional Requirements

-   **NFR1 (Low Latency):** Bid responses must be generated and returned to the ad exchange within 100 milliseconds.
-   **NFR2 (High Availability):** The system should have an uptime of 99.99%. All components must be redundant.
-   **NFR3 (Scalability):** The system must be able to handle a load of at least 100,000 bid requests per second.
-   **NFR4 (Security):** All external communication must be over HTTPS. Sensitive data in the database should be encrypted.

## 3. System Architecture

### 3.1 Architecture Diagram

The system follows a microservices architecture to ensure scalability and separation of concerns.

--[
```
+----------------+      +----------------+      +----------------+
|                |      |                |      |                |
| Advertiser UI  +----->+  API Gateway   +----->+    Ad Server   |
| (React App)    |      | (e.g., NGINX)  |      | (Manages Ads)  |
|                |      |                |      |                |
+----------------+      +-------+--------+      +-------+--------+
                                |                 /|\    |
                                |                  |     |
                               \|/                 |    \|/
+----------------+      +----------------+      +-------+--------+
|                |      |                |      |                |
| Ad Exchange    +----->+ Bidder Service +----->+   Database     |
| (e.g., OpenRTB)|      | (Real-time)    |      | (PostgreSQL)   |
|                |      |                |      |                |
+----------------+      +----------------+      +----------------+
```
]--
`++[
```
+----------------+      +----------------+      +----------------+      +-----------------------+
|                |      |                |      |                |      |                       |
| Advertiser UI  +----->+  API Gateway   +----->+    Ad Server   +----->+ Video Transcoding Svc |
| (React App)    |      | (e.g., NGINX)  |      | (Manages Ads)  |      | (e.g., Lambda/FFmpeg) |
|                |      |                |      |      /|\       |      |           /|\         |
+----------------+      +-------+--------+      +-------+--------+      +------------+----------+
                                |                 |     |                           |
                                |                 |     |                           |
                               \|/                |     |                          \|/
+----------------+      +----------------+      +-------+--------+      +-----------------------+
|                |      |                |      |                |      |                       |
| Ad Exchange    +----->+ Bidder Service +----->+   Database     |      |  Media Storage        |
| (e.g., OpenRTB)|      | (Real-time)    |      | (PostgreSQL)   | <----+  (e.g., S3/GCS)       |
|                |      |                |      |                |      |                       |
+----------------+      +----------------+      +----------------+      +-----------------------+
```
]++`

### 3.2 Component Descriptions

-   **Advertiser UI:** A web-based interface (React) for advertisers to manage their campaigns and creatives.
-   **API Gateway:** The single entry point for all client requests. It handles routing, rate limiting, and authentication.
-   **Ad Server:** A service responsible for CRUD operations on campaigns and ads. It manages ad metadata and business logic. `++[It also orchestrates the video upload and transcoding process by communicating with the Media Storage and Video Transcoding Service.]++`
-   **Bidder Service:** A high-performance, low-latency service that listens for bid requests from ad exchanges, decides whether to bid, and determines the bid price based on campaign targeting rules.
-   **Database:** A PostgreSQL database for storing campaign data, ad metadata, and performance metrics.
-   `++[**Video Transcoding Service:** A dedicated service responsible for processing uploaded video files. It converts videos into multiple formats and resolutions (e.g., 1080p, 720p, 480p in H.264 MP4) to ensure compatibility across different devices and network conditions. This can be implemented using serverless functions (e.g., AWS Lambda) triggered by file uploads.]++`
-   `++[**Media Storage:** A scalable object storage solution (e.g., AWS S3 or Google Cloud Storage) for storing raw uploaded video files and the resulting transcoded video assets.]++`

## 4. Data Model

### 4.1 `campaigns` table

| Column        | Data Type | Description                              |
|---------------|-----------|------------------------------------------|
| `id`          | `UUID`    | Primary Key                              |
| `name`        | `VARCHAR` | Name of the campaign                     |
| `budget`      | `DECIMAL` | Total budget for the campaign            |
| `start_date`  | `TIMESTMP`| Campaign start date                      |
| `end_date`    | `TIMESTMP`| Campaign end date                        |
| `created_at`  | `TIMESTMP`| Timestamp of creation                    |

### 4.2 `ads` table

| Column           | Data Type            | Description                                                                 |
|------------------|----------------------|-----------------------------------------------------------------------------|
| `id`             | `UUID`               | Primary Key                                                                 |
| `campaign_id`    | `UUID`               | Foreign key to `campaigns` table                                            |
| `ad_type`        | `ENUM('IMAGE', --['VIDEO']--`++['VIDEO'])`++` | Type of the ad creative                                                     |
| `--[image_url]--`    | `--[VARCHAR]--`          | `--[URL of the hosted image creative.]--`                                       |
| `creative_url`   | `VARCHAR`            | `++[URL of the hosted creative (image URL or master video playlist URL).]++` |
| `click_url`      | `VARCHAR`            | The landing page URL when the ad is clicked.                                |
| `cpm`            | `DECIMAL`            | Cost per mille (thousand impressions) for this ad.                          |
| `created_at`     | `TIMESTMP`           | Timestamp of creation                                                       |
| `++[duration]++`       | `++[INTEGER]++`            | `++[Duration of the video in seconds (NULL for images).]++`                  |
| `++[mime_type]++`      | `++[VARCHAR]++`            | `++[MIME type of the primary video file (e.g., 'video/mp4', NULL for images).]++` |

### 4.3 `ad_metrics` table

| Column           | Data Type | Description                                        |
|------------------|-----------|----------------------------------------------------|
| `ad_id`          | `UUID`    | Foreign key to `ads` table                         |
| `timestamp`      | `TIMESTMP`| The hour for which metrics are aggregated        |
| `impressions`    | `BIGINT`  | Number of times the ad was shown                   |
| `clicks`         | `BIGINT`  | Number of times the ad was clicked                 |
| `++[view_count]++`       | `++[BIGINT]++`  | `++[Number of times the video ad was viewed.]++`        |
| `++[completion_rate]++`| `++[DECIMAL]++` | `++[Percentage of completed video views (0.0 to 1.0).]++` |
| **PRIMARY KEY**  | (`ad_id`, `timestamp`) |                                            |

## 5. API Specification

### 5.1 Ad Management API

#### `POST /ads`

Creates a new ad creative.

**Request Body:**
```json
{
  "campaign_id": "c9e4b2d8-3e4f-4a1c-9b0d-7e8f6a5c4b3d",
  "ad_type": "IMAGE", --[// or "VIDEO"]--
  "creative_url": "https://cdn.example.com/image.jpg",
  "click_url": "https://advertiser.com/product"
}
```

`++[
**Request Body (Video Example):**
```json
{
  "campaign_id": "c9e4b2d8-3e4f-4a1c-9b0d-7e8f6a5c4b3d",
  "ad_type": "VIDEO",
  "creative_url": "https://media.example.com/video_upload_presigned_url",
  "click_url": "https://advertiser.com/product",
  "duration": 30,
  "mime_type": "video/mp4"
}
```
]++`

**Response:** `201 Created` with the ad object.

#### `GET /ads/{id}`

Retrieves an existing ad creative.

**Response:** `200 OK` with the ad object.

## 6. Security

-   **Authentication:** The API Gateway will use JWT (JSON Web Tokens) to authenticate requests from the Advertiser UI.
-   **Authorization