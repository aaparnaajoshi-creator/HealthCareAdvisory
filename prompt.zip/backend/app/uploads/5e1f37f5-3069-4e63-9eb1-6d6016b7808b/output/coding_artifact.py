# PharmaCorp Commercial Website - Application Code

## backend/app/main.py