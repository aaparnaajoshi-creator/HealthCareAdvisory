<!-- about.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About - Pharma Inc.</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav>
        <a href="/">Home</a> |
        <a href="/about">About Us</a> |
        <a href="/products">Products</a> |
        <a href="/contact">Contact Us</a>
    </nav>
    <div class="content">
        <h1>About Us</h1>
        <p>Founded in 2005, Pharma Inc. has been dedicated to discovering and developing life-changing medicines.</p>
        ++ ADDED START ++
        <h2>Our Values</h2>
        <ul>
            <li>Innovation: Continuously seeking new and better solutions for healthcare challenges.</li>
            <li>Integrity: Upholding the highest ethical standards in all our operations.</li>
            <li>Patient-Centricity: Prioritizing the well-being and needs of patients above all else.</li>
            <li>Collaboration: Fostering partnerships to accelerate scientific discovery and improve global health.</li>
        </ul>
        ++ ADDED END ++
    </div>
</body>
</html>