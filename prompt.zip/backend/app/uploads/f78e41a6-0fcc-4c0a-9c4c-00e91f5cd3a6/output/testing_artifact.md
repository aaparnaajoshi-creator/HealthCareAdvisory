```markdown
# PharmaCorp Commercial Website - Testing Document

## 1. Test Strategy

### 1.1. Scope

This test strategy covers the testing of the PharmaCorp commercial website, encompassing all functionalities and features as defined in the Software Requirements Specification (SRS) and High-Level Design (HLD) documents. The testing scope includes:

*   Core Pages and Navigation
*   Product Information
*   Contact and Communication
*   Site Functionality and Compliance
*   Privacy/Terms Page
*   Content Management System (CMS)
*   CI/CD Pipeline
*   Security
*   Accessibility
*   Performance

### 1.2. Objectives

The primary objectives of testing are to:

*   Verify that the website meets all functional and non-functional requirements outlined in the SRS.
*   Ensure the website is user-friendly, intuitive, and provides a positive user experience.
*   Identify and resolve any defects or issues before the website is released to production.
*   Validate the security and compliance of the website with relevant regulations (GDPR, CCPA, WCAG 2.2 AA).
*   Confirm the performance and scalability of the website under expected load conditions.
*   Ensure the website functions correctly across different browsers, devices, and operating systems.
*   Verify the accuracy of data stored in the PostgreSQL database.

### 1.3. Types of Testing

The following types of testing will be performed:

*   **Functional Testing:** Verifies that each feature of the website functions as expected according to the SRS. This includes testing navigation, product browsing, contact forms, newsletter signup, search functionality, and other features.
*   **Usability Testing:** Evaluates the ease of use and user-friendliness of the website. This involves observing users as they interact with the website and gathering feedback on their experience.
*   **Regression Testing:** Ensures that new code changes or bug fixes do not introduce new defects or negatively impact existing functionality.
*   **Performance Testing:** Assesses the website's performance under various load conditions. This includes testing page load times, response times, and scalability.
*   **Security Testing:** Identifies and addresses potential security vulnerabilities in the website. This includes testing for XSS, SQL injection, and other common security threats.
*   **Accessibility Testing:** Verifies that the website is accessible to users with disabilities, conforming to WCAG 2.2 AA guidelines. This includes testing with screen readers, keyboard navigation, and color contrast analysis.
*   **Database Testing:** Validates the integrity and accuracy of data stored in the PostgreSQL database. This includes verifying data relationships, constraints, and stored procedures.
*   **CI/CD Pipeline Testing:** Tests the automated build, test, and deployment process across different environments (Dev, Staging, Prod), including rollback scenarios.
*   **Browser Compatibility Testing:** Ensures that the website functions correctly across different browsers (e.g., Chrome, Firefox, Safari, Edge) and versions.
*   **Mobile Testing:** Verifies that the website is responsive and functions correctly on different mobile devices (e.g., smartphones, tablets) and operating systems (e.g., iOS, Android).
*   **Acceptance Testing:** Conducted by stakeholders to determine whether to accept or reject the website.

## 2. Test Plan

### 2.1. Test Cases

**I. Core Pages & Navigation**

*   **TC_01: Verify website navigation menu.**
    *   **Steps:**
        1.  Open the website in a browser.
        2.  Verify that the navigation menu is visible and contains links to Home, About Us, Products, Contact Us, and Privacy/Terms pages.
        3.  Click on each link in the navigation menu.
    *   **Expected Result:**
        *   The navigation menu is visible and contains the correct links.
        *   Clicking on each link navigates to the corresponding page.

*   **TC_02: Verify website responsiveness.**
    *   **Steps:**
        1.  Open the website in a browser.
        2.  Resize the browser window to different screen sizes (e.g., mobile, tablet, desktop).
    *   **Expected Result:**
        *   The website layout adapts correctly to different screen sizes.
        *   The navigation menu remains functional and usable on all screen sizes.

*   **TC_03: Verify website sitemap accessibility.**
    *   **Steps:**
        1.  Access the website's sitemap (e.g., by entering `/sitemap.xml` in the browser's address bar).
    *   **Expected Result:**
        *   The sitemap is accessible and lists all the website's pages.
        *   The sitemap is in a format that is readable by search engines.

*   **TC_04: Verify page reachability.**
    *   **Steps:**
        1.  Navigate to the homepage.
        2.  Attempt to reach every other page on the website within a maximum of 3 clicks.
    *   **Expected Result:**
        *   All pages on the website are reachable within a maximum of 3 clicks from the homepage.

*   **TC_05: Verify keyboard navigation.**
    *   **Steps:**
        1.  Open the website in a browser.
        2.  Use the Tab key to navigate through the website's elements (links, form fields, buttons).
        3.  Use the Enter key to activate links and buttons.
    *   **Expected Result:**
        *   All interactive elements on the website are accessible using the keyboard.
        *   The focus indicator is clearly visible for each element.
        *   The navigation order is logical and intuitive.

*   **TC_06: Verify screen reader compatibility.**
    *   **Steps:**
        1.  Open the website in a browser.
        2.  Activate a screen reader (e.g., NVDA, JAWS).
        3.  Navigate through the website's content using the screen reader.
    *   **Expected Result:**
        *   The screen reader correctly reads the website's content, including text, images (alt text), and form fields.
        *   The website is navigable using screen reader commands.
        *   All ARIA attributes are correctly implemented.

**II. Content Management System (CMS)**

*   **TC_07: Verify page creation.**
    *   **Steps:**
        1.  Log in to the CMS as an administrator.
        2.  Navigate to the page management section.
        3.  Create a new page with a title, content, and slug.
        4.  Save the page.
    *   **Expected Result:**
        *   The page is created successfully and is visible in the page management list.
        *   The page is accessible on the website using the specified slug.

*   **TC_08: Verify page editing.**
    *   **Steps:**
        1.  Log in to the CMS as an administrator.
        2.  Navigate to the page management section.
        3.  Select an existing page to edit.
        4.  Modify the page title, content, or slug.
        5.  Save the changes.
    *   **Expected Result:**
        *   The page is updated successfully and the changes are reflected on the website.

*   **TC_09: Verify page deletion.**
    *   **Steps:**
        1.  Log in to the CMS as an administrator.
        2.  Navigate to the page management section.
        3.  Select an existing page to delete.
        4.  Confirm the deletion.
    *   **Expected Result:**
        *   The page is deleted successfully and is no longer visible on the website.

*   **TC_10: Verify product creation.**
    *   **Steps:**
        1.  Log in to the CMS as an administrator.
        2.  Navigate to the product management section.
        3.  Create a new product with name, description, indications, dosage, administration, and ISI.
        4.  Upload a PI PDF.
        5.  Save the product.
    *   **Expected Result:**
        *   The product is created successfully and is visible in the product management list.
        *   The product is accessible on the website.

*   **TC_11: Verify product editing.**
    *   **Steps:**
        1.  Log in to the CMS as an administrator.
        2.  Navigate to the product management section.
        3.  Select an existing product to edit.
        4.  Modify the product details.
        5.  Save the changes.
    *   **Expected Result:**
        *   The product is updated successfully and the changes are reflected on the website.

*   **TC_12: Verify product deletion.**
    *   **Steps:**
        1.  Log in to the CMS as an administrator.
        2.  Navigate to the product management section.
        3.  Select an existing product to delete.
        4.  Confirm the deletion.
    *   **Expected Result:**
        *   The product is deleted successfully and is no longer visible on the website.

*   **TC_13: Verify media management.**
    *   **Steps:**
        1.  Log in to the CMS as an administrator.
        2.  Navigate to the media management section.
        3.  Upload a new image.
        4.  Verify that the image is displayed correctly.
        5.  Edit the image metadata (e.g., alternative text).
        6.  Delete the image.
    *   **Expected Result:**
        *   The image is uploaded successfully and is displayed correctly.
        *   The image metadata is updated successfully.
        *   The image is deleted successfully.

*   **TC_14: Verify scheduling updates.**
    *   **Steps:**
        1.  Log in to the CMS as an administrator.
        2.  Schedule a page update for a future date and time.
        3.  Verify that the update is applied at the scheduled time.
    *   **Expected Result:**
        *   The page update is scheduled successfully.
        *   The update is applied at the scheduled time.

*   **TC_15: Verify audit logs.**
    *   **Steps:**
        1.  Log in to the CMS as an administrator.
        2.  Navigate to the audit log section.
        3.  Review the audit log for recent content changes.
    *   **Expected Result:**
        *   The audit log displays all recent content changes, including the user who made the changes, the date and time of the changes, and the details of the changes.

*   **TC_16: Verify alternative text management.**
    *   **Steps:**
        1.  Log in to the CMS as an administrator.
        2.  Upload a new image to the media library or add an image to a page/product.
        3.  Verify that the CMS requires alternative text to be entered for the image.
        4.  Enter alternative text for the image.
        5.  Save the image or page/product.
        6.  View the image on the website and inspect the HTML to ensure the alternative text is present in the `alt` attribute.
    *   **Expected Result:**
        *   The CMS requires alternative text to be entered for all images.
        *   The alternative text is saved correctly and is displayed in the `alt` attribute of the image on the website.

**III. Product Information**

*   **TC_17: Verify product listing.**
    *   **Steps:**
        1.  Navigate to the Products page.
    *   **Expected Result:**
        *   All PharmaCorp products are listed with a brief description and image.
        *   The product information is accurate and up-to-date.

*   **TC_18: Verify product filtering and sorting.**
    *   **Steps:**
        1.  Navigate to the Products page.
        2.  Filter the products by name, therapeutic area, or other relevant criteria.
        3.  Sort the products by name or other relevant criteria.
    *   **Expected Result:**
        *   The products are filtered and sorted correctly according to the selected criteria.

*   **TC_19: Verify product detail page.**
    *   **Steps:**
        1.  Navigate to a product detail page.
    *   **Expected Result:**
        *   The product detail page includes the product name, description, indications, dosage, and administration information.
        *   The product detail page includes a prominent Important Safety Information (ISI) section.
        *   The product detail page includes a link to download the full Prescribing Information (PI) PDF.
        *   The product detail page adheres to PharmaCorp's branding guidelines.

*   **TC_20: Verify ISI section stickiness.**
    *   **Steps:**
        1.  Navigate to a product detail page.
        2.  Scroll down the page.
    *   **Expected Result:**
        *   The ISI section remains fixed to the top of the screen as the user scrolls down the page.
        *   The ISI section is clearly distinguishable from the rest of the page content.
        *   The sticky ISI section is responsive and adapts to different screen sizes.
        *   The sticky ISI section does not obscure other important page elements.

*   **TC_21: Verify PI PDF download.**
    *   **Steps:**
        1.  Navigate to a product detail page.
        2.  Click on the link to download the PI PDF.
    *   **Expected Result:**
        *   The PI PDF opens in a new tab or window.
        *   The PI PDF is accessible and searchable.
        *   The filename of the PI PDF includes the product name and version date.

**IV. Contact & Communication**

*   **TC_22: Verify contact form submission.**
    *   **Steps:**
        1.  Navigate to the Contact Us page.
        2.  Fill out the contact form with valid information.
        3.  Submit the form.
    *   **Expected Result:**
        *   The user receives a confirmation message.
        *   The website administrator receives an email notification.
        *   The contact form submission is stored securely in the PostgreSQL database.

*   **TC_23: Verify contact form validation.**
    *   **Steps:**
        1.  Navigate to the Contact Us page.
        2.  Attempt to submit the contact form with missing or invalid information.
    *   **Expected Result:**
        *   The contact form displays error messages for missing or invalid fields.
        *   The form cannot be submitted until all required fields are filled in correctly.

*   **TC_24: Verify newsletter signup.**
    *   **Steps:**
        1.  Navigate to the newsletter signup form.
        2.  Enter a valid email address.
        3.  Check the box to consent to receiving marketing emails.
        4.  Submit the form.
    *   **Expected Result:**
        *   The user receives a confirmation email with a link to verify their subscription.
        *   Email addresses are stored securely and used only for sending the PharmaCorp newsletter.

*   **TC_25: Verify newsletter unsubscription.**
    *   **Steps:**
        1.  Open a PharmaCorp newsletter email.
        2.  Click on the unsubscribe link.
    *   **Expected Result:**
        *   The user is unsubscribed from the newsletter.
        *   The user no longer receives PharmaCorp newsletter emails.

**V. Site Functionality & Compliance**

*   **TC_26: Verify website search.**
    *   **Steps:**
        1.  Enter a search query in the search bar.
    *   **Expected Result:**
        *   Search results are displayed in a clear and organized manner.
        *   Search results include a snippet of text from the relevant page or document.
        *   The search functionality is performant and returns results quickly.

*   **TC_27: Verify cookie consent banner.**
    *   **Steps:**
        1.  Open the website in a browser for the first time.
    *   **Expected Result:**
        *   The website displays a cookie consent banner.
        *   The cookie consent banner explains the website's use of cookies and provides a link to the privacy policy.
        *   The cookie consent banner provides options to accept all cookies, reject all cookies, or customize cookie preferences.

*   **TC_28: Verify cookie consent functionality.**
    *   **Steps:**
        1.  Open the website in a browser for the first time.
        2.  Select a cookie consent option (e.g., accept all cookies, reject all cookies, customize cookie preferences).
    *   **Expected Result:**
        *   The website only sets cookies after the user has provided their consent.
        *   The website adheres to GDPR and CCPA requirements for cookie consent.

*   **TC_29: Verify HTTPS.**
    *   **Steps:**
        1.  Open the website in a browser.
    *   **Expected Result:**
        *   The website uses HTTPS to encrypt all data transmitted between the user's browser and the server.
        *   The browser displays a secure connection indicator (e.g., a padlock icon).

*   **TC_30: Verify Content Security Policy (CSP).**
    *   **Steps:**
        1.  Open the website in a browser.
        2.  Inspect the HTTP headers to verify that a Content Security Policy (CSP) is implemented.
    *   **Expected Result:**
        *   The website implements Content Security Policy (CSP) to prevent cross-site scripting (XSS) attacks.
        *   The CSP policy restricts the sources from which the website can load resources.

*   **TC_31: Verify rate limiting.**
    *   **Steps:**
        1.  Send a large number of requests to the website in a short period of time.
    *   **Expected Result:**
        *   The website implements rate limiting to prevent denial-of-service (DoS) attacks.
        *   The website returns an error message or blocks further requests after a certain threshold is reached.

*   **TC_32: Verify input validation.**
    *   **Steps:**
        1.  Enter invalid or malicious input into form fields (e.g., SQL injection attempts).
    *   **Expected Result:**
        *   The website validates all user input to prevent injection attacks.
        *   The website sanitizes or escapes user input before storing it in the database.

*   **TC_33: Verify LCP (Largest Contentful Paint).**
    *   **Steps:**
        1.  Use a performance testing tool (e.g., Google PageSpeed Insights, WebPageTest) to measure the website's LCP.
    *   **Expected Result:**
        *   The website's Largest Contentful Paint (LCP) is less than 2.5 seconds.

*   **TC_34: Verify Privacy/Terms page.**
    *   **Steps:**
        1.  Navigate to the Privacy/Terms page.
    *   **Expected Result:**
        *   The Privacy/Terms page includes a detailed explanation of PharmaCorp's data privacy practices and website terms of use.
        *   The Privacy/Terms page is written in clear and easy-to-understand language.
        *   The Privacy/Terms page is regularly reviewed and updated to reflect changes in data privacy laws and regulations.

**VI. Accessibility (WCAG 2.2 AA Compliance)**

*   **TC_35: Verify alternative text for images.**
    *   **Steps:**
        1.  Inspect the HTML code of all images on the website.
    *   **Expected Result:**
        *   All images have descriptive alternative text in the `alt` attribute.
        *   Decorative images have an empty `alt` attribute (`alt=""`).

*   **TC_36: Verify color contrast.**
    *   **Steps:**
        1.  Use a color contrast analyzer tool to check the contrast ratio between text and background colors.
    *   **Expected Result:**
        *   Sufficient color contrast is used to meet WCAG 2.2 AA guidelines (minimum contrast ratio of 4.5:1 for normal text and 3:1 for large text).

*   **TC_37: Verify form label association.**
    *   **Steps:**
        1.  Inspect the HTML code of all forms on the website.
    *   **Expected Result:**
        *   All form elements are properly associated with their labels using the `<label>` element and the `for` attribute.

*   **TC_38: Verify ARIA attributes.**
    *   **Steps:**
        1.  Inspect the HTML code of interactive elements on the website (e.g., buttons, links, menus).
    *   **Expected Result:**
        *   ARIA attributes are used correctly to provide additional information about the role, state, and properties of interactive elements.

*   **TC_39: Verify screen reader compatibility with NVDA and Chrome.**
    *   **Steps:**
        1.  Open the website in Chrome.
        2.  Activate NVDA screen reader.
        3.  Navigate through the website's content using NVDA.
    *   **Expected Result:**
        *   NVDA correctly reads the website's content, including text, images (alt text), form fields, and ARIA attributes.
        *   The website is navigable using NVDA commands.

*   **TC_40: Verify screen reader compatibility with JAWS and Firefox.**
    *   **Steps:**
        1.  Open the website in Firefox.
        2.  Activate JAWS screen reader.
        3.  Navigate through the website's content using JAWS.
    *   **Expected Result:**
        *   JAWS correctly reads the website's content, including text, images (alt text), form fields, and ARIA attributes.
        *   The website is navigable using JAWS commands.

*   **TC_41: Verify focus order.**
    *   **Steps:**
        1.  Open the website in a browser.
        2.  Use the Tab key to navigate through the website's elements.
    *   **Expected Result:**
        *   The focus order is logical and intuitive, following the visual flow of the page.

**VII. CI/CD Pipeline Testing**

*   **TC_42: Verify automated build and unit tests.**
    *   **Steps:**
        1.  Commit a code change to the Git repository.
        2.  Monitor the CI/CD pipeline to ensure that the automated build is triggered.
        3.  Verify that all unit tests pass successfully.
    *   **Expected Result:**
        *   The automated build is triggered successfully.
        *   All unit tests pass successfully.

*   **TC_43: Verify automated deployment to Dev environment.**
    *   **Steps:**
        1.  Commit a code change to the development branch in the Git repository.
        2.  Monitor the CI/CD pipeline to ensure that the automated deployment to the Dev environment is triggered.
    *   **Expected Result:**
        *   The automated deployment to the Dev environment is triggered successfully.
        *   The code change is deployed to the Dev environment.
        *   Verify the code change is functional in the Dev environment.

*   **TC_44: Verify automated deployment to Staging environment.**
    *   **Steps:**
        1.  Merge code changes from the development branch to the staging branch in the Git repository.
        2.  Monitor the CI/CD pipeline to ensure that the automated deployment to the Staging environment is triggered.
    *   **Expected Result:**
        *   The automated deployment to the Staging environment is triggered successfully.
        *   The code change is deployed to the Staging environment.
        *   Verify the code change is functional in the Staging environment.

*   **TC_45: Verify automated deployment to Prod environment.**
    *   **Steps:**
        1.  Merge code changes from the staging branch to the main/master branch in the Git repository.
        2.  Monitor the CI/CD pipeline to ensure that the automated deployment to the Prod environment is triggered.
    *   **Expected Result:**
        *   The automated deployment to the Prod environment is triggered successfully.
        *   The code change is deployed to the Prod environment.
        *   Verify the code change is functional in the Prod environment.

*   **TC_46: Verify rollback capability.**
    *   **Steps:**
        1.  Deploy a faulty code change to the Dev environment.
        2.  Trigger the rollback mechanism in the CI/CD pipeline.
    *   **Expected Result:**
        *   The rollback mechanism is triggered successfully.
        *   The Dev environment is reverted to the previous working version.

**VIII. Database Testing**

*   **TC_47: Verify data integrity of ContactFormSubmission table.**
    *   **Steps:**
        1.  Submit a contact form with valid data.
        2.  Query the `ContactFormSubmission` table in the PostgreSQL database.
    *   **Expected Result:**
        *   A new record is created in the `ContactFormSubmission` table with the submitted data.
        *   All fields in the record match the submitted data.

*   **TC_48: Verify data integrity of NewsletterSubscription table.**
    *   **Steps:**
        1.  Subscribe to the newsletter with a valid email address and consent.
        2.  Query the `NewsletterSubscription` table in the PostgreSQL database.
    *   **Expected Result:**
        *   A new record is created in the `NewsletterSubscription` table with the submitted data.
        *   The `email` field matches the submitted email address.
        *   The `is_active` field is set to `false` until the user verifies their subscription.
        *   The `consent_given` field is set to `true`.

*   **TC_49: Verify data integrity of CookieConsent table.**
    *   **Steps:**
        1.  Visit the website and provide cookie consent preferences.
        2.  Query the `CookieConsent` table in the PostgreSQL database.
    *   **Expected Result:**
        *   A new record is created in the `CookieConsent` table with the user's consent preferences.
        *   The `analytics_consent`, `marketing_consent`, and `functional_consent` fields are set according to the user's choices.

*   **TC_50: Verify data relationships between Page and Product tables.**
    *   **Steps:**
        1.  Create a new page and a new product in the CMS.
        2.  Verify that the `page_id` and `product_id` are auto-incremented correctly.
        3.  Verify that there are no orphaned records if a page or product is deleted.
    *   **Expected Result:**
        *   The `page_id` and `product_id` are auto-incremented correctly.
        *   There are no orphaned records if a page or product is deleted (referential integrity).

### 2.2. Test Environment

The tests will be executed in the following environments:

*   **Development (Dev):** Used for initial testing and development.
*   **Staging:** Used for testing in a production-like environment.
*   **Production (Prod):** The live website environment.

### 2.3. Test Data

Test data will be created and managed for each test case. This includes:

*   Valid and invalid user input for forms.
*   Product information with varying attributes.
*   Different types of media files.
*   User accounts with different roles and permissions.

### 2.4. Test Schedule

The testing activities will be scheduled according to the project timeline. The following is a tentative schedule:

*   **Phase 1: Unit Testing (Developers):** Ongoing throughout the development process.
*   **Phase 2: Functional Testing (QA):** 2 weeks after the completion of development.
*   **Phase 3: Regression Testing (QA):** After each major code change or bug fix.
*   **Phase 4: Performance Testing (QA):** 1 week before the release to production.
*   **Phase 5: Security Testing (Security Team):** 1 week before the release to production.
*   **Phase 6: Accessibility Testing (QA):** Integrated throughout the testing process.
*   **Phase 7: Acceptance Testing (Stakeholders):** 1 week before the release to production.

### 2.5. Test Deliverables

The following deliverables will be produced during the testing process:

*   Test Plan
*   Test Cases
*   Test Scripts (for automated tests)
*   Test Results
*   Defect Reports
*   Test Summary Report

## 3. Test Automation

### 3.1. Automation Scope

The following critical user stories will be automated:

*   **US-1: As a user, I want to navigate the website easily so I can find the information I need quickly.**
*   **US-5: As a user, I want to browse a list of PharmaCorp products so I can find the specific product I'm interested in.**
*   **US-9: As a user, I want to contact PharmaCorp through a contact form so I can ask questions or provide feedback.**
*   **US-10: As a user, I want to sign up for the PharmaCorp newsletter so I can receive updates about new products, research, and other relevant information.**
*   **US-11: As a user, I want to be able to search the website for specific information so I can quickly find what I'm looking for.**

### 3.2. Automation Framework

The following tools and technologies will be used for test automation:

*   **Programming Language:** Python
*   **Test Automation Framework:** Selenium WebDriver
*   **Test Runner:** pytest
*   **Assertion Library:** pytest
*   **Configuration Management:** Environment variables

### 3.3. Automation Scripts

```python
# automation_scripts.py
import os
import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options

# Environment variables
BASE_URL = os.environ.get("BASE_URL", "http://localhost:8000")  # Default to localhost
CONTACT_FORM_EMAIL = os.environ.get("CONTACT_FORM_EMAIL", "test@example.com")
NEWSLETTER_EMAIL = os.environ.get("NEWSLETTER_EMAIL", "newsletter@example.com")

@pytest.fixture(scope="module")
def driver():
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Run Chrome in headless mode
    driver = webdriver.Chrome(options=chrome_options)
    driver.implicitly_wait(10)  # Implicit wait for elements to load
    yield driver
    driver.quit()

def test_website_navigation(driver):
    driver.get(BASE_URL)
    assert "PharmaCorp" in driver.title

    # Check navigation links
    nav_links = {
        "About Us": "/about-us",
        "Products": "/products",
        "Contact Us": "/contact",
        "Privacy/Terms": "/privacy-terms"
    }

    for link_text, link_url in nav_links.items():
        try:
            link = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.LINK_TEXT, link_text))
            )
            link.click()
            assert link_url in driver.current_url, f"Navigation to {link_text} failed"
            driver.back()  # Go back to the homepage
        except Exception as e:
            pytest.fail(f"Navigation to {link_text} failed: {e}")

def test_product_listing(driver):
    driver.get(f"{BASE_URL}/products")
    product_elements = driver.find_elements(By.CLASS_NAME, "product-item")  # Assuming a class name for product items
    assert len(product_elements) > 0, "No products found on the product listing page"

def test_contact_form_submission(driver):
    driver.get(f"{BASE_URL}/contact")
    driver.find_element(By.ID, "name").send_keys("John Doe")
    driver.find_element(By.ID, "email").send_keys(CONTACT_FORM_EMAIL)
    driver.find_element(By.ID, "subject").send_keys("Test Inquiry")
    driver.find_element(By.ID, "message").send_keys("This is a test message.")
    driver.find_element(By.ID, "submit").click()

    # Verify confirmation message (adjust locator as needed)
    confirmation_message = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.ID, "confirmation-message"))  # Assuming an ID for the message
    ).text
    assert "Thank you for your submission!" in confirmation_message

def test_newsletter_signup(driver):
    driver.get(BASE_URL)
    # Assuming the newsletter signup form is in the footer
    newsletter_email_field = driver.find_element(By.ID, "newsletter-email") # Assuming an ID for the email field
    newsletter_email_field.send_keys(NEWSLETTER_EMAIL)
    consent_checkbox = driver.find_element(By.ID, "newsletter-consent") # Assuming an ID for the consent checkbox
    consent_checkbox.click()
    driver.find_element(By.ID, "newsletter-submit").click() # Assuming an ID for the submit button

    # Verify confirmation message (adjust locator as needed)
    confirmation_message = WebDriverWait(driver, 10).until(
        EC.visibility_of_element_located((By.ID, "newsletter-confirmation"))  # Assuming an ID for the message
    ).text
    assert "Subscription pending verification" in confirmation_message

def test_website_search(driver):
    driver.get(BASE_URL)
    search_box = driver.find_element(By.ID, "search-box") # Assuming an ID for the search box
    search_box.send_keys("Product A")
    search_box.submit()

    # Verify search results (adjust locator as needed)
    search_results = driver.find_elements(By.CLASS_NAME, "search-result") # Assuming a class name for search results
    assert len(search_results) > 0, "No search results found for 'Product A'"
```

**How to Run the Automation Scripts:**

1.  **Install Dependencies:**
    ```bash
    pip install selenium pytest webdriver-manager
    ```
2.  **Set Environment Variables:**
    Set the `BASE_URL`, `CONTACT_FORM_EMAIL`, and `NEWSLETTER_EMAIL` environment variables.  For example:
    ```bash
    export BASE_URL="https://www.pharmacor.com"
    export CONTACT_FORM_EMAIL="qa@pharmacor.com"
    export NEWSLETTER_EMAIL="testuser@pharmacor.com"
    ```
3.  **Run the Tests:**
    ```bash
    pytest automation_scripts.py
    ```

### 3.4. Reporting

Test results will be reported using pytest's built-in reporting capabilities. Reports will include:

*   Number of tests run
*   Number of tests passed
*   Number of tests failed
*   Details of failed tests

## 4. Defect Management

Defects identified during testing will be reported and tracked using a defect tracking system (e.g., Jira). The following information will be included in each defect report:

*   Defect ID
*   Test Case ID
*   Summary
*   Description
*   Steps to Reproduce
*   Expected Result
*   Actual Result
*   Severity
*   Priority
*   Assignee
*   Status

## 5. Roles and Responsibilities

The following roles and responsibilities are defined for the testing process:

*   **QA Lead:** Responsible for creating and maintaining the test plan, managing the testing process, and reporting on test results.
*   **QA Engineers:** Responsible for creating and executing test cases, reporting defects, and performing regression testing.
*   **Developers:** Responsible for fixing defects and implementing new features.
*   **Stakeholders:** Responsible for providing