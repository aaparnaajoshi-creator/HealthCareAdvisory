```markdown
## Dockerfile

```dockerfile
FROM python:3.9-slim-buster

WORKDIR /app

# Set environment variables
ENV PYTHONDONTWRITEBYTECODE 1
ENV PYTHONUNBUFFERED 1

# Install system dependencies
RUN apt-get update && apt-get install --no-install-recommends -y \
    postgresql-client \
    && rm -rf /var/lib/apt/lists/*

# Copy project files
COPY ./backend /app/backend
COPY ./frontend /app/frontend
COPY ./requirements.txt /app/requirements.txt

# Install Python dependencies
RUN pip install --no-cache-dir -r /app/requirements.txt

# Expose the application port
EXPOSE 8000

# Command to run the application
CMD ["uvicorn", "backend.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

## docker-compose.yml

```yaml
version: "3.9"

services:
  web:
    build: .
    ports:
      - "8000:8000"
    depends_on:
      - db
    environment:
      DATABASE_URL: postgresql://postgres:postgres@db:5432/pharmacorpdb
    volumes:
      - ./backend:/app/backend
      - ./frontend:/app/frontend
    restart: always

  db:
    image: postgres:13
    volumes:
      - db_data:/var/lib/postgresql/data
    ports:
      # Remove port exposure in production
      # - "5432:5432"
      # Instead, use the internal network
    environment:
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: postgres
      POSTGRES_DB: pharmacorpdb
    restart: always

volumes:
  db_data:
```

## README.md

```markdown
# PharmaCorp Commercial Website - Deployment Instructions

This document provides instructions for building, configuring, and deploying the PharmaCorp commercial website.

## Prerequisites

*   Docker and Docker Compose installed on your machine.
*   Python 3.9 or higher.
*   A PostgreSQL database instance (local or remote).
*   An AWS S3 bucket configured for storing Prescribing Information (PI) PDFs and other static assets.

## Build Instructions

1.  **Clone the repository:**

    ```bash
    git clone <repository_url>
    cd <repository_directory>
    ```

2.  **Build the Docker image:**

    ```bash
    docker-compose build
    ```

## Configuration

1.  **Environment Variables:**

    The application relies on environment variables for configuration. Create a `.env` file in the root directory to override the default values.  **Important:** Add `.env` to your `.gitignore` file to prevent committing sensitive information to the repository.

    Example `.env` file:

    ```
    DATABASE_URL=postgresql://user:password@host:port/database_name
    S3_BUCKET_NAME=your-s3-bucket-name
    AWS_ACCESS_KEY_ID=your-aws-access-key-id
    AWS_SECRET_ACCESS_KEY=your-aws-secret-access-key
    ```

    **Note:** The `DATABASE_URL` in `docker-compose.yml` is configured for the Dockerized PostgreSQL database. If you're using a separate database instance, update the `DATABASE_URL` accordingly.

2.  **Database Configuration:**

    The application uses PostgreSQL. Ensure that a PostgreSQL database is running and accessible.  The `docker-compose.yml` file includes a PostgreSQL service for local development.

3.  **Object Store Configuration (AWS S3):**

    The application uses an object store (e.g., AWS S3) to store Prescribing Information (PI) PDFs and other static assets.

    *   Create an S3 bucket in AWS.
    *   Configure the following environment variables:
        *   `S3_BUCKET_NAME`: The name of your S3 bucket.
        *   `AWS_ACCESS_KEY_ID`: Your AWS access key ID.
        *   `AWS_SECRET_ACCESS_KEY`: Your AWS secret access key.
    *   Ensure that the backend application has the necessary permissions to read and write to the S3 bucket.  This typically involves configuring an IAM role for the EC2 instance or container running the backend application.

## Deployment Instructions

1.  **Start the application using Docker Compose:**

    ```bash
    docker-compose up -d
    ```

    This command will start the web application and the PostgreSQL database in detached mode.

2.  **Database Migrations (using Alembic):**

    The application uses Alembic for database migrations.  Follow these steps to set up and run migrations:

    a.  **Install Alembic:**

        ```bash
        pip install alembic
        ```

    b.  **Configure Alembic:**

        *   Create an `alembic.ini` file in the root directory (or in the `backend` directory).
        *   Configure the `sqlalchemy.url` in `alembic.ini` to match your `DATABASE_URL` environment variable.
        *   Run `alembic init alembic` to create the Alembic environment.

    c.  **Create Migrations:**

        ```bash
        alembic revision -m "Initial migration"
        ```

        This will create a new migration script in the `alembic/versions` directory.  Modify the script to define the necessary database changes (e.g., create tables, add columns).

    d.  **Run Migrations:**

        ```bash
        alembic upgrade head
        ```

        This will apply all pending migrations to the database.

        **Note:** For more comprehensive instructions on Alembic, refer to the official Alembic documentation: [https://www.alembic.org/en/latest/](https://www.alembic.org/en/latest/)

## CI/CD Pipeline

To automate the deployment process, configure a CI/CD pipeline using tools like Jenkins or GitLab CI. The pipeline should:

1.  Build the Docker image.
2.  Run automated tests.
3.  Apply database migrations.
4.  Deploy the application to the appropriate environment (Dev, Staging, Prod).

## Security Considerations

*   **Database Port Exposure:**  The `docker-compose.yml` file should **not** expose the database port (5432) to the host in production environments. Remove or restrict port exposure.  Instead, the web application should connect to the database using the internal Docker network.
*   **Environment Variables:**  Protect sensitive environment variables (e.g., database passwords, AWS credentials) by storing them securely and avoiding committing them to the repository. Use a secrets management solution if necessary.
*   **HTTPS:**  Ensure that the website is served over HTTPS to encrypt all data transmitted between the user's browser and the server.
*   **Regular Security Audits:**  Conduct regular security audits and penetration testing to identify and address potential vulnerabilities.
```