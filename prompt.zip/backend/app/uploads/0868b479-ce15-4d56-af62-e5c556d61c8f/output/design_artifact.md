```markdown
# High-Level Design Document: HubSpot Company to Customer DB Sync

**Version:** 1.0
**Date:** 2025-09-01

## 1. Introduction

This document outlines the high-level design (HLD) for a system that automatically synchronizes new Company records created in HubSpot to an internal customer database (PostgreSQL). The system leverages a MuleSoft System API deployed to CloudHub to listen for HubSpot webhook calls, validate the signature, transform the data, and insert it into the customer database.

## 2. Goals

*   Automate the synchronization of new HubSpot Company records to the customer database.
*   Improve data consistency between HubSpot and the internal customer database.
*   Reduce manual data entry for the Sales Operations team.
*   Provide near real-time access to accurate customer information for reporting and analysis.
*   Ensure data security and integrity throughout the synchronization process.

## 3. Architecture Overview

The system adopts a webhook-driven, event-based architecture. When a new Company record is created in HubSpot, a webhook is triggered, sending a POST request to a MuleSoft System API. The API validates the request, transforms the data, and inserts it into the PostgreSQL database.

```mermaid
graph LR
    A[HubSpot] --> B(MuleSoft System API - CloudHub);
    B --> C(PostgreSQL Database);
    B --> D[Anypoint Monitoring];
    B --> E[Email Service];
    style A fill:#f9f,stroke:#333,stroke-width:2px
    style B fill:#ccf,stroke:#333,stroke-width:2px
    style C fill:#ccf,stroke:#333,stroke-width:2px
    style D fill:#f9f,stroke:#333,stroke-width:2px
    style E fill:#f9f,stroke:#333,stroke-width:2px
```

## 4. Components

*   **HubSpot:** The source CRM system where Company records are created.
*   **MuleSoft System API:** A System API deployed to CloudHub that acts as the webhook listener, data transformer, and database connector.
*   **PostgreSQL Database:** The target database where customer data is stored.
*   **Anypoint Monitoring:** MuleSoft's monitoring platform for logging and error tracking.
*   **Email Service:** Used for sending error notifications.

## 5. API Design

### 5.1. API Endpoint

The MuleSoft System API will expose a single HTTP endpoint to receive webhook calls from HubSpot.

*   **Endpoint:** `/api/v1/hubspot/company`
*   **Method:** `POST`
*   **Content-Type:** `application/json`

### 5.2. Request Format (Example HubSpot Payload)

```json
{
  "eventId": 12345,
  "subscriptionId": 67890,
  "portalId": 1234567,
  "occurredAt": 1678886400000,
  "propertyName": "name",
  "propertyValue": "Example Company",
  "changeSource": "CRM_UI",
  "objectId": 98765,
  "propertyNameHistory": {
    "name": [
      {
        "value": "Old Company Name",
        "timestamp": 1678800000000,
        "source": "CRM_UI",
        "sourceId": null
      },
      {
        "value": "Example Company",
        "timestamp": 1678886400000,
        "source": "CRM_UI",
        "sourceId": null
      }
    ]
  },
  "propertyNames": [
    "name",
    "domain",
    "numberofemployees",
    "lifecyclestage",
    "city",
    "state",
    "country",
    "zip",
    "phone"
  ],
  "properties": {
    "name": "Example Company",
    "domain": "example.com",
    "numberofemployees": "50",
    "lifecyclestage": "customer",
    "city": "Anytown",
    "state": "CA",
    "country": "USA",
    "zip": "91234",
    "phone": "555-123-4567"
  }
}
```

### 5.3. Response Format

*   **Success (200 OK):**

```json
{
  "status": "success",
  "message": "Company record synchronized successfully.",
  "hubspotCompanyId": 98765,
  "databaseRecordId": 123
}
```

*   **Error (400 Bad Request, 401 Unauthorized, 500 Internal Server Error):**

```json
{
  "status": "error",
  "message": "Error message describing the failure.",
  "hubspotCompanyId": 98765,
  "errorCode": "DATABASE_ERROR"
}
```

### 5.4 Rate Limiting

The MuleSoft API will implement rate limiting using the Rate Limiting policy available in Anypoint Platform.  This will prevent abuse and ensure the API remains available and responsive. A reasonable default limit will be 10 requests per minute per IP address. This can be adjusted as needed based on usage patterns.

## 6. Data Model and Database Schema

The following database schema will be used to store customer data in the PostgreSQL database.

```sql
CREATE TABLE customers (
    id SERIAL PRIMARY KEY,
    hubspot_company_id VARCHAR(255) UNIQUE,
    name VARCHAR(255),
    domain VARCHAR(255),
    number_of_employees INTEGER,
    lifecycle_stage VARCHAR(255),
    city VARCHAR(255),
    state VARCHAR(255),
    country VARCHAR(255),
    zip VARCHAR(255),
    phone VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_customers_updated_at
BEFORE UPDATE ON customers
FOR EACH ROW
EXECUTE FUNCTION update_updated_at();
```

## 7. Data Flow

```mermaid
sequenceDiagram
    participant HubSpot
    participant MuleSoft API
    participant PostgreSQL
    participant Anypoint Monitoring
    participant Email Service

    HubSpot->>MuleSoft API: New Company Webhook (POST /api/v1/hubspot/company)
    activate MuleSoft API
    MuleSoft API->>MuleSoft API: Validate X-HubSpot-Signature
    alt Invalid Signature
        MuleSoft API-->>HubSpot: 401 Unauthorized
        deactivate MuleSoft API
    else Valid Signature
        MuleSoft API->>MuleSoft API: Transform Data (DataWeave)
        MuleSoft API->>PostgreSQL: INSERT INTO customers
        activate PostgreSQL
        PostgreSQL-->>MuleSoft API: Success/Failure
        deactivate PostgreSQL
        alt Database Insertion Success
            MuleSoft API->>MuleSoft API: Log "End of webhook transaction" (success)
            MuleSoft API->>Anypoint Monitoring: Log Payload (masked), Transaction Start/End
            MuleSoft API-->>HubSpot: 200 OK
            deactivate MuleSoft API
        else Database Insertion Failure
            MuleSoft API->>MuleSoft API: Log "End of webhook transaction" (failure)
            MuleSoft API->>Anypoint Monitoring: Log Error Details, Payload (masked)
            MuleSoft API->>Email Service: Send Error Notification
            MuleSoft API-->>HubSpot: 500 Internal Server Error
            deactivate MuleSoft API
        end
    end
```

## 8. Security

*   **Webhook Validation:** The MuleSoft API will validate the `X-HubSpot-Signature` header in each webhook request to ensure the request is authentic. The HubSpot Client Secret will be stored in secure properties in Anypoint Platform.
*   **Database Credentials:** The database username and password will be stored in secure properties in Anypoint Platform and retrieved at runtime.
*   **TLS/SSL:** The JDBC connection to the PostgreSQL database will be encrypted using TLS/SSL.
*   **Data Masking:** Sensitive data in the HubSpot payload (e.g., email addresses, phone numbers) will be masked before being logged to Anypoint Monitoring.
*   **Rate Limiting:** Implemented to prevent abuse of the API.

## 9. Error Handling and Logging

*   **Global Error Handler:** A global error handler will be implemented in the MuleSoft application to catch any exceptions that occur during the webhook processing.
*   **Logging:** The application will generate logs for key events:
    *   Start and end of each webhook transaction (including a unique transaction ID).
    *   Payload received from HubSpot (with sensitive data masked).
    *   Success or failure of the database insertion.
*   **Error Notifications:** Upon encountering an error, the global error handler will:
    *   Log the full stack trace and the original HubSpot payload (with sensitive data masked) to Anypoint Monitoring.
    *   Send an email notification to the configured email address, including the error message and the HubSpot Company ID.

## 10. Deployment

The MuleSoft System API will be deployed to CloudHub using a 0.1 vCores worker size.

## 11. Future Enhancements

*   **Manual Synchronization:** Add the ability to manually trigger the synchronization process for failed Company records.
*   **Update Synchronization:** Implement logic to synchronize updates to existing Company records in HubSpot to the customer database.
*   **Deletion Support:** Implement logic to handle company deletions in HubSpot and reflect those changes in the customer database (soft delete).
*   **Data Enrichment:** Enrich the customer data with additional information from external sources.