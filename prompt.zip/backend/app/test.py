import os, requests, base64
from dotenv import load_dotenv
from langchain_google_genai import ChatGoogleGenerativeAI
from database import log_technical_event

load_dotenv()
token = os.getenv("GITHUB_TOKEN").strip()
url = "https://api.github.com/repos/sagark82/Agentic_SDLC_Test_Enh_01/contents/test_file.txt"

content = base64.b64encode(b"Hello from Python!").decode("utf-8")
data = {"message": "Add test_file.txt", "content": content, "branch": "main"}

headers = {"Authorization": f"token {token}", "Accept": "application/vnd.github.v3+json"}

resp = requests.put(url, headers=headers, json=data)
print(resp.status_code, resp.text)
