﻿import asyncio
import threading
import uvicorn
import re
from flask import Flask, jsonify, request, send_from_directory, send_file, abort, render_template
from flask_cors import CORS
from typing import List, Optional, Dict, Any
import json
import os
import zipfile
import uuid
import tempfile
import pprint
import shutil

from models import ProjectConfig
from database import init_db, create_project, get_project_config, update_project_status, log_agent_activity, get_project_logs, get_technical_logs_for_phase, get_cumulative_phase_durations, get_all_projects,delete_project_from_db, update_project_phases_to_run
from agent_graph import get_agent_graph, HumanInputRequired, PHASES
from tools import load_phase_artifact, fetch_from_github, fetch_github_raw_file

# Create uploads directory if it doesn't exist
UPLOADS_DIR = "uploads"
os.makedirs(UPLOADS_DIR, exist_ok=True)

# Correctly set the template and static folder paths
# Assuming your folder structure is backend/app.py and frontend/index.html
frontend_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'frontend')
app = Flask(__name__,
            template_folder=frontend_dir,
            static_folder=frontend_dir,
            static_url_path='') # Serve static files from the root URL
CORS(app)

def run_async_in_thread(fn, *args, **kwargs):
    """
    Runs an async function in a new thread with a new event loop.
    """
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(fn(*args, **kwargs))
    loop.close()

@app.route("/")
def index():
    """Renders the main frontend page."""
    return render_template("index.html")

def process_logs_for_frontend(logs: List[Dict], all_phases: List[str]) -> List[Dict[str, Any]]:
    phase_data = {
        phase: {
            "phase_name": phase, 
            "status": "Pending", 
            "final_output": "", 
            "details": [], 
            "duration": 0
        } for phase in all_phases
    }

    final_log_for_phase = {}

    for log in logs:
        phase_name = log.get('phase')
        if phase_name in phase_data:
            phase_data[phase_name]['details'].append(log)
            
            if log.get('status') == 'Completed' or log.get('agent_name') == 'Human Edit':
                final_log_for_phase[phase_name] = log
            elif log.get('status') == 'Generated Output':
                 final_log_for_phase[phase_name] = log

    for phase_name, data in phase_data.items():
        if phase_name in final_log_for_phase:
            final_log = final_log_for_phase[phase_name]
            data['final_output'] = final_log.get('output', '')
            
            if final_log.get('status') == 'Completed' or final_log.get('agent_name') == 'Human Edit':
                data['status'] = 'Completed'
            elif data['details']:
                data['status'] = 'In Progress'

    return list(phase_data.values())

@app.route("/projects", methods=["GET"])
def list_all_projects():
    return jsonify(get_all_projects())

@app.route("/projects", methods=["POST"])
def create_new_project():
    project_id = str(uuid.uuid4())
    project_upload_dir = os.path.join(UPLOADS_DIR, project_id)
    os.makedirs(project_upload_dir, exist_ok=True)
    
    try:
        project_name = request.form.get('project_name')
        start_phase = request.form.get('start_phase')
        end_phase = request.form.get('end_phase')
        phases_to_run = request.form.getlist('phases_to_run')

        if not all([project_name, start_phase, end_phase]):
            missing = [field for field, value in [('project_name', project_name), ('start_phase', start_phase), ('end_phase', end_phase)] if not value]
            return jsonify({"detail": f"Missing required fields: {', '.join(missing)}"}), 400
        
        output_destination = request.form.get('output_destination', 'disk')
        github_repo_url = request.form.get('github_repo_url') if output_destination == 'github' else None
        github_push_phases = request.form.getlist('github_push_phases') if output_destination == 'github' else []
        project_type = request.form.get('project_type', 'enhancement')
        human_steps_list = request.form.getlist('human_steps')

        def handle_raw_github_file(url: str, name_pattern: str):
            filename, content = fetch_github_raw_file(url, name_pattern)
            if isinstance(content, str) and content.strip().startswith("Error:"):
                raise ValueError(content)
            if filename and isinstance(content, bytes):
                file_path = os.path.join(project_upload_dir, filename)
                with open(file_path, "wb") as f:
                    f.write(content)
        
        if project_type == 'enhancement':
            if request.form.get('input_mode_new_requirement') == 'github' and request.form.get('new_requirement_github_url'):
                handle_raw_github_file(request.form['new_requirement_github_url'], "new_requirement")
            elif 'new_requirement_file' in request.files:
                file = request.files.get('new_requirement_file')
                if file and file.filename:
                    _, extension = os.path.splitext(file.filename)
                    new_filename = f"new_requirement{extension}"
                    file_path = os.path.join(project_upload_dir, new_filename)
                    file.save(file_path)

            if request.form.get('input_mode_existing_artifacts_zip') == 'github' and request.form.get('existing_artifacts_zip_github_url'):
                for phase in PHASES:
                    fetched_data = fetch_from_github(request.form['existing_artifacts_zip_github_url'], phase)
                    if isinstance(fetched_data, str):
                        if fetched_data.strip().startswith("Error:"): raise ValueError(fetched_data)
                        continue
                    phase_dir = os.path.join(project_upload_dir, phase)
                    for relative_path, content_bytes in fetched_data:
                        full_path = os.path.join(phase_dir, relative_path)
                        os.makedirs(os.path.dirname(full_path), exist_ok=True)
                        with open(full_path, "wb") as f:
                            f.write(content_bytes)
            elif 'existing_artifacts_zip_file' in request.files:
                file = request.files.get('existing_artifacts_zip_file')
                if file and file.filename:
                    zip_path = os.path.join(project_upload_dir, file.filename)
                    file.save(zip_path)
                    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                        zip_ref.extractall(project_upload_dir)
        
        else: # 'new' project
            artifact_map = {
                "hl_functional_req": (request.form.get('input_mode_hl_functional_req'), request.form.get('hl_functional_req_github_url'), request.files.get('hl_functional_req_file')),
                "hl_technical_req": (request.form.get('input_mode_hl_technical_req'), request.form.get('hl_technical_req_github_url'), request.files.get('hl_technical_req_file')),
                "user_stories": (request.form.get('input_mode_user_stories'), request.form.get('user_stories_github_url'), request.files.get('user_stories_file')),
                "design": (request.form.get('input_mode_design'), request.form.get('design_github_url'), request.files.get('design_file')),
                "coding": (request.form.get('input_mode_coding'), request.form.get('coding_github_url'), request.files.get('code_file')),
            }
            for name, (mode, url, file) in artifact_map.items():
                if mode == 'github' and url:
                    handle_raw_github_file(url, name)
                elif file and file.filename:
                    _, extension = os.path.splitext(file.filename)
                    new_filename = f"{name}{extension}"
                    file_path = os.path.join(project_upload_dir, new_filename)
                    file.save(file_path)
        
        config = ProjectConfig(
            project_name=project_name, project_type=project_type, start_phase=start_phase,
            end_phase=end_phase, human_in_loop_steps=human_steps_list, output_destination=output_destination,
            github_repo_url=github_repo_url,
            github_push_phases=github_push_phases,
            phases_to_run=phases_to_run
        )
        create_project(project_id, config)
        
        if phases_to_run:
            update_project_phases_to_run(project_id, phases_to_run)

        return jsonify({"project_id": project_id, "message": "Project created successfully"})

    except ValueError as e:
        return jsonify({"detail": str(e)}), 400
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"detail": f"Failed to create project: {str(e)}"}), 500

@app.route("/projects/<project_id>/execute", methods=["POST"])
def execute_project(project_id: str):
    config_data = get_project_config(project_id)
    if not config_data:
        abort(404, description="Project not found")
    
    update_project_status(project_id, f"In Progress - {config_data['start_phase']}")
    
    # CORRECTED: Pass the raw config_data dictionary to the thread
    thread = threading.Thread(target=run_async_in_thread, args=(run_agentic_workflow, project_id, config_data))
    thread.start()
    
    return jsonify({"message": "Project execution started."})

# CORRECTED: This function now accepts the raw config dictionary
async def run_agentic_workflow(project_id: str, config_data: dict):
    # We still create a Pydantic object for validation and easy access to typed fields
    config = ProjectConfig(**config_data) 
    graph = get_agent_graph(config.human_in_loop_steps)
    
    initial_artifacts = {
        "ImpactAnalysis": load_phase_artifact(project_id, "ImpactAnalysis"),
        "new_requirement": load_phase_artifact(project_id, "new_requirement"),
        "Requirements": load_phase_artifact(project_id, "Requirements"),
        "Design": load_phase_artifact(project_id, "Design"),
        "Coding": load_phase_artifact(project_id, "Coding"),
        "Testing": load_phase_artifact(project_id, "Testing"),
        "Deployment": load_phase_artifact(project_id, "Deployment"),
        "hl_functional_req": load_phase_artifact(project_id, "hl_functional_req"),
        "hl_technical_req": load_phase_artifact(project_id, "hl_technical_req"),
        "user_stories": load_phase_artifact(project_id, "user_stories"),
        "Incidents": load_phase_artifact(project_id, "Incidents"),
        "ScreenFlow": load_phase_artifact(project_id, "ScreenFlow"),
    }

    initial_state = {
        "project_id": project_id,
        "project_name": config.project_name,
        "project_type": config.project_type,
        "start_phase": config.start_phase,
        "end_phase": config.end_phase,
        "current_phase": config.start_phase,
        # CORRECTED: Access phases_to_run from the dictionary, with a fallback
        "phases_to_run": config_data.get('phases_to_run', []),
        "artifacts": initial_artifacts,
        "logs": [],
        "human_input": None,
        "review_cycles": 0,
        "human_in_loop_steps": config.human_in_loop_steps,
        "output_destination": config.output_destination,
        "github_repo_url": config.github_repo_url,
    }

    try:
        async for _ in graph.astream(initial_state):
            pass
        update_project_status(project_id, "Completed")
    except HumanInputRequired as e:
        phase = str(e).split(" at ")[-1]
        update_project_status(project_id, f"Paused - Waiting for Human Input at {phase}")
        log_agent_activity(project_id, "System", "Paused", f"Workflow paused: {str(e)}", phase=phase)
    except Exception as e:
        import traceback
        traceback.print_exc()
        error_message = f"Workflow failed with an unexpected error: {str(e)}"
        update_project_status(project_id, "Failed")
        log_agent_activity(project_id, "System", "Error", error_message)

@app.route("/projects/<project_id>/status", methods=["GET"])
def get_project_status_and_logs(project_id: str):
    config_data = get_project_config(project_id)
    if not config_data:
        abort(404, description="Project not found")
    
    project_specific_phases = config_data.get('phases_to_run')
    if not project_specific_phases:
        try:
            start_index = PHASES.index(config_data['start_phase'])
            end_index = PHASES.index(config_data['end_phase'])
            project_specific_phases = PHASES[start_index : end_index + 1]
        except ValueError:
            project_specific_phases = PHASES
    
    raw_logs = get_project_logs(project_id)
    overall_status = config_data.get('status', 'Unknown')
    durations = get_cumulative_phase_durations(project_id)
    
    processed_phases = process_logs_for_frontend(raw_logs, project_specific_phases)

    for phase_info in processed_phases:
        if phase_info['phase_name'] in durations:
            phase_info['duration'] = durations[phase_info['phase_name']]
    
    return jsonify({
        "project_name": config_data.get('project_name', 'Unknown Project'),
        "project_type": config_data.get('project_type', 'enhancement'),
        "start_phase": config_data.get('start_phase'),
        "end_phase": config_data.get('end_phase'),
        "human_in_loop_steps": config_data.get('human_in_loop_steps', []),
        "overall_status": overall_status,
        "phases": processed_phases,
        "output_destination": config_data.get('output_destination', 'disk'),
        "github_repo_url": config_data.get('github_repo_url')
    })

@app.route("/projects/<project_id>/technical_logs/<phase_name>", methods=["GET"])
def get_phase_technical_logs(project_id: str, phase_name: str):
    logs = get_technical_logs_for_phase(project_id, phase_name)
    if logs is None:
        abort(404, description="Project not found or no technical logs available.")
    return jsonify(logs)

@app.route("/projects/<project_id>/download/<phase_name>", methods=["GET"])
def download_phase_output(project_id: str, phase_name: str):
    output_dir = os.path.join(UPLOADS_DIR, project_id, "output")
    if not os.path.isdir(output_dir):
        abort(404, description="Output directory not found.")

    found_file = None
    for filename in os.listdir(output_dir):
        if filename.lower().startswith(phase_name.lower()):
            found_file = filename
            break
    
    if not found_file:
        abort(404, description=f"Artifact for phase '{phase_name}' not found.")

    return send_from_directory(output_dir, found_file, as_attachment=True)

@app.route("/projects/<project_id>/resume", methods=["POST"])
def resume_project(project_id: str):
    edited_content = request.form.get('edited_content')
    phase_of_edit = request.form.get('phase_of_edit')

    if not edited_content or not phase_of_edit:
        return jsonify({"detail": "Missing required fields: edited_content and phase_of_edit"}), 400
    
    log_agent_activity(
        project_id=project_id,
        agent_name="Human Edit",
        status="Approved with Edits",
        output=edited_content,
        details=f"Human user edited and approved the output for the {phase_of_edit} phase.",
        phase=phase_of_edit
    )

    output_dir = os.path.join(UPLOADS_DIR, project_id, "output")
    os.makedirs(output_dir, exist_ok=True)
    
    file_extension = ".md" 
    if phase_of_edit == "Coding":
        if "```python" in edited_content: file_extension = ".py"
        elif "```java" in edited_content: file_extension = ".java"
        elif "```javascript" in edited_content: file_extension = ".js"
        else: file_extension = ".txt"
    elif phase_of_edit == "Deployment":
        file_extension = ".sh"
    
    artifact_path = os.path.join(output_dir, f"{phase_of_edit.lower()}_artifact{file_extension}")
    try:
        with open(artifact_path, "w", encoding="utf-8") as f:
            f.write(edited_content)
    except Exception as e:
        return jsonify({"detail": f"Failed to save human-edited artifact: {str(e)}"}), 500

    config_data = get_project_config(project_id)
    if not config_data:
        abort(404, description="Project not found")

    try:
        phases_to_run = config_data.get('phases_to_run', PHASES)
        current_idx = phases_to_run.index(phase_of_edit)
        next_idx = current_idx + 1

        if next_idx >= len(phases_to_run) or phase_of_edit == config_data['end_phase']:
            update_project_status(project_id, "Completed")
            return jsonify({"message": "Final phase reviewed. Project completed."})

        next_phase = phases_to_run[next_idx]
        
        # We need to pass the full config_data dictionary, not a Pydantic object
        config_data['start_phase'] = next_phase
        
        update_project_status(project_id, f"In Progress - Resuming at {next_phase}")
        thread = threading.Thread(target=run_async_in_thread, args=(run_agentic_workflow, project_id, config_data))
        thread.start()
        
        return jsonify({"message": f"Changes saved. Workflow resuming at the {next_phase} phase."})
    except (ValueError, IndexError) as e:
        return jsonify({"detail": f"Error determining next phase: {str(e)}"}), 500

@app.route("/projects/<project_id>/download-all", methods=["GET"])
def download_all_project_outputs(project_id: str):
    output_dir = os.path.join(UPLOADS_DIR, project_id, "output")
    
    if not os.path.isdir(output_dir) or not os.listdir(output_dir):
        abort(404, description="No output artifacts found for this project.")

    zip_path = None
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as tmp_file:
            zip_path = tmp_file.name
            with zipfile.ZipFile(tmp_file, 'w', zipfile.ZIP_DEFLATED) as zip_file:
                for root, _, files in os.walk(output_dir):
                    for file in files:
                        file_path = os.path.join(root, file)
                        zip_file.write(file_path, os.path.relpath(file_path, output_dir))
        
        project_name = "project"
        config_data = get_project_config(project_id)
        if config_data and config_data.get('project_name'):
            project_name = config_data['project_name'].replace(" ", "_").lower()

        return send_file(
            zip_path,
            mimetype="application/zip",
            as_attachment=True,
            download_name=f"{project_name}_outputs.zip"
        )
    finally:
        if zip_path:
            pass

@app.route("/projects/<project_id>", methods=["DELETE"])
def delete_project(project_id: str):
    try:
        project_upload_dir = os.path.join(UPLOADS_DIR, project_id)
        if os.path.exists(project_upload_dir):
            shutil.rmtree(project_upload_dir)

        was_deleted = delete_project_from_db(project_id)
        if not was_deleted:
            return jsonify({"detail": "Project not found in database, but files were cleaned up."}), 404

        return jsonify({"message": "Project deleted successfully"}), 200
        
    except Exception as e:
        return jsonify({"detail": f"Failed to delete project: {str(e)}"}), 500
    
if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=8000)