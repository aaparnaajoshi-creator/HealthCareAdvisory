import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    # SQLite Connection String (Creates a local file named serviceops.db)
    SQLALCHEMY_DATABASE_URI = os.getenv('DATABASE_URL', 'sqlite:///serviceops.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Local ChromaDB Path
    CHROMA_DB_PATH = os.path.join(os.getcwd(), 'chroma_data')
    
    #GOOGLE_API_KEY = os.getenv('GOOGLE_API_KEY')
    # OpenAI API Key (changed from Google)
    OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
    
    SERVICENOW_USER = os.getenv('SERVICENOW_USERNAME')
    SERVICENOW_PASS = os.getenv('SERVICENOW_PASSWORD')
    UPLOAD_FOLDER = './uploads'
    
    if not os.path.exists(UPLOAD_FOLDER):
        os.makedirs(UPLOAD_FOLDER)