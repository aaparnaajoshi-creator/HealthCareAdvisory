import os
import threading
import chromadb
from flask import Flask, request, jsonify
from flask_cors import CORS
from werkzeug.utils import secure_filename
from datetime import datetime, timedelta
from sqlalchemy import func

from config import Config
from models import db, Fabric, IngestionHistory, FabricDocument, GraphNode, GraphEdge
from services.ingestion import process_fabric_build
from services.agent import ChatAgent
# adding these imports for v 0.4

from openai import OpenAI
import os
import random

app = Flask(__name__)
app.config.from_object(Config)
CORS(app)
db.init_app(app)

# Ensure tables exist
with app.app_context():
    db.create_all()

# ============= FABRIC ROUTES =============

@app.route('/api/fabrics', methods=['GET'])
def get_fabrics():
    """Get all fabrics with optional filtering"""
    # Get query parameters
    source_type = request.args.get('sourceType')  # 'uploads', 'servicenow', 'sharepoint'
    status = request.args.get('status')
    
    query = Fabric.query
    
    # Apply filters
    if status:
        query = query.filter_by(status=status)
    
    fabrics = query.all()
    
    # Filter by source type if specified
    if source_type:
        fabrics = [f for f in fabrics if f.source_breakdown.get(source_type, 0) > 0]
    
    return jsonify([f.to_dict() for f in fabrics])


@app.route('/api/fabrics/<id>', methods=['GET'])
def get_fabric(id):
    """Get fabric by ID with optional detailed stats"""
    fabric = Fabric.query.get_or_404(id)
    include_stats = request.args.get('includeStats', 'true').lower() == 'true'
    
    result = fabric.to_dict()
    
    if include_stats:
        # Add real-time ChromaDB count
        try:
            collection_name = fabric.rag_config.get('chromaCollection')
            chroma_client = chromadb.PersistentClient(path=Config.CHROMA_DB_PATH)
            collection = chroma_client.get_collection(collection_name)
            actual_chunks = collection.count()
            result['actualChunksInDB'] = actual_chunks
            result['chunksMatch'] = actual_chunks == fabric.chunks_count
        except:
            result['actualChunksInDB'] = 0
            result['chunksMatch'] = False
    
    return jsonify(result)


@app.route('/api/fabrics', methods=['POST'])
def create_fabric():
    """Create new fabric"""
    data = request.json
    
    new_fabric = Fabric(
        name=data['name'],
        description=data.get('description', ''),
        domain=data['domain'],
        sources_config=data['sources'],
        rag_config={
            'chunkSize': data['chunkSize'],
            'chunkOverlap': data['chunkOverlap'],
            'embeddingModel': data['embeddingModel'],
            'chromaCollection': data['chromaCollection']
        },
        ingestion_stats={},
        source_breakdown={}
    )
    
    db.session.add(new_fabric)
    db.session.commit()
    
    # Create upload directory
    fabric_dir = os.path.join(Config.UPLOAD_FOLDER, new_fabric.id)
    if not os.path.exists(fabric_dir):
        os.makedirs(fabric_dir)
    
    return jsonify(new_fabric.to_dict()), 201


@app.route('/api/fabrics/<id>/build', methods=['POST'])
def trigger_build(id):
    """Trigger fabric build in background"""
    fabric = Fabric.query.get_or_404(id)
    
    # Start background thread
    thread = threading.Thread(
        target=process_fabric_build,
        args=(id, app)
    )
    thread.start()
    
    return jsonify({
        "status": "Ingesting",
        "message": "Build started"
    })


@app.route('/api/fabrics/<id>/upload', methods=['POST'])
def upload_documents(id):
    """Upload documents to fabric"""
    fabric = Fabric.query.get_or_404(id)
    
    if 'files' not in request.files:
        return jsonify({"error": "No files provided"}), 400
    
    files = request.files.getlist('files')
    uploaded_files = []
    
    fabric_dir = os.path.join(Config.UPLOAD_FOLDER, id)
    if not os.path.exists(fabric_dir):
        os.makedirs(fabric_dir)
    
    for file in files:
        if file and file.filename:
            filename = secure_filename(file.filename)
            filepath = os.path.join(fabric_dir, filename)
            file.save(filepath)
            uploaded_files.append(filename)
    
    # Update fabric sources
    sources = fabric.sources_config
    if 'uploads' not in sources:
        sources['uploads'] = {}
    sources['uploads']['fileNames'] = uploaded_files
    fabric.sources_config = sources
    
    db.session.commit()
    
    return jsonify({
        "success": True,
        "message": f"Uploaded {len(uploaded_files)} files",
        "files": uploaded_files
    })


@app.route('/api/fabrics/<id>', methods=['DELETE'])
def delete_fabric(id):
    """Delete fabric and all related data"""
    fabric = Fabric.query.get_or_404(id)
    
    # Delete related records
    IngestionHistory.query.filter_by(fabric_id=id).delete()
    FabricDocument.query.filter_by(fabric_id=id).delete()
    GraphNode.query.filter_by(fabric_id=id).delete()
    GraphEdge.query.filter_by(fabric_id=id).delete()
    
    # Delete ChromaDB collection
    try:
        collection_name = fabric.rag_config.get('chromaCollection')
        chroma_client = chromadb.PersistentClient(path=Config.CHROMA_DB_PATH)
        chroma_client.delete_collection(collection_name)
    except:
        pass
    
    # Delete uploaded files
    fabric_dir = os.path.join(Config.UPLOAD_FOLDER, id)
    if os.path.exists(fabric_dir):
        import shutil
        shutil.rmtree(fabric_dir)
    
    # Delete fabric
    db.session.delete(fabric)
    db.session.commit()
    
    return jsonify({
        "success": True,
        "message": "Fabric deleted"
    })


# ============= DETAILED STATS ROUTES =============

@app.route('/api/fabrics/<id>/detailed-stats', methods=['GET'])
def get_detailed_stats(id):
    """Get comprehensive statistics for a fabric"""
    fabric = Fabric.query.get_or_404(id)
    
    # Get real-time ChromaDB count
    try:
        collection_name = fabric.rag_config.get('chromaCollection')
        chroma_client = chromadb.PersistentClient(path=Config.CHROMA_DB_PATH)
        collection = chroma_client.get_collection(collection_name)
        actual_chunks = collection.count()
    except:
        actual_chunks = 0
    
    # Get file breakdown
    fabric_docs = FabricDocument.query.filter_by(fabric_id=id).all()
    
    return jsonify({
        "stored": {
            "documentsCount": fabric.documents_count,
            "chunksCount": fabric.chunks_count,
            "graphNodes": fabric.graph_nodes,
            "graphEdges": fabric.graph_edges,
            "ingestionStats": fabric.ingestion_stats or {},
            "sourceBreakdown": fabric.source_breakdown or {}
        },
        "realtime": {
            "chunksInChromaDB": actual_chunks,
            "matchesStored": actual_chunks == fabric.chunks_count
        },
        "files": [doc.to_dict() for doc in fabric_docs]
    })


@app.route('/api/fabrics/<id>/source-breakdown', methods=['GET'])
def get_source_breakdown(id):
    """Get breakdown by source type"""
    fabric = Fabric.query.get_or_404(id)
    fabric_docs = FabricDocument.query.filter_by(fabric_id=id).all()
    
    breakdown = {
        "uploads": {
            "count": 0,
            "documents": 0,
            "chunks": 0,
            "files": []
        },
        "servicenow": {
            "count": 0,
            "documents": 0,
            "chunks": 0,
            "tables": []
        }
    }
    
    for doc in fabric_docs:
        if doc.source_type == 'upload':
            breakdown["uploads"]["count"] += 1
            breakdown["uploads"]["documents"] += doc.document_count
            breakdown["uploads"]["chunks"] += doc.chunk_count
            breakdown["uploads"]["files"].append(doc.to_dict())
        elif doc.source_type.startswith('servicenow_'):
            breakdown["servicenow"]["count"] += 1
            breakdown["servicenow"]["documents"] += doc.document_count
            breakdown["servicenow"]["chunks"] += doc.chunk_count
            breakdown["servicenow"]["tables"].append(doc.to_dict())
    
    return jsonify(breakdown)


@app.route('/api/fabrics/<id>/files', methods=['GET'])
def get_fabric_files(id):
    """List all files in the fabric"""
    fabric_docs = FabricDocument.query.filter_by(fabric_id=id).all()
    return jsonify([doc.to_dict() for doc in fabric_docs])


# ============= INGESTION HISTORY ROUTES =============

@app.route('/api/fabrics/<id>/ingestion-history', methods=['GET'])
def get_ingestion_history(id):
    """Get ingestion history for a fabric"""
    history = IngestionHistory.query.filter_by(fabric_id=id).order_by(
        IngestionHistory.started_at.desc()
    ).all()
    
    return jsonify([record.to_dict() for record in history])


@app.route('/api/ingestion-history/<history_id>', methods=['GET'])
def get_ingestion_record(history_id):
    """Get specific ingestion history record"""
    record = IngestionHistory.query.get_or_404(history_id)
    return jsonify(record.to_dict())


# ============= KNOWLEDGE GRAPH ROUTES =============

@app.route('/api/fabrics/<id>/graph', methods=['GET'])
def get_knowledge_graph(id):
    """Get knowledge graph for a fabric"""
    fabric = Fabric.query.get_or_404(id)
    
    # Get all nodes
    nodes = GraphNode.query.filter_by(fabric_id=id).all()
    
    # Get all edges
    edges = GraphEdge.query.filter_by(fabric_id=id).all()
    
    return jsonify({
        "nodes": [node.to_dict() for node in nodes],
        "edges": [edge.to_dict() for edge in edges],
        "stats": {
            "nodeCount": len(nodes),
            "edgeCount": len(edges)
        }
    })


@app.route('/api/fabrics/<id>/graph/nodes', methods=['GET'])
def get_graph_nodes(id):
    """Get graph nodes with optional filtering"""
    node_type = request.args.get('type')
    
    query = GraphNode.query.filter_by(fabric_id=id)
    
    if node_type:
        query = query.filter_by(node_type=node_type)
    
    nodes = query.all()
    return jsonify([node.to_dict() for node in nodes])


@app.route('/api/fabrics/<id>/graph/node/<node_id>', methods=['GET'])
def get_node_details(id, node_id):
    """Get details for a specific node including its connections"""
    node = GraphNode.query.filter_by(fabric_id=id, node_id=node_id).first_or_404()
    
    # Get outgoing edges
    outgoing = GraphEdge.query.filter_by(fabric_id=id, source_node_id=node.id).all()
    
    # Get incoming edges
    incoming = GraphEdge.query.filter_by(fabric_id=id, target_node_id=node.id).all()
    
    # Get connected nodes
    connected_node_ids = set()
    for edge in outgoing:
        connected_node_ids.add(edge.target_node_id)
    for edge in incoming:
        connected_node_ids.add(edge.source_node_id)
    
    connected_nodes = GraphNode.query.filter(GraphNode.id.in_(connected_node_ids)).all()
    
    return jsonify({
        "node": node.to_dict(),
        "outgoingEdges": [edge.to_dict() for edge in outgoing],
        "incomingEdges": [edge.to_dict() for edge in incoming],
        "connectedNodes": [n.to_dict() for n in connected_nodes]
    })


@app.route('/api/fabrics/<id>/graph/search', methods=['GET'])
def search_graph(id):
    """Search nodes in the graph"""
    query_text = request.args.get('q', '')
    node_type = request.args.get('type')
    
    query = GraphNode.query.filter_by(fabric_id=id)
    
    if node_type:
        query = query.filter_by(node_type=node_type)
    
    if query_text:
        query = query.filter(
            db.or_(
                GraphNode.node_id.contains(query_text),
                GraphNode.label.contains(query_text)
            )
        )
    
    nodes = query.limit(50).all()
    return jsonify([node.to_dict() for node in nodes])


# ============= ANALYTICS ROUTES =============

@app.route('/api/analytics/dashboard', methods=['GET'])
def get_analytics_dashboard():
    """Get aggregate analytics across all fabrics"""
    
    # Total counts
    total_fabrics = Fabric.query.count()
    total_documents = db.session.query(func.sum(Fabric.documents_count)).scalar() or 0
    total_chunks = db.session.query(func.sum(Fabric.chunks_count)).scalar() or 0
    total_graph_nodes = db.session.query(func.sum(Fabric.graph_nodes)).scalar() or 0
    
    # Fabrics by status
    status_counts = db.session.query(
        Fabric.status,
        func.count(Fabric.id)
    ).group_by(Fabric.status).all()
    
    fabrics_by_status = {status: count for status, count in status_counts}
    
    # Recent fabrics
    recent_fabrics = Fabric.query.order_by(
        Fabric.created_at.desc()
    ).limit(5).all()
    
    # Source type distribution
    fabrics = Fabric.query.all()
    source_distribution = {
        "uploads": 0,
        "servicenow": 0,
        "sharepoint": 0
    }
    
    for fabric in fabrics:
        breakdown = fabric.source_breakdown or {}
        for source_type, count in breakdown.items():
            if count > 0:
                source_distribution[source_type] += 1
    
    # Recent ingestion attempts
    recent_ingestions = IngestionHistory.query.order_by(
        IngestionHistory.started_at.desc()
    ).limit(10).all()
    
    # Success rate
    total_ingestions = IngestionHistory.query.count()
    successful_ingestions = IngestionHistory.query.filter_by(status='completed').count()
    success_rate = (successful_ingestions / total_ingestions * 100) if total_ingestions > 0 else 0
    
    # Average ingestion time
    avg_duration = db.session.query(
        func.avg(IngestionHistory.duration_seconds)
    ).filter(
        IngestionHistory.status == 'completed'
    ).scalar() or 0
    
    return jsonify({
        "summary": {
            "totalFabrics": total_fabrics,
            "totalDocuments": int(total_documents),
            "totalChunks": int(total_chunks),
            "totalGraphNodes": int(total_graph_nodes),
            "fabricsByStatus": fabrics_by_status,
            "sourceDistribution": source_distribution
        },
        "ingestionMetrics": {
            "totalAttempts": total_ingestions,
            "successfulAttempts": successful_ingestions,
            "successRate": round(success_rate, 2),
            "avgDurationSeconds": int(avg_duration)
        },
        "recentFabrics": [f.to_dict() for f in recent_fabrics],
        "recentIngestions": [i.to_dict() for i in recent_ingestions]
    })


@app.route('/api/analytics/fabrics-over-time', methods=['GET'])
def get_fabrics_over_time():
    """Get fabric creation over time"""
    days = int(request.args.get('days', 30))
    
    start_date = datetime.utcnow() - timedelta(days=days)
    
    fabrics = Fabric.query.filter(
        Fabric.created_at >= start_date
    ).order_by(Fabric.created_at).all()
    
    # Group by date
    date_counts = {}
    for fabric in fabrics:
        date_key = fabric.created_at.strftime('%Y-%m-%d')
        date_counts[date_key] = date_counts.get(date_key, 0) + 1
    
    return jsonify({
        "data": [
            {"date": date, "count": count}
            for date, count in sorted(date_counts.items())
        ]
    })


@app.route('/api/analytics/source-breakdown', methods=['GET'])
def get_analytics_source_breakdown():
    """Get aggregate source breakdown across all fabrics"""
    fabrics = Fabric.query.all()
    
    total_by_source = {
        "uploads": {"fabrics": 0, "documents": 0, "chunks": 0},
        "servicenow": {"fabrics": 0, "documents": 0, "chunks": 0},
        "sharepoint": {"fabrics": 0, "documents": 0, "chunks": 0}
    }
    
    for fabric in fabrics:
        breakdown = fabric.source_breakdown or {}
        for source_type, doc_count in breakdown.items():
            if doc_count > 0:
                total_by_source[source_type]["fabrics"] += 1
                total_by_source[source_type]["documents"] += doc_count
    
    return jsonify(total_by_source)

# IMPROVED KB Coverage Endpoint - Shows Incident Coverage Gaps
@app.route('/api/fabrics/<id>/kb-coverage-matrix', methods=['GET'])
def get_kb_coverage_matrix(id):
    """Get KB article coverage matrix showing incident gaps"""
    fabric = Fabric.query.get_or_404(id)
    
    # Get all nodes for this fabric
    nodes = GraphNode.query.filter_by(fabric_id=id).all()
    edges = GraphEdge.query.filter_by(fabric_id=id).all()
    
    print(f"DEBUG: Total nodes: {len(nodes)}")
    print(f"DEBUG: Total edges: {len(edges)}")
    
    # Get all unique node types
    node_types = set(n.node_type for n in nodes)
    print(f"DEBUG: Node types: {node_types}")
    
    # Extract incidents, KB articles, and categories
    incidents = [n for n in nodes if n.node_type in ['incident', 'inc']]
    kb_articles = [n for n in nodes if n.node_type in ['kb_article', 'kb', 'knowledge_base']]
    categories = [n for n in nodes if n.node_type in ['category', 'cat']]
    
    print(f"DEBUG: Incidents found: {len(incidents)}")
    print(f"DEBUG: KB articles found: {len(kb_articles)}")
    print(f"DEBUG: Categories found: {len(categories)}")
    
    # If no data, return empty with debug info
    if not incidents and not kb_articles:
        return jsonify({
            "categories": [],
            "incidentCounts": [],
            "kbCoverageCounts": [],
            "coveragePercentages": [],
            "gaps": [],
            "totalIncidents": 0,
            "totalKBArticles": 0,
            "debug": {
                "availableNodeTypes": list(node_types),
                "totalNodes": len(nodes),
                "totalEdges": len(edges)
            }
        })
    
    if not categories:
        print("DEBUG: No categories found - using documents as categories")
        categories = [n for n in nodes if n.node_type == 'document']
    
    # Build incident -> categories mapping
    incident_categories = {}
    for edge in edges:
        if edge.relationship_type == 'BELONGS_TO':
            source_node = next((n for n in nodes if n.id == edge.source_node_id), None)
            target_node = next((n for n in nodes if n.id == edge.target_node_id), None)
            
            if source_node and target_node:
                # Check if source is an incident or document mentioning incidents
                incident_id = source_node.id
                if incident_id not in incident_categories:
                    incident_categories[incident_id] = []
                incident_categories[incident_id].append(target_node.label)
    
    print(f"DEBUG: Documents/Incidents with categories: {len(incident_categories)}")
    
    # Build incident -> KB mapping (which incidents have KB article references)
    incidents_with_kb = {}
    for edge in edges:
        if edge.relationship_type in ['MENTIONS', 'REFERENCES']:
            source_node = next((n for n in nodes if n.id == edge.source_node_id), None)
            target_node = next((n for n in nodes if n.id == edge.target_node_id), None)
            
            # Check if target is a KB article
            if target_node and target_node.node_type in ['kb_article', 'kb', 'knowledge_base']:
                if source_node:
                    incident_id = source_node.id
                    if incident_id not in incidents_with_kb:
                        incidents_with_kb[incident_id] = []
                    incidents_with_kb[incident_id].append(target_node.node_id)
    
    print(f"DEBUG: Incidents with KB references: {len(incidents_with_kb)}")
    
    # Get unique categories
    all_categories = sorted(set(cat for cats in incident_categories.values() for cat in cats))
    
    if not all_categories:
        all_categories = sorted([cat.label for cat in categories])
    
    if not all_categories:
        all_categories = ['Uncategorized']
    
    print(f"DEBUG: Total unique categories: {len(all_categories)}")
    
    # Build analysis by category
    category_data = {}
    for category in all_categories:
        category_data[category] = {
            'total_incidents': 0,
            'incidents_with_kb': 0,
            'incidents_without_kb': 0,
            'unique_kb_articles': set()
        }
    
    # Count incidents per category
    for incident_id, cats in incident_categories.items():
        for cat in cats:
            if cat in category_data:
                category_data[cat]['total_incidents'] += 1
                
                # Check if this incident has KB reference
                if incident_id in incidents_with_kb:
                    category_data[cat]['incidents_with_kb'] += 1
                    # Track which KB articles are used
                    for kb_id in incidents_with_kb[incident_id]:
                        category_data[cat]['unique_kb_articles'].add(kb_id)
                else:
                    category_data[cat]['incidents_without_kb'] += 1
    
    # Prepare response data
    categories_list = []
    incident_counts = []
    kb_coverage_counts = []
    coverage_percentages = []
    gaps = []
    kb_article_counts = []
    
    for category in all_categories:
        data = category_data[category]
        total = data['total_incidents']
        covered = data['incidents_with_kb']
        gap = data['incidents_without_kb']
        kb_count = len(data['unique_kb_articles'])
        
        coverage_pct = (covered / total * 100) if total > 0 else 0
        
        categories_list.append(category)
        incident_counts.append(total)
        kb_coverage_counts.append(covered)
        coverage_percentages.append(round(coverage_pct, 1))
        gaps.append(gap)
        kb_article_counts.append(kb_count)
    
    print(f"DEBUG: Analysis complete")
    
    return jsonify({
        "categories": categories_list,
        "incidentCounts": incident_counts,
        "kbCoverageCounts": kb_coverage_counts,
        "coveragePercentages": coverage_percentages,
        "gaps": gaps,
        "kbArticleCounts": kb_article_counts,
        "totalIncidents": sum(incident_counts),
        "totalKBArticles": len(kb_articles),
        "totalCoveredIncidents": sum(kb_coverage_counts),
        "totalGapIncidents": sum(gaps),
        "overallCoveragePercentage": round(sum(kb_coverage_counts) / sum(incident_counts) * 100, 1) if sum(incident_counts) > 0 else 0
    })

# ============= CHAT ROUTES =============

@app.route('/api/chat', methods=['POST'])
def chat():
    """Process chat query"""
    data = request.json
    fabric_id = data.get('fabricId')
    messages = data.get('messages', [])
    
    fabric = Fabric.query.get(fabric_id)
    if not fabric:
        return jsonify({"error": "Fabric not found"}), 404
    
    if fabric.status != "Ready":
        return jsonify({"error": "Fabric not ready"}), 400
    
    collection_name = fabric.rag_config.get('chromaCollection')
    
    try:
        agent = ChatAgent(collection_name)
        result = agent.chat(messages[-1]['content'])
        
        return jsonify({
            "conversationId": "conv-1",
            "messages": messages + [{
                "role": "assistant",
                "content": result['answer'],
                "sources": result.get('sources', [])
            }]
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ============= FEEDBACK ROUTES =============

@app.route('/api/feedback', methods=['POST'])
def submit_feedback():
    """Submit user feedback"""
    data = request.json
    print(f"Feedback received: {data}")
    return '', 204


# ============= CONNECTION TEST ROUTES =============

@app.route('/api/connections/servicenow/check-credentials', methods=['GET'])
def check_servicenow_credentials():
    """Check if ServiceNow credentials are configured"""
    configured = bool(Config.SERVICENOW_USER and Config.SERVICENOW_PASS)
    return jsonify({
        "configured": configured,
        "message": "Credentials configured" if configured else "Credentials not set"
    })


@app.route('/api/connections/servicenow/test', methods=['POST'])
def test_servicenow_connection():
    """Test ServiceNow connection"""
    data = request.json
    instance_url = data.get('instanceUrl')
    return jsonify({
        "success": True,
        "message": "Connection successful"
    })


@app.route('/api/connections/sharepoint/test', methods=['POST'])
def test_sharepoint_connection():
    """Test SharePoint connection"""
    data = request.json
    site_url = data.get('siteUrl')
    return jsonify({
        "success": True,
        "message": "Connection successful"
    })


# ============= DEBUG ENDPOINT =============

@app.route('/api/fabrics/<id>/debug-graph', methods=['GET'])
def debug_graph(id):
    """Debug endpoint to see what's in the graph"""
    nodes = GraphNode.query.filter_by(fabric_id=id).all()
    edges = GraphEdge.query.filter_by(fabric_id=id).all()
    
    # Count node types
    node_types = {}
    for node in nodes:
        node_types[node.node_type] = node_types.get(node.node_type, 0) + 1
    
    # Count edge types
    edge_types = {}
    for edge in edges:
        edge_types[edge.relationship_type] = edge_types.get(edge.relationship_type, 0) + 1
    
    # Sample nodes by type
    samples = {}
    for node_type in node_types.keys():
        sample_nodes = [n for n in nodes if n.node_type == node_type][:3]
        samples[node_type] = [
            {
                'node_id': n.node_id,
                'label': n.label,
                'properties': n.properties
            } for n in sample_nodes
        ]
    
    return jsonify({
        'totalNodes': len(nodes),
        'totalEdges': len(edges),
        'nodeTypeCounts': node_types,
        'edgeTypeCounts': edge_types,
        'sampleNodesByType': samples
    })

### making these changes for v 0.4
# Initialize OpenAI client
openai_client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))


@app.route('/api/fabrics/<id>/incidents-without-kb', methods=['GET'])
def get_incidents_without_kb(id):
    """Get incidents that don't have KB article coverage, grouped by category"""
    category = request.args.get('category')  # Optional: filter by specific category
    
    # Get all nodes and edges
    nodes = GraphNode.query.filter_by(fabric_id=id).all()
    edges = GraphEdge.query.filter_by(fabric_id=id).all()
    
    # Get all documents/incidents
    all_documents = [n for n in nodes if n.node_type in ['incident', 'inc', 'document']]
    
    # Build document -> KB mapping
    docs_with_kb = set()
    for edge in edges:
        if edge.relationship_type in ['MENTIONS', 'REFERENCES']:
            source_node = next((n for n in nodes if n.id == edge.source_node_id), None)
            target_node = next((n for n in nodes if n.id == edge.target_node_id), None)
            
            if target_node and target_node.node_type in ['kb_article', 'kb', 'knowledge_base']:
                if source_node:
                    docs_with_kb.add(source_node.id)
    
    # Build document -> category mapping
    doc_categories = {}
    for edge in edges:
        if edge.relationship_type == 'BELONGS_TO':
            source_node = next((n for n in nodes if n.id == edge.source_node_id), None)
            target_node = next((n for n in nodes if n.id == edge.target_node_id), None)
            
            if source_node and target_node:
                doc_id = source_node.id
                if doc_id not in doc_categories:
                    doc_categories[doc_id] = []
                doc_categories[doc_id].append(target_node.label)
    
    # Extract category keywords from properties if no edges
    category_keywords = ['VPN', 'Email', 'Network', 'Password', 'Hardware', 
                        'Software', 'Database', 'Server', 'Firewall', 
                        'Authentication', 'Security']
    
    for doc in all_documents:
        if doc.id not in doc_categories:
            doc_text = (doc.label or '').upper()
            if doc.properties:
                doc_text += ' ' + str(doc.properties).upper()
            
            found_categories = []
            for keyword in category_keywords:
                if keyword.upper() in doc_text:
                    found_categories.append(keyword)
            
            if found_categories:
                doc_categories[doc.id] = found_categories
            else:
                doc_categories[doc.id] = ['Uncategorized']
    
    # Get incidents without KB coverage
    incidents_by_category = {}
    
    for doc in all_documents:
        # Skip if has KB coverage
        if doc.id in docs_with_kb:
            continue
        
        # Get categories
        categories = doc_categories.get(doc.id, ['Uncategorized'])
        
        # If filtering by category, skip if not in category
        if category and category not in categories:
            continue
        
        # Add to results
        for cat in categories:
            if cat not in incidents_by_category:
                incidents_by_category[cat] = []
            
            # Get content from node properties or label
            content = ''
            if doc.properties:
                content = str(doc.properties)
            if doc.label:
                content = doc.label + '\n' + content
            
            incident_data = {
                'id': doc.id,
                'incident_number': doc.node_id,
                'label': doc.label,
                'properties': doc.properties or {},
                'content': content,
                'category': cat
            }
            
            incidents_by_category[cat].append(incident_data)
    
    # Sort by category
    sorted_categories = sorted(incidents_by_category.keys())
    
    result = {
        'categories': []
    }
    
    for cat in sorted_categories:
        result['categories'].append({
            'name': cat,
            'count': len(incidents_by_category[cat]),
            'incidents': incidents_by_category[cat]
        })
    
    return jsonify(result)


@app.route('/api/fabrics/<id>/generate-kb-article', methods=['POST'])
def generate_kb_article_from_incidents(id):
    """Generate a KB article from selected incidents using AI"""
    data = request.json
    
    incident_ids = data.get('incident_ids', [])
    category = data.get('category', 'General')
    
    if not incident_ids:
        return jsonify({'error': 'No incidents selected'}), 400
    
    # Get incident details from GraphNode
    nodes = GraphNode.query.filter_by(fabric_id=id).filter(
        GraphNode.id.in_(incident_ids)
    ).all()
    
    incidents_data = []
    for node in nodes:
        # Get content from node properties or label
        content = ''
        if node.properties:
            content = str(node.properties)
        if node.label:
            content = node.label + '\n' + content
        
        incidents_data.append({
            'number': node.node_id,
            'label': node.label,
            'content': content
        })
    
    # Generate KB article using OpenAI
    try:
        kb_article = generate_kb_article_with_ai(incidents_data, category)
        return jsonify(kb_article)
    except Exception as e:
        print(f"Error generating KB article: {e}")
        return jsonify({'error': str(e)}), 500


def generate_kb_article_with_ai(incidents, category):
    """Use OpenAI to generate a KB article from incidents"""
    
    # Prepare incidents summary for prompt
    incidents_summary = "\n\n".join([
        f"INCIDENT {i+1}: {inc['number']}\n{inc['content'][:500]}"
        for i, inc in enumerate(incidents)
    ])
    
    prompt = f"""You are a technical writer creating a Knowledge Base article for IT support.

CATEGORY: {category}

INCIDENTS TO ADDRESS:
{incidents_summary}

Based on these incidents, create a comprehensive KB article that:
1. Identifies the common problem(s)
2. Lists symptoms users experience
3. Provides step-by-step troubleshooting
4. Includes detailed resolution steps
5. Mentions related issues
6. Provides support contact info

Format the KB article as follows:

TITLE: [Clear, descriptive title]

CATEGORY: {category}

## Overview
[Brief description of the issue]

## Symptoms
[List of symptoms users may experience]

## Common Causes
[What typically causes this issue]

## Resolution Steps

### Step 1: [First step]
[Detailed instructions]

### Step 2: [Second step]
[Detailed instructions]

[Continue with more steps as needed]

## Prevention
[How to prevent this issue]

## Related Issues
[List of related problems]

## Additional Support
[How to get more help]

---

Generate the KB article now:"""

    try:
        response = openai_client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are an expert technical writer creating IT support documentation."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=2000
        )
        
        content = response.choices[0].message.content
        
        # Extract title from content
        title_line = content.split('\n')[0]
        title = title_line.replace('TITLE:', '').strip()
        
        # Generate KB number
        kb_number = f"KB{random.randint(1000000, 9999999):07d}"
        
        return {
            'kb_number': kb_number,
            'title': title,
            'category': category,
            'content': content,
            'incident_count': len(incidents),
            'incident_numbers': [inc['number'] for inc in incidents]
        }
        
    except Exception as e:
        raise Exception(f"AI generation failed: {str(e)}")


@app.route('/api/fabrics/<id>/save-kb-article', methods=['POST'])
def save_kb_article(id):
    """Save generated KB article and link to incidents"""
    data = request.json
    
    kb_number = data.get('kb_number')
    title = data.get('title')
    category = data.get('category')
    content = data.get('content')
    incident_ids = data.get('incident_ids', [])
    
    if not all([kb_number, title, content]):
        return jsonify({'error': 'Missing required fields'}), 400
    
    try:
        # Create KB article document record
        kb_doc = FabricDocument(
            fabric_id=id,
            source_type='kb_article',
            source_name=kb_number,
            document_count=1,
            chunk_count=0,
            file_type='txt',
            meta_data={'title': title, 'category': category, 'content': content}
        )
        db.session.add(kb_doc)
        
        # Create KB article node
        kb_node = GraphNode(
            fabric_id=id,
            node_id=kb_number,
            node_type='kb_article',
            label=title,
            properties={'category': category, 'content': content}
        )
        db.session.add(kb_node)
        db.session.flush()  # Get the kb_node.id
        
        # Link incidents to KB article
        for incident_id in incident_ids:
            incident_node = GraphNode.query.get(incident_id)
            if incident_node:
                edge = GraphEdge(
                    fabric_id=id,
                    source_node_id=incident_id,
                    target_node_id=kb_node.id,
                    relationship_type='REFERENCES'
                )
                db.session.add(edge)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'kb_number': kb_number,
            'message': f'KB article {kb_number} created and linked to {len(incident_ids)} incidents'
        })
        
    except Exception as e:
        db.session.rollback()
        print(f"Error saving KB article: {e}")
        return jsonify({'error': str(e)}), 500
if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True, port=4000)
