from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import JSON, Text
from datetime import datetime
import uuid

db = SQLAlchemy()

def generate_uuid():
    return str(uuid.uuid4())

class Fabric(db.Model):
    __tablename__ = 'fabrics'

    id = db.Column(db.String(36), primary_key=True, default=generate_uuid)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    domain = db.Column(db.String(50), nullable=False)
    status = db.Column(db.String(20), default="Draft") 
    
    # Use generic JSON (works with SQLite)
    sources_config = db.Column(JSON, nullable=True, default={})
    rag_config = db.Column(JSON, nullable=True, default={})
    
    # Stats
    documents_count = db.Column(db.Integer, default=0)
    chunks_count = db.Column(db.Integer, default=0)
    graph_nodes = db.Column(db.Integer, default=0)
    graph_edges = db.Column(db.Integer, default=0)
    
    # NEW: Detailed ingestion statistics
    ingestion_stats = db.Column(JSON, nullable=True, default={})
    
    # NEW: Source breakdown for quick access
    source_breakdown = db.Column(JSON, nullable=True, default={})
    
    # NEW: Last sync tracking
    last_synced_at = db.Column(db.DateTime, nullable=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "domain": self.domain,
            "status": self.status,
            "sources": self.sources_config,
            "ragConfig": self.rag_config,
            "createdAt": self.created_at.isoformat(),
            "updatedAt": self.updated_at.isoformat(),
            "documentsCount": self.documents_count,
            "chunksCount": self.chunks_count,
            "graphNodes": self.graph_nodes,
            "graphEdges": self.graph_edges,
            "ingestionStats": self.ingestion_stats or {},
            "sourceBreakdown": self.source_breakdown or {},
            "lastSyncedAt": self.last_synced_at.isoformat() if self.last_synced_at else None,
        }


class IngestionHistory(db.Model):
    """Track history of fabric ingestion attempts"""
    __tablename__ = 'ingestion_history'
    
    id = db.Column(db.String(36), primary_key=True, default=generate_uuid)
    fabric_id = db.Column(db.String(36), db.ForeignKey('fabrics.id'), nullable=False)
    
    # Ingestion metadata
    started_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime, nullable=True)
    status = db.Column(db.String(20), nullable=False)  # 'started', 'completed', 'failed'
    
    # What was ingested
    sources_ingested = db.Column(JSON, nullable=True)  # List of sources processed
    documents_ingested = db.Column(db.Integer, default=0)
    chunks_created = db.Column(db.Integer, default=0)
    
    # Details and errors
    details = db.Column(JSON, nullable=True)  # Detailed breakdown
    error_message = db.Column(db.Text, nullable=True)
    
    # Duration
    duration_seconds = db.Column(db.Integer, nullable=True)
    
    def to_dict(self):
        return {
            "id": self.id,
            "fabricId": self.fabric_id,
            "startedAt": self.started_at.isoformat(),
            "completedAt": self.completed_at.isoformat() if self.completed_at else None,
            "status": self.status,
            "sourcesIngested": self.sources_ingested or [],
            "documentsIngested": self.documents_ingested,
            "chunksCreated": self.chunks_created,
            "details": self.details or {},
            "errorMessage": self.error_message,
            "durationSeconds": self.duration_seconds,
        }


class GraphNode(db.Model):
    """Knowledge Graph Nodes"""
    __tablename__ = 'graph_nodes'
    
    id = db.Column(db.String(36), primary_key=True, default=generate_uuid)
    fabric_id = db.Column(db.String(36), db.ForeignKey('fabrics.id'), nullable=False)
    
    # Node identity
    node_id = db.Column(db.String(100), nullable=False)  # e.g., "INC0012345", "KB0056789"
    node_type = db.Column(db.String(50), nullable=False)  # 'incident', 'kb_article', 'category', 'product', etc.
    
    # Node properties
    label = db.Column(db.String(200), nullable=False)  # Display name
    properties = db.Column(JSON, nullable=True)  # Additional properties as JSON
    
    # Metadata
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Composite unique constraint
    __table_args__ = (
        db.UniqueConstraint('fabric_id', 'node_id', name='uix_fabric_node'),
    )
    
    def to_dict(self):
        return {
            "id": self.id,
            "fabricId": self.fabric_id,
            "nodeId": self.node_id,
            "nodeType": self.node_type,
            "label": self.label,
            "properties": self.properties or {},
            "createdAt": self.created_at.isoformat(),
        }


class GraphEdge(db.Model):
    """Knowledge Graph Edges (Relationships)"""
    __tablename__ = 'graph_edges'
    
    id = db.Column(db.String(36), primary_key=True, default=generate_uuid)
    fabric_id = db.Column(db.String(36), db.ForeignKey('fabrics.id'), nullable=False)
    
    # Edge definition
    source_node_id = db.Column(db.String(36), db.ForeignKey('graph_nodes.id'), nullable=False)
    target_node_id = db.Column(db.String(36), db.ForeignKey('graph_nodes.id'), nullable=False)
    relationship_type = db.Column(db.String(50), nullable=False)  # 'RESOLVED_BY', 'RELATED_TO', 'MENTIONS', etc.
    
    # Edge properties
    properties = db.Column(JSON, nullable=True)  # Weight, confidence, etc.
    
    # Metadata
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            "id": self.id,
            "fabricId": self.fabric_id,
            "sourceNodeId": self.source_node_id,
            "targetNodeId": self.target_node_id,
            "relationshipType": self.relationship_type,
            "properties": self.properties or {},
            "createdAt": self.created_at.isoformat(),
        }


class FabricDocument(db.Model):
    """Track individual documents/files within a fabric"""
    __tablename__ = 'fabric_documents'
    
    id = db.Column(db.String(36), primary_key=True, default=generate_uuid)
    fabric_id = db.Column(db.String(36), db.ForeignKey('fabrics.id'), nullable=False)
    
    # Document identity
    source_type = db.Column(db.String(50), nullable=False)  # 'upload', 'servicenow_incident', 'servicenow_kb', etc.
    source_name = db.Column(db.String(200), nullable=False)  # Filename or record ID
    
    # Statistics
    document_count = db.Column(db.Integer, default=0)  # LangChain documents from this source
    chunk_count = db.Column(db.Integer, default=0)  # Chunks from this source
    
    # Metadata
    file_size = db.Column(db.Integer, nullable=True)  # Bytes
    file_type = db.Column(db.String(50), nullable=True)  # 'pdf', 'txt', 'docx'
    meta_data = db.Column(JSON, nullable=True)  # Additional metadata (renamed from 'metadata' to avoid SQLAlchemy conflict)
    
    # Timestamps
    ingested_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            "id": self.id,
            "fabricId": self.fabric_id,
            "sourceType": self.source_type,
            "sourceName": self.source_name,
            "documentCount": self.document_count,
            "chunkCount": self.chunk_count,
            "fileSize": self.file_size,
            "fileType": self.file_type,
            "metadata": self.meta_data or {},
            "ingestedAt": self.ingested_at.isoformat(),
        }
