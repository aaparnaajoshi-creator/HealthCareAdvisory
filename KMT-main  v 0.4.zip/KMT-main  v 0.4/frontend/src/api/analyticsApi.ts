import axiosClient from "./axiosClient";

export interface DashboardMetrics {
  summary: {
    totalFabrics: number;
    totalDocuments: number;
    totalChunks: number;
    totalGraphNodes: number;
    fabricsByStatus: Record<string, number>;
    sourceDistribution: Record<string, number>;
  };
  ingestionMetrics: {
    totalAttempts: number;
    successfulAttempts: number;
    successRate: number;
    avgDurationSeconds: number;
  };
  recentFabrics: any[];
  recentIngestions: any[];
}

export interface IngestionHistoryRecord {
  id: string;
  fabricId: string;
  startedAt: string;
  completedAt: string | null;
  status: string;
  sourcesIngested: string[];
  documentsIngested: number;
  chunksCreated: number;
  details: any;
  errorMessage: string | null;
  durationSeconds: number | null;
}

export interface DetailedStats {
  stored: {
    documentsCount: number;
    chunksCount: number;
    graphNodes: number;
    graphEdges: number;
    ingestionStats: any;
    sourceBreakdown: any;
  };
  realtime: {
    chunksInChromaDB: number;
    matchesStored: boolean;
  };
  files: any[];
}

export interface KnowledgeGraph {
  nodes: GraphNode[];
  edges: GraphEdge[];
  stats: {
    nodeCount: number;
    edgeCount: number;
  };
}

export interface GraphNode {
  id: string;
  fabricId: string;
  nodeId: string;
  nodeType: string;
  label: string;
  properties: any;
  createdAt: string;
}

export interface GraphEdge {
  id: string;
  fabricId: string;
  sourceNodeId: string;
  targetNodeId: string;
  relationshipType: string;
  properties: any;
  createdAt: string;
}

export interface NodeDetails {
  node: GraphNode;
  outgoingEdges: GraphEdge[];
  incomingEdges: GraphEdge[];
  connectedNodes: GraphNode[];
}

export const getDashboardMetrics = async (): Promise<DashboardMetrics> => {
  const res = await axiosClient.get<DashboardMetrics>("/api/analytics/dashboard");
  return res.data;
};

export const getFabricDetailedStats = async (fabricId: string): Promise<DetailedStats> => {
  const res = await axiosClient.get<DetailedStats>(`/api/fabrics/${fabricId}/detailed-stats`);
  return res.data;
};

export const getIngestionHistory = async (fabricId: string): Promise<IngestionHistoryRecord[]> => {
  const res = await axiosClient.get<IngestionHistoryRecord[]>(`/api/fabrics/${fabricId}/ingestion-history`);
  return res.data;
};

export const getKnowledgeGraph = async (fabricId: string): Promise<KnowledgeGraph> => {
  const res = await axiosClient.get<KnowledgeGraph>(`/api/fabrics/${fabricId}/graph`);
  return res.data;
};

export const getGraphNodes = async (fabricId: string, type?: string): Promise<GraphNode[]> => {
  const params = type ? { type } : {};
  const res = await axiosClient.get<GraphNode[]>(`/api/fabrics/${fabricId}/graph/nodes`, { params });
  return res.data;
};

export const getNodeDetails = async (fabricId: string, nodeId: string): Promise<NodeDetails> => {
  const res = await axiosClient.get<NodeDetails>(`/api/fabrics/${fabricId}/graph/node/${nodeId}`);
  return res.data;
};

export const searchGraphNodes = async (fabricId: string, query: string, type?: string): Promise<GraphNode[]> => {
  const params: any = { q: query };
  if (type) params.type = type;
  const res = await axiosClient.get<GraphNode[]>(`/api/fabrics/${fabricId}/graph/search`, { params });
  return res.data;
};

export interface KBCoverageMatrix {
  categories: string[];
  incidentCounts: number[];
  kbCoverageCounts: number[];
  coveragePercentages: number[];
  gaps: number[];
  kbArticleCounts: number[];
  totalIncidents: number;
  totalKBArticles: number;
  totalCoveredIncidents: number;
  totalGapIncidents: number;
  overallCoveragePercentage: number;
}

export const getKBCoverageMatrix = async (fabricId: string): Promise<KBCoverageMatrix> => {
  const res = await axiosClient.get<KBCoverageMatrix>(`/api/fabrics/${fabricId}/kb-coverage-matrix`);
  return res.data;
};
