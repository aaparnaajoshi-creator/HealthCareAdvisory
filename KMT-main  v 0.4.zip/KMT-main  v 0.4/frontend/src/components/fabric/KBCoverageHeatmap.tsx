import React, { useEffect, useState } from "react";
import { getKBCoverageMatrix } from "../../api/analyticsApi";
import { LoadingSpinner } from "../common/LoadingSpinner";
import { EmptyState } from "../common/EmptyState";
import { ChartBarIcon, ExclamationTriangleIcon, CheckCircleIcon } from "@heroicons/react/24/outline";

interface CoverageData {
  categories: string[];
  incidentCounts: number[];
  kbCoverageCounts: number[];
  coveragePercentages: number[];
  gaps: number[];
  kbArticleCounts: number[];
  totalIncidents: number;
  totalKBArticles: number;
  totalCoveredIncidents: number;
  totalGapIncidents: number;
  overallCoveragePercentage: number;
}

interface KBCoverageHeatmapProps {
  fabricId: string;
}

export const KBCoverageHeatmap: React.FC<KBCoverageHeatmapProps> = ({ fabricId }) => {
  const [data, setData] = useState<CoverageData | null>(null);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState<"gap" | "coverage" | "incidents">("gap");

  const loadCoverageData = async () => {
    setLoading(true);
    try {
      const coverage = await getKBCoverageMatrix(fabricId);
      setData(coverage);
    } catch (err) {
      console.error("Failed to load KB coverage data", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCoverageData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fabricId]);

  const getCoverageColor = (percentage: number): string => {
    if (percentage >= 90) return "bg-green-500";
    if (percentage >= 70) return "bg-yellow-500";
    if (percentage >= 50) return "bg-orange-500";
    return "bg-red-500";
  };

  const getGapSeverity = (gap: number, total: number): string => {
    const gapPercentage = (gap / total) * 100;
    if (gapPercentage >= 50) return "🔴 CRITICAL";
    if (gapPercentage >= 30) return "🟠 HIGH";
    if (gapPercentage >= 10) return "🟡 MEDIUM";
    return "🟢 LOW";
  };

  const getSortedData = () => {
    if (!data) return null;

    const indices = data.categories.map((_, i) => i);
    
    indices.sort((a, b) => {
      if (sortBy === "gap") {
        return data.gaps[b] - data.gaps[a]; // Descending
      } else if (sortBy === "coverage") {
        return data.coveragePercentages[a] - data.coveragePercentages[b]; // Ascending
      } else {
        return data.incidentCounts[b] - data.incidentCounts[a]; // Descending
      }
    });

    return indices;
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  if (!data || data.categories.length === 0) {
    return (
      <EmptyState
        icon={<ChartBarIcon className="w-16 h-16" />}
        title="No Coverage Data"
        message="KB article coverage will be available after incidents are ingested and analyzed."
      />
    );
  }

  const sortedIndices = getSortedData() || [];

  return (
    <div className="space-y-6">
      {/* Summary Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="card p-4">
          <div className="text-sm text-slate-400">Total Incidents</div>
          <div className="text-2xl font-bold text-slate-100">{data.totalIncidents}</div>
        </div>
        <div className="card p-4">
          <div className="text-sm text-slate-400">Covered by KB</div>
          <div className="text-2xl font-bold text-green-400">{data.totalCoveredIncidents}</div>
        </div>
        <div className="card p-4">
          <div className="text-sm text-slate-400">Gap (No KB)</div>
          <div className="text-2xl font-bold text-red-400">{data.totalGapIncidents}</div>
        </div>
        <div className="card p-4">
          <div className="text-sm text-slate-400">Coverage %</div>
          <div className="text-2xl font-bold text-blue-400">{data.overallCoveragePercentage}%</div>
        </div>
      </div>

      {/* Coverage Alert */}
      {data.overallCoveragePercentage < 70 && (
        <div className="card p-4 bg-red-900/20 border-red-500">
          <div className="flex items-start space-x-3">
            <ExclamationTriangleIcon className="w-6 h-6 text-red-400 flex-shrink-0 mt-1" />
            <div>
              <h3 className="text-lg font-semibold text-red-300">Low KB Coverage Detected</h3>
              <p className="text-sm text-red-200 mt-1">
                Only {data.overallCoveragePercentage}% of incidents have KB article coverage.
                <strong className="ml-1">{data.totalGapIncidents} incidents</strong> need KB articles.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Sort Controls */}
      <div className="card p-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-100">Sort by:</h3>
          <div className="flex space-x-2">
            <button
              onClick={() => setSortBy("gap")}
              className={`px-3 py-1 rounded text-sm ${
                sortBy === "gap"
                  ? "bg-red-600 text-white"
                  : "bg-slate-700 text-slate-300 hover:bg-slate-600"
              }`}
            >
              Biggest Gap
            </button>
            <button
              onClick={() => setSortBy("coverage")}
              className={`px-3 py-1 rounded text-sm ${
                sortBy === "coverage"
                  ? "bg-yellow-600 text-white"
                  : "bg-slate-700 text-slate-300 hover:bg-slate-600"
              }`}
            >
              Lowest Coverage
            </button>
            <button
              onClick={() => setSortBy("incidents")}
              className={`px-3 py-1 rounded text-sm ${
                sortBy === "incidents"
                  ? "bg-blue-600 text-white"
                  : "bg-slate-700 text-slate-300 hover:bg-slate-600"
              }`}
            >
              Most Incidents
            </button>
          </div>
        </div>
      </div>

      {/* Coverage Table */}
      <div className="card p-6">
        <h3 className="text-lg font-semibold text-slate-100 mb-4">
          Incident Coverage by Category
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-700">
                <th className="text-left p-3 text-sm font-semibold text-slate-300">Category</th>
                <th className="text-center p-3 text-sm font-semibold text-slate-300">Total Incidents</th>
                <th className="text-center p-3 text-sm font-semibold text-slate-300">Covered by KB</th>
                <th className="text-center p-3 text-sm font-semibold text-slate-300">Gap (No KB)</th>
                <th className="text-center p-3 text-sm font-semibold text-slate-300">KB Articles</th>
                <th className="text-center p-3 text-sm font-semibold text-slate-300">Coverage %</th>
                <th className="text-center p-3 text-sm font-semibold text-slate-300">Status</th>
              </tr>
            </thead>
            <tbody>
              {sortedIndices.map((idx) => {
                const category = data.categories[idx];
                const total = data.incidentCounts[idx];
                const covered = data.kbCoverageCounts[idx];
                const gap = data.gaps[idx];
                const kbCount = data.kbArticleCounts[idx];
                const coverage = data.coveragePercentages[idx];

                return (
                  <tr
                    key={idx}
                    className="border-b border-slate-800 hover:bg-slate-800/50 transition-colors"
                  >
                    <td className="p-3 font-medium text-slate-200">{category}</td>
                    <td className="p-3 text-center text-slate-300">{total}</td>
                    <td className="p-3 text-center">
                      <span className="text-green-400 font-semibold">{covered}</span>
                    </td>
                    <td className="p-3 text-center">
                      <span
                        className={`font-bold ${
                          gap > 0 ? "text-red-400" : "text-green-400"
                        }`}
                      >
                        {gap}
                      </span>
                    </td>
                    <td className="p-3 text-center text-slate-300">{kbCount}</td>
                    <td className="p-3">
                      <div className="flex items-center justify-center space-x-2">
                        <div className="w-24 bg-slate-700 rounded-full h-2">
                          <div
                            className={`${getCoverageColor(coverage)} h-2 rounded-full`}
                            style={{ width: `${coverage}%` }}
                          ></div>
                        </div>
                        <span className="text-sm font-semibold text-slate-200 w-12">
                          {coverage}%
                        </span>
                      </div>
                    </td>
                    <td className="p-3 text-center text-xs">
                      {getGapSeverity(gap, total)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr className="bg-slate-900 border-t-2 border-slate-700">
                <td className="p-3 font-bold text-slate-100">TOTAL</td>
                <td className="p-3 text-center font-bold text-slate-100">{data.totalIncidents}</td>
                <td className="p-3 text-center font-bold text-green-400">
                  {data.totalCoveredIncidents}
                </td>
                <td className="p-3 text-center font-bold text-red-400">{data.totalGapIncidents}</td>
                <td className="p-3 text-center font-bold text-slate-100">{data.totalKBArticles}</td>
                <td className="p-3 text-center font-bold text-blue-400">
                  {data.overallCoveragePercentage}%
                </td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* Action Items */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Priority Gaps */}
        <div className="card p-4">
          <h4 className="text-sm font-semibold text-red-300 mb-3 flex items-center">
            <ExclamationTriangleIcon className="w-5 h-5 mr-2" />
            Priority: Create KB Articles
          </h4>
          <div className="space-y-2">
            {sortedIndices
              .filter((idx) => data.gaps[idx] > 0)
              .slice(0, 5)
              .map((idx) => {
                const category = data.categories[idx];
                const gap = data.gaps[idx];
                const total = data.incidentCounts[idx];

                return (
                  <div
                    key={idx}
                    className="flex items-center justify-between p-2 bg-red-900/20 border border-red-800 rounded"
                  >
                    <div>
                      <div className="text-sm font-medium text-red-200">{category}</div>
                      <div className="text-xs text-red-300">
                        {gap} incidents without KB coverage
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs text-red-400">
                        {getGapSeverity(gap, total)}
                      </div>
                    </div>
                  </div>
                );
              })}
            {data.totalGapIncidents === 0 && (
              <div className="text-sm text-green-400 text-center py-2 flex items-center justify-center">
                <CheckCircleIcon className="w-5 h-5 mr-2" />
                All incidents have KB coverage!
              </div>
            )}
          </div>
        </div>

        {/* Well Covered Categories */}
        <div className="card p-4">
          <h4 className="text-sm font-semibold text-green-300 mb-3 flex items-center">
            <CheckCircleIcon className="w-5 h-5 mr-2" />
            Well Covered Categories
          </h4>
          <div className="space-y-2">
            {sortedIndices
              .filter((idx) => data.coveragePercentages[idx] >= 70)
              .slice(0, 5)
              .map((idx) => {
                const category = data.categories[idx];
                const coverage = data.coveragePercentages[idx];
                const total = data.incidentCounts[idx];
                const kbCount = data.kbArticleCounts[idx];

                return (
                  <div
                    key={idx}
                    className="flex items-center justify-between p-2 bg-green-900/20 border border-green-800 rounded"
                  >
                    <div>
                      <div className="text-sm font-medium text-green-200">{category}</div>
                      <div className="text-xs text-green-300">
                        {kbCount} KB articles covering {total} incidents
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-bold text-green-400">{coverage}%</div>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      </div>

      {/* Recommendations */}
      {data.totalGapIncidents > 0 && (
        <div className="card p-6 bg-blue-900/20 border-blue-700">
          <h3 className="text-lg font-semibold text-blue-300 mb-3">📝 Recommendations</h3>
          <ul className="space-y-2 text-sm text-blue-200">
            <li className="flex items-start">
              <span className="mr-2">1.</span>
              <span>
                <strong>Create {Math.ceil(data.totalGapIncidents / 5)} new KB articles</strong> to
                cover the {data.totalGapIncidents} incidents without documentation
              </span>
            </li>
            <li className="flex items-start">
              <span className="mr-2">2.</span>
              <span>
                Focus on categories marked as 🔴 CRITICAL or 🟠 HIGH priority first
              </span>
            </li>
            <li className="flex items-start">
              <span className="mr-2">3.</span>
              <span>
                Target coverage goal: <strong>90%</strong> (currently at{" "}
                {data.overallCoveragePercentage}%)
              </span>
            </li>
          </ul>
        </div>
      )}
    </div>
  );
};
