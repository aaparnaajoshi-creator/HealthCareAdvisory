export type FabricStatus =
  | "Draft"
  | "Ingesting"
  | "Chunking"
  | "Vectorizing"
  | "GraphBuilding"
  | "Ready"
  | "Error";

export interface FabricSources {
  serviceNow?: {
    enabled: boolean;
    instanceUrl?: string;
    tables?: string[];
  };
  sharePoint?: {
    enabled: boolean;
    siteUrl?: string;
    library?: string;
  };
  uploads?: {
    fileNames: string[];
  };
}

export interface Fabric {
  id: string;
  name: string;
  description: string;
  domain:
    | "Incident Management"
    | "Problem Management"
    | "Change Management"
    | string;
  status: FabricStatus;
  sources: FabricSources;
  createdAt: string;
  updatedAt: string;
  chunksCount?: number;
  graphNodes?: number;
  graphEdges?: number;
  documentsCount?: number;
  error?: string;
  
  // NEW FIELDS
  ingestionStats?: {
    uploads?: {
      file_count: number;
      document_count: number;
      files: Record<string, number>;
    };
    servicenow?: {
      total_records: number;
      by_table: Record<string, number>;
    };
    total_documents?: number;
    total_chunks?: number;
  };
  sourceBreakdown?: {
    uploads: number;
    servicenow: number;
    sharepoint: number;
  };
  lastSyncedAt?: string | null;
}
