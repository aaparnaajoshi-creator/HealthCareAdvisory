﻿import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { KBArticleGenerator } from "../components/fabric/KBArticleGenerator";
import { SparklesIcon, CubeIcon } from "@heroicons/react/24/outline";
import { getFabrics } from "../api/fabricsApi";
import { Fabric } from "../types/fabric";

export const GenerateKBArticlePage: React.FC = () => {
    const { fabricId } = useParams<{ fabricId: string }>();
    const navigate = useNavigate();
    const [loading, setLoading] = useState(true);
    const [fabrics, setFabrics] = useState<Fabric[]>([]);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        // If we already have a fabricId from URL, we're good
        if (fabricId) {
            setLoading(false);
            return;
        }

        // Otherwise, fetch available fabrics using your API
        const fetchFabrics = async () => {
            try {
                const data = await getFabrics();
                console.log('Fetched fabrics:', data);

                if (data && data.length > 0) {
                    setFabrics(data);

                    // If only one fabric, auto-select it
                    if (data.length === 1) {
                        navigate(`/generate-kb/${data[0].id}`, { replace: true });
                    }
                } else {
                    setError('No fabrics available. Please create a fabric first.');
                }
            } catch (err: any) {
                console.error('Error fetching fabrics:', err);
                setError(err.message || 'Could not load fabrics. Please check your backend connection.');
            } finally {
                setLoading(false);
            }
        };

        fetchFabrics();
    }, [fabricId, navigate]);

    const handleFabricSelect = (selectedFabricId: string) => {
        navigate(`/generate-kb/${selectedFabricId}`);
    };

    // Loading state
    if (loading) {
        return (
            <div className="flex items-center justify-center min-h-screen bg-slate-950">
                <div className="text-center">
                    <SparklesIcon className="w-16 h-16 mx-auto text-purple-400 mb-4 animate-pulse" />
                    <p className="text-slate-400">Loading fabrics...</p>
                </div>
            </div>
        );
    }

    // If we have a fabricId, show the KB Article Generator
    if (fabricId) {
        return (
            <div className="min-h-screen bg-slate-950 p-6">
                <div className="max-w-7xl mx-auto">
                    <div className="mb-6">
                        <button
                            onClick={() => navigate('/generate-kb')}
                            className="text-slate-400 hover:text-slate-200 text-sm mb-2 flex items-center transition-colors"
                        >
                            ← Back to Fabric Selection
                        </button>
                        <h1 className="text-3xl font-bold text-slate-100 flex items-center">
                            <SparklesIcon className="w-8 h-8 mr-3 text-purple-400" />
                            Generate KB Article
                        </h1>
                    </div>
                    <KBArticleGenerator
                        fabricId={fabricId}
                        onClose={() => navigate('/generate-kb')}
                        onSuccess={() => navigate('/generate-kb')}
                        standalone={true}
                    />
                </div>
            </div>
        );
    }

    // Error state
    if (error) {
        return (
            <div className="flex items-center justify-center min-h-screen bg-slate-950">
                <div className="text-center max-w-md">
                    <div className="text-red-400 text-6xl mb-4">⚠️</div>
                    <h2 className="text-2xl font-bold text-slate-100 mb-2">Error Loading Fabrics</h2>
                    <p className="text-slate-400 mb-6">{error}</p>
                    <div className="space-y-3">
                        <button
                            onClick={() => navigate('/fabrics')}
                            className="w-full px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
                        >
                            Create a Fabric
                        </button>
                        <button
                            onClick={() => window.location.reload()}
                            className="w-full px-6 py-3 border border-slate-600 hover:border-slate-500 text-slate-300 rounded-lg transition-colors"
                        >
                            Retry
                        </button>
                    </div>
                </div>
            </div>
        );
    }

    // Fabric selection UI (multiple fabrics)
    return (
        <div className="min-h-screen bg-slate-950 p-6">
            <div className="max-w-4xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-slate-100 flex items-center mb-2">
                        <SparklesIcon className="w-8 h-8 mr-3 text-purple-400" />
                        Generate KB Article
                    </h1>
                    <p className="text-slate-400">
                        Select a fabric to generate KB articles from incidents
                    </p>
                </div>

                {fabrics.length > 0 ? (
                    <div className="space-y-4">
                        {fabrics.map((fabric) => (
                            <button
                                key={fabric.id}
                                onClick={() => handleFabricSelect(fabric.id)}
                                className="w-full bg-slate-800 border border-slate-700 hover:border-purple-600 rounded-lg p-6 text-left transition-all hover:shadow-lg hover:shadow-purple-900/20 group"
                            >
                                <div className="flex items-center justify-between">
                                    <div className="flex items-center space-x-4">
                                        <div className="w-12 h-12 bg-purple-900/30 rounded-lg flex items-center justify-center group-hover:bg-purple-900/50 transition-colors">
                                            <CubeIcon className="w-6 h-6 text-purple-400" />
                                        </div>
                                        <div>
                                            <h3 className="text-lg font-semibold text-slate-100">
                                                {fabric.name}
                                            </h3>
                                            {fabric.description && (
                                                <p className="text-sm text-slate-400 mt-1">
                                                    {fabric.description}
                                                </p>
                                            )}
                                            {fabric.domain && (
                                                <p className="text-xs text-slate-500 mt-1">
                                                    Domain: {fabric.domain}
                                                </p>
                                            )}
                                        </div>
                                    </div>
                                    <div className="text-slate-400 group-hover:text-purple-400 transition-colors">
                                        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                                        </svg>
                                    </div>
                                </div>
                            </button>
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-12">
                        <CubeIcon className="w-16 h-16 mx-auto text-slate-600 mb-4" />
                        <p className="text-slate-400 mb-4">No fabrics available</p>
                        <button
                            onClick={() => navigate('/fabrics')}
                            className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
                        >
                            Create Your First Fabric
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};