import React, { useState } from "react";
import { useFabricContext } from "../../context/FabricContext";
import { useToast } from "../../components/toast/ToastProvider";
import { Stepper } from "../../components/common/Stepper";
import { CreateFabricPayload, uploadDocuments } from "../../api/fabricsApi";
import { 
  XMarkIcon, 
  DocumentArrowUpIcon,
  TableCellsIcon,
  DocumentTextIcon,
  CheckCircleIcon,
  ExclamationCircleIcon
} from "@heroicons/react/24/outline";

interface DocumentUploadWizardProps {
  isOpen: boolean;
  onClose: () => void;
}

// File type icons and colors
const FILE_TYPE_CONFIG: Record<string, { icon: React.ReactNode; color: string; label: string }> = {
  csv: { 
    icon: <TableCellsIcon className="w-5 h-5" />, 
    color: 'text-green-400', 
    label: 'CSV Data' 
  },
  pdf: { 
    icon: <DocumentTextIcon className="w-5 h-5" />, 
    color: 'text-red-400', 
    label: 'PDF Document' 
  },
  docx: { 
    icon: <DocumentTextIcon className="w-5 h-5" />, 
    color: 'text-blue-400', 
    label: 'Word Document' 
  },
  txt: { 
    icon: <DocumentTextIcon className="w-5 h-5" />, 
    color: 'text-slate-400', 
    label: 'Text File' 
  },
};

// CSV type detection from filename
const detectCSVType = (filename: string): string => {
  const lower = filename.toLowerCase();
  if (lower.includes('kb') || lower.includes('knowledge') || lower.includes('article')) {
    return 'KB Articles';
  }
  if (lower.includes('incident') || lower.includes('inc')) {
    return 'Incidents';
  }
  if (lower.includes('ci_categor') || lower.includes('category')) {
    return 'CI Categories';
  }
  if (lower.includes('sub_categor') || lower.includes('subcategor')) {
    return 'Sub-Categories';
  }
  return 'Data File';
};

const STEPS = [
  "Fabric Basics",
  "Upload Documents",
  "RAG Configuration",
  "Review & Create",
];

export const DocumentUploadWizard: React.FC<DocumentUploadWizardProps> = ({
  isOpen,
  onClose,
}) => {
  const { createNewFabric, triggerBuild, reloadFabrics } = useFabricContext();
  const { showToast } = useToast();
  const [currentStep, setCurrentStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadResults, setUploadResults] = useState<any[]>([]);

  // Step 1: Basics
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [domain, setDomain] = useState("Incident Management");

  // Step 2: Documents
  const [uploadFiles, setUploadFiles] = useState<File[]>([]);

  // Step 3: RAG Configuration
  const [chunkSize, setChunkSize] = useState(512);
  const [chunkOverlap, setChunkOverlap] = useState(64);
  const [embeddingModel, setEmbeddingModel] = useState("text-embedding-3-large");
  const [chromaCollection, setChromaCollection] = useState("");

  // Get file extension
  const getFileExtension = (filename: string): string => {
    return filename.split('.').pop()?.toLowerCase() || '';
  };

  // Handle file selection - UPDATED to accept CSV
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const validFiles = files.filter(
      (file) =>
        // PDF
        file.type === "application/pdf" ||
        file.name.endsWith(".pdf") ||
        // Text
        file.type === "text/plain" ||
        file.name.endsWith(".txt") ||
        // Word
        file.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
        file.name.endsWith(".docx") ||
        // CSV - NEW
        file.type === "text/csv" ||
        file.type === "application/vnd.ms-excel" ||
        file.name.endsWith(".csv")
    );
    
    // Warn about invalid files
    const invalidFiles = files.filter(f => !validFiles.includes(f));
    if (invalidFiles.length > 0) {
      showToast(`${invalidFiles.length} file(s) not supported. Allowed: PDF, DOCX, TXT, CSV`, "warning");
    }
    
    setUploadFiles([...uploadFiles, ...validFiles]);
  };

  const handleRemoveFile = (index: number) => {
    setUploadFiles(uploadFiles.filter((_, i) => i !== index));
  };

  // Get file type info for display
  const getFileTypeInfo = (file: File) => {
    const ext = getFileExtension(file.name);
    const config = FILE_TYPE_CONFIG[ext] || FILE_TYPE_CONFIG.txt;
    
    // For CSV, detect the type
    if (ext === 'csv') {
      const csvType = detectCSVType(file.name);
      return { ...config, label: csvType };
    }
    
    return config;
  };

  // Count files by type
  const fileCounts = {
    csv: uploadFiles.filter(f => getFileExtension(f.name) === 'csv').length,
    documents: uploadFiles.filter(f => ['pdf', 'docx', 'txt'].includes(getFileExtension(f.name))).length,
  };

  const handleCreate = async () => {
    if (!name || !chromaCollection) {
      showToast("Please fill in all required fields", "error");
      return;
    }

    if (uploadFiles.length === 0) {
      showToast("Please upload at least one document", "error");
      return;
    }

    setLoading(true);
    setUploadResults([]);
    
    try {
      // Step 1: Create fabric
      const payload: CreateFabricPayload = {
        name,
        description,
        domain,
        sources: {
          uploads: {
            fileNames: uploadFiles.map((f) => f.name),
          },
        },
        chunkSize,
        chunkOverlap,
        embeddingModel,
        chromaCollection,
      };

      const newFabric = await createNewFabric(payload);
      showToast("Fabric created. Uploading documents...", "info");

      // Step 2: Upload documents (backend will auto-detect CSV)
      setUploading(true);
      try {
        const result = await uploadDocuments(newFabric.id, uploadFiles);
        setUploadResults(result.results || []);
        
        // Show summary
        const csvIngested = result.results?.filter((r: any) => r.status === 'ingested').length || 0;
        const docsUploaded = result.results?.filter((r: any) => r.type === 'document').length || 0;
        
        if (csvIngested > 0) {
          showToast(`${csvIngested} CSV file(s) ingested, ${docsUploaded} document(s) uploaded`, "success");
        } else {
          showToast("Documents uploaded successfully", "success");
        }
      } catch (uploadError: any) {
        showToast(uploadError.message || "Failed to upload documents", "error");
        throw uploadError;
      } finally {
        setUploading(false);
      }

      // Step 3: Trigger RAG architecture build
      await triggerBuild(newFabric.id);
      
      // Reload fabrics
      await reloadFabrics();
      
      showToast(
        "Knowledge Fabric created! RAG architecture build started.",
        "success"
      );
      handleClose();
    } catch (error: any) {
      showToast(error.message || "Failed to create fabric", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setCurrentStep(1);
    setName("");
    setDescription("");
    setDomain("Incident Management");
    setUploadFiles([]);
    setChunkSize(512);
    setChunkOverlap(64);
    setEmbeddingModel("text-embedding-3-large");
    setChromaCollection("");
    setUploadResults([]);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex">
      <div className="fixed inset-0 bg-black/50" onClick={handleClose} />
      <div className="fixed right-0 top-0 h-full w-full lg:w-2/5 bg-slate-900 border-l border-slate-800 shadow-2xl overflow-y-auto">
        <div className="sticky top-0 bg-slate-900 border-b border-slate-800 p-6 flex items-center justify-between z-10">
          <div className="flex items-center space-x-3">
            <DocumentArrowUpIcon className="w-6 h-6 text-blue-400" />
            <h2 className="text-xl font-bold text-slate-100">Document Upload Fabric</h2>
          </div>
          <button onClick={handleClose} className="text-slate-400 hover:text-white">
            <XMarkIcon className="w-6 h-6" />
          </button>
        </div>
        <div className="p-6">
          <Stepper currentStep={currentStep} totalSteps={4} steps={STEPS} />

          {/* Step 1: Basics */}
          {currentStep === 1 && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Fabric Name *
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:ring-2 focus:ring-brand-600"
                  placeholder="e.g., Incident Resolution Knowledge Base"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Description
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={4}
                  className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:ring-2 focus:ring-brand-600"
                  placeholder="Describe the purpose and scope of this knowledge fabric..."
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Business Domain
                </label>
                <select
                  value={domain}
                  onChange={(e) => setDomain(e.target.value)}
                  className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:ring-2 focus:ring-brand-600"
                >
                  <option>Incident Management</option>
                  <option>IT Service Management</option>
                  <option>Customer Support</option>
                  <option>Security Operations</option>
                  <option>Application Support</option>
                  <option>Infrastructure</option>
                  <option>Other</option>
                </select>
              </div>

              <div className="flex justify-end pt-4">
                <button onClick={() => setCurrentStep(2)} className="btn-primary">
                  Next
                </button>
              </div>
            </div>
          )}

          {/* Step 2: Upload Documents */}
          {currentStep === 2 && (
            <div className="space-y-4">
              {/* File Type Info */}
              <div className="card p-4 bg-blue-600/10 border border-blue-600/20">
                <h4 className="font-medium text-slate-100 mb-2">Supported File Types</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="flex items-center space-x-2 text-slate-300">
                    <TableCellsIcon className="w-4 h-4 text-green-400" />
                    <span>CSV (KB, Incidents, Categories)</span>
                  </div>
                  <div className="flex items-center space-x-2 text-slate-300">
                    <DocumentTextIcon className="w-4 h-4 text-red-400" />
                    <span>PDF Documents</span>
                  </div>
                  <div className="flex items-center space-x-2 text-slate-300">
                    <DocumentTextIcon className="w-4 h-4 text-blue-400" />
                    <span>Word Documents (.docx)</span>
                  </div>
                  <div className="flex items-center space-x-2 text-slate-300">
                    <DocumentTextIcon className="w-4 h-4 text-slate-400" />
                    <span>Text Files (.txt)</span>
                  </div>
                </div>
              </div>

              {/* Upload Area */}
              <div className="border-2 border-dashed border-slate-700 rounded-lg p-8 text-center hover:border-brand-600 transition-colors">
                <input
                  type="file"
                  multiple
                  accept=".pdf,.docx,.txt,.csv"
                  onChange={handleFileSelect}
                  className="hidden"
                  id="file-upload"
                />
                <label htmlFor="file-upload" className="cursor-pointer">
                  <DocumentArrowUpIcon className="w-12 h-12 mx-auto text-slate-500 mb-4" />
                  <p className="text-slate-300 mb-2">
                    Drag & drop files here, or click to browse
                  </p>
                  <p className="text-sm text-slate-500">
                    PDF, DOCX, TXT, CSV (max 50MB each)
                  </p>
                </label>
              </div>

              {/* File Summary */}
              {uploadFiles.length > 0 && (
                <div className="flex items-center justify-between p-3 bg-slate-800 rounded-lg">
                  <div className="flex items-center space-x-4 text-sm">
                    <span className="text-slate-300">
                      {uploadFiles.length} file(s) selected
                    </span>
                    {fileCounts.csv > 0 && (
                      <span className="px-2 py-0.5 bg-green-600/20 text-green-400 rounded">
                        {fileCounts.csv} CSV
                      </span>
                    )}
                    {fileCounts.documents > 0 && (
                      <span className="px-2 py-0.5 bg-blue-600/20 text-blue-400 rounded">
                        {fileCounts.documents} Documents
                      </span>
                    )}
                  </div>
                </div>
              )}

              {/* File List */}
              {uploadFiles.length > 0 && (
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {uploadFiles.map((file, index) => {
                    const typeInfo = getFileTypeInfo(file);
                    return (
                      <div
                        key={index}
                        className="flex items-center justify-between p-3 bg-slate-800 rounded-lg"
                      >
                        <div className="flex items-center space-x-3">
                          <span className={typeInfo.color}>{typeInfo.icon}</span>
                          <div>
                            <span className="text-slate-200 text-sm">{file.name}</span>
                            <div className="flex items-center space-x-2">
                              <span className="text-xs text-slate-500">
                                {(file.size / 1024).toFixed(1)} KB
                              </span>
                              <span className={`text-xs ${typeInfo.color}`}>
                                {typeInfo.label}
                              </span>
                            </div>
                          </div>
                        </div>
                        <button
                          onClick={() => handleRemoveFile(index)}
                          className="text-red-400 hover:text-red-300"
                        >
                          <XMarkIcon className="w-5 h-5" />
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* CSV Info */}
              {fileCounts.csv > 0 && (
                <div className="card p-4 bg-green-600/10 border border-green-600/20">
                  <div className="flex items-start space-x-3">
                    <TableCellsIcon className="w-5 h-5 text-green-400 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-green-300">CSV Files Detected</h4>
                      <p className="text-sm text-green-200/70 mt-1">
                        CSV files will be automatically ingested based on their content:
                      </p>
                      <ul className="text-sm text-green-200/70 mt-2 space-y-1">
                        <li>• <strong>kb_articles*.csv</strong> → KB Articles</li>
                        <li>• <strong>incidents*.csv</strong> → Incidents</li>
                        <li>• <strong>ci_categories*.csv</strong> → CI Categories</li>
                      </ul>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex justify-end space-x-2 pt-4">
                <button onClick={() => setCurrentStep(1)} className="btn-secondary">
                  Back
                </button>
                <button
                  onClick={() => setCurrentStep(3)}
                  disabled={uploadFiles.length === 0}
                  className="btn-primary"
                >
                  Next
                </button>
              </div>
            </div>
          )}

          {/* Step 3: RAG Configuration */}
          {currentStep === 3 && (
            <div className="space-y-6">
              <div className="card p-4">
                <h3 className="font-semibold text-slate-100 mb-4">Chunking Settings</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Chunk Size (tokens)
                    </label>
                    <input
                      type="number"
                      value={chunkSize}
                      onChange={(e) => setChunkSize(parseInt(e.target.value) || 512)}
                      className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:ring-2 focus:ring-brand-600"
                    />
                    <p className="text-xs text-slate-500 mt-1">
                      Recommended: 512-1024 tokens per chunk
                    </p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      Chunk Overlap (tokens)
                    </label>
                    <input
                      type="number"
                      value={chunkOverlap}
                      onChange={(e) => setChunkOverlap(parseInt(e.target.value) || 64)}
                      className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:ring-2 focus:ring-brand-600"
                    />
                    <p className="text-xs text-slate-500 mt-1">
                      Recommended: 10-20% of chunk size
                    </p>
                  </div>
                </div>
              </div>

              <div className="card p-4">
                <h3 className="font-semibold text-slate-100 mb-4">Embedding Model</h3>
                <select
                  value={embeddingModel}
                  onChange={(e) => setEmbeddingModel(e.target.value)}
                  className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:ring-2 focus:ring-brand-600"
                >
                  <option>text-embedding-3-large</option>
                  <option>text-embedding-3-small</option>
                  <option>azure-openai-embedding-1</option>
                  <option>custom-embedding</option>
                </select>
              </div>

              <div className="card p-4">
                <h3 className="font-semibold text-slate-100 mb-4">Chroma Collection Name *</h3>
                <input
                  type="text"
                  value={chromaCollection}
                  onChange={(e) => setChromaCollection(e.target.value)}
                  className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-100 focus:outline-none focus:ring-2 focus:ring-brand-600"
                  placeholder="knowledge-fabric-collection"
                />
                <p className="text-xs text-slate-500 mt-1">
                  Collection name in Chroma DB for storing vectorized chunks
                </p>
              </div>

              <div className="card p-4 bg-blue-600/10 border border-blue-600/20">
                <h3 className="font-semibold text-slate-100 mb-3">RAG Architecture Pipeline</h3>
                <div className="space-y-2 text-sm text-slate-300">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span>1. CSV Ingestion (KB, Incidents, Categories)</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span>2. Document Ingestion & Parsing</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span>3. Text Chunking (Size: {chunkSize}, Overlap: {chunkOverlap})</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span>4. Vectorization ({embeddingModel})</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span>5. Store in Chroma DB ({chromaCollection || 'collection'})</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span>6. Build Knowledge Graph</span>
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <button onClick={() => setCurrentStep(2)} className="btn-secondary">
                  Back
                </button>
                <button onClick={() => setCurrentStep(4)} className="btn-primary">
                  Next
                </button>
              </div>
            </div>
          )}

          {/* Step 4: Review & Create */}
          {currentStep === 4 && (
            <div className="space-y-6">
              <div className="card p-6">
                <h3 className="font-semibold text-slate-100 mb-4">Summary</h3>
                <div className="space-y-3 text-sm">
                  <div>
                    <span className="text-slate-400">Name:</span>{" "}
                    <span className="text-slate-100">{name}</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Description:</span>{" "}
                    <span className="text-slate-100">{description || "None"}</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Domain:</span>{" "}
                    <span className="text-slate-100">{domain}</span>
                  </div>
                  <div className="border-t border-slate-700 pt-3 mt-3">
                    <span className="text-slate-400">Files:</span>{" "}
                    <span className="text-slate-100">{uploadFiles.length} total</span>
                    {fileCounts.csv > 0 && (
                      <span className="ml-2 px-2 py-0.5 bg-green-600/20 text-green-400 rounded text-xs">
                        {fileCounts.csv} CSV
                      </span>
                    )}
                    {fileCounts.documents > 0 && (
                      <span className="ml-2 px-2 py-0.5 bg-blue-600/20 text-blue-400 rounded text-xs">
                        {fileCounts.documents} Docs
                      </span>
                    )}
                  </div>
                  <div>
                    <span className="text-slate-400">Chunk Size:</span>{" "}
                    <span className="text-slate-100">{chunkSize}</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Chunk Overlap:</span>{" "}
                    <span className="text-slate-100">{chunkOverlap}</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Embedding Model:</span>{" "}
                    <span className="text-slate-100">{embeddingModel}</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Chroma Collection:</span>{" "}
                    <span className="text-slate-100">{chromaCollection}</span>
                  </div>
                </div>
              </div>

              {/* Upload Results (shown during/after upload) */}
              {uploadResults.length > 0 && (
                <div className="card p-4">
                  <h4 className="font-medium text-slate-100 mb-3">Upload Results</h4>
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {uploadResults.map((result, idx) => (
                      <div 
                        key={idx} 
                        className={`flex items-center justify-between p-2 rounded text-sm ${
                          result.status === 'ingested' 
                            ? 'bg-green-600/10 border border-green-600/20' 
                            : result.status === 'failed'
                            ? 'bg-red-600/10 border border-red-600/20'
                            : 'bg-slate-800'
                        }`}
                      >
                        <div className="flex items-center space-x-2">
                          {result.status === 'ingested' ? (
                            <CheckCircleIcon className="w-4 h-4 text-green-400" />
                          ) : result.status === 'failed' ? (
                            <ExclamationCircleIcon className="w-4 h-4 text-red-400" />
                          ) : (
                            <DocumentTextIcon className="w-4 h-4 text-slate-400" />
                          )}
                          <span className="text-slate-200">{result.filename}</span>
                        </div>
                        <div className="text-xs">
                          {result.status === 'ingested' && result.stats && (
                            <span className="text-green-400">
                              {result.stats.succeeded} records
                            </span>
                          )}
                          {result.status === 'uploaded' && (
                            <span className="text-slate-400">Uploaded</span>
                          )}
                          {result.status === 'failed' && (
                            <span className="text-red-400">Failed</span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex justify-end space-x-2 pt-4">
                <button onClick={() => setCurrentStep(3)} className="btn-secondary">
                  Back
                </button>
                <button
                  onClick={handleCreate}
                  disabled={loading || uploading || !name || !chromaCollection}
                  className="btn-primary"
                >
                  {loading || uploading
                    ? uploading
                      ? "Uploading & Ingesting..."
                      : "Creating..."
                    : "Create Fabric with RAG"}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
