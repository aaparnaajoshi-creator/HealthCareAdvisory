// =============================================================================
// SERVICENOW IMPORT WIZARD - Simple 3-Step Version
// =============================================================================
// Place in: frontend/src/pages/Fabrics/ServiceNowWizard.tsx

import React, { useState } from 'react';
import {
    XMarkIcon,
    ArrowLeftIcon,
    ArrowRightIcon,
    CloudIcon,
    CheckCircleIcon,
    ExclamationTriangleIcon,
} from '@heroicons/react/24/outline';
import axiosClient from '../../api/axiosClient';

interface ServiceNowWizardProps {
    isOpen: boolean;
    onClose: () => void;
    onComplete?: (fabricId: string) => void;
}

export const ServiceNowWizard: React.FC<ServiceNowWizardProps> = ({
    isOpen,
    onClose,
    onComplete,
}) => {
    // Wizard state
    const [step, setStep] = useState(1);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    // Step 1: Connection
    const [instanceUrl, setInstanceUrl] = useState('');
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [connectionId, setConnectionId] = useState<string | null>(null);
    const [availableCounts, setAvailableCounts] = useState({ kb_articles: 0, incidents: 0 });

    // Step 2: Configuration
    const [fabricName, setFabricName] = useState('');
    const [fabricDescription, setFabricDescription] = useState('');
    const [importKB, setImportKB] = useState(true);
    const [importIncidents, setImportIncidents] = useState(true);
    const [kbLimit, setKbLimit] = useState(100);
    const [incidentLimit, setIncidentLimit] = useState(500);
    const [incidentState, setIncidentState] = useState('resolved_or_closed');

    // Step 3: Result
    const [importResult, setImportResult] = useState<any>(null);

    if (!isOpen) return null;

    // =========================================================================
    // HANDLERS
    // =========================================================================

    const handleConnect = async () => {
        setLoading(true);
        setError(null);

        try {
            const response = await axiosClient.post(
                '/api/servicenow/connect',
                {
                    instance_url: instanceUrl,
                    username,
                    password,
                },
                { timeout: 120000 }  // 2 minutes timeout
            );

            if (response.data.success) {
                setConnectionId(response.data.connection_id);
                setAvailableCounts(response.data.available);
                setFabricName(`ServiceNow Import - ${new Date().toLocaleDateString()}`);
                setStep(2);
            } else {
                setError(response.data.error || 'Connection failed');
            }
        } catch (err: any) {
            setError(err.response?.data?.error || err.message || 'Connection failed');
        } finally {
            setLoading(false);
        }
    };

    const handleImport = async () => {
        setLoading(true);
        setError(null);

        try {
            const response = await axiosClient.post(
                '/api/servicenow/import',
                {
                    connection_id: connectionId,
                    fabric_name: fabricName,
                    fabric_description: fabricDescription,
                    import_kb: importKB,
                    import_incidents: importIncidents,
                    kb_limit: kbLimit,
                    incident_limit: incidentLimit,
                    incident_state: incidentState,
                },
                { timeout: 600000 }  // 10 minutes timeout for import
            );

            if (response.data.success) {
                setImportResult(response.data);
                setStep(3);
            } else {
                setError(response.data.error || 'Import failed');
            }
        } catch (err: any) {
            setError(err.response?.data?.error || err.message || 'Import failed');
        } finally {
            setLoading(false);
        }
    };

    const handleClose = () => {
        // Cleanup connection
        if (connectionId) {
            axiosClient.post('/api/servicenow/disconnect', { connection_id: connectionId }).catch(() => { });
        }
        onClose();
    };

    const handleComplete = () => {
        if (importResult?.fabric_id && onComplete) {
            onComplete(importResult.fabric_id);
        }
        handleClose();
    };

    // =========================================================================
    // RENDER
    // =========================================================================

    return (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-slate-800 rounded-xl w-full max-w-lg overflow-hidden">
                {/* Header */}
                <div className="flex items-center justify-between p-4 border-b border-slate-700">
                    <div className="flex items-center space-x-3">
                        <CloudIcon className="w-6 h-6 text-orange-500" />
                        <h2 className="text-lg font-semibold text-white">Import from ServiceNow</h2>
                    </div>
                    <button onClick={handleClose} className="p-2 hover:bg-slate-700 rounded-lg">
                        <XMarkIcon className="w-5 h-5 text-slate-400" />
                    </button>
                </div>

                {/* Progress */}
                <div className="px-4 py-3 border-b border-slate-700 flex justify-center space-x-4">
                    {['Connect', 'Configure', 'Complete'].map((label, i) => (
                        <div key={label} className="flex items-center">
                            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-sm font-medium ${step > i + 1 ? 'bg-green-500 text-white' :
                                    step === i + 1 ? 'bg-brand-500 text-white' : 'bg-slate-700 text-slate-400'
                                }`}>
                                {step > i + 1 ? '✓' : i + 1}
                            </div>
                            <span className={`ml-2 text-sm ${step >= i + 1 ? 'text-white' : 'text-slate-500'}`}>{label}</span>
                            {i < 2 && <div className={`w-8 h-0.5 mx-2 ${step > i + 1 ? 'bg-green-500' : 'bg-slate-700'}`} />}
                        </div>
                    ))}
                </div>

                {/* Content */}
                <div className="p-6">
                    {error && (
                        <div className="mb-4 p-3 bg-red-500/20 border border-red-500/50 rounded-lg text-red-400 text-sm flex items-center">
                            <ExclamationTriangleIcon className="w-5 h-5 mr-2 flex-shrink-0" />
                            {error}
                        </div>
                    )}

                    {/* STEP 1: Connect */}
                    {step === 1 && (
                        <div className="space-y-4">
                            <p className="text-slate-400 text-sm text-center mb-6">
                                Enter your ServiceNow credentials to connect
                            </p>
                            <div>
                                <label className="block text-sm font-medium text-slate-300 mb-1">Instance URL</label>
                                <input
                                    type="text"
                                    value={instanceUrl}
                                    onChange={(e) => setInstanceUrl(e.target.value)}
                                    placeholder="https://company.service-now.com"
                                    className="w-full px-3 py-2 bg-slate-900 border border-slate-600 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-brand-500"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-slate-300 mb-1">Username</label>
                                <input
                                    type="text"
                                    value={username}
                                    onChange={(e) => setUsername(e.target.value)}
                                    placeholder="admin"
                                    className="w-full px-3 py-2 bg-slate-900 border border-slate-600 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-brand-500"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-slate-300 mb-1">Password</label>
                                <input
                                    type="password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    placeholder="••••••••"
                                    className="w-full px-3 py-2 bg-slate-900 border border-slate-600 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-brand-500"
                                />
                            </div>
                            <button
                                onClick={handleConnect}
                                disabled={loading || !instanceUrl || !username || !password}
                                className="w-full py-2.5 bg-brand-500 hover:bg-brand-600 disabled:bg-slate-600 disabled:cursor-not-allowed rounded-lg text-white font-medium flex items-center justify-center"
                            >
                                {loading ? (
                                    <><div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />Connecting...</>
                                ) : (
                                    <>Connect <ArrowRightIcon className="w-4 h-4 ml-2" /></>
                                )}
                            </button>
                        </div>
                    )}

                    {/* STEP 2: Configure */}
                    {step === 2 && (
                        <div className="space-y-4">
                            {/* Available counts */}
                            <div className="grid grid-cols-2 gap-3 mb-4">
                                <div className="p-3 bg-green-500/10 border border-green-500/30 rounded-lg text-center">
                                    <div className="text-2xl font-bold text-green-400">{availableCounts.kb_articles}</div>
                                    <div className="text-xs text-slate-400">KB Articles Available</div>
                                </div>
                                <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-center">
                                    <div className="text-2xl font-bold text-red-400">{availableCounts.incidents}</div>
                                    <div className="text-xs text-slate-400">Incidents Available</div>
                                </div>
                            </div>

                            {/* Fabric name */}
                            <div>
                                <label className="block text-sm font-medium text-slate-300 mb-1">Fabric Name</label>
                                <input
                                    type="text"
                                    value={fabricName}
                                    onChange={(e) => setFabricName(e.target.value)}
                                    className="w-full px-3 py-2 bg-slate-900 border border-slate-600 rounded-lg text-white focus:outline-none focus:border-brand-500"
                                />
                            </div>

                            {/* Data selection */}
                            <div className="space-y-3">
                                <label className="block text-sm font-medium text-slate-300">What to Import</label>

                                <div className="flex items-center justify-between p-3 bg-slate-900 rounded-lg">
                                    <label className="flex items-center cursor-pointer">
                                        <input
                                            type="checkbox"
                                            checked={importKB}
                                            onChange={(e) => setImportKB(e.target.checked)}
                                            className="w-4 h-4 rounded border-slate-500 text-brand-500 mr-3"
                                        />
                                        <span className="text-white">KB Articles</span>
                                    </label>
                                    {importKB && (
                                        <div className="flex items-center">
                                            <span className="text-slate-400 text-sm mr-2">Limit:</span>
                                            <input
                                                type="number"
                                                value={kbLimit}
                                                onChange={(e) => setKbLimit(Math.min(500, parseInt(e.target.value) || 0))}
                                                className="w-20 px-2 py-1 bg-slate-800 border border-slate-600 rounded text-white text-sm"
                                                max={500}
                                            />
                                        </div>
                                    )}
                                </div>

                                <div className="p-3 bg-slate-900 rounded-lg space-y-3">
                                    <div className="flex items-center justify-between">
                                        <label className="flex items-center cursor-pointer">
                                            <input
                                                type="checkbox"
                                                checked={importIncidents}
                                                onChange={(e) => setImportIncidents(e.target.checked)}
                                                className="w-4 h-4 rounded border-slate-500 text-brand-500 mr-3"
                                            />
                                            <span className="text-white">Incidents</span>
                                        </label>
                                        {importIncidents && (
                                            <div className="flex items-center">
                                                <span className="text-slate-400 text-sm mr-2">Limit:</span>
                                                <input
                                                    type="number"
                                                    value={incidentLimit}
                                                    onChange={(e) => setIncidentLimit(Math.min(2000, parseInt(e.target.value) || 0))}
                                                    className="w-20 px-2 py-1 bg-slate-800 border border-slate-600 rounded text-white text-sm"
                                                    max={2000}
                                                />
                                            </div>
                                        )}
                                    </div>
                                    {importIncidents && (
                                        <div className="flex items-center">
                                            <span className="text-slate-400 text-sm mr-2">State:</span>
                                            <select
                                                value={incidentState}
                                                onChange={(e) => setIncidentState(e.target.value)}
                                                className="px-2 py-1 bg-slate-800 border border-slate-600 rounded text-white text-sm"
                                            >
                                                <option value="resolved_or_closed">Resolved & Closed</option>
                                                <option value="resolved">Resolved Only</option>
                                                <option value="closed">Closed Only</option>
                                                <option value="">All States</option>
                                            </select>
                                        </div>
                                    )}
                                </div>
                            </div>

                            {/* Navigation */}
                            <div className="flex justify-between pt-4">
                                <button onClick={() => setStep(1)} className="px-4 py-2 text-slate-400 hover:text-white flex items-center">
                                    <ArrowLeftIcon className="w-4 h-4 mr-2" />Back
                                </button>
                                <button
                                    onClick={handleImport}
                                    disabled={loading || !fabricName || (!importKB && !importIncidents)}
                                    className="px-6 py-2 bg-brand-500 hover:bg-brand-600 disabled:bg-slate-600 disabled:cursor-not-allowed rounded-lg text-white flex items-center"
                                >
                                    {loading ? (
                                        <><div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />Importing...</>
                                    ) : (
                                        <>Start Import <ArrowRightIcon className="w-4 h-4 ml-2" /></>
                                    )}
                                </button>
                            </div>
                        </div>
                    )}

                    {/* STEP 3: Complete */}
                    {step === 3 && importResult && (
                        <div className="text-center space-y-4">
                            <CheckCircleIcon className="w-16 h-16 text-green-500 mx-auto" />
                            <h3 className="text-xl font-semibold text-white">Import Complete!</h3>

                            <div className="grid grid-cols-3 gap-3 text-center">
                                <div className="p-3 bg-slate-900 rounded-lg">
                                    <div className="text-xl font-bold text-green-400">{importResult.stats?.kb_articles?.imported || 0}</div>
                                    <div className="text-xs text-slate-400">KB Articles</div>
                                </div>
                                <div className="p-3 bg-slate-900 rounded-lg">
                                    <div className="text-xl font-bold text-red-400">{importResult.stats?.incidents?.imported || 0}</div>
                                    <div className="text-xs text-slate-400">Incidents</div>
                                </div>
                                <div className="p-3 bg-slate-900 rounded-lg">
                                    <div className="text-xl font-bold text-brand-400">{importResult.stats?.chunks_created || 0}</div>
                                    <div className="text-xs text-slate-400">Chunks</div>
                                </div>
                            </div>

                            <p className="text-slate-400 text-sm">
                                Your knowledge fabric "<span className="text-white">{fabricName}</span>" is ready!
                            </p>

                            <button
                                onClick={handleComplete}
                                className="w-full py-2.5 bg-brand-500 hover:bg-brand-600 rounded-lg text-white font-medium"
                            >
                                View Fabric
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ServiceNowWizard;
