import axiosClient from "./axiosClient";
import { Fabric } from "../types/fabric";



export const getFabrics = async (): Promise<Fabric[]> => {
  const res = await axiosClient.get<Fabric[]>("/api/fabrics");
  return res.data;
};

export const getFabricById = async (id: string): Promise<Fabric> => {
  const res = await axiosClient.get<Fabric>(`/api/fabrics/${id}`);
  return res.data;
};

export interface CreateFabricPayload {
  name: string;
  description: string;
  domain: string;
  sources: Fabric["sources"];
  chunkSize: number;
  chunkOverlap: number;
  embeddingModel: string;
  chromaCollection: string;
}

export const createFabric = async (
  payload: CreateFabricPayload
): Promise<Fabric> => {
  // TODO: Backend: create fabric, persist config, initiate build state = "Draft" or "Ingesting"
  const res = await axiosClient.post<Fabric>("/api/fabrics", payload);
  return res.data;
};

export const triggerFabricBuild = async (
  id: string
): Promise<{ status: string; message?: string }> => {
  // Backend: start RAG pipeline
  // 1. Ingest documents from source (ServiceNow/SharePoint/uploads)
  // 2. Chunk documents (configurable size/overlap)
  // 3. Generate embeddings using specified model
  // 4. Store vectorized chunks in Chroma DB collection
  // 5. Build Knowledge Graph (extract entities/relationships)
  // 6. Mark fabric as "Ready" for RAG-powered chat
  try {
    const res = await axiosClient.post<{ status: string; message?: string }>(
      `/api/fabrics/${id}/build`
    );
    return res.data;
  } catch (err: any) {
    const errorMessage = err.response?.data?.error || err.message || "Failed to trigger build";
    const buildError = new Error(errorMessage);
    (buildError as any).status = err.response?.status;
    throw buildError;
  }
};

// =============================================================================
// UPLOAD DOCUMENTS - UPDATED
// =============================================================================

/**
 * Upload documents to a fabric.
 * Automatically detects CSV files and ingests them appropriately.
 * 
 * @param fabricId - The fabric ID to upload to
 * @param files - Array of files to upload
 * @returns Upload results with CSV ingestion stats
 */
export const uploadDocuments = async (
    fabricId: string,
    files: File[]
): Promise<UploadResponse> => {
    const formData = new FormData();

    files.forEach((file) => {
        formData.append("files", file);
    });

    const response = await axiosClient.post<UploadResponse>(
        `/api/fabrics/${fabricId}/upload`,
        formData,
        {
            headers: {
                "Content-Type": "multipart/form-data",
            },
            timeout: 120000, // 2 minutes for large CSV files
        }
    );

    return response.data;
};

export const checkServiceNowCredentials = async (): Promise<{
  configured: boolean;
  message?: string;
}> => {
  const res = await axiosClient.get<{ configured: boolean; message?: string }>(
    "/api/connections/servicenow/check-credentials"
  );
  return res.data;
};

export const testServiceNowConnection = async (config: {
  instanceUrl: string;
  tables?: string[];
}): Promise<{ success: boolean; message?: string }> => {
  const res = await axiosClient.post<{ success: boolean; message?: string }>(
    "/api/connections/servicenow/test",
    config
  );
  return res.data;
};

export const testSharePointConnection = async (config: {
  siteUrl: string;
  library?: string;
}): Promise<{ success: boolean; message?: string }> => {
  const res = await axiosClient.post<{ success: boolean; message?: string }>(
    "/api/connections/sharepoint/test",
    config
  );
  return res.data;
};

export const deleteFabric = async (
  id: string
): Promise<{ success: boolean; message?: string }> => {
  const res = await axiosClient.delete<{ success: boolean; message?: string }>(
    `/api/fabrics/${id}`
  );
  return res.data;
};
// =============================================================================
// UPLOAD RESPONSE TYPES
// =============================================================================

export interface UploadResult {
    filename: string;
    type: 'document' | 'kb_articles' | 'incidents' | 'ci_categories' | 'sub_categories' | 'unknown_csv';
    status: 'uploaded' | 'ingested' | 'failed' | 'rejected';
    stats?: {
        total: number;
        processed: number;
        succeeded: number;
        failed: number;
        needs_review: number;
        errors: string[];
    };
    errors?: string[];
    error?: string;
    message?: string;
    warning?: string;
}

export interface UploadResponse {
    success: boolean;
    summary: {
        total: number;
        succeeded: number;
        failed: number;
    };
    results: UploadResult[];
}
// =============================================================================
// EXPLICIT CSV INGESTION
// =============================================================================

export type CSVType = 'kb' | 'incident' | 'ci' | 'auto';

export interface CSVIngestRequest {
    file_path?: string;
    csv_type?: CSVType;
    use_csv_category?: boolean;
}

export interface CSVIngestResponse {
    success: boolean;
    csv_type: string;
    file: string;
    stats?: {
        total: number;
        processed: number;
        succeeded: number;
        failed: number;
        needs_review: number;
        errors: string[];
    };
    errors?: string[];
    warnings?: string[];
    error?: string;
}

/**
 * Explicitly ingest a CSV file with specified type.
 * 
 * @param fabricId - The fabric ID
 * @param file - CSV file to ingest
 * @param csvType - Type of CSV: 'kb', 'incident', 'ci', or 'auto'
 * @param useCsvCategory - Whether to use category from CSV (default: true)
 */
export const ingestCSV = async (
    fabricId: string,
    file: File,
    csvType: CSVType = 'auto',
    useCsvCategory: boolean = true
): Promise<CSVIngestResponse> => {
    const formData = new FormData();
    formData.append("file", file);
    formData.append("csv_type", csvType);
    formData.append("use_csv_category", String(useCsvCategory));

    const response = await axiosClient.post<CSVIngestResponse>(
        `/api/fabrics/${fabricId}/ingest-csv`,
        formData,
        {
            headers: {
                "Content-Type": "multipart/form-data",
            },
            timeout: 120000,
        }
    );

    return response.data;
};

/**
 * Ingest a CSV file from a server-side path.
 * 
 * @param fabricId - The fabric ID
 * @param filePath - Server-side path to CSV file
 * @param csvType - Type of CSV
 * @param useCsvCategory - Whether to use category from CSV
 */
export const ingestCSVFromPath = async (
    fabricId: string,
    filePath: string,
    csvType: CSVType = 'auto',
    useCsvCategory: boolean = true
): Promise<CSVIngestResponse> => {
    const response = await axiosClient.post<CSVIngestResponse>(
        `/api/fabrics/${fabricId}/ingest-csv`,
        {
            file_path: filePath,
            csv_type: csvType,
            use_csv_category: useCsvCategory
        }
    );

    return response.data;
};


