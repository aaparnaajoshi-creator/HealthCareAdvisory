/**
 * Analytics API Client - Updated
 * ================================
 * Includes new endpoints for semantic coverage calculation
 */

import axiosClient from "./axiosClient";

// =============================================================================
// TYPES - Dashboard & Stats
// =============================================================================

export interface DashboardMetrics {
  summary: {
    totalFabrics: number;
    totalDocuments: number;
    totalChunks: number;
    totalGraphNodes: number;
    fabricsByStatus: Record<string, number>;
    sourceDistribution: Record<string, number>;
  };
  ingestionMetrics: {
    totalAttempts: number;
    successfulAttempts: number;
    successRate: number;
    avgDurationSeconds: number;
  };
  recentFabrics: any[];
  recentIngestions: any[];
}

export interface IngestionHistoryRecord {
  id: string;
  fabricId: string;
  startedAt: string;
  completedAt: string | null;
  status: string;
  sourcesIngested: string[];
  documentsIngested: number;
  chunksCreated: number;
  details: any;
  errorMessage: string | null;
  durationSeconds: number | null;
}

export interface DetailedStats {
  stored: {
    documentsCount: number;
    chunksCount: number;
    graphNodes: number;
    graphEdges: number;
    ingestionStats: any;
    sourceBreakdown: any;
  };
  realtime: {
    chunksInChromaDB: number;
    matchesStored: boolean;
  };
  files: any[];
}

// =============================================================================
// TYPES - Knowledge Graph
// =============================================================================

export interface KnowledgeGraph {
  nodes: GraphNode[];
  edges: GraphEdge[];
  stats: {
    nodeCount: number;
    edgeCount: number;
  };
}

export interface GraphNode {
  id: string;
  fabricId: string;
  nodeId: string;
  nodeType: string;
  label: string;
  properties: any;
  createdAt: string;
}

export interface GraphEdge {
  id: string;
  fabricId: string;
  sourceNodeId: string;
  targetNodeId: string;
  relationshipType: string;
  properties: any;
  createdAt: string;
}

export interface NodeDetails {
  node: GraphNode;
  outgoingEdges: GraphEdge[];
  incomingEdges: GraphEdge[];
  connectedNodes: GraphNode[];
}

// =============================================================================
// TYPES - KB Coverage
// =============================================================================

export interface KBCoverageMatrix {
  categories: string[];
  incidentCounts: number[];
  kbCoverageCounts: number[];
  coveragePercentages: number[];
  gaps: number[];
  kbArticleCounts: number[];
  totalIncidents: number;
  totalKBArticles: number;
  totalCoveredIncidents: number;
  totalGapIncidents: number;
  overallCoveragePercentage: number;
  // Optional warning if fallback mode
  warning?: string;
}

export interface SubCategoryCoverage {
  [category: string]: {
    [subCategory: string]: {
      total_incidents: number;
      total_steps: number;
      covered_steps: number;
      avg_coverage_percentage: number;
    };
  };
}

export interface IncidentCoverageDetails {
  incidentId: string;
  category: string;
  subCategory: string;
  totalSteps: number;
  coveredSteps: number;
  coveragePercentage: number;
  bestMatchingKb: string | null;
  bestKbSimilarity: number;
  stepDetails: Array<{
    step: string;
    covered: boolean;
    similarity: number;
    matching_kb: string | null;
  }>;
}

// =============================================================================
// API FUNCTIONS - Dashboard
// =============================================================================

export const getDashboardMetrics = async (): Promise<DashboardMetrics> => {
  const res = await axiosClient.get<DashboardMetrics>("/api/analytics/dashboard");
  return res.data;
};

export const getFabricDetailedStats = async (fabricId: string): Promise<DetailedStats> => {
  const res = await axiosClient.get<DetailedStats>(`/api/fabrics/${fabricId}/detailed-stats`);
  return res.data;
};

export const getIngestionHistory = async (fabricId: string): Promise<IngestionHistoryRecord[]> => {
  const res = await axiosClient.get<IngestionHistoryRecord[]>(`/api/fabrics/${fabricId}/ingestion-history`);
  return res.data;
};

// =============================================================================
// API FUNCTIONS - Knowledge Graph
// =============================================================================

export const getKnowledgeGraph = async (fabricId: string): Promise<KnowledgeGraph> => {
  const res = await axiosClient.get<KnowledgeGraph>(`/api/fabrics/${fabricId}/graph`);
  return res.data;
};

export const getGraphNodes = async (fabricId: string, type?: string): Promise<GraphNode[]> => {
  const params = type ? { type } : {};
  const res = await axiosClient.get<GraphNode[]>(`/api/fabrics/${fabricId}/graph/nodes`, { params });
  return res.data;
};

export const getNodeDetails = async (fabricId: string, nodeId: string): Promise<NodeDetails> => {
  const res = await axiosClient.get<NodeDetails>(`/api/fabrics/${fabricId}/graph/node/${nodeId}`);
  return res.data;
};

export const searchGraphNodes = async (fabricId: string, query: string, type?: string): Promise<GraphNode[]> => {
  const params: any = { q: query };
  if (type) params.type = type;
  const res = await axiosClient.get<GraphNode[]>(`/api/fabrics/${fabricId}/graph/search`, { params });
  return res.data;
};

// =============================================================================
// API FUNCTIONS - KB Coverage (Updated with Semantic Coverage)
// =============================================================================

/**
 * Get KB coverage matrix using semantic similarity
 * Coverage is calculated by comparing incident resolution steps
 * with KB article content using embeddings
 */
export const getKBCoverageMatrix = async (fabricId: string): Promise<KBCoverageMatrix> => {
  const res = await axiosClient.get<KBCoverageMatrix>(`/api/fabrics/${fabricId}/kb-coverage-matrix`);
  return res.data;
};

/**
 * Get coverage breakdown by category AND sub-category
 */
export const getKBCoverageBySubcategory = async (fabricId: string): Promise<SubCategoryCoverage> => {
  const res = await axiosClient.get<SubCategoryCoverage>(`/api/fabrics/${fabricId}/kb-coverage-by-subcategory`);
  return res.data;
};

/**
 * Get detailed coverage analysis for a single incident
 * Shows which resolution steps are covered by which KB articles
 */
export const getIncidentCoverageDetails = async (
  fabricId: string,
  incidentId: string
): Promise<IncidentCoverageDetails> => {
  const res = await axiosClient.get<IncidentCoverageDetails>(
    `/api/fabrics/${fabricId}/incidents/${incidentId}/coverage`
  );
  return res.data;
};

// =============================================================================
// API FUNCTIONS - Graph with CI Categories
// =============================================================================

/**
 * Get graph data with CI categories as central nodes
 * Used for the interactive force-directed graph
 */
export const getGraphWithCategories = async (fabricId: string): Promise<KnowledgeGraph> => {
  const res = await axiosClient.get<KnowledgeGraph>(`/api/fabrics/${fabricId}/graph`, {
    params: { includeCategories: true }
  });
  return res.data;
};

/**
 * Get all CI categories for the fabric
 */
export const getCICategories = async (fabricId: string): Promise<string[]> => {
  const res = await axiosClient.get<{ categories: string[] }>(`/api/fabrics/${fabricId}/ci-categories`);
  return res.data.categories;
};

/**
 * Get nodes by category
 */
export const getNodesByCategory = async (
  fabricId: string,
  category: string,
  nodeType?: string
): Promise<GraphNode[]> => {
  const params: any = { category };
  if (nodeType) params.type = nodeType;
  const res = await axiosClient.get<GraphNode[]>(`/api/fabrics/${fabricId}/graph/nodes`, { params });
  return res.data;
};
