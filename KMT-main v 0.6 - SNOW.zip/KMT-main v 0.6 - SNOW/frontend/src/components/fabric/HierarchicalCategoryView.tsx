/**
 * Hierarchical Category View - Fixed
 * ====================================
 * Tree view showing CI categories with their incidents and KB articles
 * Fixed Map iteration for TypeScript compatibility
 */

import React, { useEffect, useState, useMemo } from "react";
import {
  getKnowledgeGraph,
  getKBCoverageMatrix,
  KnowledgeGraph,
  GraphNode,
  KBCoverageMatrix,
} from "../../api/analyticsApi";
import { LoadingSpinner } from "../common/LoadingSpinner";
import { EmptyState } from "../common/EmptyState";
import {
  FolderIcon,
  FolderOpenIcon,
  DocumentTextIcon,
  ExclamationTriangleIcon,
  ChevronRightIcon,
  ChevronDownIcon,
  BookOpenIcon,
  CubeIcon,
} from "@heroicons/react/24/outline";

// =============================================================================
// TYPES
// =============================================================================

interface SubCategoryNode {
  name: string;
  nodeType: "subcategory";
  incidents: GraphNode[];
  kbArticles: GraphNode[];
  coverage: number;
  isExpanded: boolean;
}

interface CategoryNode {
  name: string;
  nodeType: "category";
  incidents: GraphNode[];
  kbArticles: GraphNode[];
  subCategories: { [key: string]: SubCategoryNode };
  coverage: number;
  isExpanded: boolean;
}

interface HierarchicalCategoryViewProps {
  fabricId: string;
  onNodeClick?: (node: GraphNode) => void;
}

// =============================================================================
// HELPERS
// =============================================================================

const getCoverageColor = (coverage: number): string => {
  if (coverage >= 80) return "text-green-400";
  if (coverage >= 60) return "text-yellow-400";
  if (coverage >= 40) return "text-orange-400";
  if (coverage > 0) return "text-red-400";
  return "text-slate-500";
};

const getCoverageBgColor = (coverage: number): string => {
  if (coverage >= 80) return "bg-green-500";
  if (coverage >= 60) return "bg-yellow-500";
  if (coverage >= 40) return "bg-orange-500";
  if (coverage > 0) return "bg-red-500";
  return "bg-slate-600";
};

const getCoverageIcon = (coverage: number, kbCount: number): string => {
  if (kbCount === 0) return "🔴";
  if (coverage >= 80) return "🟢";
  if (coverage >= 60) return "🟡";
  if (coverage >= 40) return "🟠";
  return "🔴";
};

// =============================================================================
// COMPONENT
// =============================================================================

export const HierarchicalCategoryView: React.FC<HierarchicalCategoryViewProps> = ({
  fabricId,
  onNodeClick,
}) => {
  const [graphData, setGraphData] = useState<KnowledgeGraph | null>(null);
  const [coverageData, setCoverageData] = useState<KBCoverageMatrix | null>(null);
  const [loading, setLoading] = useState(true);
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set());
  const [expandedSubCategories, setExpandedSubCategories] = useState<Set<string>>(new Set());
  const [searchQuery, setSearchQuery] = useState("");

  // Load data
  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        const [graph, coverage] = await Promise.all([
          getKnowledgeGraph(fabricId),
          getKBCoverageMatrix(fabricId),
        ]);
        setGraphData(graph);
        setCoverageData(coverage);
      } catch (err) {
        console.error("Failed to load hierarchical data", err);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, [fabricId]);

  // Build hierarchical structure (using object instead of Map for better TS compatibility)
  const categoryTree = useMemo((): { [key: string]: CategoryNode } => {
    if (!graphData) return {};

    const tree: { [key: string]: CategoryNode } = {};

    // Group nodes by category
    graphData.nodes.forEach((node) => {
      const category = node.properties?.category_ci || node.properties?.category || "Uncategorized";
      const subCategory = node.properties?.sub_category || "General";

      // Initialize category if not exists
      if (!tree[category]) {
        // Find coverage for this category
        let coverage = 0;
        if (coverageData) {
          const idx = coverageData.categories.indexOf(category);
          if (idx >= 0) {
            coverage = coverageData.coveragePercentages[idx];
          }
        }

        tree[category] = {
          name: category,
          nodeType: "category",
          incidents: [],
          kbArticles: [],
          subCategories: {},
          coverage,
          isExpanded: false,
        };
      }

      const categoryNode = tree[category];

      // Initialize subcategory if not exists
      if (!categoryNode.subCategories[subCategory]) {
        categoryNode.subCategories[subCategory] = {
          name: subCategory,
          nodeType: "subcategory",
          incidents: [],
          kbArticles: [],
          coverage: 0,
          isExpanded: false,
        };
      }

      const subCategoryNode = categoryNode.subCategories[subCategory];

      // Add node to appropriate list
      if (node.nodeType === "incident" || node.nodeType === "inc") {
        categoryNode.incidents.push(node);
        subCategoryNode.incidents.push(node);
      } else if (node.nodeType === "kb" || node.nodeType === "kb_article") {
        categoryNode.kbArticles.push(node);
        subCategoryNode.kbArticles.push(node);
      }
    });

    return tree;
  }, [graphData, coverageData]);

  // Filtered categories based on search
  const filteredCategories = useMemo((): Array<[string, CategoryNode]> => {
    const entries = Object.entries(categoryTree);
    
    if (!searchQuery) return entries;

    const query = searchQuery.toLowerCase();
    return entries.filter(([name, data]) => {
      // Check category name
      if (name.toLowerCase().includes(query)) return true;

      // Check subcategories
      for (const subName of Object.keys(data.subCategories)) {
        if (subName.toLowerCase().includes(query)) return true;
      }

      // Check incidents and KB articles
      for (const node of [...data.incidents, ...data.kbArticles]) {
        if (node.label.toLowerCase().includes(query)) return true;
      }

      return false;
    });
  }, [categoryTree, searchQuery]);

  // Toggle category expansion
  const toggleCategory = (category: string) => {
    setExpandedCategories((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(category)) {
        newSet.delete(category);
      } else {
        newSet.add(category);
      }
      return newSet;
    });
  };

  // Toggle subcategory expansion
  const toggleSubCategory = (key: string) => {
    setExpandedSubCategories((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(key)) {
        newSet.delete(key);
      } else {
        newSet.add(key);
      }
      return newSet;
    });
  };

  // Loading state
  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  // Empty state
  if (!graphData || Object.keys(categoryTree).length === 0) {
    return (
      <EmptyState
        icon={<FolderIcon className="w-16 h-16" />}
        title="No Categories Found"
        message="Categories will appear after data is ingested."
      />
    );
  }

  const totalIncidents = Object.values(categoryTree).reduce((sum, c) => sum + c.incidents.length, 0);
  const totalKBArticles = Object.values(categoryTree).reduce((sum, c) => sum + c.kbArticles.length, 0);

  return (
    <div className="space-y-4">
      {/* Search */}
      <div className="card p-4">
        <input
          type="text"
          placeholder="Search categories, incidents, or KB articles..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-blue-500"
        />
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="card p-3">
          <div className="text-xs text-slate-400">Categories</div>
          <div className="text-xl font-bold text-purple-400">{Object.keys(categoryTree).length}</div>
        </div>
        <div className="card p-3">
          <div className="text-xs text-slate-400">Total Incidents</div>
          <div className="text-xl font-bold text-red-400">{totalIncidents}</div>
        </div>
        <div className="card p-3">
          <div className="text-xs text-slate-400">Total KB Articles</div>
          <div className="text-xl font-bold text-green-400">{totalKBArticles}</div>
        </div>
      </div>

      {/* Tree View */}
      <div className="card p-4">
        <div className="space-y-1">
          {filteredCategories.map(([categoryName, category]) => {
            const isExpanded = expandedCategories.has(categoryName);
            const hasKB = category.kbArticles.length > 0;
            const subCategoryEntries = Object.entries(category.subCategories);

            return (
              <div key={categoryName} className="border-l-2 border-slate-700">
                {/* Category Header */}
                <div
                  className="flex items-center justify-between p-2 hover:bg-slate-800 rounded-r cursor-pointer transition-colors"
                  onClick={() => toggleCategory(categoryName)}
                >
                  <div className="flex items-center space-x-2">
                    {/* Expand Icon */}
                    <span className="text-slate-400">
                      {isExpanded ? (
                        <ChevronDownIcon className="w-4 h-4" />
                      ) : (
                        <ChevronRightIcon className="w-4 h-4" />
                      )}
                    </span>

                    {/* Folder Icon */}
                    {isExpanded ? (
                      <FolderOpenIcon className="w-5 h-5 text-purple-400" />
                    ) : (
                      <FolderIcon className="w-5 h-5 text-purple-400" />
                    )}

                    {/* Category Name */}
                    <span className="font-medium text-slate-200">{categoryName}</span>

                    {/* Coverage Badge */}
                    <span className="text-xs">
                      {getCoverageIcon(category.coverage, category.kbArticles.length)}
                    </span>
                  </div>

                  {/* Stats */}
                  <div className="flex items-center space-x-4 text-xs">
                    <span className="text-red-400">{category.incidents.length} inc</span>
                    <span className={hasKB ? "text-green-400" : "text-slate-500"}>
                      {category.kbArticles.length} KB
                    </span>
                    <span className={getCoverageColor(category.coverage)}>
                      {category.coverage}%
                    </span>
                    {/* Mini progress bar */}
                    <div className="w-16 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                      <div
                        className={`h-full ${getCoverageBgColor(category.coverage)}`}
                        style={{ width: `${category.coverage}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* Expanded Content */}
                {isExpanded && (
                  <div className="ml-6 space-y-1 pb-2">
                    {/* Sub-categories */}
                    {subCategoryEntries.map(([subName, subCategory]) => {
                      const subKey = `${categoryName}:${subName}`;
                      const isSubExpanded = expandedSubCategories.has(subKey);

                      return (
                        <div key={subKey} className="border-l border-slate-700/50">
                          {/* Sub-category Header */}
                          <div
                            className="flex items-center justify-between p-1.5 pl-2 hover:bg-slate-800/50 rounded-r cursor-pointer text-sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleSubCategory(subKey);
                            }}
                          >
                            <div className="flex items-center space-x-2">
                              <span className="text-slate-500">
                                {isSubExpanded ? (
                                  <ChevronDownIcon className="w-3 h-3" />
                                ) : (
                                  <ChevronRightIcon className="w-3 h-3" />
                                )}
                              </span>
                              <CubeIcon className="w-4 h-4 text-slate-500" />
                              <span className="text-slate-400">{subName}</span>
                            </div>
                            <div className="flex items-center space-x-3 text-xs">
                              <span className="text-red-400/70">{subCategory.incidents.length}</span>
                              <span className="text-green-400/70">{subCategory.kbArticles.length}</span>
                            </div>
                          </div>

                          {/* Sub-category Items */}
                          {isSubExpanded && (
                            <div className="ml-4 space-y-0.5 py-1">
                              {/* KB Articles */}
                              {subCategory.kbArticles.map((kb) => (
                                <div
                                  key={kb.id}
                                  className="flex items-center space-x-2 p-1 pl-2 hover:bg-green-900/20 rounded text-xs cursor-pointer"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onNodeClick?.(kb);
                                  }}
                                >
                                  <BookOpenIcon className="w-3 h-3 text-green-400" />
                                  <span className="text-green-300 truncate">{kb.label}</span>
                                </div>
                              ))}

                              {/* Incidents */}
                              {subCategory.incidents.slice(0, 5).map((inc) => (
                                <div
                                  key={inc.id}
                                  className="flex items-center space-x-2 p-1 pl-2 hover:bg-red-900/20 rounded text-xs cursor-pointer"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onNodeClick?.(inc);
                                  }}
                                >
                                  <ExclamationTriangleIcon className="w-3 h-3 text-red-400" />
                                  <span className="text-red-300 truncate">{inc.label}</span>
                                </div>
                              ))}

                              {subCategory.incidents.length > 5 && (
                                <div className="text-xs text-slate-500 pl-5">
                                  +{subCategory.incidents.length - 5} more incidents
                                </div>
                              )}

                              {/* Empty state for sub-category */}
                              {subCategory.kbArticles.length === 0 && subCategory.incidents.length === 0 && (
                                <div className="text-xs text-slate-500 pl-5 italic">No items</div>
                              )}
                            </div>
                          )}
                        </div>
                      );
                    })}

                    {/* Direct items (not in subcategory) */}
                    {subCategoryEntries.length === 0 && (
                      <>
                        {category.kbArticles.map((kb) => (
                          <div
                            key={kb.id}
                            className="flex items-center space-x-2 p-1.5 pl-2 hover:bg-green-900/20 rounded text-sm cursor-pointer"
                            onClick={(e) => {
                              e.stopPropagation();
                              onNodeClick?.(kb);
                            }}
                          >
                            <DocumentTextIcon className="w-4 h-4 text-green-400" />
                            <span className="text-green-300 truncate">{kb.label}</span>
                          </div>
                        ))}
                        {category.incidents.slice(0, 5).map((inc) => (
                          <div
                            key={inc.id}
                            className="flex items-center space-x-2 p-1.5 pl-2 hover:bg-red-900/20 rounded text-sm cursor-pointer"
                            onClick={(e) => {
                              e.stopPropagation();
                              onNodeClick?.(inc);
                            }}
                          >
                            <ExclamationTriangleIcon className="w-4 h-4 text-red-400" />
                            <span className="text-red-300 truncate">{inc.label}</span>
                          </div>
                        ))}
                      </>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Empty filtered results */}
        {filteredCategories.length === 0 && searchQuery && (
          <div className="text-center py-8 text-slate-500">
            No results found for "{searchQuery}"
          </div>
        )}
      </div>

      {/* Legend */}
      <div className="card p-3">
        <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-slate-400">
          <span>Coverage:</span>
          <span className="flex items-center space-x-1">
            <span>🟢</span>
            <span>&gt;80%</span>
          </span>
          <span className="flex items-center space-x-1">
            <span>🟡</span>
            <span>60-79%</span>
          </span>
          <span className="flex items-center space-x-1">
            <span>🟠</span>
            <span>40-59%</span>
          </span>
          <span className="flex items-center space-x-1">
            <span>🔴</span>
            <span>&lt;40% or No KB</span>
          </span>
        </div>
      </div>
    </div>
  );
};

export default HierarchicalCategoryView;
