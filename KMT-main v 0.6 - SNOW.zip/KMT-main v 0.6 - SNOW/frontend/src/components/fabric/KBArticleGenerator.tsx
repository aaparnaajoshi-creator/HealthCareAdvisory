import React, { useState, useEffect } from "react";
import {
    DocumentTextIcon,
    CheckCircleIcon,
    SparklesIcon,
    XMarkIcon
} from "@heroicons/react/24/outline";
import axiosClient from "../../api/axiosClient";

interface Incident {
    id: string;
    incident_number: string;
    label: string;
    content: string;
    category: string;
}

interface CategoryGroup {
    name: string;
    count: number;
    incidents: Incident[];
}

interface GeneratedKBArticle {
    kb_number: string;
    title: string;
    category: string;
    content: string;
    incident_count: number;
    incident_numbers: string[];
}

interface KBArticleGeneratorProps {
    fabricId: string;
    category?: string;
    onClose?: () => void;
    onSuccess?: () => void;
    standalone?: boolean;
}

export const KBArticleGenerator: React.FC<KBArticleGeneratorProps> = ({
    fabricId,
    category,
    onClose,
    onSuccess,
    standalone = false
}) => {
    const [loading, setLoading] = useState(true);
    const [categories, setCategories] = useState<CategoryGroup[]>([]);
    const [selectedIncidents, setSelectedIncidents] = useState<Set<string>>(new Set());
    const [generating, setGenerating] = useState(false);
    const [generatedArticle, setGeneratedArticle] = useState<GeneratedKBArticle | null>(null);
    const [saving, setSaving] = useState(false);
    const [step, setStep] = useState<"select" | "preview" | "success">("select");

    useEffect(() => {
        loadIncidentsWithoutKB();
    }, [fabricId, category]);

    const loadIncidentsWithoutKB = async () => {
        setLoading(true);
        try {
            const params = category ? `?category=${category}` : '';
            const response = await axiosClient.get(`/api/fabrics/${fabricId}/incidents-without-kb${params}`);
            console.log('Loaded incidents:', response.data);
            setCategories(response.data.categories || []);
        } catch (error) {
            console.error("Failed to load incidents", error);
        } finally {
            setLoading(false);
        }
    };

    const toggleIncident = (incidentId: string) => {
        const newSelected = new Set(selectedIncidents);
        if (newSelected.has(incidentId)) {
            newSelected.delete(incidentId);
        } else {
            newSelected.add(incidentId);
        }
        setSelectedIncidents(newSelected);
    };

    const selectAllInCategory = (categoryName: string) => {
        const categoryGroup = categories.find(c => c.name === categoryName);
        if (!categoryGroup) return;

        const newSelected = new Set(selectedIncidents);
        categoryGroup.incidents.forEach(inc => {
            newSelected.add(inc.id);
        });
        setSelectedIncidents(newSelected);
    };

    const deselectAllInCategory = (categoryName: string) => {
        const categoryGroup = categories.find(c => c.name === categoryName);
        if (!categoryGroup) return;

        const newSelected = new Set(selectedIncidents);
        categoryGroup.incidents.forEach(inc => {
            newSelected.delete(inc.id);
        });
        setSelectedIncidents(newSelected);
    };

    const generateKBArticle = async () => {
        if (selectedIncidents.size === 0) {
            alert("Please select at least one incident");
            return;
        }

        setGenerating(true);
        try {
            let selectedCategory = category;
            if (!selectedCategory) {
                for (const cat of categories) {
                    const hasSelected = cat.incidents.some(inc => selectedIncidents.has(inc.id));
                    if (hasSelected) {
                        selectedCategory = cat.name;
                        break;
                    }
                }
            }

            const response = await axiosClient.post(`/api/fabrics/${fabricId}/generate-kb-article`, {
                incident_ids: Array.from(selectedIncidents),
                category: selectedCategory
            });

            const article = response.data;
            setGeneratedArticle(article);
            setStep("preview");
        } catch (error) {
            console.error("Failed to generate KB article", error);
            alert("Failed to generate KB article. Please try again.");
        } finally {
            setGenerating(false);
        }
    };

    const saveKBArticle = async () => {
        if (!generatedArticle) return;

        setSaving(true);
        try {
            await axiosClient.post(`/api/fabrics/${fabricId}/save-kb-article`, {
                ...generatedArticle,
                incident_ids: Array.from(selectedIncidents)
            });

            setStep("success");
            setTimeout(() => {
                if (onSuccess) onSuccess();
                if (onClose) onClose();
            }, 2000);
        } catch (error) {
            console.error("Failed to save KB article", error);
            alert("Failed to save KB article. Please try again.");
        } finally {
            setSaving(false);
        }
    };

    const totalIncidents = categories.reduce((sum, cat) => sum + cat.count, 0);

    const content = (
        <div className="space-y-6">
            {loading && (
                <div className="flex justify-center py-12">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-400"></div>
                </div>
            )}

            {!loading && step === "select" && (
                <>
                    {/* Summary */}
                    <div className="bg-blue-900/20 border border-blue-700 rounded-lg p-4">
                        <div className="flex items-center justify-between">
                            <div>
                                <h3 className="text-lg font-semibold text-blue-300">
                                    Incidents Without KB Coverage
                                </h3>
                                <p className="text-sm text-blue-200 mt-1">
                                    Select one or more incidents to generate a comprehensive KB article
                                </p>
                            </div>
                            <div className="text-right">
                                <div className="text-3xl font-bold text-blue-400">{totalIncidents}</div>
                                <div className="text-sm text-blue-300">Total Incidents</div>
                            </div>
                        </div>
                    </div>

                    {/* Selected count */}
                    {selectedIncidents.size > 0 && (
                        <div className="bg-green-900/20 border border-green-700 rounded-lg p-3">
                            <div className="flex items-center justify-between">
                                <span className="text-green-300">
                                    <CheckCircleIcon className="w-5 h-5 inline mr-2" />
                                    {selectedIncidents.size} incident(s) selected
                                </span>
                                <button
                                    onClick={generateKBArticle}
                                    disabled={generating}
                                    className="px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-600 text-white rounded-lg transition-colors flex items-center"
                                >
                                    {generating ? (
                                        <>
                                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                                            Generating...
                                        </>
                                    ) : (
                                        <>
                                            <SparklesIcon className="w-5 h-5 mr-2" />
                                            Generate KB Article
                                        </>
                                    )}
                                </button>
                            </div>
                        </div>
                    )}

                    {/* Categories and Incidents */}
                    <div className="space-y-4">
                        {categories.map((cat) => (
                            <div key={cat.name} className="bg-slate-800 border border-slate-700 rounded-lg p-4">
                                <div className="flex items-center justify-between mb-3">
                                    <h3 className="text-lg font-semibold text-slate-100">
                                        {cat.name}
                                        <span className="ml-2 text-sm text-slate-400">
                                            ({cat.count} incidents)
                                        </span>
                                    </h3>
                                    <div className="space-x-2">
                                        <button
                                            onClick={() => selectAllInCategory(cat.name)}
                                            className="px-3 py-1 text-xs border border-slate-600 hover:border-slate-500 text-slate-300 rounded transition-colors"
                                        >
                                            Select All
                                        </button>
                                        <button
                                            onClick={() => deselectAllInCategory(cat.name)}
                                            className="px-3 py-1 text-xs border border-slate-600 hover:border-slate-500 text-slate-300 rounded transition-colors"
                                        >
                                            Deselect All
                                        </button>
                                    </div>
                                </div>

                                <div className="space-y-2">
                                    {cat.incidents.map((incident) => (
                                        <div
                                            key={incident.id}
                                            className={`p-3 rounded border cursor-pointer transition-colors ${selectedIncidents.has(incident.id)
                                                    ? 'bg-blue-900/30 border-blue-600'
                                                    : 'bg-slate-800 border-slate-700 hover:border-slate-600'
                                                }`}
                                            onClick={() => toggleIncident(incident.id)}
                                        >
                                            <div className="flex items-start">
                                                <input
                                                    type="checkbox"
                                                    checked={selectedIncidents.has(incident.id)}
                                                    onChange={() => toggleIncident(incident.id)}
                                                    className="mt-1 mr-3"
                                                />
                                                <div className="flex-1">
                                                    <div className="flex items-center justify-between">
                                                        <span className="font-semibold text-slate-200">
                                                            {incident.incident_number}
                                                        </span>
                                                        <span className="text-xs text-slate-400">
                                                            {cat.name}
                                                        </span>
                                                    </div>
                                                    <p className="text-sm text-slate-300 mt-1">
                                                        {incident.label || 'No description'}
                                                    </p>
                                                    {incident.content && (
                                                        <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                                                            {incident.content.substring(0, 200)}...
                                                        </p>
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        ))}
                    </div>

                    {categories.length === 0 && (
                        <div className="bg-slate-800 border border-slate-700 rounded-lg p-8 text-center">
                            <CheckCircleIcon className="w-16 h-16 mx-auto text-green-400 mb-4" />
                            <h3 className="text-xl font-semibold text-slate-100 mb-2">
                                All Incidents Have KB Coverage!
                            </h3>
                            <p className="text-slate-400">
                                {category
                                    ? `All incidents in the ${category} category are covered by KB articles.`
                                    : 'All incidents across all categories have KB article coverage.'}
                            </p>
                        </div>
                    )}
                </>
            )}

            {step === "preview" && generatedArticle && (
                <>
                    {/* Preview Header */}
                    <div className="bg-green-900/20 border border-green-700 rounded-lg p-4">
                        <div className="flex items-center justify-between">
                            <div>
                                <h3 className="text-lg font-semibold text-green-300">
                                    KB Article Generated Successfully!
                                </h3>
                                <p className="text-sm text-green-200 mt-1">
                                    Review the article below and save to link it to {generatedArticle.incident_count} incident(s)
                                </p>
                            </div>
                            <DocumentTextIcon className="w-12 h-12 text-green-400" />
                        </div>
                    </div>

                    {/* Article Info */}
                    <div className="grid grid-cols-3 gap-4">
                        <div className="bg-slate-800 border border-slate-700 rounded-lg p-3">
                            <div className="text-sm text-slate-400">KB Number</div>
                            <div className="text-lg font-semibold text-slate-100">
                                {generatedArticle.kb_number}
                            </div>
                        </div>
                        <div className="bg-slate-800 border border-slate-700 rounded-lg p-3">
                            <div className="text-sm text-slate-400">Category</div>
                            <div className="text-lg font-semibold text-slate-100">
                                {generatedArticle.category}
                            </div>
                        </div>
                        <div className="bg-slate-800 border border-slate-700 rounded-lg p-3">
                            <div className="text-sm text-slate-400">Incidents Covered</div>
                            <div className="text-lg font-semibold text-slate-100">
                                {generatedArticle.incident_count}
                            </div>
                        </div>
                    </div>

                    {/* Article Content */}
                    <div className="bg-slate-800 border border-slate-700 rounded-lg p-6">
                        <h3 className="text-xl font-bold text-slate-100 mb-4">
                            {generatedArticle.title}
                        </h3>
                        <div className="prose prose-invert max-w-none">
                            <pre className="whitespace-pre-wrap text-sm text-slate-300 font-sans">
                                {generatedArticle.content}
                            </pre>
                        </div>
                    </div>

                    {/* Covered Incidents */}
                    <div className="bg-slate-800 border border-slate-700 rounded-lg p-4">
                        <h4 className="font-semibold text-slate-100 mb-2">
                            This KB article will be linked to:
                        </h4>
                        <div className="flex flex-wrap gap-2">
                            {generatedArticle.incident_numbers.map((num) => (
                                <span
                                    key={num}
                                    className="px-3 py-1 bg-blue-900/30 border border-blue-700 rounded text-sm text-blue-300"
                                >
                                    {num}
                                </span>
                            ))}
                        </div>
                    </div>

                    {/* Actions */}
                    <div className="flex justify-end space-x-3">
                        <button
                            onClick={() => setStep("select")}
                            disabled={saving}
                            className="px-4 py-2 border border-slate-600 hover:border-slate-500 text-slate-300 rounded-lg transition-colors"
                        >
                            Back to Selection
                        </button>
                        <button
                            onClick={saveKBArticle}
                            disabled={saving}
                            className="px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-600 text-white rounded-lg transition-colors flex items-center"
                        >
                            {saving ? (
                                <>
                                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                                    Saving...
                                </>
                            ) : (
                                <>
                                    <CheckCircleIcon className="w-5 h-5 mr-2" />
                                    Save KB Article
                                </>
                            )}
                        </button>
                    </div>
                </>
            )}

            {step === "success" && (
                <div className="py-12 text-center">
                    <CheckCircleIcon className="w-24 h-24 mx-auto text-green-400 mb-6" />
                    <h3 className="text-2xl font-bold text-slate-100 mb-2">
                        KB Article Created Successfully!
                    </h3>
                    <p className="text-slate-400 mb-4">
                        {generatedArticle?.kb_number} has been saved and linked to {selectedIncidents.size} incident(s)
                    </p>
                    <p className="text-sm text-slate-500">
                        Redirecting...
                    </p>
                </div>
            )}
        </div>
    );

    // If standalone mode, render without modal wrapper
    if (standalone) {
        return <div className="max-w-7xl mx-auto">{content}</div>;
    }

    // Modal mode - render with modal overlay
    return (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-slate-900 rounded-lg max-w-6xl w-full max-h-[90vh] overflow-y-auto">
                <div className="sticky top-0 bg-slate-900 border-b border-slate-700 p-4 flex items-center justify-between">
                    <h2 className="text-2xl font-bold text-slate-100 flex items-center">
                        <SparklesIcon className="w-8 h-8 mr-3 text-blue-400" />
                        Generate KB Article from Incidents
                    </h2>
                    {onClose && (
                        <button
                            onClick={onClose}
                            className="text-slate-400 hover:text-slate-200 transition-colors"
                        >
                            <XMarkIcon className="w-6 h-6" />
                        </button>
                    )}
                </div>
                <div className="p-6">{content}</div>
            </div>
        </div>
    );
};