/**
 * Knowledge Graph View - Upgraded
 * ================================
 * Enhanced version with:
 * - Interactive force-directed graph (react-force-graph-2d)
 * - Original canvas fallback if package not installed
 * - CI categories as central nodes
 * - Click to view details
 * - Filter by node type
 * - Search and highlight
 * - Zoom and pan
 */

import React, { useEffect, useState, useRef, useCallback, useMemo } from "react";
import { getKnowledgeGraph, getNodeDetails, KnowledgeGraph, GraphNode, NodeDetails } from "../../api/analyticsApi";
import { LoadingSpinner } from "../common/LoadingSpinner";
import { EmptyState } from "../common/EmptyState";
import { 
  CubeTransparentIcon, 
  XMarkIcon,
  MagnifyingGlassIcon,
  FunnelIcon,
  ArrowsPointingOutIcon,
  ArrowPathIcon
} from "@heroicons/react/24/outline";
import { KBCoverageHeatmap } from "./KBCoverageHeatmap";

// Try to import ForceGraph2D - will be undefined if not installed
let ForceGraph2D: any = null;
try {
  ForceGraph2D = require("react-force-graph-2d").default;
} catch (e) {
  console.log("react-force-graph-2d not installed, using canvas fallback");
}

// =============================================================================
// TYPES
// =============================================================================

interface GraphNodeData {
  id: string;
  nodeId: string;
  label: string;
  nodeType: string;
  category?: string;
  subCategory?: string;
  properties?: any;
  x?: number;
  y?: number;
}

interface GraphLinkData {
  source: string | GraphNodeData;
  target: string | GraphNodeData;
  relationshipType: string;
}

interface GraphData {
  nodes: GraphNodeData[];
  links: GraphLinkData[];
}

// =============================================================================
// CONSTANTS
// =============================================================================

const NODE_COLORS: Record<string, string> = {
  ci: "#8b5cf6",           // Purple - CI/Category nodes
  category: "#8b5cf6",     // Purple
  kb: "#10b981",           // Green - KB articles
  kb_article: "#10b981",   // Green
  incident: "#ef4444",     // Red - Incidents
  inc: "#ef4444",          // Red
  document: "#3b82f6",     // Blue - Documents
  error_code: "#f59e0b",   // Orange - Error codes
  default: "#6b7280",      // Gray
};

const NODE_SIZES: Record<string, number> = {
  ci: 12,
  category: 12,
  kb: 6,
  kb_article: 6,
  incident: 5,
  inc: 5,
  document: 6,
  default: 5,
};

// =============================================================================
// COMPONENT
// =============================================================================

interface KnowledgeGraphViewProps {
  fabricId: string;
}

export const KnowledgeGraphView: React.FC<KnowledgeGraphViewProps> = ({ fabricId }) => {
  const [graph, setGraph] = useState<KnowledgeGraph | null>(null);
  const [graphData, setGraphData] = useState<GraphData | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedNode, setSelectedNode] = useState<NodeDetails | null>(null);
  const [hoveredNode, setHoveredNode] = useState<GraphNodeData | null>(null);
  const [nodeFilter, setNodeFilter] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [showLabels, setShowLabels] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<"graph" | "heatmap">("graph");
  const [highlightedNodes, setHighlightedNodes] = useState<Set<string>>(new Set());
  const [highlightedLinks, setHighlightedLinks] = useState<Set<string>>(new Set());
  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const graphRef = useRef<any>();
  const containerRef = useRef<HTMLDivElement>(null);

  // =============================================================================
  // DATA LOADING
  // =============================================================================

  const loadGraph = async () => {
    setLoading(true);
    try {
      const data = await getKnowledgeGraph(fabricId);
      setGraph(data);
      
      // Transform for force graph
      if (ForceGraph2D) {
        const transformed = transformGraphData(data);
        setGraphData(transformed);
      }
    } catch (err) {
      console.error("Failed to load knowledge graph", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadGraph();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fabricId]);

  // Draw canvas graph (fallback)
  useEffect(() => {
    if (!ForceGraph2D && graph && canvasRef.current) {
      drawCanvasGraph();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [graph, nodeFilter]);

  // =============================================================================
  // DATA TRANSFORMATION
  // =============================================================================

  const transformGraphData = (data: KnowledgeGraph): GraphData => {
    const nodesMap = new Map<string, GraphNodeData>();
    
    data.nodes.forEach((node) => {
      nodesMap.set(node.id, {
        id: node.id,
        nodeId: node.nodeId,
        label: node.label,
        nodeType: node.nodeType,
        category: node.properties?.category_ci || node.properties?.category,
        subCategory: node.properties?.sub_category,
        properties: node.properties,
      });
    });

    const links: GraphLinkData[] = data.edges
      .filter(edge => nodesMap.has(edge.sourceNodeId) && nodesMap.has(edge.targetNodeId))
      .map((edge) => ({
        source: edge.sourceNodeId,
        target: edge.targetNodeId,
        relationshipType: edge.relationshipType,
      }));

    return {
      nodes: Array.from(nodesMap.values()),
      links,
    };
  };

  // =============================================================================
  // FILTERED DATA
  // =============================================================================

  const filteredGraphData = useMemo(() => {
    if (!graphData) return null;

    let filteredNodes = graphData.nodes;
    
    // Filter by node type
    if (nodeFilter !== "all") {
      filteredNodes = filteredNodes.filter(
        (n) => n.nodeType === nodeFilter || n.nodeType === nodeFilter.replace("_", "")
      );
    }

    // Filter by search
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filteredNodes = filteredNodes.filter(
        (n) => 
          n.label.toLowerCase().includes(query) ||
          n.nodeId.toLowerCase().includes(query) ||
          n.category?.toLowerCase().includes(query)
      );
    }

    const validNodeIds = new Set(filteredNodes.map((n) => n.id));

    const filteredLinks = graphData.links.filter((l) => {
      const sourceId = typeof l.source === 'object' ? l.source.id : l.source;
      const targetId = typeof l.target === 'object' ? l.target.id : l.target;
      return validNodeIds.has(sourceId) && validNodeIds.has(targetId);
    });

    return { nodes: filteredNodes, links: filteredLinks };
  }, [graphData, nodeFilter, searchQuery]);

  // =============================================================================
  // NODE INTERACTIONS
  // =============================================================================

  const handleNodeClick = async (node: GraphNodeData | string) => {
    const nodeId = typeof node === 'string' ? node : node.nodeId;
    try {
      const details = await getNodeDetails(fabricId, nodeId);
      setSelectedNode(details);
    } catch (err) {
      console.error("Failed to load node details", err);
    }
  };

  const handleNodeHover = useCallback((node: GraphNodeData | null) => {
    setHoveredNode(node);
    
    if (node && graphData) {
      const connectedNodes = new Set<string>();
      const connectedLinks = new Set<string>();
      
      connectedNodes.add(node.id);
      
      graphData.links.forEach((link) => {
        const sourceId = typeof link.source === 'object' ? link.source.id : link.source;
        const targetId = typeof link.target === 'object' ? link.target.id : link.target;
        
        if (sourceId === node.id || targetId === node.id) {
          connectedNodes.add(sourceId);
          connectedNodes.add(targetId);
          connectedLinks.add(`${sourceId}-${targetId}`);
        }
      });
      
      setHighlightedNodes(connectedNodes);
      setHighlightedLinks(connectedLinks);
    } else {
      setHighlightedNodes(new Set());
      setHighlightedLinks(new Set());
    }
  }, [graphData]);

  // =============================================================================
  // GRAPH CONTROLS
  // =============================================================================

  const handleZoomToFit = () => {
    graphRef.current?.zoomToFit(400, 50);
  };

  const handleResetView = () => {
    graphRef.current?.centerAt(0, 0, 400);
    graphRef.current?.zoom(1, 400);
  };

  // =============================================================================
  // RENDERING HELPERS
  // =============================================================================

  const getNodeColor = (node: GraphNodeData): string => {
    if (highlightedNodes.size > 0 && !highlightedNodes.has(node.id)) {
      return "#1f2937";
    }
    return NODE_COLORS[node.nodeType] || NODE_COLORS.default;
  };

  const getNodeSize = (node: GraphNodeData): number => {
    const baseSize = NODE_SIZES[node.nodeType] || NODE_SIZES.default;
    if (highlightedNodes.has(node.id)) return baseSize * 1.5;
    if (highlightedNodes.size > 0) return baseSize * 0.7;
    return baseSize;
  };

  const getLinkColor = (link: GraphLinkData): string => {
    const sourceId = typeof link.source === 'object' ? link.source.id : link.source;
    const targetId = typeof link.target === 'object' ? link.target.id : link.target;
    const linkId = `${sourceId}-${targetId}`;
    
    if (highlightedLinks.size > 0 && !highlightedLinks.has(linkId)) {
      return "#0f172a";
    }
    return "#475569";
  };

  const nodeCanvasObject = useCallback((
    node: GraphNodeData,
    ctx: CanvasRenderingContext2D,
    globalScale: number
  ) => {
    const fontSize = Math.max(10 / globalScale, 3);
    const nodeSize = getNodeSize(node);
    const color = getNodeColor(node);
    
    // Draw node
    ctx.beginPath();
    ctx.arc(node.x || 0, node.y || 0, nodeSize, 0, 2 * Math.PI);
    ctx.fillStyle = color;
    ctx.fill();
    
    // Border for CI nodes
    if (node.nodeType === 'ci' || node.nodeType === 'category') {
      ctx.strokeStyle = "#ffffff";
      ctx.lineWidth = 2 / globalScale;
      ctx.stroke();
    }
    
    // Label
    if (showLabels && globalScale > 0.5) {
      ctx.font = `${fontSize}px Sans-Serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "top";
      
      const displayLabel = node.label.length > 20 
        ? node.label.substring(0, 20) + "..." 
        : node.label;
      
      const textWidth = ctx.measureText(displayLabel).width;
      ctx.fillStyle = "rgba(15, 23, 42, 0.8)";
      ctx.fillRect(
        (node.x || 0) - textWidth / 2 - 2,
        (node.y || 0) + nodeSize + 2,
        textWidth + 4,
        fontSize + 4
      );
      
      ctx.fillStyle = highlightedNodes.has(node.id) ? "#ffffff" : "#94a3b8";
      ctx.fillText(displayLabel, node.x || 0, (node.y || 0) + nodeSize + 4);
    }
  }, [showLabels, highlightedNodes]);

  // =============================================================================
  // CANVAS FALLBACK
  // =============================================================================

  const drawCanvasGraph = () => {
    if (!canvasRef.current || !graph) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    let filteredNodes = graph.nodes;
    if (nodeFilter !== "all") {
      filteredNodes = graph.nodes.filter((n) => n.nodeType === nodeFilter);
    }

    if (filteredNodes.length === 0) return;

    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = Math.min(canvas.width, canvas.height) * 0.35;

    const positions: Record<string, { x: number; y: number }> = {};
    filteredNodes.forEach((node, i) => {
      const angle = (i / filteredNodes.length) * 2 * Math.PI;
      positions[node.id] = {
        x: centerX + radius * Math.cos(angle),
        y: centerY + radius * Math.sin(angle),
      };
    });

    // Draw edges
    ctx.strokeStyle = "#475569";
    ctx.lineWidth = 1;
    graph.edges.forEach((edge) => {
      const source = positions[edge.sourceNodeId];
      const target = positions[edge.targetNodeId];
      if (source && target) {
        ctx.beginPath();
        ctx.moveTo(source.x, source.y);
        ctx.lineTo(target.x, target.y);
        ctx.stroke();
      }
    });

    // Draw nodes
    filteredNodes.forEach((node) => {
      const pos = positions[node.id];
      if (!pos) return;

      ctx.fillStyle = NODE_COLORS[node.nodeType] || NODE_COLORS.default;
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, 8, 0, 2 * Math.PI);
      ctx.fill();

      ctx.fillStyle = "#e2e8f0";
      ctx.font = "10px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(node.label.substring(0, 15), pos.x, pos.y + 20);
    });
  };

  // =============================================================================
  // STATS
  // =============================================================================

  const stats = useMemo(() => {
    if (!graph) return null;
    
    const nodeTypes: Record<string, number> = {};
    graph.nodes.forEach((n) => {
      nodeTypes[n.nodeType] = (nodeTypes[n.nodeType] || 0) + 1;
    });
    
    return {
      totalNodes: graph.stats.nodeCount,
      totalEdges: graph.stats.edgeCount,
      nodeTypes,
    };
  }, [graph]);

  // =============================================================================
  // RENDER
  // =============================================================================

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  if (!graph || graph.nodes.length === 0) {
    return (
      <EmptyState
        icon={<CubeTransparentIcon className="w-16 h-16" />}
        title="No Knowledge Graph"
        message="Knowledge graph will be generated after fabric build completes."
      />
    );
  }

  return (
    <div className="space-y-4">
      {/* Tab Navigation */}
      <div className="card p-2">
        <div className="flex space-x-2">
          <button
            onClick={() => setActiveTab("graph")}
            className={`flex-1 px-4 py-2 rounded-lg font-medium transition-colors ${
              activeTab === "graph"
                ? "bg-blue-600 text-white"
                : "bg-slate-800 text-slate-400 hover:bg-slate-700"
            }`}
          >
            🔗 Interactive Graph
          </button>
          <button
            onClick={() => setActiveTab("heatmap")}
            className={`flex-1 px-4 py-2 rounded-lg font-medium transition-colors ${
              activeTab === "heatmap"
                ? "bg-blue-600 text-white"
                : "bg-slate-800 text-slate-400 hover:bg-slate-700"
            }`}
          >
            📊 KB Coverage Heatmap
          </button>
        </div>
      </div>

      {/* Tab Content */}
      {activeTab === "heatmap" ? (
        <KBCoverageHeatmap fabricId={fabricId} />
      ) : (
        <>
          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            <div className="card p-3">
              <div className="text-xs text-slate-400">Total Nodes</div>
              <div className="text-xl font-bold text-slate-100">{stats?.totalNodes || 0}</div>
            </div>
            <div className="card p-3">
              <div className="text-xs text-slate-400">Connections</div>
              <div className="text-xl font-bold text-slate-100">{stats?.totalEdges || 0}</div>
            </div>
            <div className="card p-3">
              <div className="text-xs text-slate-400 flex items-center">
                <span className="w-2 h-2 rounded-full bg-purple-500 mr-1"></span>
                Categories
              </div>
              <div className="text-xl font-bold text-purple-400">
                {(stats?.nodeTypes?.ci || 0) + (stats?.nodeTypes?.category || 0)}
              </div>
            </div>
            <div className="card p-3">
              <div className="text-xs text-slate-400 flex items-center">
                <span className="w-2 h-2 rounded-full bg-green-500 mr-1"></span>
                KB Articles
              </div>
              <div className="text-xl font-bold text-green-400">
                {(stats?.nodeTypes?.kb || 0) + (stats?.nodeTypes?.kb_article || 0)}
              </div>
            </div>
            <div className="card p-3">
              <div className="text-xs text-slate-400 flex items-center">
                <span className="w-2 h-2 rounded-full bg-red-500 mr-1"></span>
                Incidents
              </div>
              <div className="text-xl font-bold text-red-400">
                {(stats?.nodeTypes?.incident || 0) + (stats?.nodeTypes?.inc || 0)}
              </div>
            </div>
          </div>

          {/* Controls */}
          <div className="card p-4">
            <div className="flex flex-wrap items-center gap-4">
              {/* Search */}
              <div className="flex-1 min-w-[200px]">
                <div className="relative">
                  <MagnifyingGlassIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search nodes..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              {/* Filter */}
              <div className="flex items-center space-x-2">
                <FunnelIcon className="w-4 h-4 text-slate-400" />
                <select
                  value={nodeFilter}
                  onChange={(e) => setNodeFilter(e.target.value)}
                  className="px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-sm text-slate-100 focus:outline-none focus:border-blue-500"
                >
                  <option value="all">All Types</option>
                  <option value="ci">🟣 CI/Categories</option>
                  <option value="kb_article">🟢 KB Articles</option>
                  <option value="incident">🔴 Incidents</option>
                  <option value="document">🔵 Documents</option>
                </select>
              </div>

              {/* Show Labels */}
              {ForceGraph2D && (
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showLabels}
                    onChange={(e) => setShowLabels(e.target.checked)}
                    className="w-4 h-4 rounded border-slate-600 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-sm text-slate-300">Labels</span>
                </label>
              )}

              {/* Zoom Controls */}
              {ForceGraph2D && (
                <div className="flex items-center space-x-2">
                  <button
                    onClick={handleZoomToFit}
                    className="p-2 bg-slate-700 hover:bg-slate-600 rounded-lg transition-colors"
                    title="Zoom to Fit"
                  >
                    <ArrowsPointingOutIcon className="w-4 h-4 text-slate-300" />
                  </button>
                  <button
                    onClick={handleResetView}
                    className="p-2 bg-slate-700 hover:bg-slate-600 rounded-lg transition-colors"
                    title="Reset View"
                  >
                    <ArrowPathIcon className="w-4 h-4 text-slate-300" />
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Graph Visualization */}
          <div className="card p-0 overflow-hidden" ref={containerRef}>
            <div className="relative bg-slate-900" style={{ height: "600px" }}>
              {ForceGraph2D && filteredGraphData ? (
                // Interactive Force Graph
                <ForceGraph2D
                  ref={graphRef}
                  graphData={filteredGraphData}
                  nodeId="id"
                  nodeLabel={(node: any) => `${node.label}\n(${node.nodeType})`}
                  nodeCanvasObject={nodeCanvasObject as any}
                  nodePointerAreaPaint={(node: any, color: any, ctx: any) => {
                    ctx.fillStyle = color;
                    ctx.beginPath();
                    ctx.arc(node.x, node.y, getNodeSize(node) + 2, 0, 2 * Math.PI);
                    ctx.fill();
                  }}
                  linkColor={getLinkColor as any}
                  linkWidth={(link: any) => {
                    const sourceId = typeof link.source === 'object' ? link.source.id : link.source;
                    const targetId = typeof link.target === 'object' ? link.target.id : link.target;
                    return highlightedLinks.has(`${sourceId}-${targetId}`) ? 2 : 0.5;
                  }}
                  linkDirectionalParticles={2}
                  linkDirectionalParticleWidth={(link: any) => {
                    const sourceId = typeof link.source === 'object' ? link.source.id : link.source;
                    const targetId = typeof link.target === 'object' ? link.target.id : link.target;
                    return highlightedLinks.has(`${sourceId}-${targetId}`) ? 3 : 0;
                  }}
                  onNodeClick={(node: any) => handleNodeClick(node)}
                  onNodeHover={(node: any) => handleNodeHover(node)}
                  backgroundColor="#0f172a"
                  width={containerRef.current?.clientWidth || 800}
                  height={600}
                  cooldownTicks={100}
                  d3AlphaDecay={0.02}
                  d3VelocityDecay={0.3}
                  enableNodeDrag={true}
                  enableZoomPanInteraction={true}
                />
              ) : (
                // Canvas Fallback
                <canvas
                  ref={canvasRef}
                  className="w-full h-full"
                />
              )}
              
              {/* Hover Info */}
              {hoveredNode && (
                <div className="absolute top-4 left-4 bg-slate-800/95 border border-slate-700 rounded-lg p-3 max-w-xs">
                  <div className="flex items-center space-x-2 mb-2">
                    <span
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: NODE_COLORS[hoveredNode.nodeType] || NODE_COLORS.default }}
                    ></span>
                    <span className="text-sm font-medium text-slate-100">{hoveredNode.label}</span>
                  </div>
                  <div className="text-xs text-slate-400">
                    <div>Type: {hoveredNode.nodeType}</div>
                    {hoveredNode.category && <div>Category: {hoveredNode.category}</div>}
                  </div>
                </div>
              )}
            </div>

            {/* Legend */}
            <div className="bg-slate-800 px-4 py-3 border-t border-slate-700">
              <div className="flex flex-wrap items-center gap-4 text-xs">
                <span className="text-slate-400 font-medium">Legend:</span>
                <div className="flex items-center space-x-1">
                  <span className="w-3 h-3 rounded-full bg-purple-500"></span>
                  <span className="text-slate-300">CI/Category</span>
                </div>
                <div className="flex items-center space-x-1">
                  <span className="w-3 h-3 rounded-full bg-green-500"></span>
                  <span className="text-slate-300">KB Article</span>
                </div>
                <div className="flex items-center space-x-1">
                  <span className="w-3 h-3 rounded-full bg-red-500"></span>
                  <span className="text-slate-300">Incident</span>
                </div>
                <div className="flex items-center space-x-1">
                  <span className="w-3 h-3 rounded-full bg-blue-500"></span>
                  <span className="text-slate-300">Document</span>
                </div>
                <span className="text-slate-500 ml-4">
                  {ForceGraph2D 
                    ? "Click node for details • Hover to highlight • Scroll to zoom"
                    : "Install react-force-graph-2d for interactive graph"
                  }
                </span>
              </div>
            </div>
          </div>

          {/* Node List */}
          <div className="card p-6">
            <h3 className="text-lg font-semibold text-slate-100 mb-4">Nodes</h3>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {graph.nodes
                .filter((n) => nodeFilter === "all" || n.nodeType === nodeFilter)
                .filter((n) => !searchQuery || n.label.toLowerCase().includes(searchQuery.toLowerCase()))
                .map((node) => (
                  <div
                    key={node.id}
                    className="flex items-center justify-between p-2 bg-slate-800 rounded hover:bg-slate-750 cursor-pointer transition-colors"
                    onClick={() => handleNodeClick(node.nodeId)}
                  >
                    <div className="flex items-center space-x-2">
                      <span
                        className="w-2 h-2 rounded-full"
                        style={{ backgroundColor: NODE_COLORS[node.nodeType] || NODE_COLORS.default }}
                      ></span>
                      <span className="text-sm text-slate-200">{node.label}</span>
                    </div>
                    <span className="text-xs text-slate-500">{node.nodeType}</span>
                  </div>
                ))}
            </div>
          </div>

          {/* Node Details Modal */}
          {selectedNode && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
              <div className="bg-slate-800 rounded-lg p-6 max-w-2xl w-full mx-4 max-h-[80vh] overflow-y-auto">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <span
                      className="w-4 h-4 rounded-full"
                      style={{ backgroundColor: NODE_COLORS[selectedNode.node.nodeType] || NODE_COLORS.default }}
                    ></span>
                    <h3 className="text-lg font-semibold text-slate-100">
                      {selectedNode.node.label}
                    </h3>
                  </div>
                  <button
                    onClick={() => setSelectedNode(null)}
                    className="text-slate-400 hover:text-white"
                  >
                    <XMarkIcon className="w-6 h-6" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-sm text-slate-400">Node ID:</div>
                      <div className="text-slate-200 font-mono text-sm bg-slate-900 px-2 py-1 rounded">
                        {selectedNode.node.nodeId}
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-slate-400">Type:</div>
                      <div className="text-slate-200">{selectedNode.node.nodeType}</div>
                    </div>
                  </div>

                  {selectedNode.node.properties && Object.keys(selectedNode.node.properties).length > 0 && (
                    <div>
                      <div className="text-sm text-slate-400 mb-2">Properties:</div>
                      <div className="bg-slate-900 p-3 rounded text-xs font-mono text-slate-300 overflow-x-auto">
                        <pre>{JSON.stringify(selectedNode.node.properties, null, 2)}</pre>
                      </div>
                    </div>
                  )}

                  <div>
                    <div className="text-sm text-slate-400 mb-2">
                      Outgoing ({selectedNode.outgoingEdges.length}):
                    </div>
                    <div className="space-y-1 max-h-32 overflow-y-auto">
                      {selectedNode.outgoingEdges.map((edge, idx) => (
                        <div key={idx} className="text-sm text-slate-300 bg-slate-900 p-2 rounded">
                          → {edge.relationshipType}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <div className="text-sm text-slate-400 mb-2">
                      Incoming ({selectedNode.incomingEdges.length}):
                    </div>
                    <div className="space-y-1 max-h-32 overflow-y-auto">
                      {selectedNode.incomingEdges.map((edge, idx) => (
                        <div key={idx} className="text-sm text-slate-300 bg-slate-900 p-2 rounded">
                          ← {edge.relationshipType}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <div className="text-sm text-slate-400 mb-2">
                      Connected Nodes ({selectedNode.connectedNodes.length}):
                    </div>
                    <div className="space-y-1 max-h-48 overflow-y-auto">
                      {selectedNode.connectedNodes.map((node) => (
                        <div
                          key={node.id}
                          className="flex items-center justify-between bg-slate-900 p-2 rounded cursor-pointer hover:bg-slate-800"
                          onClick={() => handleNodeClick(node.nodeId)}
                        >
                          <div className="flex items-center space-x-2">
                            <span
                              className="w-2 h-2 rounded-full"
                              style={{ backgroundColor: NODE_COLORS[node.nodeType] || NODE_COLORS.default }}
                            ></span>
                            <span className="text-sm text-slate-300">
                              {node.label.length > 40 ? node.label.substring(0, 40) + "..." : node.label}
                            </span>
                          </div>
                          <span className="text-xs text-slate-500">{node.nodeType}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default KnowledgeGraphView;
