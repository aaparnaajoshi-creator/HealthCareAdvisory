import React, { useState, useEffect } from "react";
import axiosClient from "../../api/axiosClient";
import {
  ChevronLeftIcon,
  ChevronRightIcon,
} from "@heroicons/react/24/outline";

// =============================================================================
// TYPES
// =============================================================================

interface Category {
  id: string;
  name: string;
  kbCount: number;
  incidentCount: number;
}

interface KBArticle {
  id: string;
  title: string;
  fullTitle: string;
  category: string;
  categoryId: string;
}

interface Incident {
  id: string;
  title: string;
  fullTitle: string;
  category: string;
  categoryId: string;
  linkedKb: string | null;
}

interface Edge {
  source: string;
  target: string;
  type: "category-kb" | "category-incident" | "kb-incident";
}

interface GraphData {
  categories: Category[];
  kbArticles: KBArticle[];
  incidents: Incident[];
  edges: Edge[];
  stats: {
    totalCategories: number;
    totalKbArticles: number;
    totalIncidents: number;
    displayedKb: number;
    displayedIncidents: number;
    linkedIncidents: number;
    linkageRate: number;
  };
}

interface GraphLibraryProps {
  fabricId: string;
}

// =============================================================================
// GRAPH TYPE DEFINITIONS
// =============================================================================

const graphTypes = [
  {
    id: "sankey",
    name: "Sankey Flow",
    description: "Shows flow from Categories to KBs to Incidents",
    icon: "📊",
  },
  {
    id: "hierarchical",
    name: "Hierarchical Tree",
    description: "Tree structure with categories as roots",
    icon: "🌳",
  },
  {
    id: "force",
    name: "Force Network",
    description: "Interactive node-link diagram",
    icon: "🕸️",
  },
  {
    id: "radial",
    name: "Radial Tree",
    description: "Circular layout with category at center",
    icon: "🎯",
  },
  {
    id: "matrix",
    name: "Coverage Matrix",
    description: "Grid showing KB coverage per category",
    icon: "📋",
  },
  {
    id: "sunburst",
    name: "Sunburst Chart",
    description: "Nested rings showing hierarchy",
    icon: "☀️",
  },
];

// Color schemes
const colors = {
  category: "#8b5cf6", // Purple
  kb: "#22c55e", // Green
  incident: "#ef4444", // Red
  edge: "#475569", // Slate
  highlight: "#3b82f6", // Blue
};

// =============================================================================
// PAGINATION CONTROLS COMPONENT
// =============================================================================

interface PaginationControlsProps {
  currentPage: number;
  totalPages: number;
  totalItems: number;
  pageSize: number;
  onPrevious: () => void;
  onNext: () => void;
}

const PaginationControls: React.FC<PaginationControlsProps> = ({
  currentPage,
  totalPages,
  totalItems,
  pageSize,
  onPrevious,
  onNext,
}) => {
  const startItem = currentPage * pageSize + 1;
  const endItem = Math.min((currentPage + 1) * pageSize, totalItems);

  return (
    <div className="flex items-center justify-between bg-slate-800/50 rounded-lg px-4 py-2 mb-4 w-full">
      <button
        onClick={onPrevious}
        disabled={currentPage === 0}
        className={`flex items-center px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
          currentPage === 0
            ? "text-slate-600 cursor-not-allowed"
            : "text-slate-300 hover:text-white hover:bg-slate-700"
        }`}
      >
        <ChevronLeftIcon className="w-4 h-4 mr-1" />
        Previous
      </button>

      <div className="text-sm text-slate-400">
        Showing <span className="text-white font-medium">{startItem}-{endItem}</span> of{" "}
        <span className="text-white font-medium">{totalItems}</span> categories
        <span className="text-slate-500 ml-2">
          (Page {currentPage + 1} of {totalPages})
        </span>
      </div>

      <button
        onClick={onNext}
        disabled={currentPage >= totalPages - 1}
        className={`flex items-center px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
          currentPage >= totalPages - 1
            ? "text-slate-600 cursor-not-allowed"
            : "text-slate-300 hover:text-white hover:bg-slate-700"
        }`}
      >
        Next
        <ChevronRightIcon className="w-4 h-4 ml-1" />
      </button>
    </div>
  );
};

// =============================================================================
// SANKEY DIAGRAM WITH PAGINATION
// =============================================================================

const SankeyDiagram: React.FC<{ 
  data: GraphData; 
  width?: number; 
  height?: number;
  currentPage: number;
  pageSize: number;
}> = ({
  data,
  width = 800,
  height = 500,
  currentPage,
  pageSize,
}) => {
  const startIdx = currentPage * pageSize;
  const categories = data.categories.slice(startIdx, startIdx + pageSize);
  const nodeHeight = 45;
  const colWidth = width / 3;
  const catY = (i: number) => 50 + i * ((height - 100) / Math.max(categories.length, 1));

  return (
    <svg width={width} height={height} className="bg-slate-900 rounded-lg">
      {/* Column Labels */}
      <text x={colWidth * 0.5} y={25} fill="#94a3b8" textAnchor="middle" fontSize="14" fontWeight="bold">
        Categories ({data.stats.totalCategories})
      </text>
      <text x={colWidth * 1.5} y={25} fill="#94a3b8" textAnchor="middle" fontSize="14" fontWeight="bold">
        KB Articles ({data.stats.totalKbArticles})
      </text>
      <text x={colWidth * 2.5} y={25} fill="#94a3b8" textAnchor="middle" fontSize="14" fontWeight="bold">
        Incidents ({data.stats.totalIncidents})
      </text>

      {categories.map((cat, i) => {
        const y = catY(i);
        return (
          <g key={cat.id}>
            {/* Category Node */}
            <rect x={20} y={y} width={130} height={nodeHeight} fill={colors.category} rx={4} />
            <text x={85} y={y + 20} fill="white" textAnchor="middle" fontSize="10">
              {cat.name.slice(0, 16)}
            </text>
            <text x={85} y={y + 35} fill="rgba(255,255,255,0.7)" textAnchor="middle" fontSize="9">
              {cat.kbCount} KB / {cat.incidentCount} Inc
            </text>

            {/* Flow to KB */}
            <path
              d={`M 150 ${y + nodeHeight / 2} C ${colWidth} ${y + nodeHeight / 2}, ${colWidth} ${y + nodeHeight / 2}, ${colWidth + 20} ${y + nodeHeight / 2}`}
              fill="none"
              stroke={colors.kb}
              strokeWidth={Math.max(3, Math.min(15, cat.kbCount * 2))}
              opacity={0.5}
            />

            {/* KB Node */}
            <rect x={colWidth + 20} y={y + 5} width={90} height={nodeHeight - 10} fill={colors.kb} rx={4} />
            <text x={colWidth + 65} y={y + nodeHeight / 2 + 4} fill="white" textAnchor="middle" fontSize="12" fontWeight="bold">
              {cat.kbCount}
            </text>

            {/* Flow to Incidents */}
            <path
              d={`M ${colWidth + 110} ${y + nodeHeight / 2} C ${colWidth * 1.7} ${y + nodeHeight / 2}, ${colWidth * 1.7} ${y + nodeHeight / 2}, ${colWidth * 2 + 20} ${y + nodeHeight / 2}`}
              fill="none"
              stroke={colors.incident}
              strokeWidth={Math.max(3, Math.min(20, cat.incidentCount / 3))}
              opacity={0.5}
            />

            {/* Incident Node */}
            <rect x={colWidth * 2 + 20} y={y + 5} width={90} height={nodeHeight - 10} fill={colors.incident} rx={4} />
            <text x={colWidth * 2 + 65} y={y + nodeHeight / 2 + 4} fill="white" textAnchor="middle" fontSize="12" fontWeight="bold">
              {cat.incidentCount}
            </text>
          </g>
        );
      })}
    </svg>
  );
};

// =============================================================================
// HIERARCHICAL TREE
// =============================================================================

const HierarchicalTree: React.FC<{ data: GraphData; width?: number; height?: number }> = ({
  data,
  width = 800,
  height = 500,
}) => {
  const categories = data.categories.slice(0, 4);
  const catWidth = width / categories.length;

  return (
    <svg width={width} height={height} className="bg-slate-900 rounded-lg">
      <text x={width / 2} y={30} fill="#94a3b8" textAnchor="middle" fontSize="14" fontWeight="bold">
        Knowledge Fabric Hierarchy
      </text>

      {categories.map((cat, i) => {
        const x = 50 + i * catWidth;
        const kbs = data.kbArticles.filter((kb) => kb.category === cat.name).slice(0, 3);
        const incs = data.incidents.filter((inc) => inc.category === cat.name).slice(0, 4);

        return (
          <g key={cat.id}>
            {/* Category (Root) */}
            <circle cx={x + catWidth / 2 - 25} cy={80} r={28} fill={colors.category} />
            <text x={x + catWidth / 2 - 25} y={75} fill="white" textAnchor="middle" fontSize="8">
              {cat.name.slice(0, 10)}
            </text>
            <text x={x + catWidth / 2 - 25} y={88} fill="rgba(255,255,255,0.8)" textAnchor="middle" fontSize="7">
              {cat.kbCount}KB/{cat.incidentCount}Inc
            </text>

            {/* Lines to KBs */}
            {kbs.map((kb, j) => (
              <g key={kb.id}>
                <line
                  x1={x + catWidth / 2 - 25}
                  y1={108}
                  x2={x + 30 + j * 55}
                  y2={180}
                  stroke={colors.kb}
                  strokeWidth={2}
                  opacity={0.6}
                />
                <circle cx={x + 30 + j * 55} cy={200} r={20} fill={colors.kb} />
                <text x={x + 30 + j * 55} y={197} fill="white" textAnchor="middle" fontSize="7">
                  {kb.id.slice(0, 8)}
                </text>
                <text x={x + 30 + j * 55} y={208} fill="rgba(255,255,255,0.7)" textAnchor="middle" fontSize="6">
                  KB
                </text>
              </g>
            ))}

            {/* Lines to Incidents */}
            {incs.map((inc, j) => (
              <g key={inc.id}>
                <line
                  x1={x + catWidth / 2 - 25}
                  y1={108}
                  x2={x + 20 + j * 45}
                  y2={320}
                  stroke={colors.incident}
                  strokeWidth={1}
                  opacity={0.4}
                />
                <circle cx={x + 20 + j * 45} cy={340} r={16} fill={colors.incident} />
                <text x={x + 20 + j * 45} y={343} fill="white" textAnchor="middle" fontSize="6">
                  {inc.id.slice(0, 7)}
                </text>

                {/* KB-Incident link if exists */}
                {inc.linkedKb && (
                  <line
                    x1={x + 20 + j * 45}
                    y1={324}
                    x2={x + 30 + (j % 3) * 55}
                    y2={220}
                    stroke={colors.highlight}
                    strokeWidth={1.5}
                    strokeDasharray="4,3"
                    opacity={0.8}
                  />
                )}
              </g>
            ))}
          </g>
        );
      })}

      {/* Legend */}
      <g transform="translate(20, 440)">
        <circle cx={10} cy={10} r={8} fill={colors.category} />
        <text x={25} y={14} fill="#94a3b8" fontSize="10">Category</text>
        <circle cx={100} cy={10} r={8} fill={colors.kb} />
        <text x={115} y={14} fill="#94a3b8" fontSize="10">KB Article</text>
        <circle cx={200} cy={10} r={8} fill={colors.incident} />
        <text x={215} y={14} fill="#94a3b8" fontSize="10">Incident</text>
        <line x1={290} y1={10} x2={330} y2={10} stroke={colors.highlight} strokeWidth={2} strokeDasharray="4,3" />
        <text x={340} y={14} fill="#94a3b8" fontSize="10">KB resolves Incident</text>
      </g>
    </svg>
  );
};

// =============================================================================
// FORCE DIRECTED GRAPH
// =============================================================================

const ForceGraph: React.FC<{ data: GraphData; width?: number; height?: number }> = ({
  data,
  width = 800,
  height = 500,
}) => {
  const [hoveredNode, setHoveredNode] = useState<string | null>(null);
  const centerX = width / 2;
  const centerY = height / 2;

  const categories = data.categories.slice(0, 8);
  const angleStep = (2 * Math.PI) / categories.length;

  interface Node {
    id: string;
    type: string;
    x: number;
    y: number;
    name: string;
    size: number;
    parent?: string;
    linkedKb?: string | null;
  }

  const nodes: Node[] = [];
  const edges: Array<{ source: string; target: string; type: string }> = [];

  categories.forEach((cat, i) => {
    const angle = i * angleStep - Math.PI / 2;
    const catX = centerX + Math.cos(angle) * 140;
    const catY = centerY + Math.sin(angle) * 140;

    nodes.push({ id: cat.id, type: "category", x: catX, y: catY, name: cat.name, size: 28 });

    // Add KB nodes
    const kbs = data.kbArticles.filter((kb) => kb.category === cat.name).slice(0, 3);
    kbs.forEach((kb, j) => {
      const kbAngle = angle + (j - kbs.length / 2) * 0.25;
      const kbX = catX + Math.cos(kbAngle) * 70;
      const kbY = catY + Math.sin(kbAngle) * 70;
      nodes.push({ id: kb.id, type: "kb", x: kbX, y: kbY, name: kb.title, size: 14, parent: cat.id });
      edges.push({ source: cat.id, target: kb.id, type: "category-kb" });
    });

    // Add Incident nodes
    const incs = data.incidents.filter((inc) => inc.category === cat.name).slice(0, 4);
    incs.forEach((inc, j) => {
      const incAngle = angle + (j - incs.length / 2) * 0.2 + Math.PI;
      const incX = catX + Math.cos(incAngle) * 90;
      const incY = catY + Math.sin(incAngle) * 90;
      nodes.push({ id: inc.id, type: "incident", x: incX, y: incY, name: inc.title, size: 10, parent: cat.id, linkedKb: inc.linkedKb });
      edges.push({ source: cat.id, target: inc.id, type: "category-incident" });

      if (inc.linkedKb) {
        edges.push({ source: inc.linkedKb, target: inc.id, type: "kb-incident" });
      }
    });
  });

  const getNodeColor = (type: string) => {
    switch (type) {
      case "category": return colors.category;
      case "kb": return colors.kb;
      case "incident": return colors.incident;
      default: return colors.edge;
    }
  };

  return (
    <svg width={width} height={height} className="bg-slate-900 rounded-lg">
      {/* Edges */}
      {edges.map((edge, i) => {
        const source = nodes.find((n) => n.id === edge.source);
        const target = nodes.find((n) => n.id === edge.target);
        if (!source || !target) return null;

        const isHighlighted = hoveredNode && (edge.source === hoveredNode || edge.target === hoveredNode);

        return (
          <line
            key={i}
            x1={source.x}
            y1={source.y}
            x2={target.x}
            y2={target.y}
            stroke={edge.type === "kb-incident" ? colors.highlight : colors.edge}
            strokeWidth={isHighlighted ? 2.5 : 1}
            opacity={isHighlighted ? 1 : 0.3}
            strokeDasharray={edge.type === "kb-incident" ? "5,3" : "none"}
          />
        );
      })}

      {/* Nodes */}
      {nodes.map((node) => {
        const isHovered = hoveredNode === node.id;
        return (
          <g
            key={node.id}
            onMouseEnter={() => setHoveredNode(node.id)}
            onMouseLeave={() => setHoveredNode(null)}
            style={{ cursor: "pointer" }}
          >
            <circle
              cx={node.x}
              cy={node.y}
              r={isHovered ? node.size + 4 : node.size}
              fill={getNodeColor(node.type)}
              stroke={isHovered ? "white" : "none"}
              strokeWidth={2}
            />
            {(node.type === "category" || isHovered) && (
              <text
                x={node.x}
                y={node.y + node.size + 14}
                fill="#94a3b8"
                textAnchor="middle"
                fontSize={node.type === "category" ? 10 : 8}
              >
                {node.name.slice(0, 18)}
              </text>
            )}
          </g>
        );
      })}

      {/* Legend */}
      <g transform="translate(20, 20)">
        <rect x={0} y={0} width={200} height={90} fill="#1e293b" rx={4} />
        <text x={10} y={18} fill="white" fontSize="11" fontWeight="bold">Legend</text>
        <circle cx={20} cy={38} r={8} fill={colors.category} />
        <text x={35} y={42} fill="#94a3b8" fontSize="10">Category</text>
        <circle cx={110} cy={38} r={6} fill={colors.kb} />
        <text x={125} y={42} fill="#94a3b8" fontSize="10">KB</text>
        <circle cx={20} cy={60} r={5} fill={colors.incident} />
        <text x={35} y={64} fill="#94a3b8" fontSize="10">Incident</text>
        <line x1={100} y1={60} x2={130} y2={60} stroke={colors.highlight} strokeWidth={2} strokeDasharray="4,2" />
        <text x={140} y={64} fill="#94a3b8" fontSize="9">KB→Inc</text>
        <text x={10} y={82} fill="#64748b" fontSize="9">Hover to highlight</text>
      </g>
    </svg>
  );
};

// =============================================================================
// RADIAL TREE
// =============================================================================

const RadialTree: React.FC<{ data: GraphData; width?: number; height?: number }> = ({
  data,
  width = 800,
  height = 500,
}) => {
  const centerX = width / 2;
  const centerY = height / 2;
  const categories = data.categories.slice(0, 8);

  return (
    <svg width={width} height={height} className="bg-slate-900 rounded-lg">
      {/* Center node */}
      <circle cx={centerX} cy={centerY} r={45} fill="#3b82f6" />
      <text x={centerX} y={centerY - 8} fill="white" textAnchor="middle" fontSize="11" fontWeight="bold">
        Knowledge
      </text>
      <text x={centerX} y={centerY + 8} fill="white" textAnchor="middle" fontSize="11" fontWeight="bold">
        Fabric
      </text>

      {categories.map((cat, i) => {
        const angle = (i / categories.length) * 2 * Math.PI - Math.PI / 2;
        const catX = centerX + Math.cos(angle) * 110;
        const catY = centerY + Math.sin(angle) * 110;
        const kbX = centerX + Math.cos(angle) * 180;
        const kbY = centerY + Math.sin(angle) * 180;
        const incX = centerX + Math.cos(angle) * 240;
        const incY = centerY + Math.sin(angle) * 240;

        return (
          <g key={cat.id}>
            {/* Lines */}
            <line x1={centerX} y1={centerY} x2={catX} y2={catY} stroke={colors.category} strokeWidth={2} opacity={0.5} />
            <line x1={catX} y1={catY} x2={kbX} y2={kbY} stroke={colors.kb} strokeWidth={Math.max(2, cat.kbCount)} opacity={0.5} />
            <line x1={catX} y1={catY} x2={incX} y2={incY} stroke={colors.incident} strokeWidth={Math.max(2, cat.incidentCount / 5)} opacity={0.5} />

            {/* Category node */}
            <circle cx={catX} cy={catY} r={22} fill={colors.category} />
            <text x={catX} y={catY + 4} fill="white" textAnchor="middle" fontSize="7">
              {cat.name.slice(0, 10)}
            </text>

            {/* KB node */}
            <circle cx={kbX} cy={kbY} r={12 + Math.min(cat.kbCount * 2, 15)} fill={colors.kb} />
            <text x={kbX} y={kbY + 4} fill="white" textAnchor="middle" fontSize="11" fontWeight="bold">
              {cat.kbCount}
            </text>

            {/* Incident node */}
            <circle cx={incX} cy={incY} r={10 + Math.min(cat.incidentCount / 3, 20)} fill={colors.incident} />
            <text x={incX} y={incY + 4} fill="white" textAnchor="middle" fontSize="11" fontWeight="bold">
              {cat.incidentCount}
            </text>
          </g>
        );
      })}

      {/* Ring labels */}
      <text x={centerX} y={35} fill="#94a3b8" textAnchor="middle" fontSize="11">
        🟣 Categories → 🟢 KB Articles → 🔴 Incidents
      </text>
    </svg>
  );
};

// =============================================================================
// COVERAGE MATRIX WITH PAGINATION
// =============================================================================

const CoverageMatrix: React.FC<{ 
  data: GraphData; 
  width?: number; 
  height?: number;
  currentPage: number;
  pageSize: number;
}> = ({
  data,
  width = 800,
  height = 500,
  currentPage,
  pageSize,
}) => {
  const startIdx = currentPage * pageSize;
  const categories = data.categories.slice(startIdx, startIdx + pageSize);
  const cellWidth = 100;
  const cellHeight = 50;
  const startX = 180;
  const startY = 70;

  return (
    <svg width={width} height={height} className="bg-slate-900 rounded-lg">
      <text x={width / 2} y={30} fill="#94a3b8" textAnchor="middle" fontSize="14" fontWeight="bold">
        KB Coverage Matrix by Category
      </text>

      {/* Header row */}
      <text x={startX + cellWidth * 0.5} y={startY - 15} fill="#94a3b8" textAnchor="middle" fontSize="11" fontWeight="bold">
        KB Count
      </text>
      <text x={startX + cellWidth * 1.5} y={startY - 15} fill="#94a3b8" textAnchor="middle" fontSize="11" fontWeight="bold">
        Incidents
      </text>
      <text x={startX + cellWidth * 2.5} y={startY - 15} fill="#94a3b8" textAnchor="middle" fontSize="11" fontWeight="bold">
        Coverage
      </text>

      {/* Data rows */}
      {categories.map((cat, rowIndex) => {
        const y = startY + rowIndex * cellHeight;
        const coverage = cat.incidentCount > 0 ? Math.round((cat.kbCount / cat.incidentCount) * 100) : 0;
        const coverageColor = coverage > 30 ? colors.kb : coverage > 10 ? "#eab308" : colors.incident;

        return (
          <g key={cat.id}>
            {/* Category label */}
            <text x={startX - 10} y={y + cellHeight / 2 + 5} fill="white" textAnchor="end" fontSize="11">
              {cat.name.slice(0, 20)}
            </text>

            {/* KB Count cell */}
            <rect x={startX} y={y} width={cellWidth - 5} height={cellHeight - 5} fill={colors.kb} opacity={0.2} rx={4} />
            <text x={startX + cellWidth / 2} y={y + cellHeight / 2 + 5} fill={colors.kb} textAnchor="middle" fontSize="16" fontWeight="bold">
              {cat.kbCount}
            </text>

            {/* Incidents cell */}
            <rect x={startX + cellWidth} y={y} width={cellWidth - 5} height={cellHeight - 5} fill={colors.incident} opacity={0.2} rx={4} />
            <text x={startX + cellWidth * 1.5} y={y + cellHeight / 2 + 5} fill={colors.incident} textAnchor="middle" fontSize="16" fontWeight="bold">
              {cat.incidentCount}
            </text>

            {/* Coverage cell */}
            <rect x={startX + cellWidth * 2} y={y} width={cellWidth - 5} height={cellHeight - 5} fill={coverageColor} opacity={0.2} rx={4} />
            <text x={startX + cellWidth * 2.5} y={y + cellHeight / 2 + 5} fill={coverageColor} textAnchor="middle" fontSize="16" fontWeight="bold">
              {coverage}%
            </text>

            {/* Coverage bar */}
            <rect x={startX + cellWidth * 3 + 10} y={y + 12} width={120} height={cellHeight - 28} fill="#334155" rx={4} />
            <rect
              x={startX + cellWidth * 3 + 10}
              y={y + 12}
              width={Math.min(120, coverage * 1.2)}
              height={cellHeight - 28}
              fill={coverageColor}
              rx={4}
            />
          </g>
        );
      })}
    </svg>
  );
};

// =============================================================================
// SUNBURST CHART
// =============================================================================

const SunburstChart: React.FC<{ data: GraphData; width?: number; height?: number }> = ({
  data,
  width = 800,
  height = 500,
}) => {
  const centerX = width / 2;
  const centerY = height / 2 + 20;
  const categories = data.categories.slice(0, 8);
  const total = categories.reduce((sum, c) => sum + c.incidentCount + c.kbCount, 0);

  let currentAngle = -Math.PI / 2;

  return (
    <svg width={width} height={height} className="bg-slate-900 rounded-lg">
      <text x={centerX} y={30} fill="#94a3b8" textAnchor="middle" fontSize="14" fontWeight="bold">
        Knowledge Distribution Sunburst
      </text>

      {categories.map((cat) => {
        const catTotal = cat.incidentCount + cat.kbCount;
        if (catTotal === 0) return null;

        const catAngle = (catTotal / total) * 2 * Math.PI;
        const startAngle = currentAngle;
        const endAngle = currentAngle + catAngle;
        currentAngle = endAngle;

        const midAngle = (startAngle + endAngle) / 2;
        const innerR = 50;
        const outerR = 100;

        // Arc path
        const x1 = centerX + Math.cos(startAngle) * innerR;
        const y1 = centerY + Math.sin(startAngle) * innerR;
        const x2 = centerX + Math.cos(startAngle) * outerR;
        const y2 = centerY + Math.sin(startAngle) * outerR;
        const x3 = centerX + Math.cos(endAngle) * outerR;
        const y3 = centerY + Math.sin(endAngle) * outerR;
        const x4 = centerX + Math.cos(endAngle) * innerR;
        const y4 = centerY + Math.sin(endAngle) * innerR;

        const largeArc = catAngle > Math.PI ? 1 : 0;

        // KB proportion
        const kbRatio = cat.kbCount / catTotal;
        const kbEndAngle = startAngle + catAngle * kbRatio;

        // Label position
        const labelX = centerX + Math.cos(midAngle) * 75;
        const labelY = centerY + Math.sin(midAngle) * 75;

        return (
          <g key={cat.id}>
            {/* Category arc (inner) */}
            <path
              d={`M ${x1} ${y1} L ${x2} ${y2} A ${outerR} ${outerR} 0 ${largeArc} 1 ${x3} ${y3} L ${x4} ${y4} A ${innerR} ${innerR} 0 ${largeArc} 0 ${x1} ${y1}`}
              fill={colors.category}
              stroke="#1e293b"
              strokeWidth={2}
              opacity={0.85}
            />

            {/* KB arc (outer - green portion) */}
            {cat.kbCount > 0 && (
              <path
                d={`M ${centerX + Math.cos(startAngle) * (outerR + 5)} ${centerY + Math.sin(startAngle) * (outerR + 5)} 
                    A ${outerR + 5} ${outerR + 5} 0 ${kbRatio > 0.5 ? 1 : 0} 1 
                    ${centerX + Math.cos(kbEndAngle) * (outerR + 5)} ${centerY + Math.sin(kbEndAngle) * (outerR + 5)}
                    L ${centerX + Math.cos(kbEndAngle) * (outerR + 40)} ${centerY + Math.sin(kbEndAngle) * (outerR + 40)}
                    A ${outerR + 40} ${outerR + 40} 0 ${kbRatio > 0.5 ? 1 : 0} 0
                    ${centerX + Math.cos(startAngle) * (outerR + 40)} ${centerY + Math.sin(startAngle) * (outerR + 40)} Z`}
                fill={colors.kb}
                stroke="#1e293b"
                strokeWidth={1}
                opacity={0.85}
              />
            )}

            {/* Incident arc (outer - red portion) */}
            {cat.incidentCount > 0 && (
              <path
                d={`M ${centerX + Math.cos(kbEndAngle) * (outerR + 5)} ${centerY + Math.sin(kbEndAngle) * (outerR + 5)} 
                    A ${outerR + 5} ${outerR + 5} 0 ${1 - kbRatio > 0.5 ? 1 : 0} 1 
                    ${centerX + Math.cos(endAngle) * (outerR + 5)} ${centerY + Math.sin(endAngle) * (outerR + 5)}
                    L ${centerX + Math.cos(endAngle) * (outerR + 40)} ${centerY + Math.sin(endAngle) * (outerR + 40)}
                    A ${outerR + 40} ${outerR + 40} 0 ${1 - kbRatio > 0.5 ? 1 : 0} 0
                    ${centerX + Math.cos(kbEndAngle) * (outerR + 40)} ${centerY + Math.sin(kbEndAngle) * (outerR + 40)} Z`}
                fill={colors.incident}
                stroke="#1e293b"
                strokeWidth={1}
                opacity={0.85}
              />
            )}

            {/* Label */}
            {catAngle > 0.35 && (
              <text x={labelX} y={labelY} fill="white" textAnchor="middle" fontSize="8" fontWeight="bold">
                {cat.name.slice(0, 8)}
              </text>
            )}
          </g>
        );
      })}

      {/* Center */}
      <circle cx={centerX} cy={centerY} r={45} fill="#1e293b" />
      <text x={centerX} y={centerY - 8} fill="white" textAnchor="middle" fontSize="11" fontWeight="bold">
        Total
      </text>
      <text x={centerX} y={centerY + 12} fill="#94a3b8" textAnchor="middle" fontSize="18" fontWeight="bold">
        {total}
      </text>

      {/* Legend */}
      <g transform="translate(20, 440)">
        <rect x={0} y={0} width={15} height={15} fill={colors.category} rx={2} />
        <text x={22} y={12} fill="#94a3b8" fontSize="10">Category</text>
        <rect x={100} y={0} width={15} height={15} fill={colors.kb} rx={2} />
        <text x={122} y={12} fill="#94a3b8" fontSize="10">KB Articles</text>
        <rect x={210} y={0} width={15} height={15} fill={colors.incident} rx={2} />
        <text x={232} y={12} fill="#94a3b8" fontSize="10">Incidents</text>
      </g>
    </svg>
  );
};

// =============================================================================
// MAIN COMPONENT
// =============================================================================

export const GraphLibrary: React.FC<GraphLibraryProps> = ({ fabricId }) => {
  const [selectedGraph, setSelectedGraph] = useState("force");
  const [data, setData] = useState<GraphData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // Pagination state for Sankey and Matrix
  const [sankeyPage, setSankeyPage] = useState(0);
  const [matrixPage, setMatrixPage] = useState(0);
  const pageSize = 8;

  useEffect(() => {
    fetchGraphData();
  }, [fabricId]);

  // Reset pagination when switching graphs
  useEffect(() => {
    setSankeyPage(0);
    setMatrixPage(0);
  }, [selectedGraph]);

  const fetchGraphData = async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await axiosClient.get(`/api/fabrics/${fabricId}/graph-library-data`);
      if (response.data.success) {
        setData(response.data);
      } else {
        setError(response.data.error || "Failed to load graph data");
      }
    } catch (err: any) {
      setError(err.message || "Failed to fetch graph data");
    } finally {
      setLoading(false);
    }
  };

  const totalCategories = data?.categories.length || 0;
  const totalPages = Math.ceil(totalCategories / pageSize);

  const renderGraph = () => {
    if (!data) return null;

    switch (selectedGraph) {
      case "sankey": 
        return (
          <>
            <PaginationControls
              currentPage={sankeyPage}
              totalPages={totalPages}
              totalItems={totalCategories}
              pageSize={pageSize}
              onPrevious={() => setSankeyPage(p => Math.max(0, p - 1))}
              onNext={() => setSankeyPage(p => Math.min(totalPages - 1, p + 1))}
            />
            <SankeyDiagram data={data} currentPage={sankeyPage} pageSize={pageSize} />
          </>
        );
      case "hierarchical": 
        return <HierarchicalTree data={data} />;
      case "force": 
        return <ForceGraph data={data} />;
      case "radial": 
        return <RadialTree data={data} />;
      case "matrix": 
        return (
          <>
            <PaginationControls
              currentPage={matrixPage}
              totalPages={totalPages}
              totalItems={totalCategories}
              pageSize={pageSize}
              onPrevious={() => setMatrixPage(p => Math.max(0, p - 1))}
              onNext={() => setMatrixPage(p => Math.min(totalPages - 1, p + 1))}
            />
            <CoverageMatrix data={data} currentPage={matrixPage} pageSize={pageSize} />
          </>
        );
      case "sunburst": 
        return <SunburstChart data={data} />;
      default: 
        return <ForceGraph data={data} />;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-lg text-red-400">
        {error}
      </div>
    );
  }

  if (!data) return null;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-100">Knowledge Graph Visualizations</h2>
          <p className="text-slate-400 mt-1">
            Explore Category → KB Article → Incident relationships
          </p>
        </div>
        <div className="flex items-center space-x-4 text-sm">
          <span className="flex items-center">
            <span className="w-3 h-3 rounded-full bg-purple-500 mr-2"></span>
            {data.stats.totalCategories} Categories
          </span>
          <span className="flex items-center">
            <span className="w-3 h-3 rounded-full bg-green-500 mr-2"></span>
            {data.stats.totalKbArticles} KB Articles
          </span>
          <span className="flex items-center">
            <span className="w-3 h-3 rounded-full bg-red-500 mr-2"></span>
            {data.stats.totalIncidents} Incidents
          </span>
          <span className="px-2 py-1 bg-blue-500/20 text-blue-400 rounded text-xs">
            {data.stats.linkageRate}% linked
          </span>
        </div>
      </div>

      {/* Graph Type Selector */}
      <div className="grid grid-cols-6 gap-3">
        {graphTypes.map((type) => (
          <button
            key={type.id}
            onClick={() => setSelectedGraph(type.id)}
            className={`p-3 rounded-lg border-2 transition-all text-center ${
              selectedGraph === type.id
                ? "border-brand-500 bg-brand-500/20"
                : "border-slate-700 bg-slate-800/50 hover:border-slate-500"
            }`}
          >
            <div className="text-2xl mb-1">{type.icon}</div>
            <div className="text-xs font-medium text-slate-100">{type.name}</div>
          </button>
        ))}
      </div>

      {/* Selected Graph */}
      <div className="bg-slate-800/50 rounded-xl border border-slate-700 p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-slate-100">
            {graphTypes.find((g) => g.id === selectedGraph)?.icon}{" "}
            {graphTypes.find((g) => g.id === selectedGraph)?.name}
          </h3>
          <span className="text-sm text-slate-400">
            {graphTypes.find((g) => g.id === selectedGraph)?.description}
          </span>
        </div>

        <div className="flex flex-col items-center overflow-x-auto">
          {renderGraph()}
        </div>
      </div>
    </div>
  );
};

export default GraphLibrary;
