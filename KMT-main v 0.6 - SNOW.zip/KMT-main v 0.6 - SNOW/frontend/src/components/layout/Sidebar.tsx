import React from "react";
import { Link, useLocation } from "react-router-dom";
import {
  ChatBubbleLeftRightIcon,
  CubeIcon,
  ChartBarIcon,
} from "@heroicons/react/24/outline";
// added this line in v 0.4
import { SparklesIcon } from "@heroicons/react/24/outline";

// changed this in v 0.4
interface NavItem {
    path: string;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: string;  // ADD THIS LINE
}
// changed the entire navigate array in v 0.4
const navItems: NavItem[] = [
    {
        path: "/fabrics",
        label: "Knowledge Fabric Builder",
        icon: CubeIcon,
    },
    {
        path: "/available-fabrics",
        label: "Available Fabrics",
        icon: CubeIcon,
    },
    {
        path: "/chat",
        label: "Chat on Fabric",
        icon: ChatBubbleLeftRightIcon,
    },
    {
        path: "/generate-kb",
        label: "Generate KB Article",
        icon: SparklesIcon,
        badge: "AI"
    },
    {
        path: "/analytics",
        label: "Analytics Dashboard",
        icon: ChartBarIcon,
    },
];

export const Sidebar: React.FC = () => {
  const location = useLocation();

  return (
    <div className="fixed left-0 top-0 h-full w-72 bg-slate-900 border-r border-slate-800 flex flex-col z-40">
      <div className="p-6 border-b border-slate-800">
        <h1 className="text-xl font-bold text-slate-100">ServiceOps</h1>
        <p className="text-xs text-slate-400 mt-1 leading-relaxed">
          Knowledge Fabric<br />Studio
        </p>
      </div>
      <nav className="flex-1 p-4 space-y-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          return (
              // changed the code between <Link> </Link> in v 0.4
              <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 ${isActive
                          ? "bg-brand-600 text-white"
                          : "text-slate-300 hover:bg-slate-800 hover:text-white"
                      }`}
              >
                  <Icon className="w-5 h-5" />
                  <span className="font-medium flex-1">{item.label}</span>
                  {item.badge && (
                      <span className={`px-2 py-0.5 text-xs font-semibold rounded ${isActive
                              ? 'bg-white text-brand-600'
                              : 'bg-purple-600 text-white'
                          }`}>
                          {item.badge}
                      </span>
                  )}
              </Link>
          );
        })}
      </nav>
    </div>
  );
};
