﻿import os
import threading
import chromadb
from flask import Flask, request, jsonify
from flask_cors import CORS
from werkzeug.utils import secure_filename
from datetime import datetime, timedelta
from sqlalchemy import func

from config import Config
#made this change for version 0.51
from models import db, Fabric, IngestionHistory, FabricDocument, GraphNode, GraphEdge,Conversation, ConversationMessage,IngestedContent, CICategory


from services.ingestion import process_fabric_build
from services.agent import ChatAgent
# adding these imports for v 0.4

from openai import OpenAI
import os
import random

#added this for v 0.51 for ingesting CSV
from werkzeug.utils import secure_filename
from services.csv_ingestion import CSVIngestionService
from collections import defaultdict



app = Flask(__name__)
app.config.from_object(Config)
CORS(app)
db.init_app(app)



# Ensure tables exist
with app.app_context():
    db.create_all()

# ============= FABRIC ROUTES =============

@app.route('/api/fabrics', methods=['GET'])
def get_fabrics():
    """Get all fabrics with optional filtering"""
    # Get query parameters
    source_type = request.args.get('sourceType')  # 'uploads', 'servicenow', 'sharepoint'
    status = request.args.get('status')
    
    query = Fabric.query
    
    # Apply filters
    if status:
        query = query.filter_by(status=status)
    
    fabrics = query.all()
    
    # Filter by source type if specified
    if source_type:
        fabrics = [f for f in fabrics if f.source_breakdown.get(source_type, 0) > 0]
    
    return jsonify([f.to_dict() for f in fabrics])


@app.route('/api/fabrics/<id>', methods=['GET'])
def get_fabric(id):
    """Get fabric by ID with optional detailed stats"""
    fabric = Fabric.query.get_or_404(id)
    include_stats = request.args.get('includeStats', 'true').lower() == 'true'
    
    result = fabric.to_dict()
    
    if include_stats:
        # Add real-time ChromaDB count
        try:
            collection_name = fabric.rag_config.get('chromaCollection')
            chroma_client = chromadb.PersistentClient(path=Config.CHROMA_DB_PATH)
            collection = chroma_client.get_collection(collection_name)
            actual_chunks = collection.count()
            result['actualChunksInDB'] = actual_chunks
            result['chunksMatch'] = actual_chunks == fabric.chunks_count
        except:
            result['actualChunksInDB'] = 0
            result['chunksMatch'] = False
    
    return jsonify(result)


@app.route('/api/fabrics', methods=['POST'])
def create_fabric():
    """Create new fabric"""
    data = request.json
    
    new_fabric = Fabric(
        name=data['name'],
        description=data.get('description', ''),
        domain=data['domain'],
        sources_config=data['sources'],
        rag_config={
            'chunkSize': data['chunkSize'],
            'chunkOverlap': data['chunkOverlap'],
            'embeddingModel': data['embeddingModel'],
            'chromaCollection': data['chromaCollection']
        },
        ingestion_stats={},
        source_breakdown={}
    )
    
    db.session.add(new_fabric)
    db.session.commit()
    
    # Create upload directory
    fabric_dir = os.path.join(Config.UPLOAD_FOLDER, new_fabric.id)
    if not os.path.exists(fabric_dir):
        os.makedirs(fabric_dir)
    
    return jsonify(new_fabric.to_dict()), 201


@app.route('/api/fabrics/<id>/build', methods=['POST'])
def trigger_build(id):
    """Trigger fabric build in background - preserves CSV-ingested data"""
    fabric = Fabric.query.get_or_404(id)
    
    # Check if we already have CSV-ingested data
    existing_nodes = GraphNode.query.filter_by(fabric_id=id).count()
    existing_content = IngestedContent.query.filter_by(fabric_id=id).count()
    
    if existing_nodes > 0 or existing_content > 0:
        print(f"Skipping document build - fabric already has {existing_nodes} nodes, {existing_content} content items from CSV")
        fabric.status = 'ready'
        fabric.graph_nodes = existing_nodes
        fabric.graph_edges = GraphEdge.query.filter_by(fabric_id=id).count()
        fabric.documents_count = existing_content
        db.session.commit()
        return jsonify({
            "status": "ready",
            "message": f"Fabric ready with {existing_content} documents and {existing_nodes} graph nodes from CSV"
        })
    
    # Start background thread for document processing (PDF, DOCX, TXT)
    thread = threading.Thread(
        target=process_fabric_build,
        args=(id, app)
    )
    thread.start()
    
    return jsonify({
        "status": "Ingesting",
        "message": "Build started"
    })



@app.route('/api/fabrics/<id>', methods=['DELETE'])
def delete_fabric(id):
    """Delete fabric and all related data"""
    fabric = Fabric.query.get_or_404(id)
    
    # Delete related records
    IngestionHistory.query.filter_by(fabric_id=id).delete()
    FabricDocument.query.filter_by(fabric_id=id).delete()
    GraphNode.query.filter_by(fabric_id=id).delete()
    GraphEdge.query.filter_by(fabric_id=id).delete()
    IngestedContent.query.filter_by(fabric_id=id).delete() # added this line to fix error in 0.51
    
    # Delete ChromaDB collection
    try:
        collection_name = fabric.rag_config.get('chromaCollection')
        chroma_client = chromadb.PersistentClient(path=Config.CHROMA_DB_PATH)
        chroma_client.delete_collection(collection_name)
    except:
        pass
    
    # Delete uploaded files
    fabric_dir = os.path.join(Config.UPLOAD_FOLDER, id)
    if os.path.exists(fabric_dir):
        import shutil
        shutil.rmtree(fabric_dir)
    
    # Delete fabric
    db.session.delete(fabric)
    db.session.commit()
    
    return jsonify({
        "success": True,
        "message": "Fabric deleted"
    })


# ============= DETAILED STATS ROUTES =============

@app.route('/api/fabrics/<id>/detailed-stats', methods=['GET'])
def get_detailed_stats(id):
    """Get comprehensive statistics for a fabric"""
    fabric = Fabric.query.get_or_404(id)
    
    # Get real-time ChromaDB count
    try:
        collection_name = fabric.rag_config.get('chromaCollection')
        chroma_client = chromadb.PersistentClient(path=Config.CHROMA_DB_PATH)
        collection = chroma_client.get_collection(collection_name)
        actual_chunks = collection.count()
    except:
        actual_chunks = 0
    
    # Get file breakdown
    fabric_docs = FabricDocument.query.filter_by(fabric_id=id).all()
    
    return jsonify({
        "stored": {
            "documentsCount": fabric.documents_count,
            "chunksCount": fabric.chunks_count,
            "graphNodes": fabric.graph_nodes,
            "graphEdges": fabric.graph_edges,
            "ingestionStats": fabric.ingestion_stats or {},
            "sourceBreakdown": fabric.source_breakdown or {}
        },
        "realtime": {
            "chunksInChromaDB": actual_chunks,
            "matchesStored": actual_chunks == fabric.chunks_count
        },
        "files": [doc.to_dict() for doc in fabric_docs]
    })


@app.route('/api/fabrics/<id>/source-breakdown', methods=['GET'])
def get_source_breakdown(id):
    """Get breakdown by source type"""
    fabric = Fabric.query.get_or_404(id)
    fabric_docs = FabricDocument.query.filter_by(fabric_id=id).all()
    
    breakdown = {
        "uploads": {
            "count": 0,
            "documents": 0,
            "chunks": 0,
            "files": []
        },
        "servicenow": {
            "count": 0,
            "documents": 0,
            "chunks": 0,
            "tables": []
        }
    }
    
    for doc in fabric_docs:
        if doc.source_type == 'upload':
            breakdown["uploads"]["count"] += 1
            breakdown["uploads"]["documents"] += doc.document_count
            breakdown["uploads"]["chunks"] += doc.chunk_count
            breakdown["uploads"]["files"].append(doc.to_dict())
        elif doc.source_type.startswith('servicenow_'):
            breakdown["servicenow"]["count"] += 1
            breakdown["servicenow"]["documents"] += doc.document_count
            breakdown["servicenow"]["chunks"] += doc.chunk_count
            breakdown["servicenow"]["tables"].append(doc.to_dict())
    
    return jsonify(breakdown)


@app.route('/api/fabrics/<id>/files', methods=['GET'])
def get_fabric_files(id):
    """List all files in the fabric"""
    fabric_docs = FabricDocument.query.filter_by(fabric_id=id).all()
    return jsonify([doc.to_dict() for doc in fabric_docs])


# ============= INGESTION HISTORY ROUTES =============

@app.route('/api/fabrics/<id>/ingestion-history', methods=['GET'])
def get_ingestion_history(id):
    """Get ingestion history for a fabric"""
    history = IngestionHistory.query.filter_by(fabric_id=id).order_by(
        IngestionHistory.started_at.desc()
    ).all()
    
    return jsonify([record.to_dict() for record in history])


@app.route('/api/ingestion-history/<history_id>', methods=['GET'])
def get_ingestion_record(history_id):
    """Get specific ingestion history record"""
    record = IngestionHistory.query.get_or_404(history_id)
    return jsonify(record.to_dict())


# ============= KNOWLEDGE GRAPH ROUTES =============

@app.route('/api/fabrics/<id>/graph', methods=['GET'])
def get_knowledge_graph(id):
    """Get knowledge graph for a fabric"""
    fabric = Fabric.query.get_or_404(id)
    
    # Get all nodes
    nodes = GraphNode.query.filter_by(fabric_id=id).all()
    
    # Get all edges
    edges = GraphEdge.query.filter_by(fabric_id=id).all()
    
    return jsonify({
        "nodes": [node.to_dict() for node in nodes],
        "edges": [edge.to_dict() for edge in edges],
        "stats": {
            "nodeCount": len(nodes),
            "edgeCount": len(edges)
        }
    })


@app.route('/api/fabrics/<id>/graph/nodes', methods=['GET'])
def get_graph_nodes(id):
    """Get graph nodes with optional filtering"""
    node_type = request.args.get('type')
    
    query = GraphNode.query.filter_by(fabric_id=id)
    
    if node_type:
        query = query.filter_by(node_type=node_type)
    
    nodes = query.all()
    return jsonify([node.to_dict() for node in nodes])


@app.route('/api/fabrics/<id>/graph/node/<node_id>', methods=['GET'])
def get_node_details(id, node_id):
    """Get details for a specific node including its connections"""
    node = GraphNode.query.filter_by(fabric_id=id, node_id=node_id).first_or_404()
    
    # Get outgoing edges
    outgoing = GraphEdge.query.filter_by(fabric_id=id, source_node_id=node.id).all()
    
    # Get incoming edges
    incoming = GraphEdge.query.filter_by(fabric_id=id, target_node_id=node.id).all()
    
    # Get connected nodes
    connected_node_ids = set()
    for edge in outgoing:
        connected_node_ids.add(edge.target_node_id)
    for edge in incoming:
        connected_node_ids.add(edge.source_node_id)
    
    connected_nodes = GraphNode.query.filter(GraphNode.id.in_(connected_node_ids)).all()
    
    return jsonify({
        "node": node.to_dict(),
        "outgoingEdges": [edge.to_dict() for edge in outgoing],
        "incomingEdges": [edge.to_dict() for edge in incoming],
        "connectedNodes": [n.to_dict() for n in connected_nodes]
    })


@app.route('/api/fabrics/<id>/graph/search', methods=['GET'])
def search_graph(id):
    """Search nodes in the graph"""
    query_text = request.args.get('q', '')
    node_type = request.args.get('type')
    
    query = GraphNode.query.filter_by(fabric_id=id)
    
    if node_type:
        query = query.filter_by(node_type=node_type)
    
    if query_text:
        query = query.filter(
            db.or_(
                GraphNode.node_id.contains(query_text),
                GraphNode.label.contains(query_text)
            )
        )
    
    nodes = query.limit(50).all()
    return jsonify([node.to_dict() for node in nodes])


# ============= ANALYTICS ROUTES =============

@app.route('/api/analytics/dashboard', methods=['GET'])
def get_analytics_dashboard():
    """Get aggregate analytics across all fabrics"""
    
    # Total counts
    total_fabrics = Fabric.query.count()
    total_documents = db.session.query(func.sum(Fabric.documents_count)).scalar() or 0
    total_chunks = db.session.query(func.sum(Fabric.chunks_count)).scalar() or 0
    total_graph_nodes = db.session.query(func.sum(Fabric.graph_nodes)).scalar() or 0
    
    # Fabrics by status
    status_counts = db.session.query(
        Fabric.status,
        func.count(Fabric.id)
    ).group_by(Fabric.status).all()
    
    fabrics_by_status = {status: count for status, count in status_counts}
    
    # Recent fabrics
    recent_fabrics = Fabric.query.order_by(
        Fabric.created_at.desc()
    ).limit(5).all()
    
    # Source type distribution
    fabrics = Fabric.query.all()
    source_distribution = defaultdict(int)
    
    for fabric in fabrics:
        breakdown = fabric.source_breakdown or {}
        for source_type, count in breakdown.items():
            if count > 0:
                source_distribution[source_type] += 1
    
    # Recent ingestion attempts
    recent_ingestions = IngestionHistory.query.order_by(
        IngestionHistory.started_at.desc()
    ).limit(10).all()
    
    # Success rate
    total_ingestions = IngestionHistory.query.count()
    successful_ingestions = IngestionHistory.query.filter_by(status='completed').count()
    success_rate = (successful_ingestions / total_ingestions * 100) if total_ingestions > 0 else 0
    
    # Average ingestion time
    avg_duration = db.session.query(
        func.avg(IngestionHistory.duration_seconds)
    ).filter(
        IngestionHistory.status == 'completed'
    ).scalar() or 0
    
    return jsonify({
        "summary": {
            "totalFabrics": total_fabrics,
            "totalDocuments": int(total_documents),
            "totalChunks": int(total_chunks),
            "totalGraphNodes": int(total_graph_nodes),
            "fabricsByStatus": fabrics_by_status,
            "sourceDistribution": source_distribution
        },
        "ingestionMetrics": {
            "totalAttempts": total_ingestions,
            "successfulAttempts": successful_ingestions,
            "successRate": round(success_rate, 2),
            "avgDurationSeconds": int(avg_duration)
        },
        "recentFabrics": [f.to_dict() for f in recent_fabrics],
        "recentIngestions": [i.to_dict() for i in recent_ingestions]
    })


@app.route('/api/analytics/fabrics-over-time', methods=['GET'])
def get_fabrics_over_time():
    """Get fabric creation over time"""
    days = int(request.args.get('days', 30))
    
    start_date = datetime.utcnow() - timedelta(days=days)
    
    fabrics = Fabric.query.filter(
        Fabric.created_at >= start_date
    ).order_by(Fabric.created_at).all()
    
    # Group by date
    date_counts = {}
    for fabric in fabrics:
        date_key = fabric.created_at.strftime('%Y-%m-%d')
        date_counts[date_key] = date_counts.get(date_key, 0) + 1
    
    return jsonify({
        "data": [
            {"date": date, "count": count}
            for date, count in sorted(date_counts.items())
        ]
    })


@app.route('/api/analytics/source-breakdown', methods=['GET'])
def get_analytics_source_breakdown():
    """Get aggregate source breakdown across all fabrics"""
    fabrics = Fabric.query.all()
    
    total_by_source = {
        "uploads": {"fabrics": 0, "documents": 0, "chunks": 0},
        "servicenow": {"fabrics": 0, "documents": 0, "chunks": 0},
        "sharepoint": {"fabrics": 0, "documents": 0, "chunks": 0}
    }
    
    for fabric in fabrics:
        breakdown = fabric.source_breakdown or {}
        for source_type, doc_count in breakdown.items():
            if doc_count > 0:
                total_by_source[source_type]["fabrics"] += 1
                total_by_source[source_type]["documents"] += doc_count
    
    return jsonify(total_by_source)

# IMPROVED KB Coverage Endpoint - Shows Incident Coverage Gaps
@app.route('/api/fabrics/<id>/kb-coverage-matrix', methods=['GET'])
def get_kb_coverage_matrix(id):
    """Get KB article coverage matrix showing incident gaps"""
    fabric = Fabric.query.get_or_404(id)
    
    # Get all nodes for this fabric
    nodes = GraphNode.query.filter_by(fabric_id=id).all()
    edges = GraphEdge.query.filter_by(fabric_id=id).all()
    
    print(f"DEBUG: Total nodes: {len(nodes)}")
    print(f"DEBUG: Total edges: {len(edges)}")
    
    # Get all unique node types
    node_types = set(n.node_type for n in nodes)
    print(f"DEBUG: Node types: {node_types}")
    
    # Extract incidents, KB articles, and categories
    incidents = [n for n in nodes if n.node_type in ['incident', 'inc']]
    kb_articles = [n for n in nodes if n.node_type in ['kb_article', 'kb', 'knowledge_base']]
    categories = [n for n in nodes if n.node_type in ['category', 'cat']]
    
    print(f"DEBUG: Incidents found: {len(incidents)}")
    print(f"DEBUG: KB articles found: {len(kb_articles)}")
    print(f"DEBUG: Categories found: {len(categories)}")
    
    # If no data, return empty with debug info
    if not incidents and not kb_articles:
        return jsonify({
            "categories": [],
            "incidentCounts": [],
            "kbCoverageCounts": [],
            "coveragePercentages": [],
            "gaps": [],
            "totalIncidents": 0,
            "totalKBArticles": 0,
            "debug": {
                "availableNodeTypes": list(node_types),
                "totalNodes": len(nodes),
                "totalEdges": len(edges)
            }
        })
    
    if not categories:
        print("DEBUG: No categories found - using documents as categories")
        categories = [n for n in nodes if n.node_type == 'document']
    
    # Build incident -> categories mapping
    incident_categories = {}
    for edge in edges:
        if edge.relationship_type == 'BELONGS_TO':
            source_node = next((n for n in nodes if n.id == edge.source_node_id), None)
            target_node = next((n for n in nodes if n.id == edge.target_node_id), None)
            
            if source_node and target_node:
                # Check if source is an incident or document mentioning incidents
                incident_id = source_node.id
                if incident_id not in incident_categories:
                    incident_categories[incident_id] = []
                incident_categories[incident_id].append(target_node.label)
    
    print(f"DEBUG: Documents/Incidents with categories: {len(incident_categories)}")
    
    # Build incident -> KB mapping (which incidents have KB article references)
    incidents_with_kb = {}
    for edge in edges:
        if edge.relationship_type in ['MENTIONS', 'REFERENCES']:
            source_node = next((n for n in nodes if n.id == edge.source_node_id), None)
            target_node = next((n for n in nodes if n.id == edge.target_node_id), None)
            
            # Check if target is a KB article
            if target_node and target_node.node_type in ['kb_article', 'kb', 'knowledge_base']:
                if source_node:
                    incident_id = source_node.id
                    if incident_id not in incidents_with_kb:
                        incidents_with_kb[incident_id] = []
                    incidents_with_kb[incident_id].append(target_node.node_id)
    
    print(f"DEBUG: Incidents with KB references: {len(incidents_with_kb)}")
    
    # Get unique categories
    all_categories = sorted(set(cat for cats in incident_categories.values() for cat in cats))
    
    if not all_categories:
        all_categories = sorted([cat.label for cat in categories])
    
    if not all_categories:
        all_categories = ['Uncategorized']
    
    print(f"DEBUG: Total unique categories: {len(all_categories)}")
    
    # Build analysis by category
    category_data = {}
    for category in all_categories:
        category_data[category] = {
            'total_incidents': 0,
            'incidents_with_kb': 0,
            'incidents_without_kb': 0,
            'unique_kb_articles': set()
        }
    
    # Count incidents per category
    for incident_id, cats in incident_categories.items():
        for cat in cats:
            if cat in category_data:
                category_data[cat]['total_incidents'] += 1
                
                # Check if this incident has KB reference
                if incident_id in incidents_with_kb:
                    category_data[cat]['incidents_with_kb'] += 1
                    # Track which KB articles are used
                    for kb_id in incidents_with_kb[incident_id]:
                        category_data[cat]['unique_kb_articles'].add(kb_id)
                else:
                    category_data[cat]['incidents_without_kb'] += 1
    
    # Prepare response data
    categories_list = []
    incident_counts = []
    kb_coverage_counts = []
    coverage_percentages = []
    gaps = []
    kb_article_counts = []
    
    for category in all_categories:
        data = category_data[category]
        total = data['total_incidents']
        covered = data['incidents_with_kb']
        gap = data['incidents_without_kb']
        kb_count = len(data['unique_kb_articles'])
        
        coverage_pct = (covered / total * 100) if total > 0 else 0
        
        categories_list.append(category)
        incident_counts.append(total)
        kb_coverage_counts.append(covered)
        coverage_percentages.append(round(coverage_pct, 1))
        gaps.append(gap)
        kb_article_counts.append(kb_count)
    
    print(f"DEBUG: Analysis complete")
    
    return jsonify({
        "categories": categories_list,
        "incidentCounts": incident_counts,
        "kbCoverageCounts": kb_coverage_counts,
        "coveragePercentages": coverage_percentages,
        "gaps": gaps,
        "kbArticleCounts": kb_article_counts,
        "totalIncidents": sum(incident_counts),
        "totalKBArticles": len(kb_articles),
        "totalCoveredIncidents": sum(kb_coverage_counts),
        "totalGapIncidents": sum(gaps),
        "overallCoveragePercentage": round(sum(kb_coverage_counts) / sum(incident_counts) * 100, 1) if sum(incident_counts) > 0 else 0
    })

# ============= CHAT ROUTES =============

# =============================================================================
# Change in v 0.5 UPDATED CHAT ENDPOINT - Add to backend/app.py
# =============================================================================
# This endpoint supports conversation history for better follow-up handling

# Add this import at the top of app.py (if not already present)
# from services.agent import ChatAgent

# Replace or add this endpoint in your app.py:

@app.route('/api/chat', methods=['POST'])
def chat():
    """
    Chat endpoint that properly saves conversations and messages.
    """
    data = request.json
    
    # Validate required fields
    fabric_id = data.get('fabricId')
    message = data.get('message')
    
    if not fabric_id or not message:
        return jsonify({'error': 'fabricId and message are required'}), 400
    
    # Get optional parameters
    conversation_id = data.get('conversationId')
    conversation_history = data.get('conversationHistory', [])
    llm_id = data.get('llmId', 'gpt-4')
    temperature = data.get('temperature', 0.7)
    max_tokens = data.get('maxTokens', 2000)
    
    print(f"[Chat] fabric_id={fabric_id}, conversation_id={conversation_id}, message={message[:50]}...")
    
    # Get fabric
    fabric = db.session.get(Fabric, fabric_id)
    if not fabric:
        return jsonify({'error': 'Fabric not found'}), 404
    
    if fabric.status != 'Ready':
        return jsonify({'error': 'Fabric is not ready for chat'}), 400
    
    # Get or create conversation
    conversation = None
    if conversation_id:
        conversation = db.session.get(Conversation, conversation_id)
        print(f"[Chat] Found existing conversation: {conversation_id}")
    
    if not conversation:
        # Create new conversation
        new_id = generate_uuid()
        conversation = Conversation(
            id=new_id,
            fabric_id=fabric_id,
            llm_id=llm_id,
            temperature=temperature,
            max_tokens=max_tokens,
            title=message[:50] + ('...' if len(message) > 50 else ''),
        )
        db.session.add(conversation)
        db.session.flush()  # Ensure we get the ID
        print(f"[Chat] Created new conversation: {conversation.id}")
    
    # Save user message
    user_msg_id = generate_uuid()
    user_msg = ConversationMessage(
        id=user_msg_id,
        conversation_id=conversation.id,
        role='user',
        content=message,
    )
    db.session.add(user_msg)
    print(f"[Chat] Saved user message: {user_msg_id}")
    
    # Get collection name
    collection_name = fabric.name
    if hasattr(fabric, 'rag_config') and fabric.rag_config:
        collection_name = fabric.rag_config.get('chromaCollection', fabric.name)
    
    # Get ServiceNow instance URL
    servicenow_instance = None
    try:
        servicenow_instance = getattr(Config, 'SERVICENOW_INSTANCE_URL', None)
    except:
        pass
    
    try:
        # Initialize agent
        from services.agent import ChatAgent
        
        agent = ChatAgent(
            collection_name=collection_name,
            model_name=llm_id,
            servicenow_instance=servicenow_instance
        )
        
        # Call chat with conversation history
        result = agent.chat(
            user_input=message,
            conversation_history=conversation_history
        )
        
        # Save assistant message
        assistant_msg_id = generate_uuid()
        assistant_msg = ConversationMessage(
            id=assistant_msg_id,
            conversation_id=conversation.id,
            role='assistant',
            content=result['answer'],
            sources=result.get('sources', []),
        )
        db.session.add(assistant_msg)
        print(f"[Chat] Saved assistant message: {assistant_msg_id}")
        
        # Update conversation timestamp
        conversation.updated_at = datetime.utcnow()
        
        # Commit all changes
        db.session.commit()
        print(f"[Chat] Committed to database. Conversation: {conversation.id}")
        
        # Format response
        response = {
            'id': assistant_msg_id,
            'role': 'assistant',
            'content': result['answer'],
            'sources': result.get('sources', []),
            'conversationId': conversation.id,
            'conversationHistory': result.get('conversation_history', []),
            'createdAt': datetime.utcnow().isoformat() + 'Z'
        }
        
        return jsonify(response)
    
    except Exception as e:
        db.session.rollback()
        print(f"[Chat] Error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 50



# v 0.5 change complete.
#Changes for v o.5 to the feedback endpoint =============================================================================
# FEEDBACK ENDPOINTS - Add to backend/app.py
# =============================================================================
# These endpoints track chat feedback and link it to KB article quality

# First, add this model to your models.py:
"""
class ChatFeedback(db.Model):
    '''Track feedback on chat responses for KB quality analysis'''
    __tablename__ = 'chat_feedback'
    
    id = db.Column(db.String(36), primary_key=True, default=generate_uuid)
    fabric_id = db.Column(db.String(36), db.ForeignKey('fabrics.id'), nullable=False)
    conversation_id = db.Column(db.String(100), nullable=False)
    message_id = db.Column(db.String(100), nullable=False)
    llm_id = db.Column(db.String(50), nullable=False)
    
    # Feedback data
    rating = db.Column(db.String(10), nullable=False)  # 'up' or 'down'
    comments = db.Column(db.Text, nullable=True)
    
    # Source tracking (JSON array of source IDs)
    source_ids = db.Column(JSON, nullable=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'fabricId': self.fabric_id,
            'conversationId': self.conversation_id,
            'messageId': self.message_id,
            'llmId': self.llm_id,
            'rating': self.rating,
            'comments': self.comments,
            'sourceIds': self.source_ids or [],
            'createdAt': self.created_at.isoformat() if self.created_at else None
        }
"""

# Then add these endpoints to app.py:

from datetime import datetime
import uuid

def generate_uuid():
    return str(uuid.uuid4())


@app.route('/api/feedback', methods=['POST'])
def submit_feedback():
    """
    Submit feedback for a chat response.
    
    This tracks:
    - Overall response quality (thumbs up/down)
    - Which KB articles were cited
    - User comments for improvement
    
    Request body:
    {
        "messageId": "msg-123",
        "fabricId": "fabric-uuid",
        "llmId": "gpt-4",
        "rating": "up" | "down",
        "comments": "optional comments",
        "conversationId": "conv-123",
        "timestamp": "2024-01-06T12:00:00Z",
        "sourceIds": ["KB001", "INC002"]
    }
    """
    data = request.json
    
    # Validate required fields
    required = ['messageId', 'fabricId', 'llmId', 'rating', 'conversationId']
    for field in required:
        if not data.get(field):
            return jsonify({'error': f'{field} is required'}), 400
    
    if data['rating'] not in ['up', 'down']:
        return jsonify({'error': 'rating must be "up" or "down"'}), 400
    
    try:
        # Check if ChatFeedback model exists
        # If not, store in a simple way or create the table
        
        feedback_id = generate_uuid()
        
        # Try to use ChatFeedback model if it exists
        try:
            from models import ChatFeedback
            
            feedback = ChatFeedback(
                id=feedback_id,
                fabric_id=data['fabricId'],
                conversation_id=data['conversationId'],
                message_id=data['messageId'],
                llm_id=data['llmId'],
                rating=data['rating'],
                comments=data.get('comments'),
                source_ids=data.get('sourceIds', [])
            )
            db.session.add(feedback)
            db.session.commit()
            
        except ImportError:
            # ChatFeedback model doesn't exist yet
            # Log to console for now
            print(f"[Feedback] {data['rating']} from {data['conversationId']}")
            print(f"[Feedback] Sources: {data.get('sourceIds', [])}")
            print(f"[Feedback] Comments: {data.get('comments', 'None')}")
        
        return jsonify({
            'success': True,
            'id': feedback_id,
            'message': 'Feedback submitted successfully'
        })
        
    except Exception as e:
        print(f"Feedback error: {e}")
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@app.route('/api/fabrics/<fabric_id>/feedback-stats', methods=['GET'])
def get_feedback_stats(fabric_id):
    """
    Get feedback statistics for a fabric.
    
    Returns:
    {
        "totalFeedback": 150,
        "positiveCount": 120,
        "negativeCount": 30,
        "positiveRate": 80.0,
        "bySource": {
            "KB001": {"positive": 10, "negative": 2, "total": 12, "rating": 83.3},
            "KB002": {"positive": 5, "negative": 8, "total": 13, "rating": 38.5}
        }
    }
    """
    try:
        from models import ChatFeedback
        
        # Get all feedback for this fabric
        feedback_list = ChatFeedback.query.filter_by(fabric_id=fabric_id).all()
        
        total = len(feedback_list)
        positive = sum(1 for f in feedback_list if f.rating == 'up')
        negative = total - positive
        
        # Calculate per-source stats
        source_stats = {}
        for feedback in feedback_list:
            if feedback.source_ids:
                for source_id in feedback.source_ids:
                    if source_id not in source_stats:
                        source_stats[source_id] = {'positive': 0, 'negative': 0, 'total': 0}
                    
                    source_stats[source_id]['total'] += 1
                    if feedback.rating == 'up':
                        source_stats[source_id]['positive'] += 1
                    else:
                        source_stats[source_id]['negative'] += 1
        
        # Calculate ratings
        for source_id in source_stats:
            stats = source_stats[source_id]
            stats['rating'] = round(stats['positive'] / stats['total'] * 100, 1) if stats['total'] > 0 else 0
        
        return jsonify({
            'totalFeedback': total,
            'positiveCount': positive,
            'negativeCount': negative,
            'positiveRate': round(positive / total * 100, 1) if total > 0 else 0,
            'bySource': source_stats
        })
        
    except ImportError:
        # Model doesn't exist yet
        return jsonify({
            'totalFeedback': 0,
            'positiveCount': 0,
            'negativeCount': 0,
            'positiveRate': 0,
            'bySource': {}
        })
    except Exception as e:
        print(f"Feedback stats error: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/fabrics/<fabric_id>/kb-attention', methods=['GET'])
def get_kb_articles_needing_attention(fabric_id):
    """
    Get KB articles that have low ratings and need improvement.
    
    Returns articles with more negative than positive feedback,
    sorted by negative rating count.
    """
    try:
        from models import ChatFeedback
        
        # Get all feedback for this fabric
        feedback_list = ChatFeedback.query.filter_by(fabric_id=fabric_id).all()
        
        # Calculate per-source stats
        source_stats = {}
        for feedback in feedback_list:
            if feedback.source_ids:
                for source_id in feedback.source_ids:
                    # Only track KB articles
                    if not source_id.upper().startswith('KB'):
                        continue
                        
                    if source_id not in source_stats:
                        source_stats[source_id] = {
                            'id': source_id,
                            'positive': 0,
                            'negative': 0,
                            'total': 0,
                            'last_feedback': None
                        }
                    
                    source_stats[source_id]['total'] += 1
                    if feedback.rating == 'up':
                        source_stats[source_id]['positive'] += 1
                    else:
                        source_stats[source_id]['negative'] += 1
                    
                    # Track most recent feedback
                    if feedback.created_at:
                        if source_stats[source_id]['last_feedback'] is None or \
                           feedback.created_at > source_stats[source_id]['last_feedback']:
                            source_stats[source_id]['last_feedback'] = feedback.created_at
        
        # Filter to articles with more negative than positive
        # or rating below 50%
        attention_needed = []
        for source_id, stats in source_stats.items():
            rating = stats['positive'] / stats['total'] * 100 if stats['total'] > 0 else 0
            
            if rating < 50 or stats['negative'] >= stats['positive']:
                attention_needed.append({
                    'id': source_id,
                    'title': f"KB Article {source_id}",  # Would need to lookup actual title
                    'positiveCount': stats['positive'],
                    'negativeCount': stats['negative'],
                    'rating': round(rating, 1),
                    'lastFeedback': stats['last_feedback'].isoformat() if stats['last_feedback'] else None
                })
        
        # Sort by negative count (highest first)
        attention_needed.sort(key=lambda x: x['negativeCount'], reverse=True)
        
        return jsonify({
            'articles': attention_needed[:20]  # Top 20
        })
        
    except ImportError:
        return jsonify({'articles': []})
    except Exception as e:
        print(f"KB attention error: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/fabrics/<fabric_id>/feedback', methods=['GET'])
def get_feedback_list(fabric_id):
    """
    Get list of feedback for a fabric (for admin/analysis).
    
    Query params:
    - limit: number of results (default 50)
    - offset: pagination offset
    - rating: filter by 'up' or 'down'
    """
    try:
        from models import ChatFeedback
        
        limit = request.args.get('limit', 50, type=int)
        offset = request.args.get('offset', 0, type=int)
        rating_filter = request.args.get('rating')
        
        query = ChatFeedback.query.filter_by(fabric_id=fabric_id)
        
        if rating_filter in ['up', 'down']:
            query = query.filter_by(rating=rating_filter)
        
        total = query.count()
        feedback_list = query.order_by(ChatFeedback.created_at.desc()) \
                            .offset(offset) \
                            .limit(limit) \
                            .all()
        
        return jsonify({
            'feedback': [f.to_dict() for f in feedback_list],
            'total': total
        })
        
    except ImportError:
        return jsonify({'feedback': [], 'total': 0})
    except Exception as e:
        print(f"Feedback list error: {e}")
        return jsonify({'error': str(e)}), 500

# end of change for v 0.5

# ============= CONNECTION TEST ROUTES =============

@app.route('/api/connections/servicenow/check-credentials', methods=['GET'])
def check_servicenow_credentials():
    """Check if ServiceNow credentials are configured"""
    configured = bool(Config.SERVICENOW_USER and Config.SERVICENOW_PASS)
    return jsonify({
        "configured": configured,
        "message": "Credentials configured" if configured else "Credentials not set"
    })


@app.route('/api/connections/servicenow/test', methods=['POST'])
def test_servicenow_connection():
    """Test ServiceNow connection"""
    data = request.json
    instance_url = data.get('instanceUrl')
    return jsonify({
        "success": True,
        "message": "Connection successful"
    })


@app.route('/api/connections/sharepoint/test', methods=['POST'])
def test_sharepoint_connection():
    """Test SharePoint connection"""
    data = request.json
    site_url = data.get('siteUrl')
    return jsonify({
        "success": True,
        "message": "Connection successful"
    })


# ============= DEBUG ENDPOINT =============

@app.route('/api/fabrics/<id>/debug-graph', methods=['GET'])
def debug_graph(id):
    """Debug endpoint to see what's in the graph"""
    nodes = GraphNode.query.filter_by(fabric_id=id).all()
    edges = GraphEdge.query.filter_by(fabric_id=id).all()
    
    # Count node types
    node_types = {}
    for node in nodes:
        node_types[node.node_type] = node_types.get(node.node_type, 0) + 1
    
    # Count edge types
    edge_types = {}
    for edge in edges:
        edge_types[edge.relationship_type] = edge_types.get(edge.relationship_type, 0) + 1
    
    # Sample nodes by type
    samples = {}
    for node_type in node_types.keys():
        sample_nodes = [n for n in nodes if n.node_type == node_type][:3]
        samples[node_type] = [
            {
                'node_id': n.node_id,
                'label': n.label,
                'properties': n.properties
            } for n in sample_nodes
        ]
    
    return jsonify({
        'totalNodes': len(nodes),
        'totalEdges': len(edges),
        'nodeTypeCounts': node_types,
        'edgeTypeCounts': edge_types,
        'sampleNodesByType': samples
    })

### making these changes for v 0.4
# Initialize OpenAI client
openai_client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))


@app.route('/api/fabrics/<id>/incidents-without-kb', methods=['GET'])
def get_incidents_without_kb(id):
    """Get incidents that don't have KB article coverage, grouped by category"""
    category = request.args.get('category')  # Optional: filter by specific category
    
    # Get all nodes and edges
    nodes = GraphNode.query.filter_by(fabric_id=id).all()
    edges = GraphEdge.query.filter_by(fabric_id=id).all()
    
    # Get all documents/incidents
    all_documents = [n for n in nodes if n.node_type in ['incident', 'inc', 'document']]
    
    # Build document -> KB mapping
    docs_with_kb = set()
    for edge in edges:
        if edge.relationship_type in ['MENTIONS', 'REFERENCES']:
            source_node = next((n for n in nodes if n.id == edge.source_node_id), None)
            target_node = next((n for n in nodes if n.id == edge.target_node_id), None)
            
            if target_node and target_node.node_type in ['kb_article', 'kb', 'knowledge_base']:
                if source_node:
                    docs_with_kb.add(source_node.id)
    
    # Build document -> category mapping
    doc_categories = {}
    for edge in edges:
        if edge.relationship_type == 'BELONGS_TO':
            source_node = next((n for n in nodes if n.id == edge.source_node_id), None)
            target_node = next((n for n in nodes if n.id == edge.target_node_id), None)
            
            if source_node and target_node:
                doc_id = source_node.id
                if doc_id not in doc_categories:
                    doc_categories[doc_id] = []
                doc_categories[doc_id].append(target_node.label)
    
    # Extract category keywords from properties if no edges
    category_keywords = ['VPN', 'Email', 'Network', 'Password', 'Hardware', 
                        'Software', 'Database', 'Server', 'Firewall', 
                        'Authentication', 'Security']
    
    for doc in all_documents:
        if doc.id not in doc_categories:
            doc_text = (doc.label or '').upper()
            if doc.properties:
                doc_text += ' ' + str(doc.properties).upper()
            
            found_categories = []
            for keyword in category_keywords:
                if keyword.upper() in doc_text:
                    found_categories.append(keyword)
            
            if found_categories:
                doc_categories[doc.id] = found_categories
            else:
                doc_categories[doc.id] = ['Uncategorized']
    
    # Get incidents without KB coverage
    incidents_by_category = {}
    
    for doc in all_documents:
        # Skip if has KB coverage
        if doc.id in docs_with_kb:
            continue
        
        # Get categories
        categories = doc_categories.get(doc.id, ['Uncategorized'])
        
        # If filtering by category, skip if not in category
        if category and category not in categories:
            continue
        
        # Add to results
        for cat in categories:
            if cat not in incidents_by_category:
                incidents_by_category[cat] = []
            
            # Get content from node properties or label
            content = ''
            if doc.properties:
                content = str(doc.properties)
            if doc.label:
                content = doc.label + '\n' + content
            
            incident_data = {
                'id': doc.id,
                'incident_number': doc.node_id,
                'label': doc.label,
                'properties': doc.properties or {},
                'content': content,
                'category': cat
            }
            
            incidents_by_category[cat].append(incident_data)
    
    # Sort by category
    sorted_categories = sorted(incidents_by_category.keys())
    
    result = {
        'categories': []
    }
    
    for cat in sorted_categories:
        result['categories'].append({
            'name': cat,
            'count': len(incidents_by_category[cat]),
            'incidents': incidents_by_category[cat]
        })
    
    return jsonify(result)


@app.route('/api/fabrics/<id>/generate-kb-article', methods=['POST'])
def generate_kb_article_from_incidents(id):
    """Generate a KB article from selected incidents using AI"""
    data = request.json
    
    incident_ids = data.get('incident_ids', [])
    category = data.get('category', 'General')
    
    if not incident_ids:
        return jsonify({'error': 'No incidents selected'}), 400
    
    # Get incident details from GraphNode
    nodes = GraphNode.query.filter_by(fabric_id=id).filter(
        GraphNode.id.in_(incident_ids)
    ).all()
    
    incidents_data = []
    for node in nodes:
        # Get content from node properties or label
        content = ''
        if node.properties:
            content = str(node.properties)
        if node.label:
            content = node.label + '\n' + content
        
        incidents_data.append({
            'number': node.node_id,
            'label': node.label,
            'content': content
        })
    
    # Generate KB article using OpenAI
    try:
        kb_article = generate_kb_article_with_ai(incidents_data, category)
        return jsonify(kb_article)
    except Exception as e:
        print(f"Error generating KB article: {e}")
        return jsonify({'error': str(e)}), 500


def generate_kb_article_with_ai(incidents, category):
    """Use OpenAI to generate a KB article from incidents"""
    
    # Prepare incidents summary for prompt
    incidents_summary = "\n\n".join([
        f"INCIDENT {i+1}: {inc['number']}\n{inc['content'][:500]}"
        for i, inc in enumerate(incidents)
    ])
    
    prompt = f"""You are a technical writer creating a Knowledge Base article for IT support.

CATEGORY: {category}

INCIDENTS TO ADDRESS:
{incidents_summary}

Based on these incidents, create a comprehensive KB article that:
1. Identifies the common problem(s)
2. Lists symptoms users experience
3. Provides step-by-step troubleshooting
4. Includes detailed resolution steps
5. Mentions related issues
6. Provides support contact info

Format the KB article as follows:

TITLE: [Clear, descriptive title]

CATEGORY: {category}

## Overview
[Brief description of the issue]

## Symptoms
[List of symptoms users may experience]

## Common Causes
[What typically causes this issue]

## Resolution Steps

### Step 1: [First step]
[Detailed instructions]

### Step 2: [Second step]
[Detailed instructions]

[Continue with more steps as needed]

## Prevention
[How to prevent this issue]

## Related Issues
[List of related problems]

## Additional Support
[How to get more help]

---

Generate the KB article now:"""

    try:
        response = openai_client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are an expert technical writer creating IT support documentation."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=2000
        )
        
        content = response.choices[0].message.content
        
        # Extract title from content
        title_line = content.split('\n')[0]
        title = title_line.replace('TITLE:', '').strip()
        
        # Generate KB number
        kb_number = f"KB{random.randint(1000000, 9999999):07d}"
        
        return {
            'kb_number': kb_number,
            'title': title,
            'category': category,
            'content': content,
            'incident_count': len(incidents),
            'incident_numbers': [inc['number'] for inc in incidents]
        }
        
    except Exception as e:
        raise Exception(f"AI generation failed: {str(e)}")


@app.route('/api/fabrics/<id>/save-kb-article', methods=['POST'])
def save_kb_article(id):
    """Save generated KB article and link to incidents"""
    data = request.json
    
    kb_number = data.get('kb_number')
    title = data.get('title')
    category = data.get('category')
    content = data.get('content')
    incident_ids = data.get('incident_ids', [])
    
    if not all([kb_number, title, content]):
        return jsonify({'error': 'Missing required fields'}), 400
    
    try:
        # Create KB article document record
        kb_doc = FabricDocument(
            fabric_id=id,
            source_type='kb_article',
            source_name=kb_number,
            document_count=1,
            chunk_count=0,
            file_type='txt',
            meta_data={'title': title, 'category': category, 'content': content}
        )
        db.session.add(kb_doc)
        
        # Create KB article node
        kb_node = GraphNode(
            fabric_id=id,
            node_id=kb_number,
            node_type='kb_article',
            label=title,
            properties={'category': category, 'content': content}
        )
        db.session.add(kb_node)
        db.session.flush()  # Get the kb_node.id
        
        # Link incidents to KB article
        for incident_id in incident_ids:
            incident_node = GraphNode.query.get(incident_id)
            if incident_node:
                edge = GraphEdge(
                    fabric_id=id,
                    source_node_id=incident_id,
                    target_node_id=kb_node.id,
                    relationship_type='REFERENCES'
                )
                db.session.add(edge)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'kb_number': kb_number,
            'message': f'KB article {kb_number} created and linked to {len(incident_ids)} incidents'
        })
        
    except Exception as e:
        db.session.rollback()
        print(f"Error saving KB article: {e}")
        return jsonify({'error': str(e)}), 500

# Added these for persistent chathistory in v 0.5
# =============================================================================
# CONVERSATION ENDPOINTS - Add to backend/app.py
# =============================================================================
# These endpoints manage chat conversation history

from datetime import datetime
import uuid

def generate_uuid():
    return str(uuid.uuid4())


# =============================================================================
# CHAT CONVERSATION ENDPOINTS (Renamed to avoid conflicts)
# =============================================================================

@app.route('/api/conversations', methods=['GET'])
def list_chat_conversations():
    """List all conversations with accurate message counts."""
    fabric_id = request.args.get('fabricId')
    limit = request.args.get('limit', 50, type=int)
    offset = request.args.get('offset', 0, type=int)
    
    try:
        query = Conversation.query
        
        if fabric_id:
            query = query.filter_by(fabric_id=fabric_id)
        
        query = query.order_by(Conversation.updated_at.desc())
        
        total = query.count()
        conversations = query.offset(offset).limit(limit).all()
        
        # Build response with accurate message counts
        result = []
        for conv in conversations:
            msg_count = ConversationMessage.query.filter_by(
                conversation_id=conv.id
            ).count()
            
            result.append({
                'id': conv.id,
                'fabricId': conv.fabric_id,
                'title': conv.title or 'New Conversation',
                'llmId': conv.llm_id,
                'temperature': conv.temperature,
                'maxTokens': conv.max_tokens,
                'createdAt': conv.created_at.isoformat() if conv.created_at else None,
                'updatedAt': conv.updated_at.isoformat() if conv.updated_at else None,
                'messageCount': msg_count,
            })
        
        print(f"[ListConversations] Found {len(result)} conversations for fabric {fabric_id}")
        
        return jsonify({
            'conversations': result,
            'total': total
        })
        
    except Exception as e:
        print(f"[ListConversations] Error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/conversations/<conversation_id>', methods=['GET'])
def get_chat_conversation(conversation_id):
    """Get a single conversation with all its messages."""
    try:
        conversation = db.session.get(Conversation, conversation_id)
        
        if not conversation:
            return jsonify({'error': 'Conversation not found'}), 404
        
        # Get messages explicitly
        messages = ConversationMessage.query.filter_by(
            conversation_id=conversation_id
        ).order_by(ConversationMessage.created_at.asc()).all()
        
        print(f"[GetConversation] Found {len(messages)} messages for conversation {conversation_id}")
        
        result = {
            'id': conversation.id,
            'fabricId': conversation.fabric_id,
            'title': conversation.title or 'New Conversation',
            'llmId': conversation.llm_id,
            'temperature': conversation.temperature,
            'maxTokens': conversation.max_tokens,
            'createdAt': conversation.created_at.isoformat() if conversation.created_at else None,
            'updatedAt': conversation.updated_at.isoformat() if conversation.updated_at else None,
            'messageCount': len(messages),
            'messages': [
                {
                    'id': msg.id,
                    'conversationId': msg.conversation_id,
                    'role': msg.role,
                    'content': msg.content,
                    'sources': msg.sources or [],
                    'createdAt': msg.created_at.isoformat() if msg.created_at else None,
                }
                for msg in messages
            ]
        }
        
        return jsonify(result)
        
    except Exception as e:
        print(f"[GetConversation] Error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500


@app.route('/api/conversations', methods=['POST'])
def create_chat_conversation():
    """Create a new conversation."""
    data = request.json
    
    fabric_id = data.get('fabricId')
    if not fabric_id:
        return jsonify({'error': 'fabricId is required'}), 400
    
    try:
        conversation = Conversation(
            id=generate_uuid(),
            fabric_id=fabric_id,
            llm_id=data.get('llmId', 'gpt-4'),
            temperature=data.get('temperature', 0.7),
            max_tokens=data.get('maxTokens', 2000),
            title=data.get('title'),
        )
        
        db.session.add(conversation)
        db.session.commit()
        
        return jsonify(conversation.to_dict()), 201
        
    except Exception as e:
        db.session.rollback()
        print(f"Create conversation error: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/conversations/<conversation_id>', methods=['PATCH'])
def update_chat_conversation(conversation_id):
    """Update conversation metadata (e.g., title)."""
    data = request.json
    
    try:
        conversation = Conversation.query.get(conversation_id)
        
        if not conversation:
            return jsonify({'error': 'Conversation not found'}), 404
        
        if 'title' in data:
            conversation.title = data['title']
        if 'llmId' in data:
            conversation.llm_id = data['llmId']
        if 'temperature' in data:
            conversation.temperature = data['temperature']
        if 'maxTokens' in data:
            conversation.max_tokens = data['maxTokens']
        
        conversation.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify(conversation.to_dict())
        
    except Exception as e:
        db.session.rollback()
        print(f"Update conversation error: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/conversations/<conversation_id>', methods=['DELETE'])
def delete_chat_conversation(conversation_id):
    """Delete a conversation and all its messages."""
    try:
        conversation = Conversation.query.get(conversation_id)
        
        if not conversation:
            return jsonify({'error': 'Conversation not found'}), 404
        
        db.session.delete(conversation)
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Conversation deleted'})
        
    except Exception as e:
        db.session.rollback()
        print(f"Delete conversation error: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/conversations/<conversation_id>/messages', methods=['POST'])
def add_message_to_chat_conversation(conversation_id):
    """Add a message to a conversation."""
    data = request.json
    
    role = data.get('role')
    content = data.get('content')
    
    if not role or not content:
        return jsonify({'error': 'role and content are required'}), 400
    
    if role not in ['user', 'assistant']:
        return jsonify({'error': 'role must be "user" or "assistant"'}), 400
    
    try:
        conversation = Conversation.query.get(conversation_id)
        
        if not conversation:
            return jsonify({'error': 'Conversation not found'}), 404
        
        message = ConversationMessage(
            id=generate_uuid(),
            conversation_id=conversation_id,
            role=role,
            content=content,
            sources=data.get('sources'),
        )
        
        db.session.add(message)
        
        # Auto-title from first user message
        if not conversation.title and role == 'user':
            conversation.title = content[:50] + ('...' if len(content) > 50 else '')
        
        conversation.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify(message.to_dict()), 201
        
    except Exception as e:
        db.session.rollback()
        print(f"Add message error: {e}")
        return jsonify({'error': str(e)}), 500
 
# added this for v o.51    
# =============================================================================
# DOCUMENT UPLOAD WITH CSV AUTO-DETECTION
# =============================================================================

from werkzeug.utils import secure_filename
from services.csv_ingestion import CSVIngestionService

ALLOWED_EXTENSIONS = {'pdf', 'docx', 'txt', 'csv'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def detect_csv_type(filename, file_path=None):
    """Detect CSV type from filename."""
    filename_lower = filename.lower()
    
    if 'kb' in filename_lower or 'knowledge' in filename_lower or 'article' in filename_lower:
        return 'kb'
    if 'incident' in filename_lower or 'inc' in filename_lower:
        return 'incident'
    if 'ci_categor' in filename_lower or 'category' in filename_lower:
        return 'ci'
    if 'sub_categor' in filename_lower:
        return 'sub_category'
    
    # Check headers if filename doesn't help
    if file_path and os.path.exists(file_path):
        try:
            import pandas as pd
            df = pd.read_csv(file_path, nrows=1)
            columns = [col.lower() for col in df.columns]
            
            if 'article_id' in columns or 'knowledge_article' in columns:
                return 'kb'
            if 'number' in columns and 'resolution_notes' in columns:
                return 'incident'
            if 'ci_name' in columns:
                return 'ci'
        except:
            pass
    
    return 'unknown'


# =============================================================================
# Made this change in 0.51 for CSV ingest
# =============================================================================
# Find and DELETE your existing upload_documents function, then paste this

ALLOWED_EXTENSIONS = {'pdf', 'docx', 'txt', 'csv'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def detect_csv_type(filename, file_path=None):
    """Detect CSV type from filename or headers."""
    filename_lower = filename.lower()
    
    # Check filename for keywords
    if 'kb' in filename_lower or 'knowledge' in filename_lower or 'article' in filename_lower:
        return 'kb'
    if 'incident' in filename_lower or 'inc' in filename_lower:
        return 'incident'
    if 'ci_categor' in filename_lower or 'category' in filename_lower:
        return 'ci'
    if 'sub_categor' in filename_lower:
        return 'sub_category'
    
    # Check CSV headers if filename doesn't help
    if file_path and os.path.exists(file_path):
        try:
            import pandas as pd
            df = pd.read_csv(file_path, nrows=1)
            columns = [col.lower() for col in df.columns]
            
            if 'article_id' in columns or 'knowledge_article' in columns:
                return 'kb'
            if 'number' in columns and 'resolution_notes' in columns:
                return 'incident'
            if 'ci_name' in columns:
                return 'ci'
        except Exception as e:
            print(f"Error detecting CSV type: {e}")
    
    return 'unknown'


@app.route('/api/fabrics/<fabric_id>/upload', methods=['POST'])
def upload_documents(fabric_id):
    """Upload documents - auto-detects and ingests CSV files."""
    print(f"=== UPLOAD START ===")
    print(f"Fabric ID: {fabric_id}")
    
    # Check fabric exists
    fabric = db.session.get(Fabric, fabric_id)
    if not fabric:
        print(f"ERROR: Fabric not found: {fabric_id}")
        return jsonify({'success': False, 'error': 'Fabric not found'}), 404
    
    # Check for files
    if 'files' not in request.files:
        print("ERROR: No files in request")
        return jsonify({'success': False, 'error': 'No files provided'}), 400
    
    files = request.files.getlist('files')
    print(f"Files received: {[f.filename for f in files]}")
    
    if not files or all(f.filename == '' for f in files):
        print("ERROR: No files selected")
        return jsonify({'success': False, 'error': 'No files selected'}), 400
    
    # Create upload folder
    upload_folder = app.config.get('UPLOAD_FOLDER', Config.UPLOAD_FOLDER)
    fabric_folder = os.path.join(upload_folder, fabric_id)
    os.makedirs(fabric_folder, exist_ok=True)
    print(f"Upload folder: {fabric_folder}")
    
    results = []
    csv_service = CSVIngestionService(fabric_id)
    
    # Process each file
    for file in files:
        if not file or file.filename == '':
            continue
        
        filename = secure_filename(file.filename)
        print(f"\nProcessing file: {filename}")
        
        if not allowed_file(filename):
            print(f"  REJECTED: File type not allowed")
            results.append({
                'filename': filename,
                'status': 'rejected',
                'error': 'File type not allowed. Allowed: pdf, docx, txt, csv'
            })
            continue
        
        # Save file
        file_path = os.path.join(fabric_folder, filename)
        file.save(file_path)
        print(f"  Saved to: {file_path}")
        
        # Get extension
        extension = filename.rsplit('.', 1)[1].lower() if '.' in filename else ''
        print(f"  Extension: {extension}")
        
        # Handle CSV files
        if extension == 'csv':
            csv_type = detect_csv_type(filename, file_path)
            print(f"  CSV Type detected: {csv_type}")
            
            try:
                if csv_type == 'kb':
                    print(f"  Ingesting KB articles...")
                    result = csv_service.ingest_kb_articles(file_path, use_csv_category=True)
                    print(f"  KB Result: {result.get('stats', {})}")
                    results.append({
                        'filename': filename,
                        'type': 'kb_articles',
                        'status': 'ingested' if result.get('success') else 'failed',
                        'stats': result.get('stats'),
                        'errors': result.get('errors', [])
                    })
                    
                elif csv_type == 'incident':
                    print(f"  Ingesting incidents...")
                    result = csv_service.ingest_incidents(file_path, use_csv_category=True)
                    print(f"  Incident Result: {result.get('stats', {})}")
                    results.append({
                        'filename': filename,
                        'type': 'incidents',
                        'status': 'ingested' if result.get('success') else 'failed',
                        'stats': result.get('stats'),
                        'errors': result.get('errors', [])
                    })
                    
                elif csv_type == 'ci':
                    print(f"  Ingesting CI categories...")
                    result = csv_service.ingest_ci_categories(file_path)
                    print(f"  CI Result: {result.get('stats', {})}")
                    results.append({
                        'filename': filename,
                        'type': 'ci_categories',
                        'status': 'ingested' if result.get('success') else 'failed',
                        'stats': result.get('stats')
                    })
                    
                elif csv_type == 'sub_category':
                    print(f"  Sub-categories uploaded (reference only)")
                    results.append({
                        'filename': filename,
                        'type': 'sub_categories',
                        'status': 'uploaded',
                        'message': 'Sub-categories uploaded for reference'
                    })
                    
                else:
                    print(f"  WARNING: Unknown CSV type")
                    results.append({
                        'filename': filename,
                        'type': 'unknown_csv',
                        'status': 'uploaded',
                        'warning': 'Could not detect CSV type. Rename with kb_, incident_, or ci_ prefix.'
                    })
                    
            except Exception as e:
                print(f"  ERROR during ingestion: {str(e)}")
                import traceback
                traceback.print_exc()
                results.append({
                    'filename': filename,
                    'status': 'failed',
                    'error': str(e)
                })
        
        # Handle regular documents (PDF, DOCX, TXT)
        else:
            print(f"  Document uploaded (will process during build)")
            results.append({
                'filename': filename,
                'type': 'document',
                'status': 'uploaded'
            })
    
    # Summary
    total = len(results)
    succeeded = len([r for r in results if r['status'] in ['uploaded', 'ingested']])
    failed = len([r for r in results if r['status'] == 'failed'])
    
    print(f"\n=== UPLOAD COMPLETE ===")
    print(f"Total: {total}, Succeeded: {succeeded}, Failed: {failed}")
    print(f"Results: {results}")
    
    return jsonify({
        'success': failed == 0,
        'summary': {
            'total': total,
            'succeeded': succeeded,
            'failed': failed
        },
        'results': results
    })
# =============================================================================
# GRAPH LIBRARY API ENDPOINTS -- added this for v 0.51
# =============================================================================#
# Provides graph data for Category → KB → Incident visualizations

from flask import jsonify, request
from sqlalchemy import func
from models import db, IngestedContent, CICategory, GraphNode, GraphEdge


@app.route('/api/fabrics/<fabric_id>/graph-library-data', methods=['GET'])
def get_graph_library_data(fabric_id):
    """
    Get structured data for graph library visualizations.
    
    Returns:
    {
        "categories": [...],
        "kbArticles": [...],
        "incidents": [...],
        "edges": [...]
    }
    """
    try:
        # Get all categories with counts
        category_stats = db.session.query(
            IngestedContent.category_ci,
            IngestedContent.source_type,
            func.count(IngestedContent.id).label('count')
        ).filter(
            IngestedContent.fabric_id == fabric_id,
            IngestedContent.category_ci.isnot(None),
            IngestedContent.category_ci != '',
            IngestedContent.category_ci != 'Uncategorized'
        ).group_by(
            IngestedContent.category_ci,
            IngestedContent.source_type
        ).all()
        
        # Build category data
        category_map = {}
        for cat_ci, source_type, count in category_stats:
            if cat_ci not in category_map:
                category_map[cat_ci] = {
                    'id': cat_ci.replace(' ', '_').replace('-', '_'),
                    'name': cat_ci,
                    'kbCount': 0,
                    'incidentCount': 0
                }
            if source_type == 'kb':
                category_map[cat_ci]['kbCount'] = count
            elif source_type == 'incident':
                category_map[cat_ci]['incidentCount'] = count
        
        categories = list(category_map.values())
        
        # Sort by total count (most active first)
        categories.sort(key=lambda x: x['kbCount'] + x['incidentCount'], reverse=True)
        
        # Limit to top 20 categories for visualization
        categories = categories[:20]
        category_names = [c['name'] for c in categories]
        
        # Get KB articles
        kb_articles_raw = IngestedContent.query.filter(
            IngestedContent.fabric_id == fabric_id,
            IngestedContent.source_type == 'kb',
            IngestedContent.category_ci.in_(category_names)
        ).limit(100).all()
        
        kb_articles = [{
            'id': kb.source_id,
            'title': kb.title[:50] if kb.title else kb.source_id,
            'fullTitle': kb.title,
            'category': kb.category_ci,
            'categoryId': kb.category_ci.replace(' ', '_').replace('-', '_') if kb.category_ci else None
        } for kb in kb_articles_raw]
        
        # Get incidents
        incidents_raw = IngestedContent.query.filter(
            IngestedContent.fabric_id == fabric_id,
            IngestedContent.source_type == 'incident',
            IngestedContent.category_ci.in_(category_names)
        ).limit(200).all()
        
        # Try to match incidents to KBs based on same category + keyword similarity
        kb_by_category = {}
        for kb in kb_articles:
            cat = kb['category']
            if cat not in kb_by_category:
                kb_by_category[cat] = []
            kb_by_category[cat].append(kb)
        
        incidents = []
        for inc in incidents_raw:
            # Find potential KB match
            linked_kb = None
            if inc.category_ci in kb_by_category:
                # Simple matching: pick first KB in same category
                # Could be enhanced with keyword matching
                kbs_in_cat = kb_by_category[inc.category_ci]
                if kbs_in_cat:
                    # Check for keyword overlap
                    inc_words = set((inc.title or '').lower().split())
                    best_match = None
                    best_score = 0
                    for kb in kbs_in_cat:
                        kb_words = set((kb['fullTitle'] or '').lower().split())
                        overlap = len(inc_words & kb_words)
                        if overlap > best_score:
                            best_score = overlap
                            best_match = kb['id']
                    if best_score >= 2:  # At least 2 words in common
                        linked_kb = best_match
            
            incidents.append({
                'id': inc.source_id,
                'title': inc.short_description[:40] if inc.short_description else inc.source_id,
                'fullTitle': inc.title,
                'category': inc.category_ci,
                'categoryId': inc.category_ci.replace(' ', '_').replace('-', '_') if inc.category_ci else None,
                'linkedKb': linked_kb
            })
        
        # Build edges for visualization
        edges = []
        
        # Category -> KB edges
        for kb in kb_articles:
            if kb['categoryId']:
                edges.append({
                    'source': kb['categoryId'],
                    'target': kb['id'],
                    'type': 'category-kb'
                })
        
        # Category -> Incident edges
        for inc in incidents:
            if inc['categoryId']:
                edges.append({
                    'source': inc['categoryId'],
                    'target': inc['id'],
                    'type': 'category-incident'
                })
        
        # KB -> Incident edges (when linked)
        for inc in incidents:
            if inc['linkedKb']:
                edges.append({
                    'source': inc['linkedKb'],
                    'target': inc['id'],
                    'type': 'kb-incident'
                })
        
        # Summary stats
        total_kb = IngestedContent.query.filter_by(fabric_id=fabric_id, source_type='kb').count()
        total_inc = IngestedContent.query.filter_by(fabric_id=fabric_id, source_type='incident').count()
        linked_incidents = len([i for i in incidents if i['linkedKb']])
        
        return jsonify({
            'success': True,
            'categories': categories,
            'kbArticles': kb_articles,
            'incidents': incidents,
            'edges': edges,
            'stats': {
                'totalCategories': len(categories),
                'totalKbArticles': total_kb,
                'totalIncidents': total_inc,
                'displayedKb': len(kb_articles),
                'displayedIncidents': len(incidents),
                'linkedIncidents': linked_incidents,
                'linkageRate': round(linked_incidents / len(incidents) * 100, 1) if incidents else 0
            }
        })
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# =============================================================================
# SERVICENOW BULK IMPORT ROUTES - made this changes for v 0.6
# =============================================================================
# Add these routes to your app.py
#
# Required: Copy servicenow_client.py to backend/services/

from flask import jsonify, request
from datetime import datetime
import uuid

# Store active connections temporarily
servicenow_connections = {}


@app.route('/api/servicenow/connect', methods=['POST'])
def servicenow_connect():
    """
    Test connection to ServiceNow instance.
    
    Body: { "instance_url": "https://company.service-now.com", "username": "admin", "password": "pass" }
    """
    data = request.json
    instance_url = data.get('instance_url', '').strip()
    username = data.get('username', '').strip()
    password = data.get('password', '')
    
    if not all([instance_url, username, password]):
        return jsonify({'success': False, 'error': 'Missing required fields'}), 400
    
    if not instance_url.startswith('http'):
        instance_url = f'https://{instance_url}'
    
    try:
        from services.servicenow_client import ServiceNowClient
        client = ServiceNowClient(instance_url, username, password)
        result = client.test_connection()
        
        if result['success']:
            connection_id = str(uuid.uuid4())
            servicenow_connections[connection_id] = {
                'client': client,
                'instance_url': instance_url,
                'connected_at': datetime.utcnow().isoformat()
            }
            
            # Get counts for preview
            kb_count = client.get_kb_count()
            incident_count = client.get_incident_count()
            
            return jsonify({
                'success': True,
                'connection_id': connection_id,
                'instance_url': instance_url,
                'available': {
                    'kb_articles': kb_count,
                    'incidents': incident_count
                }
            })
        else:
            return jsonify({'success': False, 'error': result.get('message', 'Connection failed')}), 401
            
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/servicenow/import', methods=['POST'])
def servicenow_bulk_import():
    """
    Bulk import KB articles and/or incidents from ServiceNow.
    
    Body:
    {
        "connection_id": "uuid",
        "fabric_name": "My Fabric",
        "fabric_description": "Description",
        "import_kb": true,
        "import_incidents": true,
        "kb_limit": 100,
        "incident_limit": 500,
        "incident_state": "resolved_or_closed",
        "date_from": "2024-01-01"  // Optional
    }
    """
    data = request.json
    connection_id = data.get('connection_id')
    
    # Validate connection
    if not connection_id or connection_id not in servicenow_connections:
        return jsonify({'success': False, 'error': 'Not connected to ServiceNow'}), 401
    
    client = servicenow_connections[connection_id]['client']
    instance_url = servicenow_connections[connection_id]['instance_url']
    
    # Get config
    fabric_name = data.get('fabric_name', 'ServiceNow Import')
    fabric_description = data.get('fabric_description', f'Imported from {instance_url}')
    import_kb = data.get('import_kb', True)
    import_incidents = data.get('import_incidents', True)
    kb_limit = min(data.get('kb_limit', 10), 500)  # Max 500
    incident_limit = min(data.get('incident_limit', 50), 2000)  # Max 2000
    incident_state = data.get('incident_state', 'resolved_or_closed')
    date_from = data.get('date_from', '')
    
    stats = {
        'kb_articles': {'fetched': 0, 'imported': 0, 'failed': 0},
        'incidents': {'fetched': 0, 'imported': 0, 'failed': 0},
        'chunks_created': 0,
        'errors': []
    }
    
    try:
        # Create fabric
        print(f"[ServiceNow] Creating fabric: {fabric_name}")
        new_fabric = Fabric(
            name=fabric_name,
            description=fabric_description,
            domain='IT Service Operations',
            sources_config={
                'servicenow': {
                    'instance_url': instance_url,
                    'imported_at': datetime.utcnow().isoformat()
                }
            },
            rag_config={
                'chunkSize': 1000,
                'chunkOverlap': 200,
                'embeddingModel': 'text-embedding-3-large',
                'chromaCollection': fabric_name.lower().replace(' ', '_').replace('-', '_')
            },
            status='building'
        )
        db.session.add(new_fabric)
        db.session.commit()
        
        fabric_id = new_fabric.id
        print(f"[ServiceNow] Created fabric: {fabric_id}")
        
        # Initialize ingestion service
        from services.csv_ingestion import CSVIngestionService
        ingestion_service = CSVIngestionService(fabric_id)
        ingestion_service._load_fabric()
        ingestion_service._load_ci_list()
        ingestion_service._init_vectorization()
        
        # Import KB Articles
        if import_kb:
            print(f"[ServiceNow] Fetching KB articles (limit: {kb_limit})...")
            kb_result = client.fetch_all_kb_articles(limit=kb_limit)
            articles = kb_result.get('articles', [])
            stats['kb_articles']['fetched'] = len(articles)
            
            for article in articles:
                try:
                    # Check if already exists
                    existing = IngestedContent.query.filter_by(
                        fabric_id=fabric_id,
                        source_type='kb',
                        source_id=article['number']
                    ).first()
                    
                    if existing:
                        print(f"    KB: {article['number']} (skipped - already exists)")
                        stats['kb_articles']['imported'] += 1
                        continue
                    
                    # Parse created_on date if available
                    source_created = None
                    if article.get('created_on'):
                        try:
                            source_created = datetime.strptime(article['created_on'], '%Y-%m-%d %H:%M:%S')
                        except:
                            pass
                    
                    # Create IngestedContent
                    content_record = IngestedContent(
                        fabric_id=fabric_id,
                        source_type='kb',
                        source_id=article['number'],
                        title=article.get('title', '')[:500] if article.get('title') else '',
                        short_description=article.get('title', '')[:500] if article.get('title') else '',
                        content=article.get('content', ''),
                        category_ci=article.get('category', 'Uncategorized')[:200] if article.get('category') else 'Uncategorized',
                        category_confidence=1.0,
                        category_reasoning='From ServiceNow',
                        needs_review=False,
                        access_role='Support',
                        access_level=2,
                        original_metadata=article,
                        source_created_date=source_created
                    )
                    db.session.add(content_record)
                    db.session.commit()  # Commit after each record
                    
                    # Vectorize
                    chunks = ingestion_service._vectorize_content(
                        content_id=article['number'],
                        content_type='kb',
                        title=article.get('title', ''),
                        content=article.get('content', ''),
                        category=article.get('category', 'Uncategorized'),
                        access_level=2
                    )
                    stats['chunks_created'] += chunks
                    stats['kb_articles']['imported'] += 1
                    print(f"    KB: {article['number']} ({chunks} chunks)")
                    
                except Exception as e:
                    db.session.rollback()  # Rollback on error
                    stats['kb_articles']['failed'] += 1
                    stats['errors'].append(f"KB {article.get('number', '?')}: {str(e)}")
                    print(f"    KB: {article.get('number', '?')} FAILED: {str(e)}")
        
        # Import Incidents
        if import_incidents:
            print(f"[ServiceNow] Fetching incidents (limit: {incident_limit}, state: {incident_state})...")
            inc_result = client.fetch_all_incidents(
                limit=incident_limit,
                state=incident_state,
                date_from=date_from
            )
            incidents = inc_result.get('incidents', [])
            stats['incidents']['fetched'] = len(incidents)
            
            for incident in incidents:
                try:
                    # Check if already exists
                    existing = IngestedContent.query.filter_by(
                        fabric_id=fabric_id,
                        source_type='incident',
                        source_id=incident['number']
                    ).first()
                    
                    if existing:
                        print(f"    INC: {incident['number']} (skipped - already exists)")
                        stats['incidents']['imported'] += 1
                        continue
                    
                    # Combine content
                    content_parts = []
                    if incident.get('description'):
                        content_parts.append(f"Description: {incident['description']}")
                    if incident.get('resolution_notes'):
                        content_parts.append(f"Resolution: {incident['resolution_notes']}")
                    if incident.get('close_notes'):
                        content_parts.append(f"Close Notes: {incident['close_notes']}")
                    if incident.get('work_notes'):
                        content_parts.append(f"Work Notes: {incident['work_notes']}")
                    content = '\n\n'.join(content_parts)
                    
                    # Truncate fields to fit database columns
                    title = f"{incident['number']}: {incident.get('short_description', '')}"[:500]
                    short_desc = (incident.get('short_description', '') or '')[:500]
                    category = (incident.get('category', 'Uncategorized') or 'Uncategorized')[:200]
                    
                    # Parse created_on date if available
                    source_created = None
                    if incident.get('created_on'):
                        try:
                            source_created = datetime.strptime(incident['created_on'], '%Y-%m-%d %H:%M:%S')
                        except:
                            pass
                    
                    # Create IngestedContent
                    content_record = IngestedContent(
                        fabric_id=fabric_id,
                        source_type='incident',
                        source_id=incident['number'],
                        title=title,
                        short_description=short_desc,
                        content=content,
                        category_ci=category,
                        category_confidence=1.0,
                        category_reasoning='From ServiceNow',
                        needs_review=False,
                        access_role='Support',
                        access_level=2,
                        original_metadata=incident,
                        source_created_date=source_created
                    )
                    db.session.add(content_record)
                    db.session.commit()  # Commit after each record
                    
                    # Vectorize
                    chunks = ingestion_service._vectorize_content(
                        content_id=incident['number'],
                        content_type='incident',
                        title=title,
                        content=content,
                        category=category,
                        access_level=2
                    )
                    stats['chunks_created'] += chunks
                    stats['incidents']['imported'] += 1
                    print(f"    INC: {incident['number']} ({chunks} chunks)")
                    
                except Exception as e:
                    stats['incidents']['failed'] += 1
                    stats['errors'].append(f"INC {incident.get('number', '?')}: {str(e)}")
        
        # Commit and update fabric
        db.session.commit()
        ingestion_service._update_fabric_stats(stats['chunks_created'])
        
        new_fabric.status = 'ready'
        db.session.commit()
        
        print(f"[ServiceNow] Import complete: {stats['kb_articles']['imported']} KB, {stats['incidents']['imported']} incidents, {stats['chunks_created']} chunks")
        
        return jsonify({
            'success': True,
            'fabric_id': new_fabric.id,
            'fabric': new_fabric.to_dict(),
            'stats': stats
        })
        
    except Exception as e:
        db.session.rollback()
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e), 'stats': stats}), 500


@app.route('/api/servicenow/disconnect', methods=['POST'])
def servicenow_disconnect():
    """Disconnect from ServiceNow."""
    data = request.json
    connection_id = data.get('connection_id')
    if connection_id and connection_id in servicenow_connections:
        del servicenow_connections[connection_id]
    return jsonify({'success': True})


if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True, port=4000)
