"""
KB Coverage API Endpoint - Updated with Semantic Coverage
==========================================================
Replace or add this endpoint to your app.py

This endpoint calculates coverage based on semantic similarity between:
- Incident resolution steps (from resolution_notes + work_notes)
- KB article content (from article_body)
"""

# =============================================================================
# ADD THESE IMPORTS TO app.py (if not already present)
# =============================================================================
"""
from services.coverage_calculator import (
    CoverageCalculator,
    calculate_coverage_for_fabric,
    calculate_single_incident_coverage
)
"""

# =============================================================================
# UPDATED KB COVERAGE ENDPOINT
# =============================================================================

@app.route('/api/fabrics/<id>/kb-coverage-matrix', methods=['GET'])
def get_kb_coverage_matrix(id):
    """
    Get KB article coverage matrix using semantic similarity.
    
    Coverage is calculated by comparing:
    - Incident resolution steps (resolution_notes + work_notes)
    - KB article content (article_body)
    
    Returns coverage percentages showing how well KB articles
    cover the actual resolution steps used to solve incidents.
    """
    fabric = Fabric.query.get_or_404(id)
    
    # Get all ingested content for this fabric
    incidents = IngestedContent.query.filter_by(
        fabric_id=id,
        source_type='incident'
    ).all()
    
    kb_articles = IngestedContent.query.filter_by(
        fabric_id=id,
        source_type='kb'
    ).all()
    
    print(f"DEBUG: Found {len(incidents)} incidents, {len(kb_articles)} KB articles")
    
    # If no data, return empty response
    if not incidents:
        return jsonify({
            "categories": [],
            "incidentCounts": [],
            "kbCoverageCounts": [],
            "coveragePercentages": [],
            "gaps": [],
            "kbArticleCounts": [],
            "totalIncidents": 0,
            "totalKBArticles": len(kb_articles),
            "totalCoveredIncidents": 0,
            "totalGapIncidents": 0,
            "overallCoveragePercentage": 0,
            "debug": {
                "message": "No incidents found",
                "incidentsCount": 0,
                "kbCount": len(kb_articles)
            }
        })
    
    # Convert to dicts for coverage calculator
    incident_dicts = []
    for inc in incidents:
        metadata = inc.original_metadata or {}
        incident_dicts.append({
            "number": inc.source_id,
            "category": inc.category_ci or "Uncategorized",
            "sub_category": metadata.get("sub_category", ""),
            "resolution_notes": metadata.get("resolution_notes", inc.content or ""),
            "work_notes": metadata.get("work_notes", ""),
        })
    
    kb_dicts = []
    for kb in kb_articles:
        metadata = kb.original_metadata or {}
        kb_dicts.append({
            "article_id": kb.source_id,
            "category": kb.category_ci or "Uncategorized",
            "sub_category": metadata.get("sub_category", ""),
            "article_body": kb.content or metadata.get("article_body", ""),
        })
    
    # Calculate coverage using semantic similarity
    try:
        from services.coverage_calculator import calculate_coverage_for_fabric
        
        coverage_matrix = calculate_coverage_for_fabric(
            incidents=incident_dicts,
            kb_articles=kb_dicts,
            threshold=0.65  # Configurable threshold
        )
        
        return jsonify(coverage_matrix)
        
    except ImportError as e:
        # Fallback to simple category-based coverage if sentence-transformers not installed
        print(f"WARNING: sentence-transformers not available, using fallback: {e}")
        return get_kb_coverage_matrix_fallback(id, incident_dicts, kb_dicts)
    except Exception as e:
        print(f"ERROR calculating coverage: {e}")
        return jsonify({
            "error": str(e),
            "categories": [],
            "incidentCounts": [],
            "kbCoverageCounts": [],
            "coveragePercentages": [],
            "gaps": [],
            "kbArticleCounts": [],
            "totalIncidents": len(incidents),
            "totalKBArticles": len(kb_articles),
            "totalCoveredIncidents": 0,
            "totalGapIncidents": len(incidents),
            "overallCoveragePercentage": 0,
        }), 500


def get_kb_coverage_matrix_fallback(fabric_id, incidents, kb_articles):
    """
    Fallback coverage calculation when sentence-transformers not available.
    Uses simple category matching instead of semantic similarity.
    """
    # Group by category
    inc_by_cat = {}
    for inc in incidents:
        cat = inc.get("category", "Uncategorized")
        if cat not in inc_by_cat:
            inc_by_cat[cat] = []
        inc_by_cat[cat].append(inc)
    
    kb_by_cat = {}
    for kb in kb_articles:
        cat = kb.get("category", "Uncategorized")
        if cat not in kb_by_cat:
            kb_by_cat[cat] = []
        kb_by_cat[cat].append(kb)
    
    # Calculate coverage per category
    categories = []
    incident_counts = []
    kb_coverage_counts = []
    coverage_percentages = []
    gaps = []
    kb_article_counts = []
    
    all_categories = set(inc_by_cat.keys()) | set(kb_by_cat.keys())
    
    for cat in sorted(all_categories):
        inc_count = len(inc_by_cat.get(cat, []))
        kb_count = len(kb_by_cat.get(cat, []))
        
        # Simple coverage: if category has KB articles, incidents are "covered"
        if kb_count > 0:
            covered = inc_count
            gap = 0
            coverage_pct = 100.0
        else:
            covered = 0
            gap = inc_count
            coverage_pct = 0.0
        
        categories.append(cat)
        incident_counts.append(inc_count)
        kb_coverage_counts.append(covered)
        coverage_percentages.append(coverage_pct)
        gaps.append(gap)
        kb_article_counts.append(kb_count)
    
    total_incidents = sum(incident_counts)
    total_covered = sum(kb_coverage_counts)
    total_gap = sum(gaps)
    overall_pct = (total_covered / total_incidents * 100) if total_incidents > 0 else 0
    
    return jsonify({
        "categories": categories,
        "incidentCounts": incident_counts,
        "kbCoverageCounts": kb_coverage_counts,
        "coveragePercentages": coverage_percentages,
        "gaps": gaps,
        "kbArticleCounts": kb_article_counts,
        "totalIncidents": total_incidents,
        "totalKBArticles": len(kb_articles),
        "totalCoveredIncidents": total_covered,
        "totalGapIncidents": total_gap,
        "overallCoveragePercentage": round(overall_pct, 1),
        "warning": "Using fallback category-based coverage. Install sentence-transformers for semantic coverage."
    })


# =============================================================================
# NEW ENDPOINT: Single Incident Coverage Details
# =============================================================================

@app.route('/api/fabrics/<fabric_id>/incidents/<incident_id>/coverage', methods=['GET'])
def get_incident_coverage_details(fabric_id, incident_id):
    """
    Get detailed coverage analysis for a single incident.
    
    Shows which resolution steps are covered by which KB articles.
    """
    # Get the incident
    incident = IngestedContent.query.filter_by(
        fabric_id=fabric_id,
        source_type='incident',
        source_id=incident_id
    ).first()
    
    if not incident:
        return jsonify({"error": "Incident not found"}), 404
    
    # Get KB articles in same category
    kb_articles = IngestedContent.query.filter_by(
        fabric_id=fabric_id,
        source_type='kb',
        category_ci=incident.category_ci
    ).all()
    
    # Convert to dicts
    metadata = incident.original_metadata or {}
    incident_dict = {
        "number": incident.source_id,
        "category": incident.category_ci or "Uncategorized",
        "sub_category": metadata.get("sub_category", ""),
        "resolution_notes": metadata.get("resolution_notes", incident.content or ""),
        "work_notes": metadata.get("work_notes", ""),
    }
    
    kb_dicts = []
    for kb in kb_articles:
        kb_metadata = kb.original_metadata or {}
        kb_dicts.append({
            "article_id": kb.source_id,
            "category": kb.category_ci or "Uncategorized",
            "sub_category": kb_metadata.get("sub_category", ""),
            "article_body": kb.content or kb_metadata.get("article_body", ""),
        })
    
    try:
        from services.coverage_calculator import calculate_single_incident_coverage
        
        result = calculate_single_incident_coverage(
            incident=incident_dict,
            kb_articles=kb_dicts,
            threshold=0.65
        )
        
        return jsonify(result)
        
    except ImportError as e:
        return jsonify({
            "error": "sentence-transformers not installed",
            "incidentId": incident_id,
            "category": incident.category_ci,
            "kbArticlesInCategory": len(kb_articles)
        }), 500


# =============================================================================
# NEW ENDPOINT: Coverage by Sub-Category
# =============================================================================

@app.route('/api/fabrics/<id>/kb-coverage-by-subcategory', methods=['GET'])
def get_kb_coverage_by_subcategory(id):
    """
    Get coverage breakdown by category AND sub-category.
    
    Returns nested structure:
    {
        "SC_EXCHANGE": {
            "Network": {"incidents": 10, "coverage": 75.5},
            "Configuration": {"incidents": 15, "coverage": 82.3},
            ...
        },
        ...
    }
    """
    fabric = Fabric.query.get_or_404(id)
    
    incidents = IngestedContent.query.filter_by(
        fabric_id=id,
        source_type='incident'
    ).all()
    
    kb_articles = IngestedContent.query.filter_by(
        fabric_id=id,
        source_type='kb'
    ).all()
    
    if not incidents:
        return jsonify({})
    
    # Convert to dicts
    incident_dicts = []
    for inc in incidents:
        metadata = inc.original_metadata or {}
        incident_dicts.append({
            "number": inc.source_id,
            "category": inc.category_ci or "Uncategorized",
            "sub_category": metadata.get("sub_category", "Uncategorized"),
            "resolution_notes": metadata.get("resolution_notes", inc.content or ""),
            "work_notes": metadata.get("work_notes", ""),
        })
    
    kb_dicts = []
    for kb in kb_articles:
        metadata = kb.original_metadata or {}
        kb_dicts.append({
            "article_id": kb.source_id,
            "category": kb.category_ci or "Uncategorized",
            "sub_category": metadata.get("sub_category", "Uncategorized"),
            "article_body": kb.content or metadata.get("article_body", ""),
        })
    
    try:
        from services.coverage_calculator import CoverageCalculator
        
        calculator = CoverageCalculator(threshold=0.65)
        calculator.load_kb_articles(kb_dicts)
        
        coverage_results = calculator.calculate_batch_coverage(incident_dicts)
        nested_stats = calculator.aggregate_by_sub_category(coverage_results)
        
        return jsonify(nested_stats)
        
    except ImportError:
        return jsonify({"error": "sentence-transformers not installed"}), 500
