# =============================================================================
# SERVICENOW API CLIENT
# =============================================================================
# Place this file in: backend/services/servicenow_client.py

import requests
import base64
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta


class ServiceNowClient:
    """
    Client for interacting with ServiceNow REST API.
    
    Supports:
    - Basic authentication (Base64 encoded)
    - KB Articles (kb_knowledge)
    - Incidents (incident)
    - Pagination
    - Search and filtering
    """
    
    def __init__(self, instance_url: str, username: str, password: str):
        """
        Initialize ServiceNow client.
        
        Args:
            instance_url: ServiceNow instance URL (e.g., https://company.service-now.com)
            username: ServiceNow username
            password: ServiceNow password
        """
        self.instance_url = instance_url.rstrip('/')
        self.username = username
        self.password = password
        
        # Create Base64 encoded credentials
        credentials = f"{username}:{password}"
        encoded_credentials = base64.b64encode(credentials.encode('utf-8')).decode('utf-8')
        
        self.headers = {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': f'Basic {encoded_credentials}'
        }
    
    def _make_request(self, endpoint: str, params: Dict = None) -> Dict:
        """Make authenticated request to ServiceNow API."""
        url = f"{self.instance_url}/api/now/table/{endpoint}"
        
        try:
            response = requests.get(
                url,
                headers=self.headers,
                params=params,
                timeout=30
            )
            
            # Check if response is HTML (instance sleeping or login redirect)
            content_type = response.headers.get('Content-Type', '')
            if 'text/html' in content_type:
                raise ServiceNowError(
                    "ServiceNow returned HTML instead of JSON. "
                    "The instance may be sleeping. Please visit the instance URL in your browser first, "
                    "wait for it to wake up, then try again."
                )
            
            # Check for empty response
            if not response.text or response.text.strip() == '':
                raise ServiceNowError("ServiceNow returned an empty response. The instance may be waking up. Please wait a moment and try again.")
            
            response.raise_for_status()
            
            try:
                return response.json()
            except (ValueError, Exception) as json_err:
                # Response isn't valid JSON
                preview = response.text[:200] if response.text else "(empty)"
                raise ServiceNowError(
                    f"Invalid JSON response from ServiceNow. "
                    f"The instance may be sleeping or redirecting to login. "
                    f"Response preview: {preview}"
                )
            
        except ServiceNowError:
            raise
        except requests.exceptions.RequestException as e:
            raise ServiceNowError(f"API request failed: {str(e)}")
    
    def test_connection(self) -> Dict[str, Any]:
        """
        Test connection to ServiceNow instance.
        
        Returns:
            Dict with connection status and instance info
        """
        try:
            # Try to fetch 1 record from sys_user to verify connection
            result = self._make_request('sys_user', {
                'sysparm_limit': 1,
                'sysparm_fields': 'sys_id,user_name'
            })
            
            return {
                'success': True,
                'message': 'Connected successfully',
                'instance_url': self.instance_url
            }
        except Exception as e:
            return {
                'success': False,
                'message': str(e),
                'instance_url': self.instance_url
            }
    
    # =========================================================================
    # KB ARTICLES
    # =========================================================================
    
    def search_kb_articles(
        self,
        search_query: str = '',
        category: str = '',
        state: str = 'published',
        limit: int = 20,
        offset: int = 0
    ) -> Dict[str, Any]:
        """
        Search KB articles with filters.
        
        Args:
            search_query: Text to search in title/short_description
            category: Filter by category
            state: Filter by workflow state (published, draft, etc.)
            limit: Max records to return
            offset: Pagination offset
            
        Returns:
            Dict with articles list and pagination info
        """
        # Build query
        query_parts = []
        
        # State filter
        if state == 'published':
            query_parts.append('workflow_state=published')
        elif state:
            query_parts.append(f'workflow_state={state}')
        
        # Text search
        if search_query:
            query_parts.append(f'short_descriptionLIKE{search_query}^ORtextLIKE{search_query}')
        
        # Category filter
        if category:
            query_parts.append(f'kb_categoryLIKE{category}')
        
        # Active articles only
        query_parts.append('active=true')
        
        query = '^'.join(query_parts) if query_parts else ''
        
        params = {
            'sysparm_query': query,
            'sysparm_limit': limit,
            'sysparm_offset': offset,
            'sysparm_fields': 'sys_id,number,short_description,text,kb_category,workflow_state,author,sys_created_on,sys_updated_on',
            'sysparm_display_value': 'true'
        }
        
        try:
            result = self._make_request('kb_knowledge', params)
            articles = result.get('result', [])
            
            # Get total count
            count_params = {
                'sysparm_query': query,
                'sysparm_count': 'true'
            }
            count_result = self._make_request('kb_knowledge', count_params)
            total_count = int(count_result.get('result', {}).get('count', len(articles)))
            
            return {
                'success': True,
                'articles': [{
                    'sys_id': a.get('sys_id'),
                    'number': a.get('number'),
                    'title': a.get('short_description', 'Untitled'),
                    'category': a.get('kb_category', ''),
                    'state': a.get('workflow_state', ''),
                    'author': a.get('author', ''),
                    'created_on': a.get('sys_created_on', ''),
                    'updated_on': a.get('sys_updated_on', ''),
                    'preview': self._clean_html(a.get('text', ''))[:200] + '...' if a.get('text') else ''
                } for a in articles],
                'pagination': {
                    'total': total_count,
                    'limit': limit,
                    'offset': offset,
                    'has_more': (offset + limit) < total_count
                }
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'articles': [],
                'pagination': {'total': 0, 'limit': limit, 'offset': offset, 'has_more': False}
            }
    
    def get_kb_article_full(self, sys_id: str) -> Dict[str, Any]:
        """Get full KB article content by sys_id."""
        params = {
            'sysparm_query': f'sys_id={sys_id}',
            'sysparm_fields': 'sys_id,number,short_description,text,kb_category,workflow_state,author,sys_created_on,keywords',
            'sysparm_display_value': 'true'
        }
        
        try:
            result = self._make_request('kb_knowledge', params)
            articles = result.get('result', [])
            
            if not articles:
                return {'success': False, 'error': 'Article not found'}
            
            a = articles[0]
            return {
                'success': True,
                'article': {
                    'sys_id': a.get('sys_id'),
                    'number': a.get('number'),
                    'title': a.get('short_description', 'Untitled'),
                    'content': self._clean_html(a.get('text', '')),
                    'category': a.get('kb_category', ''),
                    'state': a.get('workflow_state', ''),
                    'author': a.get('author', ''),
                    'created_on': a.get('sys_created_on', ''),
                    'keywords': a.get('keywords', '')
                }
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def get_kb_categories(self) -> List[str]:
        """Get list of KB categories."""
        params = {
            'sysparm_fields': 'label',
            'sysparm_limit': 100
        }
        
        try:
            result = self._make_request('kb_category', params)
            categories = result.get('result', [])
            return [c.get('label', '') for c in categories if c.get('label')]
        except:
            return []
    
    # =========================================================================
    # INCIDENTS
    # =========================================================================
    
    def search_incidents(
        self,
        search_query: str = '',
        category: str = '',
        state: str = 'resolved',
        priority: str = '',
        date_from: str = '',
        limit: int = 20,
        offset: int = 0
    ) -> Dict[str, Any]:
        """
        Search incidents with filters.
        
        Args:
            search_query: Text to search in short_description/description
            category: Filter by category
            state: Filter by state (resolved, closed, all)
            priority: Filter by priority (1-5)
            date_from: Filter incidents from this date (YYYY-MM-DD)
            limit: Max records to return
            offset: Pagination offset
            
        Returns:
            Dict with incidents list and pagination info
        """
        query_parts = []
        
        # State filter
        if state == 'resolved':
            query_parts.append('state=6')  # 6 = Resolved in ServiceNow
        elif state == 'closed':
            query_parts.append('state=7')  # 7 = Closed
        elif state == 'resolved_or_closed':
            query_parts.append('stateIN6,7')
        
        # Text search
        if search_query:
            query_parts.append(f'short_descriptionLIKE{search_query}^ORdescriptionLIKE{search_query}')
        
        # Category filter
        if category:
            query_parts.append(f'categoryLIKE{category}')
        
        # Priority filter
        if priority:
            query_parts.append(f'priority={priority}')
        
        # Date filter
        if date_from:
            query_parts.append(f'sys_created_on>={date_from}')
        
        query = '^'.join(query_parts) if query_parts else ''
        
        # Order by created date descending
        query += '^ORDERBYDESCsys_created_on'
        
        params = {
            'sysparm_query': query,
            'sysparm_limit': limit,
            'sysparm_offset': offset,
            'sysparm_fields': 'sys_id,number,short_description,description,category,subcategory,state,priority,assignment_group,assigned_to,resolution_notes,close_notes,sys_created_on,resolved_at',
            'sysparm_display_value': 'true'
        }
        
        try:
            result = self._make_request('incident', params)
            incidents = result.get('result', [])
            
            # Get total count
            count_params = {
                'sysparm_query': query.replace('^ORDERBYDESCsys_created_on', ''),
                'sysparm_count': 'true'
            }
            count_result = self._make_request('incident', count_params)
            total_count = int(count_result.get('result', {}).get('count', len(incidents)))
            
            return {
                'success': True,
                'incidents': [{
                    'sys_id': i.get('sys_id'),
                    'number': i.get('number'),
                    'short_description': i.get('short_description', 'No description'),
                    'category': i.get('category', ''),
                    'subcategory': i.get('subcategory', ''),
                    'state': i.get('state', ''),
                    'priority': i.get('priority', ''),
                    'assignment_group': i.get('assignment_group', ''),
                    'created_on': i.get('sys_created_on', ''),
                    'resolved_at': i.get('resolved_at', ''),
                    'has_resolution': bool(i.get('resolution_notes') or i.get('close_notes'))
                } for i in incidents],
                'pagination': {
                    'total': total_count,
                    'limit': limit,
                    'offset': offset,
                    'has_more': (offset + limit) < total_count
                }
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'incidents': [],
                'pagination': {'total': 0, 'limit': limit, 'offset': offset, 'has_more': False}
            }
    
    def get_incident_full(self, sys_id: str) -> Dict[str, Any]:
        """Get full incident content by sys_id."""
        params = {
            'sysparm_query': f'sys_id={sys_id}',
            'sysparm_fields': 'sys_id,number,short_description,description,category,subcategory,state,priority,assignment_group,assigned_to,resolution_notes,close_notes,work_notes,sys_created_on,resolved_at',
            'sysparm_display_value': 'true'
        }
        
        try:
            result = self._make_request('incident', params)
            incidents = result.get('result', [])
            
            if not incidents:
                return {'success': False, 'error': 'Incident not found'}
            
            i = incidents[0]
            return {
                'success': True,
                'incident': {
                    'sys_id': i.get('sys_id'),
                    'number': i.get('number'),
                    'short_description': i.get('short_description', ''),
                    'description': i.get('description', ''),
                    'category': i.get('category', ''),
                    'subcategory': i.get('subcategory', ''),
                    'state': i.get('state', ''),
                    'priority': i.get('priority', ''),
                    'assignment_group': i.get('assignment_group', ''),
                    'assigned_to': i.get('assigned_to', ''),
                    'resolution_notes': i.get('resolution_notes', ''),
                    'close_notes': i.get('close_notes', ''),
                    'work_notes': i.get('work_notes', ''),
                    'created_on': i.get('sys_created_on', ''),
                    'resolved_at': i.get('resolved_at', '')
                }
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def get_incident_categories(self) -> List[str]:
        """Get list of incident categories."""
        params = {
            'sysparm_query': 'stateIN6,7',  # Only from resolved/closed incidents
            'sysparm_fields': 'category',
            'sysparm_limit': 1000
        }
        
        try:
            result = self._make_request('incident', params)
            incidents = result.get('result', [])
            categories = set()
            for i in incidents:
                if i.get('category'):
                    categories.add(i.get('category'))
            return sorted(list(categories))
        except:
            return []
    
    # =========================================================================
    # COUNTS
    # =========================================================================
    
    def get_kb_count(self) -> int:
        """Get total count of published KB articles."""
        try:
            params = {
                'sysparm_query': 'workflow_state=published^active=true',
                'sysparm_count': 'true'
            }
            result = self._make_request('kb_knowledge', params)
            return int(result.get('result', {}).get('count', 0))
        except:
            return 0
    
    def get_incident_count(self, state: str = 'resolved_or_closed') -> int:
        """Get total count of incidents."""
        try:
            query = ''
            if state == 'resolved':
                query = 'state=6'
            elif state == 'closed':
                query = 'state=7'
            elif state == 'resolved_or_closed':
                query = 'stateIN6,7'
            
            params = {
                'sysparm_query': query,
                'sysparm_count': 'true'
            }
            result = self._make_request('incident', params)
            return int(result.get('result', {}).get('count', 0))
        except:
            return 0
    
    # =========================================================================
    # BULK FETCH ALL
    # =========================================================================
    
    def fetch_all_kb_articles(self, limit: int = 100) -> Dict[str, Any]:
        """
        Fetch all published KB articles up to limit.
        
        Args:
            limit: Maximum articles to fetch
            
        Returns:
            Dict with articles list
        """
        all_articles = []
        offset = 0
        batch_size = 50
        
        print(f"    Fetching KB articles (limit: {limit})...")
        
        while len(all_articles) < limit:
            remaining = limit - len(all_articles)
            current_batch = min(batch_size, remaining)
            
            params = {
                'sysparm_query': 'workflow_state=published^active=true^ORDERBYDESCsys_updated_on',
                'sysparm_limit': current_batch,
                'sysparm_offset': offset,
                'sysparm_fields': 'sys_id,number,short_description,text,kb_category,workflow_state,author,sys_created_on,keywords',
                'sysparm_display_value': 'true'
            }
            
            try:
                result = self._make_request('kb_knowledge', params)
                articles = result.get('result', [])
                
                if not articles:
                    break
                
                for a in articles:
                    all_articles.append({
                        'sys_id': a.get('sys_id'),
                        'number': a.get('number'),
                        'title': a.get('short_description', 'Untitled'),
                        'content': self._clean_html(a.get('text', '')),
                        'category': a.get('kb_category', 'Uncategorized'),
                        'state': a.get('workflow_state', ''),
                        'author': a.get('author', ''),
                        'created_on': a.get('sys_created_on', ''),
                        'keywords': a.get('keywords', '')
                    })
                
                print(f"      Fetched {len(all_articles)} KB articles...")
                offset += current_batch
                
                if len(articles) < current_batch:
                    break
                    
            except Exception as e:
                print(f"      Error fetching KB batch: {e}")
                break
        
        return {
            'success': True,
            'articles': all_articles,
            'count': len(all_articles)
        }
    
    def fetch_all_incidents(
        self, 
        limit: int = 500, 
        state: str = 'resolved_or_closed',
        date_from: str = ''
    ) -> Dict[str, Any]:
        """
        Fetch all incidents up to limit.
        
        Args:
            limit: Maximum incidents to fetch
            state: State filter (resolved, closed, resolved_or_closed, all)
            date_from: Only fetch incidents from this date (YYYY-MM-DD)
            
        Returns:
            Dict with incidents list
        """
        all_incidents = []
        offset = 0
        batch_size = 100
        
        # Build query
        query_parts = []
        if state == 'resolved':
            query_parts.append('state=6')
        elif state == 'closed':
            query_parts.append('state=7')
        elif state == 'resolved_or_closed':
            query_parts.append('stateIN6,7')
        
        if date_from:
            query_parts.append(f'sys_created_on>={date_from}')
        
        query = '^'.join(query_parts) if query_parts else ''
        query += '^ORDERBYDESCsys_created_on'
        
        print(f"    Fetching incidents (limit: {limit}, state: {state})...")
        
        while len(all_incidents) < limit:
            remaining = limit - len(all_incidents)
            current_batch = min(batch_size, remaining)
            
            params = {
                'sysparm_query': query,
                'sysparm_limit': current_batch,
                'sysparm_offset': offset,
                'sysparm_fields': 'sys_id,number,short_description,description,category,subcategory,state,priority,resolution_notes,close_notes,work_notes,sys_created_on,resolved_at',
                'sysparm_display_value': 'true'
            }
            
            try:
                result = self._make_request('incident', params)
                incidents = result.get('result', [])
                
                if not incidents:
                    break
                
                for i in incidents:
                    all_incidents.append({
                        'sys_id': i.get('sys_id'),
                        'number': i.get('number'),
                        'short_description': i.get('short_description', ''),
                        'description': i.get('description', ''),
                        'category': i.get('category', 'Uncategorized'),
                        'subcategory': i.get('subcategory', ''),
                        'state': i.get('state', ''),
                        'priority': i.get('priority', ''),
                        'resolution_notes': i.get('resolution_notes', ''),
                        'close_notes': i.get('close_notes', ''),
                        'work_notes': i.get('work_notes', ''),
                        'created_on': i.get('sys_created_on', ''),
                        'resolved_at': i.get('resolved_at', '')
                    })
                
                print(f"      Fetched {len(all_incidents)} incidents...")
                offset += current_batch
                
                if len(incidents) < current_batch:
                    break
                    
            except Exception as e:
                print(f"      Error fetching incident batch: {e}")
                break
        
        return {
            'success': True,
            'incidents': all_incidents,
            'count': len(all_incidents)
        }
    
    # =========================================================================
    # FETCH BY IDS (kept for compatibility)
    # =========================================================================
    
    def fetch_kb_articles_by_ids(self, sys_ids: List[str]) -> List[Dict]:
        """Fetch multiple KB articles by their sys_ids."""
        articles = []
        for sys_id in sys_ids:
            result = self.get_kb_article_full(sys_id)
            if result.get('success'):
                articles.append(result['article'])
        return articles
    
    def fetch_incidents_by_ids(self, sys_ids: List[str]) -> List[Dict]:
        """Fetch multiple incidents by their sys_ids."""
        incidents = []
        for sys_id in sys_ids:
            result = self.get_incident_full(sys_id)
            if result.get('success'):
                incidents.append(result['incident'])
        return incidents
    
    # =========================================================================
    # HELPERS
    # =========================================================================
    
    def _clean_html(self, html_text: str) -> str:
        """Remove HTML tags from text."""
        import re
        if not html_text:
            return ''
        # Remove HTML tags
        clean = re.sub(r'<[^>]+>', ' ', html_text)
        # Remove extra whitespace
        clean = re.sub(r'\s+', ' ', clean)
        return clean.strip()


class ServiceNowError(Exception):
    """Custom exception for ServiceNow API errors."""
    pass
