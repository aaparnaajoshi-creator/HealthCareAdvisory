"""
Test Coverage Calculator Logic
==============================
Tests the coverage calculation logic using mock embeddings.
This allows testing without installing sentence-transformers.
"""

import csv
import random
from typing import List, Dict, Any

# =============================================================================
# MOCK EMBEDDING - For testing without sentence-transformers
# =============================================================================

class MockEmbeddingModel:
    """Mock embedding model that uses keyword matching for similarity"""
    
    def encode(self, texts: List[str]) -> List[List[float]]:
        """Return mock embeddings based on text content"""
        return [self._text_to_vector(t) for t in texts]
    
    def _text_to_vector(self, text: str) -> List[float]:
        """Convert text to a simple vector based on keyword presence"""
        keywords = [
            'network', 'dns', 'firewall', 'vpn', 'connection', 'ping',
            'config', 'settings', 'certificate', 'ssl', 'server',
            'install', 'client', 'software', 'update', 'restart',
            'access', 'login', 'password', 'permission', 'sso', 'mfa',
            'error', 'crash', 'memory', 'cpu', 'service',
            'slow', 'timeout', 'performance', 'query', 'index',
            'data', 'sync', 'duplicate', 'missing', 'etl',
            'api', 'integration', 'webhook', 'queue', 'oauth'
        ]
        
        text_lower = text.lower()
        vector = []
        for kw in keywords:
            if kw in text_lower:
                vector.append(1.0 + random.uniform(-0.1, 0.1))
            else:
                vector.append(random.uniform(0, 0.2))
        return vector


def cosine_similarity(vec1: List[float], vec2: List[float]) -> float:
    """Calculate cosine similarity"""
    import math
    dot = sum(a * b for a, b in zip(vec1, vec2))
    norm1 = math.sqrt(sum(a * a for a in vec1))
    norm2 = math.sqrt(sum(b * b for b in vec2))
    if norm1 == 0 or norm2 == 0:
        return 0.0
    return dot / (norm1 * norm2)


# =============================================================================
# STEP EXTRACTION
# =============================================================================

def extract_steps(text: str) -> List[str]:
    """Extract steps from resolution/work notes"""
    import re
    
    if not text:
        return []
    
    steps = []
    
    # Try numbered pattern
    numbered = re.findall(r'^\s*\d+[.\)]\s*(.+?)$', text, re.MULTILINE)
    if numbered:
        steps = [s.strip() for s in numbered if s.strip()]
    
    # Fallback to lines
    if not steps:
        lines = text.strip().split('\n')
        steps = [l.strip() for l in lines if l.strip() and len(l.strip()) > 10]
    
    return steps


# =============================================================================
# TEST COVERAGE CALCULATION
# =============================================================================

def calculate_coverage(
    incidents: List[Dict],
    kb_articles: List[Dict],
    threshold: float = 0.6
) -> Dict[str, Any]:
    """Calculate coverage using mock embeddings"""
    
    model = MockEmbeddingModel()
    
    # Group KB by category
    kb_by_cat = {}
    kb_embeddings = {}
    
    for kb in kb_articles:
        cat = kb.get('category', 'Uncategorized')
        if cat not in kb_by_cat:
            kb_by_cat[cat] = []
        kb_by_cat[cat].append(kb)
        
        # Compute embedding
        body = kb.get('article_body', '')
        kb_embeddings[kb['article_id']] = model.encode([body])[0]
    
    # Calculate coverage per incident
    results_by_cat = {}
    
    for inc in incidents:
        cat = inc.get('category', 'Uncategorized')
        resolution = inc.get('resolution_notes', '')
        work_notes = inc.get('work_notes', '')
        
        combined = f"{resolution}\n{work_notes}"
        steps = extract_steps(combined)
        
        if cat not in results_by_cat:
            results_by_cat[cat] = {
                'incidents': 0,
                'total_steps': 0,
                'covered_steps': 0,
                'coverages': []
            }
        
        results_by_cat[cat]['incidents'] += 1
        results_by_cat[cat]['total_steps'] += len(steps)
        
        # Get KB articles in same category
        candidate_kbs = kb_by_cat.get(cat, [])
        
        if not steps or not candidate_kbs:
            results_by_cat[cat]['coverages'].append(0)
            continue
        
        # Calculate step coverage
        covered = 0
        for step in steps:
            step_emb = model.encode([step])[0]
            
            best_sim = 0
            for kb in candidate_kbs:
                kb_emb = kb_embeddings[kb['article_id']]
                sim = cosine_similarity(step_emb, kb_emb)
                best_sim = max(best_sim, sim)
            
            if best_sim >= threshold:
                covered += 1
        
        coverage_pct = (covered / len(steps)) * 100 if steps else 0
        results_by_cat[cat]['covered_steps'] += covered
        results_by_cat[cat]['coverages'].append(coverage_pct)
    
    # Build output
    categories = []
    incident_counts = []
    coverage_percentages = []
    gaps = []
    kb_counts = []
    
    for cat in sorted(results_by_cat.keys()):
        data = results_by_cat[cat]
        avg_coverage = sum(data['coverages']) / len(data['coverages']) if data['coverages'] else 0
        
        # Gap = incidents with < 50% coverage
        gap = sum(1 for c in data['coverages'] if c < 50)
        
        categories.append(cat)
        incident_counts.append(data['incidents'])
        coverage_percentages.append(round(avg_coverage, 1))
        gaps.append(gap)
        kb_counts.append(len(kb_by_cat.get(cat, [])))
    
    total_incidents = sum(incident_counts)
    total_covered = sum(1 for cat in results_by_cat.values() 
                       for c in cat['coverages'] if c >= 50)
    
    return {
        "categories": categories,
        "incidentCounts": incident_counts,
        "coveragePercentages": coverage_percentages,
        "gaps": gaps,
        "kbArticleCounts": kb_counts,
        "totalIncidents": total_incidents,
        "totalKBArticles": len(kb_articles),
        "overallCoveragePercentage": round(
            sum(coverage_percentages) / len(coverage_percentages), 1
        ) if coverage_percentages else 0
    }


# =============================================================================
# MAIN TEST
# =============================================================================

def main():
    print("=" * 80)
    print("COVERAGE CALCULATOR TEST")
    print("=" * 80)
    
    # Load test data
    print("\n📂 Loading test data...")
    
    incidents = []
    with open('incidents_strategic.csv', 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            incidents.append(row)
    print(f"   Loaded {len(incidents)} incidents")
    
    kb_articles = []
    with open('kb_articles_strategic.csv', 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            kb_articles.append(row)
    print(f"   Loaded {len(kb_articles)} KB articles")
    
    # Calculate coverage
    print("\n🔄 Calculating coverage...")
    result = calculate_coverage(incidents, kb_articles, threshold=0.5)
    
    # Display results
    print("\n" + "=" * 80)
    print("COVERAGE RESULTS")
    print("=" * 80)
    
    print(f"\n{'Category':<55} {'Inc':<6} {'KB':<4} {'Cov%':<8} {'Gap':<5}")
    print("-" * 80)
    
    for i in range(len(result['categories'])):
        cat = result['categories'][i][:52] + "..." if len(result['categories'][i]) > 52 else result['categories'][i]
        inc = result['incidentCounts'][i]
        kb = result['kbArticleCounts'][i]
        cov = result['coveragePercentages'][i]
        gap = result['gaps'][i]
        
        # Color indicator
        if kb == 0:
            status = "🔴"
        elif cov >= 70:
            status = "🟢"
        elif cov >= 50:
            status = "🟡"
        else:
            status = "🟠"
        
        print(f"{status} {cat:<52} {inc:<6} {kb:<4} {cov:<8} {gap:<5}")
    
    print("-" * 80)
    print(f"   TOTAL: {result['totalIncidents']} incidents, "
          f"{result['totalKBArticles']} KB articles, "
          f"{result['overallCoveragePercentage']}% avg coverage")
    print("=" * 80)
    
    # Summary
    print("\n📊 SUMMARY:")
    no_kb = sum(1 for kb in result['kbArticleCounts'] if kb == 0)
    good_cov = sum(1 for c in result['coveragePercentages'] if c >= 70)
    poor_cov = sum(1 for c in result['coveragePercentages'] if c < 50 and c > 0)
    
    print(f"   🔴 Categories with NO KB articles: {no_kb}")
    print(f"   🟢 Categories with GOOD coverage (>=70%): {good_cov}")
    print(f"   🟠 Categories with POOR coverage (<50%): {poor_cov}")
    
    print("\n✅ Test complete!")


if __name__ == "__main__":
    main()
