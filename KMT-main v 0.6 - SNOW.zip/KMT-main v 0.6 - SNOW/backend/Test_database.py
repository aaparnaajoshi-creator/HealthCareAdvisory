from app import app, db
from models import IngestedContent

with app.app_context():
    articles = IngestedContent.query.filter_by(source_type='kb').limit(5).all()
    print('KB Articles:')
    for a in articles:
        print(f'  {a.source_id}: category = \"{a.category_ci}\"')
    
    # Count by category
    print()
    from sqlalchemy import func
    cats = db.session.query(
        IngestedContent.category_ci, 
        func.count(IngestedContent.id)
    ).filter_by(source_type='kb').group_by(IngestedContent.category_ci).all()
    print('Categories:')
    for cat, count in cats:
        print(f'  \"{cat}\": {count}')
