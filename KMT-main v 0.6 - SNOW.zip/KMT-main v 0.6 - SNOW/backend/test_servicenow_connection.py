# =============================================================================
# SERVICENOW CONNECTION TEST SCRIPT
# =============================================================================
# Run this to debug your ServiceNow connection
#
# Usage: python test_servicenow_connection.py

import requests
import base64

# =============================================================================
# ENTER YOUR CREDENTIALS HERE
# =============================================================================
INSTANCE_URL = "https://dev220808.service-now.com/dev.do"
USERNAME = "admin"      # ← CHANGE THIS to your username
PASSWORD = "password"   # ← CHANGE THIS to your password
# =============================================================================

def test_connection():
    print("=" * 60)
    print("SERVICENOW CONNECTION TEST")
    print("=" * 60)
    print(f"\nInstance: {INSTANCE_URL}")
    print(f"Username: {USERNAME}")
    print(f"Password: {'*' * len(PASSWORD)}")
    
    # Create Base64 encoded credentials
    credentials = f"{USERNAME}:{PASSWORD}"
    encoded = base64.b64encode(credentials.encode('utf-8')).decode('utf-8')
    
    print(f"\nBase64 Auth: Basic {encoded[:20]}...")
    
    # Test URL
    url = f"{INSTANCE_URL}/api/now/table/sys_user"
    params = {
        'sysparm_limit': 1,
        'sysparm_fields': 'sys_id,user_name'
    }
    
    headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': f'Basic {encoded}'
    }
    
    print(f"\nTesting URL: {url}")
    print("-" * 60)
    
    try:
        response = requests.get(url, headers=headers, params=params, timeout=30)
        
        print(f"Status Code: {response.status_code}")
        print(f"Status: {response.reason}")
        
        # Print response headers for debugging
        print(f"\nResponse Headers:")
        for key, value in response.headers.items():
            if key.lower() in ['www-authenticate', 'x-is-logged-in', 'set-cookie']:
                print(f"  {key}: {value[:100]}")
        
        if response.status_code == 200:
            print("\n✅ SUCCESS! Connection works!")
            print(f"\nResponse: {response.text[:500]}")
        elif response.status_code == 401:
            print("\n❌ 401 UNAUTHORIZED")
            print("\nPossible causes:")
            print("  1. Wrong username or password")
            print("  2. User doesn't have 'rest_api_explorer' or 'admin' role")
            print("  3. Basic Auth is disabled for this instance")
            print("  4. Dev instance may be sleeping (visit URL in browser first)")
            print(f"\nResponse body: {response.text[:500]}")
        else:
            print(f"\n⚠️ Unexpected status: {response.status_code}")
            print(f"Response: {response.text[:500]}")
            
    except requests.exceptions.ConnectionError as e:
        print(f"\n❌ CONNECTION ERROR: Cannot reach {INSTANCE_URL}")
        print(f"Error: {e}")
    except Exception as e:
        print(f"\n❌ ERROR: {e}")

    print("\n" + "=" * 60)
    print("TROUBLESHOOTING TIPS")
    print("=" * 60)
    print("""
1. VERIFY CREDENTIALS:
   - Log into ServiceNow web UI with same username/password
   - URL: {}/login.do
   
2. CHECK USER ROLES (in ServiceNow):
   - Go to: User Administration > Users
   - Find your user
   - Check Roles tab has: 'rest_api_explorer' or 'admin'
   
3. WAKE UP DEV INSTANCE:
   - Dev instances sleep after inactivity
   - Visit {} in browser first
   - Wait for it to fully load
   
4. CHECK INSTANCE STATUS:
   - Dev instances expire after ~10 days
   - Check if instance is still active

5. TRY DIFFERENT ENDPOINT:
   - Some tables may be restricted
   - Try accessing incident table instead
""".format(INSTANCE_URL, INSTANCE_URL))


def test_alternative_endpoint():
    """Try incident table instead of sys_user"""
    print("\n" + "=" * 60)
    print("TESTING ALTERNATIVE ENDPOINT (incident table)")
    print("=" * 60)
    
    credentials = f"{USERNAME}:{PASSWORD}"
    encoded = base64.b64encode(credentials.encode('utf-8')).decode('utf-8')
    
    url = f"{INSTANCE_URL}/api/now/table/incident"
    params = {
        'sysparm_limit': 1,
        'sysparm_fields': 'number,short_description'
    }
    
    headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': f'Basic {encoded}'
    }
    
    try:
        response = requests.get(url, headers=headers, params=params, timeout=30)
        print(f"Status Code: {response.status_code}")
        
        if response.status_code == 200:
            print("✅ Incident table accessible!")
            print(f"Response: {response.text[:300]}")
        else:
            print(f"❌ Status: {response.status_code}")
            
    except Exception as e:
        print(f"❌ Error: {e}")


if __name__ == "__main__":
    test_connection()
    test_alternative_endpoint()
