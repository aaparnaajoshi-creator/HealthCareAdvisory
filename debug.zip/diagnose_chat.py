"""
CHAT FLOW DIAGNOSTIC SCRIPT
Run this to check if your data is in ChromaDB and retrievable

Usage: python diagnose_chat.py
"""

import chromadb
from config import Config
from models import db, Fabric, IngestedContent
from flask import Flask

# Initialize Flask app for database access
app = Flask(__name__)
app.config.from_object(Config)
db.init_app(app)

def diagnose():
    print("=" * 60)
    print("CHAT FLOW DIAGNOSTIC")
    print("=" * 60)
    
    with app.app_context():
        # Step 1: Check Fabrics
        print("\n📁 STEP 1: Checking Fabrics...")
        fabrics = Fabric.query.all()
        
        if not fabrics:
            print("   ❌ No fabrics found!")
            return
        
        for fabric in fabrics:
            print(f"\n   Fabric: {fabric.name}")
            print(f"   ID: {fabric.id}")
            print(f"   Status: {fabric.status}")
            print(f"   Documents: {fabric.documents_count}")
            print(f"   Chunks: {fabric.chunks_count}")
            
            # Get collection name (same logic as app.py)
            collection_name = fabric.name
            if fabric.rag_config:
                collection_name = fabric.rag_config.get('chromaCollection', fabric.name)
            print(f"   ChromaDB Collection: {collection_name}")
            
            # Step 2: Check IngestedContent
            print(f"\n📊 STEP 2: Checking IngestedContent for fabric '{fabric.name}'...")
            kb_count = IngestedContent.query.filter_by(
                fabric_id=fabric.id, source_type='kb'
            ).count()
            inc_count = IngestedContent.query.filter_by(
                fabric_id=fabric.id, source_type='incident'
            ).count()
            doc_count = IngestedContent.query.filter_by(
                fabric_id=fabric.id, source_type='document'
            ).count()
            
            print(f"   KB Articles: {kb_count}")
            print(f"   Incidents: {inc_count}")
            print(f"   Documents: {doc_count}")
            
            # Step 3: Check ChromaDB
            print(f"\n🗄️ STEP 3: Checking ChromaDB...")
            try:
                chroma_client = chromadb.PersistentClient(path=Config.CHROMA_DB_PATH)
                
                # List all collections
                collections = chroma_client.list_collections()
                print(f"   All collections in ChromaDB:")
                for col in collections:
                    count = col.count()
                    match = "✅ MATCH" if col.name == collection_name else ""
                    print(f"      - {col.name}: {count} chunks {match}")
                
                # Try to get the expected collection
                try:
                    collection = chroma_client.get_collection(collection_name)
                    chunk_count = collection.count()
                    print(f"\n   Expected collection '{collection_name}': {chunk_count} chunks")
                    
                    if chunk_count == 0:
                        print("   ❌ PROBLEM: Collection exists but has 0 chunks!")
                        print("   → CSV data was NOT vectorized")
                        print("   → Use csv_ingestion_with_vectorization.py to fix")
                    else:
                        print("   ✅ Collection has data!")
                        
                        # Step 4: Test retrieval
                        print(f"\n🔍 STEP 4: Testing retrieval...")
                        
                        # Get a sample query from your data
                        sample = IngestedContent.query.filter_by(fabric_id=fabric.id).first()
                        if sample:
                            test_query = sample.short_description or sample.title or "VPN issue"
                            print(f"   Test query: '{test_query[:50]}...'")
                            
                            # Query ChromaDB directly
                            results = collection.query(
                                query_texts=[test_query],
                                n_results=3
                            )
                            
                            if results and results['documents'] and results['documents'][0]:
                                print(f"   ✅ Retrieved {len(results['documents'][0])} documents!")
                                for i, doc in enumerate(results['documents'][0][:2]):
                                    print(f"      Result {i+1}: {doc[:80]}...")
                            else:
                                print("   ❌ No documents retrieved!")
                        
                except Exception as e:
                    print(f"   ❌ Collection '{collection_name}' NOT FOUND!")
                    print(f"   Error: {e}")
                    print("   → This is why chat gives generic responses!")
                    
            except Exception as e:
                print(f"   ❌ ChromaDB error: {e}")
        
        # Summary
        print("\n" + "=" * 60)
        print("DIAGNOSIS SUMMARY")
        print("=" * 60)
        print("""
If you see:
  - "Collection exists but has 0 chunks" 
    → CSV ingestion didn't vectorize. Use the updated csv_ingestion.py
    
  - "Collection NOT FOUND"
    → Collection name mismatch. Check chromaCollection in rag_config
    
  - "Retrieved 0 documents"
    → Embeddings issue or empty collection
    
  - "Retrieved X documents" 
    → ✅ Data is there! Check agent.py generation logic
""")


if __name__ == "__main__":
    diagnose()
