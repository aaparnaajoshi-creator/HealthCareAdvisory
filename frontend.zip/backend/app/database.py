import sqlite3
import json
from typing import List, Dict
from models import ProjectConfig
import shutil

DATABASE_URL = "database.db"

def get_db_connection():
    conn = sqlite3.connect(DATABASE_URL, check_same_thread=False)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS projects (
        id TEXT PRIMARY KEY,
        project_name TEXT NOT NULL,
        project_type TEXT DEFAULT 'enhancement',
        start_phase TEXT NOT NULL,
        end_phase TEXT NOT NULL,
        human_in_loop_steps TEXT,
        output_destination TEXT DEFAULT 'disk',
        github_repo_url TEXT,
        github_push_phases TEXT,
        status TEXT DEFAULT 'Pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    
    # --- NEW: Add the phases_to_run column if it doesn't exist ---
    try:
        cursor.execute("ALTER TABLE projects ADD COLUMN phases_to_run TEXT")
    except sqlite3.OperationalError:
        # Column already exists, which is fine
        pass
    
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id TEXT,
        agent_name TEXT NOT NULL,
        status TEXT NOT NULL,
        output TEXT,
        details TEXT,
        phase TEXT,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (project_id) REFERENCES projects (id)  ON DELETE CASCADE
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS technical_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id TEXT,
        phase TEXT,
        event_description TEXT NOT NULL,
        metadata TEXT,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (project_id) REFERENCES projects (id) ON DELETE CASCADE
    )
    """)
    
    conn.commit()
    conn.close()

def create_project(project_id: str, config: ProjectConfig):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO projects (id, project_name, project_type, start_phase, end_phase, human_in_loop_steps, output_destination, github_repo_url, github_push_phases) VALUES (?, ?, ?, ?, ?, ?, ?,?,?)",
        (project_id, config.project_name, config.project_type, config.start_phase, config.end_phase, json.dumps(config.human_in_loop_steps), config.output_destination,config.github_repo_url,json.dumps(config.github_push_phases))
    )
    conn.commit()
    conn.close()

# --- NEW: Function to update the phases_to_run for a project ---
def update_project_phases_to_run(project_id: str, phases: List[str]):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE projects SET phases_to_run = ? WHERE id = ?", (json.dumps(phases), project_id))
    conn.commit()
    conn.close()

def get_project_config(project_id: str) -> dict:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM projects WHERE id = ?", (project_id,))
    project = cursor.fetchone()
    conn.close()
    if project:
        proj_dict = dict(project)
        # --- NEW: Load the phases_to_run list ---
        if proj_dict.get('phases_to_run'):
            proj_dict['phases_to_run'] = json.loads(proj_dict['phases_to_run'])
        else:
            proj_dict['phases_to_run'] = []
            
        if proj_dict.get('human_in_loop_steps'):
            proj_dict['human_in_loop_steps'] = json.loads(proj_dict['human_in_loop_steps'])
        else:
            proj_dict['human_in_loop_steps'] = []
            
        if proj_dict.get('github_push_phases'):
            proj_dict['github_push_phases'] = json.loads(proj_dict['github_push_phases'])
        else:
            proj_dict['github_push_phases'] = []
        return proj_dict
    return None

def update_project_status(project_id: str, status: str):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE projects SET status = ? WHERE id = ?", (status, project_id))
    conn.commit()
    conn.close()

def log_agent_activity(project_id: str, agent_name: str, status: str, output: str = "", details: str = "", phase: str = ""):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO logs (project_id, agent_name, status, output, details, phase) VALUES (?, ?, ?, ?, ?, ?)",
        (project_id, agent_name, status, output, details, phase)
    )
    conn.commit()
    conn.close()

def log_technical_event(project_id: str, phase: str, event_description: str, metadata: dict = {}):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO technical_logs (project_id, phase, event_description, metadata) VALUES (?, ?, ?, ?)",
        (project_id, phase, event_description, json.dumps(metadata))
    )
    conn.commit()
    conn.close()

def get_project_logs(project_id: str) -> List[dict]:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT agent_name, status, output, details, phase, timestamp FROM logs WHERE project_id = ? ORDER BY timestamp ASC", (project_id,))
    logs = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return logs

def get_technical_logs_for_phase(project_id: str, phase_name: str) -> List[dict]:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT event_description, metadata, timestamp FROM technical_logs WHERE project_id = ? AND phase = ? ORDER BY timestamp ASC", (project_id, phase_name))
    logs = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return logs

def get_cumulative_phase_durations(project_id: str) -> Dict[str, float]:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT phase, metadata FROM technical_logs WHERE project_id = ? AND event_description LIKE '%Finished'", (project_id,))
    
    durations = {}
    for row in cursor.fetchall():
        phase = row['phase']
        metadata = json.loads(row['metadata'])
        duration = metadata.get('duration_seconds', 0)
        durations[phase] = durations.get(phase, 0) + duration
        
    conn.close()
    return {k: round(v, 2) for k, v in durations.items()}

def get_all_projects() -> List[dict]:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, project_name, project_type, status, created_at FROM projects ORDER BY created_at DESC")
    projects = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return projects

def delete_project_from_db(project_id: str):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM projects WHERE id = ?", (project_id,))
    conn.commit()
    was_deleted = cursor.rowcount > 0
    conn.close()
    return was_deleted