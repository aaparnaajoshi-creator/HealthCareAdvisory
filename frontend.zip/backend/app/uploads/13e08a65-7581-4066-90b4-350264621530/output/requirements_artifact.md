```markdown
--- FILE: Requirements.docx ---

Corporate Website - Software Requirements Specification
1. Introduction
This document outlines the requirements for the Pharma Inc. corporate website. The website will serve as a digital presence for the company, providing information about its mission, products, and contact details.
2. User Stories
Home Page
US-001: As a visitor, I want to see a welcoming home page with a clear mission statement so that I understand the company's purpose.
Acceptance Criteria:
The main heading should be "Welcome to Pharma Inc."
A mission statement must be clearly visible below the main heading.
The page must load in under 3 seconds.
US-002: As a visitor, I want to easily navigate to other sections of the site (About, Products, Contact) from the home page.
Acceptance Criteria:
A navigation bar must be present at the top of the page.
The navigation bar must contain links for "Home," "About Us," "Products," and "Contact Us."
All navigation links must be functional.
About Us Page
US-003: As a potential partner, I want to read about the company's history and values on an "About Us" page to determine if they are a good fit for collaboration.
Acceptance Criteria:
The page must have a section for "Our History."
The page must have a section for "Our Values."
Products Page
US-004: As a healthcare professional, I want to view a list of the company's products to understand their offerings.
Acceptance Criteria:
The page must display a bulleted list of at least three products.
Each product in the list must have a brief description.
Contact Us Page
US-005: As a potential customer, I want a "Contact Us" page so that I can send inquiries to the company.
Acceptance Criteria:
The page must contain a contact form.
The page must display the company's contact email address.
US-006: The page must have a contact form with fields for Name, Email, and Message.
Acceptance Criteria:
The form must contain an input field for "Name" (text type).
The form must contain an input field for "Email" (email type).
The form must contain a textarea for "Message."
All fields must be marked as required.
US-007: The page must display the company's contact email address: --contact@pharma-inc.com--++inquiries@pharma-corp.com++.
Acceptance Criteria:
The email address must be visible in the page footer.
The email address must be a clickable mailto: link.
US-008: Submitting the form should send the inquiry to the contact email address.
Acceptance Criteria:
A successful form submission must trigger a POST request to the /api/contact endpoint.
A success message must be displayed to the user upon successful submission.
++The backend system must send the submitted inquiry details to inquiries@pharma-corp.com.++