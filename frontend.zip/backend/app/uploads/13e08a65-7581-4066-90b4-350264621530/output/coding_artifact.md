```html
<!-- about.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About - Pharma Inc.</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav>
        <a href="/">Home</a> |
        <a href="/about">About Us</a> |
        <a href="/products">Products</a> |
        <a href="/contact">Contact Us</a>
    </nav>
    <div class="content">
        <h1>About Us</h1>
        <p>Founded in 2005, Pharma Inc. has been dedicated to discovering and developing life-changing medicines.</p>
        ++ ADDED START ++
        <h2>Our Values</h2>
        <ul>
            <li>Innovation: Continuously seeking new and better solutions for healthcare challenges.</li>
            <li>Integrity: Upholding the highest ethical standards in all our operations.</li>
            <li>Patient-Centricity: Prioritizing the well-being and needs of patients above all else.</li>
            <li>Collaboration: Fostering partnerships to accelerate scientific discovery and improve global health.</li>
        </ul>
        ++ ADDED END ++
    </div>
</body>
</html>
```

```python
# app.py (Backend)
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS

app = Flask(__name__, template_folder='.',static_folder='.')
CORS(app)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/products')
def products():
    return render_template('products.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/api/contact', methods=['POST'])
def handle_contact_form():
    data = request.get_json()
    name = data.get('name')
    email = data.get('email')
    message = data.get('message')
    
    ++ ADDED START ++
    # Validate required fields
    if not name or not email or not message:
        return jsonify({"error": "Name, email, and message are required fields."}), 400
    
    # Basic email format validation (more robust validation might use regex)
    if "@" not in email or "." not in email:
        return jsonify({"error": "Please provide a valid email address."}), 400
    ++ ADDED END ++

    # In a real app, you would use a library like smtplib to send an email
    print("--- NEW INQUIRY ---")
    -- REMOVED START --
    print(f"Recipient: contact@pharma-inc.com")
    -- REMOVED END --
    ++ ADDED START ++
    print(f"Recipient: inquiries@pharma-corp.com")
    ++ ADDED END ++
    print(f"From: {name} <{email}>")
    print(f"Message: {message}")
    print("-------------------")
    
    return jsonify({"message": "Your inquiry has been sent!"})

if __name__ == '__main__':
    app.run(debug=True, port=5000)

```

```html
<!-- contact.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact - Pharma Inc.</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav>
        <a href="/">Home</a> |
        <a href="/about">About Us</a> |
        <a href="/products">Products</a> |
        <a href="/contact">Contact Us</a>
    </nav>
    <div class="content">
        <h1>Contact Us</h1>
        <form id="contact-form">
            <label for="name">Name:</label><br>
            <input type="text" id="name" name="name" required><br>
            <label for="email">Email:</label><br>
            <input type="email" id="email" name="email" required><br>
            <label for="message">Message:</label><br>
            <textarea id="message" name="message" required></textarea><br><br>
            <button type="submit">Send</button>
        </form> 
        <p id="form-status"></p>
        <footer>
            <p>For inquiries, please email us at: 
                -- REMOVED START --
                <a href="mailto:contact@pharma-inc.com">contact@pharma-inc.com</a>
                -- REMOVED END --
                ++ ADDED START ++
                <a href="mailto:inquiries@pharma-corp.com">inquiries@pharma-corp.com</a>
                ++ ADDED END ++
            </p>
        </footer>
    </div>
    <script src="js/main.js"></script>
</body>
</html>
```

```html
<!-- index.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pharma Inc. - Home</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav>
        <a href="/">Home</a> |
        <a href="/about">About Us</a> |
        <a href="/products">Products</a> |
        <a href="/contact">Contact Us</a>
    </nav>
    <div class="content">
        <h1>Welcome to Pharma Inc.</h1>
        <p>Our mission is to innovate for a healthier tomorrow for everyone.</p>
    </div>
</body>
</html>
```

```html
<!-- products.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Products - Pharma Inc.</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav>
        <a href="/">Home</a> |
        <a href="/about">About Us</a> |
        <a href="/products">Products</a> |
        <a href="/contact">Contact Us</a>
    </nav>
    <div class="content">
        <h1>Our Products</h1>
        <ul>
            <li>Product A - For treatment of X</li>
            <li>Product B - For treatment of Y</li>
            <li>Product C - For treatment of Z</li>
        </ul>
    </div>
</body>
</html>
```

```css
/* css/style.css */
body {
    font-family: sans-serif;
    padding: 2em;
}
nav {
    margin-bottom: 2em;
    border-bottom: 1px solid #ccc;
    padding-bottom: 1em;
}
.content {
    max-width: 800px;
}
```

```javascript
/* js/main.js */
document.getElementById('contact-form')?.addEventListener('submit', async function(event) {
    event.preventDefault();
    
    const form = event.target;
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());
    const statusEl = document.getElementById('form-status');

    // Clear previous status message
    statusEl.textContent = '';
    statusEl.style.color = 'inherit'; // Reset color

    try {
        const response = await fetch('http://localhost:5000/api/contact', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        });

        const result = await response.json();

        ++ ADDED START ++
        if (!response.ok) {
            // Handle HTTP errors (e.g., 400 Bad Request)
            statusEl.textContent = result.error || 'An unknown error occurred during submission.';
            statusEl.style.color = 'red';
            return; // Stop further processing on error
        }
        ++ ADDED END ++

        statusEl.textContent = result.message;
        statusEl.style.color = 'green'; // Indicate success
        form.reset();
    } catch (error) {
        console.error('Submission error:', error);
        statusEl.textContent = 'An error occurred. Please try again.';
        statusEl.style.color = 'red';
    }
});
```