```markdown
mule-hubspot-sync/src/main/mule/hubspot-company-sync.xml
```xml
<?xml version="1.0" encoding="UTF-8"?>

<mule xmlns:tls="http://www.mulesoft.org/schema/mule/tls" xmlns:ee="http://www.mulesoft.org/schema/mule/ee/core"
	xmlns:db="http://www.mulesoft.org/schema/mule/db"
	xmlns:http="http://www.mulesoft.org/schema/mule/http" xmlns="http://www.mulesoft.org/schema/mule/core"
	xmlns:doc="http://www.mulesoft.org/schema/mule/documentation" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.mulesoft.org/schema/mule/core http://www.mulesoft.org/schema/mule/core/current/mule.xsd
http://www.mulesoft.org/schema/mule/http http://www.mulesoft.org/schema/mule/http/current/mule-http.xsd
http://www.mulesoft.org/schema/mule/db http://www.mulesoft.org/schema/mule/db/current/mule-db.xsd
http://www.mulesoft.org/schema/mule/ee/core http://www.mulesoft.org/schema/mule/ee/core/current/mule-ee.xsd
http://www.mulesoft.org/schema/mule/tls http://www.mulesoft.org/schema/mule/tls/current/mule-tls.xsd">
	<configuration-properties doc:name="Configuration properties" file="config-${env}.yaml" />
	<http:listener-config name="HTTP_Listener_config" doc:name="HTTP Listener config" doc:id="672b871a-f814-4749-a91c-c7a86d7a9e93" >
		<http:listener-connection host="0.0.0.0" port="${http.port}" />
	</http:listener-config>
	<db:config name="Database_Config" doc:name="Database Config" doc:id="4a669491-48a2-4302-a938-45684a11b17c" >
		<db:basic-connection dataSourceClassName="${db.datasource}" user="${db.user}" password="${db.password}" url="${db.host}" >
			<tls:context >
				<tls:trust-store path="${tls.truststore.path}" password="${tls.truststore.password}" />
			</tls:context>
		</db:basic-connection>
	</db:config>
	<global-property name="hubspot.client.secret" value="${hubspot.client.secret}" doc:name="HubSpot Client Secret" />
	<flow name="mainFlow" doc:id="79473645-1434-491b-9242-5f8365796a9a" >
		<http:listener doc:name="Listener" doc:id="a6319845-6a31-4537-a857-32929698680f" config-ref="HTTP_Listener_config" path="/api/v1/hubspot/company"/>
		<set-variable value="#[uuid()]" doc:name="Set Transaction ID" doc:id="8f5648a6-94f6-4a48-8553-3a3b442d1912" variableName="transactionId"/>
		<logger level="INFO" doc:name="Log Start" doc:id="8650909b-88a8-4911-8a8d-10d4c3470739" message="Start of webhook transaction: #[vars.transactionId]"/>
		<logger level="INFO" doc:name="Log Payload" doc:id="84d78e97-4048-4c36-b318-6f22623837d7" message="Received HubSpot payload: #[json:properties]" />
		<try doc:name="Try" doc:id="38c3667c-71e2-4a42-a37c-b9a3753a63e2" >
			<flow-ref doc:name="validate-hubspot-signature" doc:id="251864e2-544c-494a-b09f-ef77c06a9e27" name="validate-hubspot-signature"/>
			<flow-ref doc:name="transform-data" doc:id="32a7b54b-146b-4f9b-8f0c-6b0b0e4b7b53" name="transform-data"/>
			<flow-ref doc:name="insert-data" doc:id="64747e1f-7650-4299-81d0-5689e72b4b64" name="insert-data"/>
			<error-handler >
				<on-error-propagate enableNotifications="true" logException="true" doc:name="On Error Propagate" doc:id="c706151e-7b4d-45fa-a151-793b15f8e82f" type="ANY">
					<flow-ref doc:name="send-error-notificationFlow" doc:id="0995258e-c561-4a0b-a467-790a364485cf" name="send-error-notificationFlow"/>
					<logger level="ERROR" doc:name="Log Error" doc:id="84076797-c988-492c-a078-913415225f6f" message="Error during webhook processing: #[error.description]"/>
					<set-payload value='#[output application/json ---&#10;{&#10;  "status": "error",&#10;  "message": error.description,&#10;  "hubspotCompanyId": payload.objectId default null,&#10;  "errorCode": error.errorType.identifier default "UNEXPECTED_ERROR"&#10;}]' doc:name="Set Error Payload" doc:id="8d85a9df-5358-4205-b84d-701643453a3f" />
					<set-variable value="500" doc:name="Set Status Code" doc:id="955d416f-12d3-4b12-a949-44352794e388" variableName="httpStatus"/>
				</on-error-propagate>
			</error-handler>
		</try>
		<choice doc:name="Choice" doc:id="38b6f29a-38f9-4a04-9878-2c59024a535c" >
			<when expression="#[vars.httpStatus != null]">
				<set-property attributeName="Content-Type" value="application/json" doc:name="Set Content Type Error" doc:id="67f79767-e9d3-4b1d-b689-516171b29247" />
				<set-property attributeName="httpStatus" value="#[vars.httpStatus]" doc:name="Set HTTP Status Error" doc:id="04122a13-42b8-47e3-9e33-a9d974c41043" />
			</when>
			<otherwise >
				<set-property attributeName="Content-Type" value="application/json" doc:name="Set Content Type Success" doc:id="3622096e-1d75-4011-8e7c-d9537a9691d8" />
				<set-property attributeName="httpStatus" value="200" doc:name="Set HTTP Status Success" doc:id="11b2f9f2-73b8-48d9-9076-05b930c83817" />
			</otherwise>
		</choice>
		<logger level="INFO" doc:name="Log End" doc:id="c9196c2a-c6b1-4c9e-a795-205493a19644" message="End of webhook transaction: #[vars.transactionId] with status #[payload.status]"/>
	</flow>
	<sub-flow name="validate-hubspot-signature" doc:id="f501489a-a1c8-47c3-8649-b47a0519a087" >
		<expression-component doc:name="Expression" doc:id="d048847b-1625-4764-9097-f5cc48c5171b" >
			<![CDATA[
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import org.apache.commons.codec.binary.Hex

def calculateSignature(clientSecret, requestBody) {
    try {
        def signingKey = new SecretKeySpec(clientSecret.getBytes("UTF-8"), "HmacSHA256")
        def mac = Mac.getInstance("HmacSHA256")
        mac.init(signingKey)
        def rawHmac = mac.doFinal(requestBody.getBytes("UTF-8"))
        return new String(Hex.encodeHex(rawHmac))
    } catch (e) {
        // Log the exception for debugging purposes
        println("Error calculating signature: " + e.getMessage())
        return null
    }
}

// Get the client secret from secure properties
def clientSecret = mule.muleContext.getRegistry().lookupObject("hubspot.client.secret")
if (!clientSecret) {
    throw new Exception("HubSpot client secret not found in secure properties.")
}

// Get the request body as a string
def requestBody = message.payload as String

// Calculate the expected signature
def expectedSignature = calculateSignature(clientSecret, requestBody)

// Get the signature from the request header
def hubspotSignature = message.attributes.headers['x-hubspot-signature']

// Validate the signature
if (!expectedSignature) {
    throw new Exception("Failed to calculate expected signature.")
}

if (!hubspotSignature) {
    throw new Exception("X-HubSpot-Signature header is missing.")
}

if (hubspotSignature != expectedSignature) {
    throw new Exception("Invalid HubSpot signature.")
}]]>
		</expression-component>
		<error-handler >
			<on-error-propagate enableNotifications="true" logException="true" doc:name="On Error Propagate" doc:id="c003a28f-b061-4421-9437-99198d07571d" type="ANY">
				<set-payload value='#[output application/json ---&#10;{&#10;  "status": "error",&#10;  "message": error.description,&#10;  "hubspotCompanyId": payload.objectId default null,&#10;  "errorCode": "INVALID_SIGNATURE"&#10;}]' doc:name="Set Error Payload" doc:id="e13b6250-9175-469f-93a7-442096e71e4e" />
				<set-variable value="401" doc:name="Set Status Code" doc:id="931d8a2b-5e8f-444c-a023-349a12a13362" variableName="httpStatus"/>
			</on-error-propagate>
		</error-handler>
	</sub-flow>
	<sub-flow name="transform-data" doc:id="68f9018e-f9d3-4c32-a312-77199017f159" >
		<ee:transform doc:name="Transform Message" doc:id="715c177b-15b6-47a3-bc52-70068905767b" >
			<ee:message >
				<ee:set-payload ><![CDATA[%dw 2.0
output application/java
---
{
	hubspot_company_id: payload.objectId,
	name: payload.properties.name,
	domain: payload.properties.domain,
	number_of_employees: payload.properties.numberofemployees as Number,
	lifecycle_stage: payload.properties.lifecyclestage,
	city: payload.properties.city,
	state: payload.properties.state,
	country: payload.properties.country,
	zip: payload.properties.zip,
	phone: payload.properties.phone
}]]></ee:set-payload>
			</ee:message>
		</ee:transform>
		<error-handler >
			<on-error-propagate enableNotifications="true" logException="true" doc:name="On Error Propagate" doc:id="62005a66-2a20-4c8b-918e-9a6b9f99e66c" type="ANY">
				<set-payload value='#[output application/json ---&#10;{&#10;  "status": "error",&#10;  "message": error.description,&#10;  "hubspotCompanyId": payload.objectId default null,&#10;  "errorCode": "TRANSFORMATION_ERROR"&#10;}]' doc:name="Set Error Payload" doc:id="3859d5b5-3c2b-4711-8106-7752a497b63d" />
				<set-variable value="400" doc:name="Set Status Code" doc:id="6c6b2983-5616-4453-a25b-100f7977f25e" variableName="httpStatus"/>
			</on-error-propagate>
		</error-handler>
	</sub-flow>
	<sub-flow name="insert-data" doc:id="3d5e49e3-7076-4a17-b272-a0116e7d5648" >
		<db:insert doc:name="Insert" doc:id="5114c962-5a95-4c96-971e-a8e626909951" config-ref="Database_Config">
			<db:sql ><![CDATA[INSERT INTO customers (hubspot_company_id, name, domain, number_of_employees, lifecycle_stage, city, state, country, zip, phone)
VALUES (:hubspot_company_id, :name, :domain, :number_of_employees, :lifecycle_stage, :city, :state, :country, :zip, :phone)]]></db:sql>
			<db:input-parameters ><![CDATA[#[payload]]]></db:input-parameters>
		</db:insert>
		<set-variable value="#[payload.generatedKeys[0].id]" doc:name="Set Database Record ID" doc:id="a2b55642-032f-4255-9601-6987f785e265" variableName="databaseRecordId"/>
		<set-payload value='#[output application/json ---&#10;{&#10;  "status": "success",&#10;  "message": "Company record synchronized successfully.",&#10;  "hubspotCompanyId": payload.hubspot_company_id,&#10;  "databaseRecordId": vars.databaseRecordId&#10;}]' doc:name="Set Success Payload" doc:id="1b419826-f1e2-477a-8d28-c037352082a3" />
		<error-handler >
			<on-error-propagate enableNotifications="true" logException="true" doc:name="On Error Propagate" doc:id="66628809-1d86-4633-8f47-59910822f85d" type="ANY">
				<set-payload value='#[output application/json ---&#10;{&#10;  "status": "error",&#10;  "message": error.description,&#10;  "hubspotCompanyId": payload.hubspot_company_id default null,&#10;  "errorCode": "DATABASE_ERROR"&#10;}]' doc:name="Set Error Payload" doc:id="9b49b211-700d-483d-97a4-3f07b960c266" />
				<set-variable value="500" doc:name="Set Status Code" doc:id="65e76057-39d3-41f8-934a-8b83f350704a" variableName="httpStatus"/>
			</on-error-propagate>
		</error-handler>
	</sub-flow>
	<sub-flow name="send-error-notificationFlow" doc:id="43ba4b41-2f88-43d5-9902-05669e934466" >
		<smtp:send doc:name="Send" doc:id="0e46769c-3690-484f-9e5a-81a0e12c1818" config-ref="SMTP_Config">
			<smtp:to-addresses>#[['${mail.to}']]</smtp:to-addresses>
			<smtp:from-address>#[ '${mail.from}' ]</smtp:from-address>
			<smtp:subject>#[ 'Error in HubSpot Company Sync' ]</smtp:subject>
			<smtp:body>#[ 'Error: ' ++ error.description ++ '\nHubSpot Company ID: ' ++ payload.objectId default 'N/A' ]</smtp:body>
		</smtp:send>
	</sub-flow>
	<smtp:config name="SMTP_Config" doc:name="SMTP Config" doc:id="a5d81d99-e6a4-457a-8a14-f804a2180595" >
		<smtp:connection host="${mail.host}" port="${mail.port}" user="${mail.user}" password="${mail.password}" >
			<tls:context >
				<tls:trust-store path="${tls.truststore.path}" password="${tls.truststore.password}" />
			</tls:context>
		</smtp:connection>
	</smtp:config>
</mule>
```

```markdown
mule-hubspot-sync/src/main/resources/config-dev.yaml
```yaml
http:
  port: 8081
db:
  host: jdbc:postgresql://localhost:5432/customerdb
  user: dbuser
  password: dbpassword
  datasource: org.postgresql.Driver
tls:
  truststore:
    path: truststore.jks
    password: password
hubspot:
  client.secret: YOUR_HUBSPOT_CLIENT_SECRET
mail:
  host: smtp.gmail.com
  port: 587
  user: your_email@gmail.com
  password: your_email_password
  to: recipient_email@example.com
  from: your_email@gmail.com
```

```markdown
mule-hubspot-sync/src/main/resources/config-prod.yaml
```yaml
http:
  port: 8081
db:
  host: jdbc:postgresql://prod-db.example.com:5432/customerdb
  user: dbuser
  password: ${secure::db.password}
  datasource: org.postgresql.Driver
tls:
  truststore:
    path: truststore.jks
    password: password
hubspot:
  client.secret: ${secure::hubspot.client.secret}
mail:
  host: smtp.gmail.com
  port: 587
  user: your_email@gmail.com
  password: ${secure::mail.password}
  to: recipient_email@example.com
  from: your_email@gmail.com
```

```markdown
mule-hubspot-sync/src/test/munit/hubspot-company-sync-test-suite.xml
```xml
<?xml version="1.0" encoding="UTF-8"?>

<mule xmlns:tls="http://www.mulesoft.org/schema/mule/tls" xmlns:ee="http://www.mulesoft.org/schema/mule/ee/core"
	xmlns:db="http://www.mulesoft.org/schema/mule/db" xmlns:munit="http://www.mulesoft.org/schema/mule/munit" xmlns:doc="http://www.mulesoft.org/schema/mule/documentation" xmlns="http://www.mulesoft.org/schema/mule/core" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.mulesoft.org/schema/mule/core http://www.mulesoft.org/schema/mule/core/current/mule.xsd
http://www.mulesoft.org/schema/mule/munit http://www.mulesoft.org/schema/mule/munit/current/mule-munit.xsd
http://www.mulesoft.org/schema/mule/db http://www.mulesoft.org/schema/mule/db/current/mule-db.xsd
http://www.mulesoft.org/schema/mule/ee/core http://www.mulesoft.org/schema/mule/ee/core/current/mule-ee.xsd
http://www.mulesoft.org/schema/mule/tls http://www.mulesoft.org/schema/mule/tls/current/mule-tls.xsd">
	<munit:config name="munit" doc:name="MUnit configuration" />
	<configuration-properties doc:name="Configuration properties" file="config-dev.yaml" />
	<munit:test name="mainFlowTest" doc:id="43577319-9411-4321-9871-b58986a6711a" >
		<munit:behavior >
			<munit:set-event doc:name="Set Event" doc:id="87368771-3f2d-4343-8845-47a908130ca6" >
				<munit:payload value='{&#10;  "eventId": 12345,&#10;  "subscriptionId": 67890,&#10;  "portalId": 1234567,&#10;  "occurredAt": 1678886400000,&#10;  "propertyName": "name",&#10;  "propertyValue": "Example Company",&#10;  "changeSource": "CRM_UI",&#10;  "objectId": 98765,&#10;  "propertyNameHistory": {&#10;    "name": [&#10;      {&#10;        "value": "Old Company Name",&#10;        "timestamp": 1678800000000,&#10;        "source": "CRM_UI",&#10;        "sourceId": null&#10;      },&#10;      {&#10;        "value": "Example Company",&#10;        "timestamp": 1678886400000,&#10;        "source": "CRM_UI",&#10;        "sourceId": null&#10;      }&#10;    ]&#10;  },&#10;  "propertyNames": [&#10;    "name",&#10;    "domain",&#10;    "numberofemployees",&#10;    "lifecyclestage",&#10;    "city",&#10;    "state",&#10;    "country",&#10;    "zip",&#10;    "phone"&#10;  ],&#10;  "properties": {&#10;    "name": "Example Company",&#10;    "domain": "example.com",&#10;    "numberofemployees": "50",&#10;    "lifecyclestage": "customer",&#10;    "city": "Anytown",&#10;    "state": "CA",&#10;    "country": "USA",&#10;    "zip": "91234",&#10;    "phone": "555-123-4567"&#10;  }&#10;}' mimeType="application/json" />
			<munit:attributes value="#[{'x-hubspot-signature' : 'd7c5763612583f49f5658b20a6c0f53911207842b9714e2a5d0a0e786d7118a7'}]" />
		</munit:behavior>
		<munit:execution >
			<db:insert doc:name="Mock DB Insert" doc:id="149555a7-7d64-479b-8265-56f6b03676d0" config-ref="Database_Config">
				<munit:before-invocation >
					<munit:execution >
						<munit:mock doc:name="Mock" doc:id="9c849c38-ca48-4748-a15c-12957647995f" whenCalled="#[1]" thenReturn="#[{id: 123}]">
							<munit:match-when expression="#[true]" />
						</munit:mock>
					</munit:execution>
				</munit:before-invocation>
				<db:sql ><![CDATA[INSERT INTO customers (hubspot_company_id, name, domain, number_of_employees, lifecycle_stage, city, state, country, zip, phone)
VALUES (:hubspot_company_id, :name, :domain, :number_of_employees, :lifecycle_stage, :city, :state, :country, :zip, :phone)]]></db:sql>
			</db:insert>
			<flow-ref doc:name="Flow-ref to mainFlow" doc:id="768994f9-0a86-4334-8486-c1674500e358" name="mainFlow" />
		</munit:execution>
		<munit:validation >
			<munit:assert-payload doc:name="Assert payload" doc:id="a6426a3c-616b-4760-b73b-1887d656412a" message="The payload is not correct" >
				<munit:actual-expression ><![CDATA[payload]]></munit:actual-expression>
				<munit:expected-expression ><![CDATA[{
  "status": "success",
  "message": "Company record synchronized successfully.",
  "hubspotCompanyId": 98765,
  "databaseRecordId": 123
}]]></munit:expected-expression>
			</munit:assert-payload>
		</munit:validation>
	</munit:test>
	<munit:test name="validateSignatureFailureTest" doc:id="e0522069-a461-4c39-9315-4014a772e8e5" >
		<munit:behavior >
			<munit:set-event doc:name="Set Event" doc:id="f4209b53-1118-4570-b28b-229c024d15a5" >
				<munit:payload value='{&#10;  "eventId": 12345,&#10;  "subscriptionId": 67890,&#10;  "portalId": 1234567,&#10;  "occurredAt": 1678886400000,&#10;  "propertyName": "name",&#10;  "propertyValue": "Example Company",&#10;  "changeSource": "CRM_UI",&#10;  "objectId": 98765,&#10;  "propertyNameHistory": {&#10;    "name": [&#10;      {&#10;        "value": "Old Company Name",&#10;        "timestamp": 1678800000000,&#10;        "source": "CRM_UI",&#10;        "sourceId": null&#10;      },&#10;      {&#10;        "value": "Example Company",&#10;        "timestamp": 1678886400000,&#10;        "source": "CRM_UI",&#10;        "sourceId": null&#10;      }&#10;    ]&#10;  },&#10;  "propertyNames": [&#10;    "name",&#10;    "domain",&#10;    "numberofemployees",&#10;    "lifecyclestage",&#10;    "city",&#10;    "state",&#10;    "country",&#10;    "zip",&#10;    "phone"&#10;  ],&#10;  "properties": {&#10;    "name": "Example Company",&#10;    "domain": "example.com",&#10;    "numberofemployees": "50",&#10;    "lifecyclestage": "customer",&#10;    "city": "Anytown",&#10;    "state": "CA",&#10;    "country": "USA",&#10;    "zip": "91234",&#10;    "phone": "555-123-4567"&#10;  }&#10;}' mimeType="application/json"/>
			<munit:attributes value="#[{'x-hubspot-signature' : 'invalid_signature'}]" />
		</munit:behavior>
		<munit:execution >
			<flow-ref doc:name="Flow-ref to mainFlow" doc:id="79e1595d-b59c-45a9-9913-f8652f2e510a" name="mainFlow" />
		</munit:execution>
		<munit:validation >
			<munit:assert-payload doc:name="Assert payload" doc:id="32d2920e-91a9-4e06-9b63-63a4238232c4" >
				<munit:actual-expression ><![CDATA[payload.status]]></munit:actual-expression>
				<munit:expected-expression ><![CDATA["error"]]></munit:expected-expression>
			</munit:assert-payload>
		</munit:validation>
	</munit:test>
</mule>
```

```markdown
mule-hubspot-sync/src/main/resources/truststore.jks
```
(Replace with your actual truststore file)

```markdown
pom.xml
```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>

  <groupId>com.example</groupId>
  <artifactId>mule-hubspot-sync</artifactId>
  <version>1.0.0-SNAPSHOT</version>
  <packaging>mule-application</packaging>

  <name>mule-hubspot-sync</name>

  <properties>
    <project.reporting.outputEncoding>UTF-8</project.reporting.outputEncoding>
    <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>

    <mule.maven.plugin.version>4.0.0</mule.maven.plugin.version>
    <mule.sdk.version>4.4.0</mule.sdk.version>
  </properties>

  <dependencies>
    <dependency>
      <groupId>org.mule.connectors</groupId>
      <artifactId>mule-http-