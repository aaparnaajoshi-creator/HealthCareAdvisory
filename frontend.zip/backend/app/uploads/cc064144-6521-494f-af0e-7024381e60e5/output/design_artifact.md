```markdown
# High-Level Design (HLD) - PharmaCorp Commercial Website

## 1. Introduction

This document outlines the high-level design for the PharmaCorp commercial website. It details the architecture, data models, API endpoints, and security considerations based on the provided user stories and technical requirements.

## 2. Architecture Overview

The website will be built using a modular architecture, separating the frontend, backend, and data storage layers. This approach allows for independent scaling and maintenance of each component.

```mermaid
graph LR
    subgraph "User"
        A[User Browser]
    end

    subgraph "Frontend (React)"
        B[React Application]
        C[Static Content (HTML, CSS, JS)]
    end

    subgraph "Backend (FastAPI)"
        D[API Gateway (FastAPI)]
        E[Content Management API]
        F[Search API]
        G[Contact Form API]
        H[Newsletter API]
        I[Cookie Consent API]
        J[Product Information API]
    end

    subgraph "Data Storage"
        K[PostgreSQL Database]
        L[Object Store (AWS S3 or similar)]
    end

    A --> B
    B --> C
    B --> D

    D --> E
    D --> F
    D --> G
    D --> H
    D --> I
    D --> J

    E --> K
    F --> K
    G --> K
    H --> K
    I --> K
    J --> K
    J --> L

    style A fill:#f9f,stroke:#333,stroke-width:2px
    style B fill:#ccf,stroke:#333,stroke-width:2px
    style D fill:#ccf,stroke:#333,stroke-width:2px
    style K fill:#ddf,stroke:#333,stroke-width:2px
    style L fill:#ddf,stroke:#333,stroke-width:2px
```

## 3. Technology Stack

*   **Frontend:** HTML5, CSS3, JavaScript, React
*   **Backend:** Python (FastAPI)
*   **Database:** PostgreSQL
*   **Object Store:** AWS S3 (or similar)
*   **CI/CD:** GitLab CI/CD (or similar)
*   **Web Server:** Nginx

## 4. Data Models and Database Schema

### 4.1. Product Information

```mermaid
erDiagram
    Product {
        uuid product_id PK
        varchar name
        text description
        text indications
        text dosage
        text administration
        text contraindications
        text warnings
        text precautions
        text adverse_reactions
        varchar pi_document_url
        timestamp created_at
        timestamp updated_at
    }
```

### 4.2. Contact Form Submission

```mermaid
erDiagram
    ContactFormSubmission {
        uuid submission_id PK
        varchar name
        varchar email
        varchar subject
        text message
        timestamp submitted_at
    }
```

### 4.3. Newsletter Subscription

```mermaid
erDiagram
    NewsletterSubscription {
        uuid subscription_id PK
        varchar email
        timestamp subscribed_at
        boolean consent
    }
```

### 4.4. Cookie Consent

```mermaid
erDiagram
    CookieConsent {
        uuid consent_id PK
        varchar user_identifier  // Session ID or Hashed IP Address
        json consent_preferences
        timestamp consent_given_at
    }
```

*   `user_identifier`:  Instead of `user_id`, which would require user accounts, we will use either a session ID (if sessions are enabled) or a hashed IP address to track consent.  This approach minimizes data collection and potential privacy concerns.  The hashing algorithm will be a one-way cryptographic hash.

## 5. API Endpoints

### 5.1. Content Management API (Example - Getting Home Page Content)

*   **Endpoint:** `GET /api/content/home`
*   **Request:** None
*   **Response:**

```json
{
    "logo_url": "/images/logo.png",
    "tagline": "PharmaCorp: Improving Lives Through Innovation",
    "navigation": [
        {"label": "About Us", "url": "/about"},
        {"label": "Products", "url": "/products"},
        {"label": "Contact Us", "url": "/contact"}
    ]
}
```

### 5.2. Product Information API

*   **Endpoint:** `GET /api/products`
*   **Request:** None
*   **Response:**

```json
[
    {
        "product_id": "a1b2c3d4-e5f6-7890-1234-567890abcdef",
        "name": "Product A",
        "description": "A brief description of Product A",
        "url": "/products/a1b2c3d4-e5f6-7890-1234-567890abcdef"
    },
    {
        "product_id": "f1e2d3c4-b5a6-7890-1234-567890abcdef",
        "name": "Product B",
        "description": "A brief description of Product B",
        "url": "/products/f1e2d3c4-b5a6-7890-1234-567890abcdef"
    }
]
```

*   **Endpoint:** `GET /api/products/{product_id}`
*   **Request:** None
*   **Response:**

```json
{
    "product_id": "a1b2c3d4-e5f6-7890-1234-567890abcdef",
    "name": "Product A",
    "description": "Detailed description of Product A",
    "indications": "...",
    "dosage": "...",
    "administration": "...",
    "contraindications": "...",
    "warnings": "...",
    "precautions": "...",
    "adverse_reactions": "...",
    "pi_document_url": "/pdfs/ProductA_PrescribingInformation.pdf"
}
```

*   **Endpoint:** `GET /api/products/{product_id}/pi`
    *   **Description:**  Returns a presigned URL for downloading the PI document from the object store.
    *   **Request:** None
    *   **Response:**

```json
{
    "presigned_url": "https://s3.amazonaws.com/pharma-corp-pi/ProductA_PrescribingInformation.pdf?AWSAccessKeyId=XXXXXXXXXXXXXXXXXXXX&Expires=1678886400&Signature=XXXXXXXXXXXXXXXXXXXX"
}
```

### 5.3. Contact Form API

*   **Endpoint:** `POST /api/contact`
*   **Request:**

```json
{
    "name": "John Doe",
    "email": "john.doe@example.com",
    "subject": "Inquiry about Product A",
    "message": "I have a question about Product A."
}
```

*   **Response:**

```json
{
    "status": "success",
    "message": "Your message has been received."
}
```

### 5.4. Newsletter API

*   **Endpoint:** `POST /api/newsletter`
*   **Request:**

```json
{
    "email": "john.doe@example.com",
    "consent": true
}
```

*   **Response:**

```json
{
    "status": "success",
    "message": "You have been subscribed to our newsletter."
}
```

### 5.5. Cookie Consent API

*   **Endpoint:** `POST /api/cookie_consent`
*   **Request:**

```json
{
    "user_identifier": "session_12345", // or hashed IP
    "consent_preferences": {
        "analytics": true,
        "marketing": false
    }
}
```

*   **Response:**

```json
{
    "status": "success",
    "message": "Cookie consent saved."
}
```

### 5.6 Search API

*   **Endpoint:** `GET /api/search?query={search_term}`
*   **Request:**
    *   `query`: The search term entered by the user.
*   **Response:**

```json
[
    {
        "title": "Product A",
        "description": "A brief description of Product A",
        "url": "/products/a1b2c3d4-e5f6-7890-1234-567890abcdef"
    },
    {
        "title": "About Us",
        "description": "Information about PharmaCorp's mission and values.",
        "url": "/about"
    }
]
```

## 6. User Interface (UI) Considerations

*   **Homepage:** Clear navigation, PharmaCorp logo and tagline, responsive design, WCAG 2.2 AA compliance.
*   **About Us:** Mission, values, company history (optional), leadership (optional), clear language, responsive design, WCAG 2.2 AA compliance.
*   **Products Page:** List of products with brief descriptions and links to detail pages, responsive design, WCAG 2.2 AA compliance.
*   **Product Detail Page:**
    *   Product name, indications, dosage, administration, contraindications, warnings, precautions, adverse reactions.
    *   **Sticky Important Safety Information (ISI) Section:**  A section containing critical safety information that remains visible as the user scrolls down the page.  This will be implemented using CSS `position: sticky`.
    *   "Download PI" button/link, responsive design, WCAG 2.2 AA compliance.
*   **Contact Us:** Contact form with validation and CAPTCHA, responsive design, WCAG 2.2 AA compliance.
*   **Search:** Prominently displayed search bar, relevant results, case-insensitive, typo handling, fast loading.
*   **Cookie Consent:** GDPR and CCPA compliant banner/popup with options to accept all, reject non-essential, or customize preferences.
*   **Footer:** Links to privacy policy and terms of use.

## 7. Security Considerations

*   **HTTPS:** Enforce HTTPS for all communication.
*   **CSP:** Implement Content Security Policy to prevent XSS attacks.
*   **Rate Limiting:** Implement rate limiting to prevent abuse of API endpoints.
*   **Input Validation:** Validate all user input to prevent injection attacks.
*   **Authentication/Authorization:** Not explicitly required based on user stories, but consider implementing for internal admin functions (e.g., content management).
*   **Object Store Security:**
    *   **Encryption at Rest:** Encrypt PI documents stored in the object store using server-side encryption (SSE).
    *   **Encryption in Transit:** Ensure all communication with the object store uses HTTPS.
    *   **Access Controls:** Implement strict access controls to limit access to PI documents to authorized users/services only.  Use pre-signed URLs with limited expiration times for controlled access to the documents.

## 8. Deployment

*   **Environments:** Dev, Staging, Prod.
*   **CI/CD Pipeline:** Automated builds, tests, and deployments using GitLab CI/CD (or similar).
*   **Infrastructure:** Cloud-based infrastructure (e.g., AWS, Azure, GCP).
*   **Containerization:** Consider using Docker containers for consistent deployments.
*   **Orchestration:** Consider using Kubernetes for container orchestration.

## 9. Accessibility

*   Adhere to WCAG 2.2 AA accessibility standards throughout the website.
*   Use proper semantic HTML.
*   Provide alt text for images.
*   Ensure sufficient color contrast.
*   Test with assistive technologies (e.g., screen readers).