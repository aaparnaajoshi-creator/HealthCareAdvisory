```markdown
# Dockerfile
```dockerfile
FROM python:3.9-slim-buster

WORKDIR /app

# Set environment variables
ENV PYTHON_UNBUFFERED=1
ENV PYTHONDONTWRITEBYTECODE=1

# Install system dependencies
RUN apt-get update && apt-get install --no-install-recommends -y \
    postgresql-client \
    && rm -rf /var/lib/apt/lists/*

# Copy requirements file
COPY ./backend/requirements.txt /app/requirements.txt

# Install Python dependencies
RUN pip install --no-cache-dir -r /app/requirements.txt

# Copy the application code
COPY ./backend /app

# Expose the application port
EXPOSE 8000

# Command to run the application
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

# docker-compose.yml
```yaml
version: "3.9"

services:
  web:
    build: .
    ports:
      - "8000:8000"
    environment:
      DATABASE_URL: postgresql://user:password@db/pharmacorp
      SECRET_KEY: YOUR_SECRET_KEY
      RECAPTCHA_SITE_KEY: YOUR_RECAPTCHA_SITE_KEY
      RECAPTCHA_SECRET_KEY: YOUR_RECAPTCHA_SECRET_KEY
      EMAIL_API_URL: YOUR_EMAIL_API_URL
      SEED_DATA: "False"
    depends_on:
      - db
    restart: always

  db:
    image: postgres:13
    volumes:
      - db_data:/var/lib/postgresql/data
    environment:
      POSTGRES_USER: user
      POSTGRES_PASSWORD: password
      POSTGRES_DB: pharmacorp
    ports:
      - "5432:5432"
    restart: always

volumes:
  db_data:
```

# README.md
```markdown
# PharmaCorp Commercial Website - Deployment Guide

This document provides instructions for building, configuring, and deploying the PharmaCorp commercial website.

## Table of Contents

1.  [Prerequisites](#prerequisites)
2.  [Building the Application](#building-the-application)
3.  [Configuration](#configuration)
4.  [Database Setup](#database-setup)
5.  [Deployment](#deployment)
6.  [CDN Integration](#cdn-integration)
7.  [Object Storage Configuration](#object-storage-configuration)
8.  [Scaling](#scaling)
9.  [Logging and Monitoring](#logging-and-monitoring)
10. [Environment-Specific Configurations](#environment-specific-configurations)
11. [Security](#security)
12. [Troubleshooting](#troubleshooting)

## 1. Prerequisites

*   Docker and Docker Compose installed on your machine.
*   Basic understanding of containerization concepts.
*   A Git client for cloning the repository.

## 2. Building the Application

1.  Clone the repository:

    ```bash
    git clone <repository_url>
    cd <repository_directory>
    ```

2.  Build the Docker image:

    ```bash
    docker-compose build
    ```

## 3. Configuration

The application is configured using environment variables. The following environment variables are required:

*   `DATABASE_URL`: The connection string for the PostgreSQL database. Example: `postgresql://user:password@db/pharmacorp`
*   `SECRET_KEY`: A secret key used for JWT authentication.  Generate a strong, random key.
*   `RECAPTCHA_SITE_KEY`: The reCAPTCHA site key.
*   `RECAPTCHA_SECRET_KEY`: The reCAPTCHA secret key.
*   `EMAIL_API_URL`: The URL of the email API service.
*   `SEED_DATA`: A boolean value indicating whether to seed the database with initial data on startup (`True` or `False`).  Defaults to `False`.

These environment variables can be set directly in the `docker-compose.yml` file or passed in via your deployment environment.

## 4. Database Setup

The application uses PostgreSQL as its database.

1.  **Initial Setup:** When the application starts for the first time, the database schema will be created automatically using SQLAlchemy's `models.Base.metadata.create_all(bind=engine)`.  This is suitable for development environments.

2.  **Production Migrations (Recommended):** For production environments, it is highly recommended to use Alembic for managing database migrations.

    *   **Install Alembic:** `pip install alembic`
    *   **Initialize Alembic:** `alembic init alembic`
    *   **Configure `alembic.ini`:**  Update the `sqlalchemy.url` setting in `alembic.ini` to match your `DATABASE_URL`.
    *   **Create Migrations:** `alembic revision -m "Initial migration"`
    *   **Apply Migrations:** `alembic upgrade head`

Refer to the Alembic documentation for more detailed instructions: [https://www.alembic.org/](https://www.alembic.org/)

## 5. Deployment

The application can be deployed using Docker Compose.

1.  Start the application:

    ```bash
    docker-compose up -d
    ```

This will start the web application and the PostgreSQL database in detached mode.

## 6. CDN Integration

The application is designed to work with a Content Delivery Network (CDN) for serving static assets. To configure CDN integration:

1.  **Configure Static Asset Serving:** Ensure your frontend application correctly references static assets (images, CSS, JavaScript) using CDN URLs.  The FastAPI backend serves static files from the `/static` directory.
2.  **Cache Headers:**  Configure appropriate cache headers for static assets served by the CDN. This can typically be done within the CDN's management console.  Consider using long cache durations (e.g., 1 year) for versioned assets.
3.  **Invalidation:** Implement a mechanism to invalidate the CDN cache when static assets are updated. This might involve using CDN APIs or a cache-busting strategy (e.g., appending a version number to asset URLs).

## 7. Object Storage Configuration

The application uses an object store (e.g., AWS S3) to store and serve PI/MedGuide PDFs. To configure object storage:

1.  **Upload PDFs:** Upload your PI/MedGuide PDFs to your object storage bucket.
2.  **Update `pi_pdf_url`:**  Ensure the `pi_pdf_url` field in the `Products` table of your database contains the correct URLs for the PDFs in your object storage bucket. These URLs should be publicly accessible, or use pre-signed URLs if you require authentication.
3.  **Configure Permissions:** Properly configure permissions on your object storage bucket to ensure that the PDFs are accessible to the public (or to authenticated users, if using pre-signed URLs).

## 8. Scaling

To scale the application, you can increase the number of web containers.

1.  **Scale Web Containers:**

    ```bash
    docker-compose up --scale web=<number_of_replicas> -d
    ```

2.  **Load Balancer:**  When scaling the web containers, you **MUST** use a load balancer (e.g., Nginx, HAProxy, AWS ELB) to distribute traffic across the containers.  Configure the load balancer to forward traffic to the port exposed by the web containers (port 8000 in this example). Without a load balancer, requests will only be routed to a single container, negating the benefits of scaling.

## 9. Logging and Monitoring

Effective logging and monitoring are crucial for production deployments.

1.  **Logging:** The application uses Python's `logging` module. Configure the logging level and output format to suit your needs. Consider using a centralized logging service (e.g., ELK stack, Graylog) to aggregate logs from all containers.
2.  **Monitoring:** Implement monitoring to track the health and performance of the application. Consider using tools such as:
    *   **Prometheus:** For collecting metrics.
    *   **Grafana:** For visualizing metrics.
    *   **New Relic, Datadog:** Comprehensive monitoring solutions.

Monitor key metrics such as CPU usage, memory usage, request latency, and error rates. Set up alerts to notify you of any issues.

## 10. Environment-Specific Configurations

To manage different configurations for Dev, Staging, and Prod environments:

1.  **Environment Variables:** Use environment variables to store environment-specific settings (e.g., database URLs, API keys).
2.  **`.env` Files (Development):** For local development, you can use `.env` files to manage environment variables.  **Do not commit `.env` files to your repository.**
3.  **CI/CD Pipeline:** Configure your CI/CD pipeline to set the appropriate environment variables for each environment. This may involve using different configuration files or secrets management tools.
4.  **Secrets Management:**  For sensitive information (e.g., database passwords, API keys), use a secrets management solution (e.g., HashiCorp Vault, AWS Secrets Manager) to securely store and manage secrets.

Example using docker-compose overrides:

Create `docker-compose.override.yml`

```yaml
version: "3.9"
services:
  web:
    environment:
      DATABASE_URL: "postgresql://prod_user:prod_password@prod_db/prod_pharmacorp"
      SECRET_KEY: "prod_secret_key"
```

Then deploy with: `docker-compose up -d`

## 11. Security

*   **HTTPS:** Ensure that all communication is encrypted using HTTPS. Configure your load balancer or CDN to handle HTTPS termination.
*   **Regular Security Audits:** Conduct regular security audits to identify and address potential vulnerabilities.
*   **Dependency Updates:** Keep your application dependencies up to date to patch security vulnerabilities.
*   **reCAPTCHA:** Implemented on the contact form to prevent spam and bot submissions.

## 12. Troubleshooting

*   **Application Not Starting:** Check the application logs for errors. Ensure that all required environment variables are set correctly.
*   **Database Connection Errors:** Verify that the database is running and that the `DATABASE_URL` is correct.
*   **Performance Issues:** Monitor the application's performance and identify any bottlenecks. Optimize database queries, implement caching, and scale the application as needed.
*   **reCAPTCHA Failing:** Ensure that the `RECAPTCHA_SITE_KEY` and `RECAPTCHA_SECRET_KEY` are correctly configured.

```