```markdown
# High-Level Design: PharmaCorp Commercial Website

## 1. Introduction

This document outlines the high-level design (HLD) for the PharmaCorp commercial website, catering to both patients and Healthcare Professionals (HCPs). The website aims to provide comprehensive information about PharmaCorp, its products, and related resources, while adhering to strict security, compliance, and performance standards.

## 2. Architecture Overview

The website will be built using a modular architecture, separating the frontend, backend, and data layers. This approach promotes maintainability, scalability, and independent development. The core components include:

*   **Frontend:** A responsive HTML5 and JavaScript application, built using a modern framework.
*   **Backend:** A Python-based API built using FastAPI, responsible for handling requests, processing data, and interacting with the database and object store.
*   **Database:** PostgreSQL will be used for storing website content, user data (e.g., newsletter subscriptions), and form submissions.
*   **Object Store:** An object store (e.g., AWS S3) will store and serve PI/MedGuide PDFs.
*   **CDN:** A Content Delivery Network (CDN) will be used to cache and deliver static assets (images, CSS, JavaScript) globally, improving website performance.

```mermaid
graph LR
    A[User] --> B(CDN);
    B --> C{Frontend (HTML5/JS)};
    C --> D[FastAPI Backend];
    D --> E[(PostgreSQL Database)];
    D --> F[(Object Store (e.g., S3))];
    C --> G[(Search Service)];
    G --> E;
    style E fill:#f9f,stroke:#333,stroke-width:2px
    style F fill:#f9f,stroke:#333,stroke-width:2px
```

## 3. Data Model and Database Schema (PostgreSQL)

The PostgreSQL database will store the following data:

*   **Pages:** (id, title, slug, content, meta_description, created_at, updated_at)
*   **Products:** (id, name, description, indications, dosage, administration, isi_content, pi_pdf_url, therapeutic_area, created_at, updated_at)
*   **Newsletter Subscriptions:** (id, email, subscribed_at, consent)
*   **Contact Form Submissions:** (id, name, email, subject, message, submitted_at)
*   **Users:** (id, username, password_hash, email, role, created_at, updated_at) - For admin access to the CMS

```mermaid
erDiagram
    Page {
        int id PK
        string title
        string slug
        string content
        string meta_description
        datetime created_at
        datetime updated_at
    }
    Product {
        int id PK
        string name
        string description
        string indications
        string dosage
        string administration
        string isi_content
        string pi_pdf_url
        string therapeutic_area
        datetime created_at
        datetime updated_at
    }
    NewsletterSubscription {
        int id PK
        string email
        datetime subscribed_at
        boolean consent
    }
    ContactFormSubmission {
        int id PK
        string name
        string email
        string subject
        string message
        datetime submitted_at
    }
    User {
        int id PK
        string username
        string password_hash
        string email
        string role
        datetime created_at
        datetime updated_at
    }
```

## 4. API Endpoints (FastAPI)

The backend API will provide the following endpoints:

*   **GET /pages/{slug}:** Retrieve a page by its slug.
    *   Request: None
    *   Response:
        ```json
        {
            "id": 1,
            "title": "About Us",
            "slug": "about-us",
            "content": "<h1>About PharmaCorp</h1>...",
            "meta_description": "Learn more about PharmaCorp",
            "created_at": "2024-10-27T10:00:00",
            "updated_at": "2024-10-27T10:00:00"
        }
        ```
    *   Error Handling: 404 Not Found if the page does not exist.

*   **GET /products:** Retrieve a list of products (with optional filtering and sorting).
    *   Request: Optional query parameters for filtering (e.g., therapeutic_area) and sorting (e.g., name).
    *   Response:
        ```json
        [
            {
                "id": 1,
                "name": "Product A",
                "description": "Description of Product A",
                "indications": "Indications for Product A",
                "dosage": "Dosage for Product A",
                "administration": "Administration for Product A",
                "isi_content": "Important Safety Information for Product A",
                "pi_pdf_url": "https://example.com/product-a-pi.pdf",
                "therapeutic_area": "Cardiology",
                "created_at": "2024-10-27T10:00:00",
                "updated_at": "2024-10-27T10:00:00"
            }
        ]
        ```
    *   Error Handling: 400 Bad Request if invalid query parameters are provided.

*   **GET /products/{id}:** Retrieve a specific product by its ID.
    *   Request: None
    *   Response:
        ```json
        {
            "id": 1,
            "name": "Product A",
            "description": "Description of Product A",
             "indications": "Indications for Product A",
                "dosage": "Dosage for Product A",
                "administration": "Administration for Product A",
            "isi_content": "Important Safety Information for Product A",
            "pi_pdf_url": "https://example.com/product-a-pi.pdf",
            "therapeutic_area": "Cardiology",
            "created_at": "2024-10-27T10:00:00",
            "updated_at": "2024-10-27T10:00:00"
        }
        ```
    *   Error Handling: 404 Not Found if the product does not exist.

*   **POST /newsletter:** Subscribe to the newsletter.
    *   Request:
        ```json
        {
            "email": "user@example.com",
            "consent": true
        }
        ```
    *   Response: 201 Created on success.
    *   Error Handling: 400 Bad Request if the email is invalid or consent is missing.

*   **POST /contact:** Submit a contact form.
    *   Request:
        ```json
        {
            "name": "John Doe",
            "email": "john.doe@example.com",
            "subject": "Inquiry",
            "message": "Hello, I have a question..."
        }
        ```
    *   Response: 201 Created on success.
    *   Error Handling: 400 Bad Request if any required fields are missing or invalid.

*   **GET /search?query={query}:** Search for content on the website.
    *   Request: Query parameter `query` containing the search term.
    *   Response:
        ```json
        [
            {
                "type": "page",
                "id": 1,
                "title": "About Us",
                "snippet": "Learn about PharmaCorp's mission..."
            },
            {
                "type": "product",
                "id": 2,
                "name": "Product B",
                "snippet": "Product B is used for..."
            }
        ]
        ```
    *   Error Handling: 400 Bad Request if the query is missing.

*   **POST /admin/login:** Admin login endpoint
    *   Request:
        ```json
        {
            "username": "admin",
            "password": "password"
        }
        ```
    *   Response:
        ```json
        {
            "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhZG1pbiIsImV4cCI6MTcwMzEwODAwMH0.example_jwt"
        }
        ```
    *   Error Handling: 401 Unauthorized if authentication fails.

*   **POST /admin/pages:** Create a new page (requires authentication).
    *   Request: (Page data in JSON format)
    *   Response: 201 Created on success.
    *   Error Handling: 401 Unauthorized if not authenticated, 400 Bad Request if data is invalid.

*   **PUT /admin/pages/{id}:** Update an existing page (requires authentication).
    *   Request: (Page data in JSON format)
    *   Response: 200 OK on success.
    *   Error Handling: 401 Unauthorized if not authenticated, 404 Not Found if page doesn't exist, 400 Bad Request if data is invalid.

*   **DELETE /admin/pages/{id}:** Delete an existing page (requires authentication).
    *   Request: None
    *   Response: 204 No Content on success.
    *   Error Handling: 401 Unauthorized if not authenticated, 404 Not Found if page doesn't exist.

## 5. Search Implementation

The search functionality will be implemented using PostgreSQL's full-text search capabilities. The `to_tsvector` and `to_tsquery` functions will be used to index and search website content.  A GIN index will be created on the `pages` and `products` tables' content columns to improve search performance.  The API will return a list of results, including the type of content (page or product), the ID, title, and a short snippet of the matching text. For complex queries and higher performance needs in the future, consider migrating to a dedicated search service like Elasticsearch.

## 6. Authentication and Authorization

Admin access to the content management system (CMS) will be secured using token-based authentication (JWT).  Upon successful login with a valid username and password, the `/admin/login` endpoint will return a JWT. Subsequent requests to admin endpoints (e.g., `/admin/pages`) will require the JWT in the `Authorization` header (e.g., `Authorization: Bearer <token>`).  Role-based access control (RBAC) will be implemented to restrict access to certain functionalities based on the user's role (e.g., "administrator," "editor"). The `Users` table in the database will store user roles.

## 7. Cookie Consent Mechanism

A JavaScript library (e.g., `cookieconsent`) will be used to display a cookie consent banner upon the user's first visit to the website. The banner will provide options to accept all cookies, reject non-essential cookies, or customize cookie settings. User cookie preferences will be stored in a cookie named `cookie_consent` with a JSON value representing the accepted cookie categories (e.g., `{ "analytics": true, "marketing": false }`). The frontend will then use this information to control which cookies are set.  The privacy policy will be linked from the banner, providing more detailed information on cookie usage.

## 8. Important Safety Information (ISI) - Sticky Element

The ISI section on product detail pages will be implemented using CSS `position: sticky`.  This will ensure that the ISI remains visible as the user scrolls down the page. The sticky element will be styled to be clearly visible and not obstruct other important content. The design will be responsive and adapt to different screen sizes.

## 9. Deployment and CI/CD

The website will be deployed to Dev, Staging, and Prod environments using a CI/CD pipeline. The pipeline will be automated using a CI/CD tool (e.g., Jenkins, GitLab CI, GitHub Actions). The pipeline will include the following steps:

1.  Code commit to a Git repository.
2.  Automated build and testing.
3.  Deployment to the Dev environment.
4.  Automated integration and user acceptance testing in the Staging environment.
5.  Manual approval for deployment to the Prod environment.
6.  Automated deployment to the Prod environment.
7.  Automated rollback capabilities in case of deployment failures.

## 10. Security Measures

The following security measures will be implemented:

*   **HTTPS:** All communication will be encrypted using HTTPS.
*   **CSP:** A Content Security Policy (CSP) will be implemented to prevent cross-site scripting (XSS) attacks.
*   **Rate Limiting:** Rate limiting will be used to prevent denial-of-service (DoS) attacks.
*   **Input Validation:** Input validation will be performed on all user inputs to prevent SQL injection and other injection attacks.
*   **Regular Security Audits:** Regular security audits will be conducted to identify and address potential vulnerabilities.
*   **reCAPTCHA:** reCAPTCHA will be used on the contact form to prevent spam and bot submissions.

## 11. Scalability and Performance

*   **CDN:** Use a CDN to cache and deliver static assets globally.
*   **Database Optimization:** Optimize database queries and schema for performance.
*   **Caching:** Implement caching mechanisms to reduce database load.
*   **Load Balancing:** Use a load balancer to distribute traffic across multiple backend servers.
*   **Asynchronous Tasks:** Use asynchronous tasks (e.g., Celery) to handle long-running operations (e.g., sending emails) without blocking the main thread.

## 12. Compliance

*   **GDPR/CCPA:** The website will comply with GDPR and CCPA regulations, including obtaining explicit consent for data collection, providing users with the ability to access, correct, and delete their personal data, and implementing appropriate security measures to protect personal data.
*   **WCAG 2.2 AA:** The website will adhere to WCAG 2.2 AA accessibility guidelines to ensure usability for people with disabilities.