```markdown
# PharmaCorp Commercial Website - Comprehensive Testing Document

## 1. Test Strategy

### 1.1. Introduction
This document outlines the test strategy for the PharmaCorp Commercial Website project. It defines the scope, objectives, types of testing, and methodologies to ensure the delivery of a high-quality, reliable, secure, and performant web application that meets all specified user stories and acceptance criteria.

### 1.2. Project Overview
The PharmaCorp Commercial Website aims to provide visitors with comprehensive information about the company, its products, and facilitate engagement through features like contact forms and newsletter subscriptions. The website emphasizes responsiveness, accessibility (WCAG 2.2 AA), performance (LCP < 2.5s), and data privacy compliance (GDPR/CCPA).

### 1.3. Scope of Testing
The testing scope encompasses all features and functionalities described in the "PharmaCorp Commercial Website User Stories" document. This includes:
*   **User Interface (UI):** All visible elements, navigation, forms, and content display across various pages.
*   **Functional Requirements:** Verification of all user stories and their acceptance criteria.
*   **API Integrations:** Testing the secure backend APIs for data retrieval (products, search) and submission (contact form, newsletter).
*   **Database Interactions:** Ensuring data is correctly stored and retrieved from the PostgreSQL database.
*   **Non-Functional Requirements:** Performance, security, accessibility, responsiveness, and compliance.
*   **Third-Party Integrations:** Cookie Consent Management.

### 1.4. Test Objectives
The primary objectives of this testing effort are to:
*   **Validate Functionality:** Ensure all features work as per the user stories and acceptance criteria.
*   **Ensure Quality:** Identify and report defects, bugs, and inconsistencies to maintain high product quality.
*   **Verify Responsiveness:** Confirm the website adapts gracefully to various device screen sizes (desktop, tablet, mobile).
*   **Guarantee Accessibility:** Ensure compliance with WCAG 2.2 AA standards for all interactive and static elements.
*   **Assess Performance:** Verify page load times, specifically Largest Contentful Paint (LCP) under 2.5 seconds, and API response times.
*   **Uphold Security:** Confirm secure data transmission (HTTPS), input validation, rate limiting, and secure data storage.
*   **Ensure Compliance:** Validate adherence to GDPR and CCPA regulations for data privacy and cookie consent.
*   **Maintain Data Integrity:** Verify accurate and secure storage and retrieval of data in the PostgreSQL database.
*   **Facilitate Regression:** Establish an automation suite to efficiently re-test existing functionalities after new changes.

### 1.5. Types of Testing

#### 1.5.1. Functional Testing
*   **Unit Testing:** (Performed by developers) Testing individual components/functions of the code.
*   **Integration Testing:** Testing the interaction between different modules (e.g., UI with API, API with database).
*   **System Testing:** End-to-end testing of the complete integrated system against the specified requirements.
    *   **UI Testing:** Verifying the visual aspects, layout, and user interactions.
    *   **Form Testing:** Validating input fields, submission, validation messages, and data storage for Contact Form (US8) and Newsletter Signup (US9).
    *   **Navigation Testing:** Ensuring all links, buttons, and navigation elements lead to the correct pages.
    *   **Content Verification:** Confirming all static and dynamic content is displayed correctly and completely.
    *   **API Testing:** Direct testing of backend API endpoints for data retrieval and submission using tools like Postman or automated scripts.

#### 1.5.2. Non-Functional Testing
*   **Performance Testing:**
    *   **Load Testing:** Assessing system behavior under anticipated user load.
    *   **Stress Testing:** Determining the system's robustness beyond normal operating conditions.
    *   **Speed Testing:** Measuring page load times (LCP < 2.5s) using tools like Lighthouse, PageSpeed Insights, or browser developer tools.
*   **Security Testing:**
    *   **Vulnerability Scanning:** Identifying known security vulnerabilities.
    *   **Penetration Testing (PEN Testing):** Simulating attacks to find exploitable weaknesses.
    *   **Input Validation:** Verifying server-side and client-side validation for all forms.
    *   **Data Transmission:** Ensuring all communication uses HTTPS.
    *   **Rate Limiting:** Testing the effectiveness of rate limiting on API endpoints (US8, US9).
    *   **Data Privacy Compliance:** Auditing data collection, storage, and consent mechanisms against GDPR/CCPA.
*   **Accessibility Testing (A11y):**
    *   Manual and automated checks to ensure WCAG 2.2 AA compliance (e.g., keyboard navigation, screen reader compatibility, sufficient color contrast, proper semantic HTML). Tools like Lighthouse, Axe DevTools, and manual screen reader testing.
*   **Responsiveness Testing:**
    *   Verifying the website's layout and functionality across various screen sizes and orientations (desktop, tablet, mobile) using browser developer tools and emulators.
*   **Cross-Browser Testing:**
    *   Ensuring consistent functionality and appearance across different web browsers (e.g., Chrome, Firefox, Safari, Edge).
*   **Database Testing:**
    *   Verifying data integrity, consistency, and accuracy of data stored and retrieved from the PostgreSQL database.

#### 1.5.3. Regression Testing
*   **Automated Regression:** Utilizing a suite of automated tests to quickly verify that new code changes have not adversely affected existing functionalities.
*   **Manual Regression:** Targeted manual testing for critical paths or areas highly impacted by changes.

#### 1.5.4. Exploratory Testing
*   Unstructured testing by experienced testers to discover defects that might be missed by formal test cases, using creativity and intuition.

### 1.6. Test Environments
*   **Development Environment:** Used by developers for initial testing.
*   **Staging Environment:** A replica of the production environment for comprehensive QA testing, UAT, and performance testing.
*   **Production Environment:** The live environment, subject to post-deployment verification.

### 1.7. Tools and Technologies
*   **Test Management:** JIRA, TestRail (or similar for tracking test cases and results).
*   **Manual Testing:** Browser Developer Tools, Accessibility Checkers (Lighthouse, Axe DevTools), Screen Readers (NVDA, JAWS).
*   **Automation (UI):** Python, Selenium WebDriver, Pytest.
*   **Automation (API):** Python `requests` library, Pytest, Postman.
*   **Performance:** Lighthouse, Google PageSpeed Insights, JMeter (for load testing if required).
*   **Security:** OWASP ZAP, Burp Suite (for penetration testing), manual review for GDPR/CCPA.
*   **Version Control:** Git.

### 1.8. Test Data Management
*   Test data will be created as needed to cover various scenarios (valid, invalid, edge cases).
*   For forms, data will be synthetically generated.
*   For product listings, existing database entries will be utilized.

### 1.9. Roles and Responsibilities
*   **QA Automation Engineer (You):** Develop test strategy, create test plans, design and execute manual test cases, develop and maintain automation scripts, report defects, analyze test results.
*   **Developers:** Perform unit testing, fix reported defects, support QA with environment setup.
*   **Project Manager:** Oversee testing activities, manage schedules, ensure resources, make go/no-go decisions.

### 1.10. Entry and Exit Criteria

#### 1.10.1. Test Entry Criteria
*   User Stories and Acceptance Criteria are finalized and signed off.
*   Test environment is set up and stable.
*   Required test data is available.
*   Development build is deployed to the staging environment.
*   Smoke tests on the new build have passed.

#### 1.10.2. Test Exit Criteria
*   All high and critical priority test cases (manual and automated) have passed.
*   All critical defects are resolved and verified.
*   Acceptable coverage of functional and non-functional requirements.
*   Performance metrics meet the defined thresholds (e.g., LCP < 2.5s).
*   Accessibility compliance (WCAG 2.2 AA) is achieved.
*   Security vulnerabilities are addressed.
*   Regression test suite passes with an acceptable defect rate.
*   Sign-off from relevant stakeholders.

### 1.11. Defect Management
*   Defects will be reported in a chosen defect tracking tool (e.g., JIRA).
*   Each defect report will include a unique ID, title, description, steps to reproduce, actual results, expected results, severity, priority, and environment details.
*   Defects will be triaged, assigned, fixed by developers, and re-tested by QA.

---

## 2. Manual Test Cases

Here are detailed manual test cases covering the core user stories and their acceptance criteria.

### 2.1. Core Website Pages

### Test Case ID: TC_US01_001
**User Story:** US1: Homepage Display
**Test Case Title:** Verify Homepage Content, Responsiveness, Accessibility, and Performance

**Preconditions:**
*   Website is deployed and accessible at `https://www.pharmacorpsite.com/`.
*   A modern web browser (Chrome, Firefox, Edge, Safari) is installed.

**Test Steps:**
1.  Open the web browser and navigate to `https://www.pharmacorpsite.com/`.
2.  **Content Verification:**
    *   Verify the presence of a clear header with primary navigation links: "Home", "About Us", "Products", "Contact Us".
    *   Verify the presence of a prominent hero section with key messaging/featured product.
    *   Verify the presence of a footer with links to "Privacy Policy", "Terms of Use", and the Newsletter Signup form/widget.
3.  **Responsiveness Check:**
    *   Open browser developer tools (F12) and activate device emulation mode.
    *   Select various common device screen sizes (e.g., iPhone SE, iPad Air, Desktop 1920x1080) and orientations (portrait/landscape for mobile/tablet).
    *   Observe the page layout, content flow, image scaling, and navigation menu behavior (e.g., hamburger menu on mobile).
4.  **Accessibility Check (WCAG 2.2 AA):**
    *   Use an accessibility testing tool (e.g., Lighthouse in Chrome DevTools, Axe DevTools extension) to scan the page. Review reported issues.
    *   Manually test keyboard navigation: Tab through all interactive elements (links, buttons, form fields). Ensure focus is visible and logical.
    *   Manually check for sufficient color contrast using a contrast checker tool for text and interactive elements.
5.  **Performance Check (LCP):**
    *   Open browser developer tools, go to the "Performance" or "Lighthouse" tab.
    *   Run a performance audit (ensure throttling is applied for consistent results).
    *   Locate the "Largest Contentful Paint" (LCP) metric.
6.  **HTTPS Verification:**
    *   Observe the browser's address bar.

**Expected Result:**
*   **Content:** All specified header, hero, and footer elements are present and correctly displayed. Navigation links are clickable.
*   **Responsiveness:** The page adapts gracefully to all tested device screen sizes and orientations without horizontal scrolling, overlapping content, or broken layouts. Navigation menus transform appropriately (e.g., into a hamburger menu on mobile).
*   **Accessibility:** No critical or serious accessibility violations are reported by automated tools. Keyboard navigation is smooth and logical. Color contrasts meet WCAG 2.2 AA requirements.
*   **Performance:** The LCP metric is reported as under 2.5 seconds.
*   **HTTPS:** The URL displays `https://` and a secure padlock icon, indicating content is served over HTTPS.

**Priority:** High
**Status:**

### Test Case ID: TC_US02_001
**User Story:** US2: About Us Page Display
**Test Case Title:** Verify About Us Page Content, Responsiveness, Accessibility, and Performance

**Preconditions:**
*   Website is deployed and accessible.
*   User is on the homepage (US1 verified).

**Test Steps:**
1.  Navigate to the "About Us" page via the primary navigation link.
2.  **Content Verification:**
    *   Verify the presence of sections detailing PharmaCorp's mission and vision.
    *   Verify the presence of information on core values and principles.
    *   Verify the presence of a summary of the company's history and key milestones.
    *   Ensure all text content is legible and images (if any) are relevant and properly displayed.
3.  **Responsiveness, Accessibility, Performance, HTTPS:**
    *   Repeat steps 3, 4, 5, and 6 from TC_US01_001 for the "About Us" page.

**Expected Result:**
*   **Content:** The "About Us" page loads successfully with all specified company information clearly displayed.
*   **Non-Functional:** The page exhibits responsiveness, WCAG 2.2 AA accessibility, LCP under 2.5 seconds, and is served over HTTPS, consistent with TC_US01_001.

**Priority:** High
**Status:**

### Test Case ID: TC_US03_001
**User Story:** US3: Contact Us Page Display
**Test Case Title:** Verify Contact Us Page Content, Responsiveness, Accessibility, and Performance

**Preconditions:**
*   Website is deployed and accessible.
*   User is on the homepage (US1 verified).

**Test Steps:**
1.  Navigate to the "Contact Us" page via the primary navigation link.
2.  **Content Verification:**
    *   Verify the presence of general company address and phone number.
    *   Verify the presence of a link or embedded section for the Contact Form (US8).
3.  **Responsiveness, Accessibility, Performance, HTTPS:**
    *   Repeat steps 3, 4, 5, and 6 from TC_US01_001 for the "Contact Us" page.

**Expected Result:**
*   **Content:** The "Contact Us" page loads successfully with clear contact details and the presence of the contact form/link.
*   **Non-Functional:** The page exhibits responsiveness, WCAG 2.2 AA accessibility, LCP under 2.5 seconds, and is served over HTTPS, consistent with TC_US01_001.

**Priority:** High
**Status:**

### Test Case ID: TC_US04_001
**User Story:** US4: Privacy Policy Page Display
**Test Case Title:** Verify Privacy Policy Page Content, Compliance, Responsiveness, Accessibility, and Performance

**Preconditions:**
*   Website is deployed and accessible.
*   User is on the homepage (US1 verified).

**Test Steps:**
1.  Navigate to the "Privacy Policy" page via the footer link.
2.  **Content and Compliance Verification:**
    *   Verify the presence of a complete and current privacy policy document.
    *   Scan the content to confirm it outlines: Types of data collected, purposes of data collection, data retention periods, user rights (access, rectification, erasure), and mechanisms for exercising rights. (Note: A full legal review is outside QA scope but basic content presence can be checked).
    *   Ensure the content explicitly mentions compliance with GDPR and CCPA regulations.
3.  **Responsiveness, Accessibility, Performance, HTTPS:**
    *   Repeat steps 3, 4, 5, and 6 from TC_US01_001 for the "Privacy Policy" page.

**Expected Result:**
*   **Content & Compliance:** The "Privacy Policy" page loads with a comprehensive policy document covering specified data handling aspects and explicitly mentioning GDPR/CCPA compliance.
*   **Non-Functional:** The page exhibits responsiveness, WCAG 2.2 AA accessibility, LCP under 2.5 seconds, and is served over HTTPS, consistent with TC_US01_001.

**Priority:** Medium
**Status:**

### Test Case ID: TC_US05_001
**User Story:** US5: Terms of Use Page Display
**Test Case Title:** Verify Terms of Use Page Content, Responsiveness, Accessibility, and Performance

**Preconditions:**
*   Website is deployed and accessible.
*   User is on the homepage (US1 verified).

**Test Steps:**
1.  Navigate to the "Terms of Use" page via the footer link.
2.  **Content Verification:**
    *   Verify the presence of a complete and current terms of use document.
    *   Ensure the content clearly outlines the legal terms and conditions for website usage.
3.  **Responsiveness, Accessibility, Performance, HTTPS:**
    *   Repeat steps 3, 4, 5, and 6 from TC_US01_001 for the "Terms of Use" page.

**Expected Result:**
*   **Content:** The "Terms of Use" page loads with a comprehensive document detailing legal terms and conditions.
*   **Non-Functional:** The page exhibits responsiveness, WCAG 2.2 AA accessibility, LCP under 2.5 seconds, and is served over HTTPS, consistent with TC_US01_001.

**Priority:** Medium
**Status:**

### 2.2. Product Information

### Test Case ID: TC_US06_001
**User Story:** US6: Product List Page Display
**Test Case Title:** Verify Product List Page Content, Dynamic Data, Responsiveness, Accessibility, and Performance

**Preconditions:**
*   Website is deployed and accessible.
*   At least 3 products exist in the PostgreSQL database.
*   User is on the homepage (US1 verified).

**Test Steps:**
1.  Navigate to the "Products" list page via the primary navigation link.
2.  **Content and Dynamic Data Verification:**
    *   Verify that a catalog of PharmaCorp's products is displayed.
    *   For each product entry, verify that at least its name and a brief description are visible.
    *   Verify that each product entry includes a clear link or button that navigates to the respective Product Detail Page (US7). Click on a few links to confirm navigation.
    *   (Optional, if possible) Compare displayed product names/descriptions with expected data from the backend/database to confirm dynamic retrieval.
3.  **Responsiveness, Accessibility, Performance, HTTPS:**
    *   Repeat steps 3, 4, 5, and 6 from TC_US01_001 for the "Products" list page.

**Expected Result:**
*   **Content & Data:** The "Products" page loads successfully, displaying a catalog of products with names, descriptions, and functional links to detail pages. Product information is dynamically retrieved and accurate.
*   **Non-Functional:** The page exhibits responsiveness, WCAG 2.2 AA accessibility, LCP under 2.5 seconds, and is served over HTTPS, consistent with TC_US01_001.

**Priority:** High
**Status:**

### Test Case ID: TC_US07_001
**User Story:** US7: Product Detail Page Display
**Test Case Title:** Verify Product Detail Page Content, Dynamic Data, ISI, PI PDF Link, Responsiveness, Accessibility, and Performance

**Preconditions:**
*   Website is deployed and accessible.
*   At least one specific product with detailed information (including ISI and PI PDF) exists in the PostgreSQL database.
*   User is on the Product List Page (US6 verified) or has a direct URL to a product detail page.

**Test Steps:**
1.  Navigate to a specific product's detail page (e.g., by clicking a product link from US6 or directly to `/products/{product-slug}`).
2.  **Content and Dynamic Data Verification:**
    *   Verify the display of the product name and a detailed description.
    *   Verify the presence of sections for Indications, Dosage, and Administration information.
    *   Verify the presence of a dedicated section for "Important Safety Information (ISI)".
    *   Verify the presence of a clear link or button labeled "Download PI PDF" (or similar).
    *   (Optional, if possible) Compare displayed product details with expected data from the backend/database.
3.  **Responsiveness, Accessibility, Performance, HTTPS:**
    *   Repeat steps 3, 4, 5, and 6 from TC_US01_001 for the "Product Detail" page.

**Expected Result:**
*   **Content & Data:** The product detail page loads successfully, displaying comprehensive, dynamically retrieved information for the specific product, including ISI and a clear PI PDF download link.
*   **Non-Functional:** The page exhibits responsiveness, WCAG 2.2 AA accessibility, LCP under 2.5 seconds, and is served over HTTPS, consistent with TC_US01_001.

**Priority:** High
**Status:**

### 2.3. Website Features

### Test Case ID: TC_US08_001
**User Story:** US8: Contact Form Submission
**Test Case Title:** Verify Contact Form Functionality, Validation, Submission, and Data Storage

**Preconditions:**
*   Website is deployed and accessible.
*   User is on the "Contact Us" page (US3 verified).
*   Backend API for form submission is operational and connected to the PostgreSQL database.

**Test Steps:**
1.  Navigate to the "Contact Us" page.
2.  **Form Field Verification:**
    *   Verify the presence of "Name", "Email", "Subject", and "Message" fields.
    *   Ensure all fields are marked as required (e.g., with an asterisk or "required" attribute).
    *   Verify "Email" field type is `email`.
3.  **Client-Side Validation (Invalid Email):**
    *   Enter valid data in "Name", "Subject", "Message".
    *   Enter an invalid email format (e.g., "test@") into the "Email" field.
    *   Click "Submit".
    *   Verify that a client-side validation error message appears for the email field, preventing submission.
4.  **Server-Side Validation (Missing Required Field):**
    *   Enter valid data in "Name", "Email", "Message".
    *   Leave the "Subject" field empty.
    *   Click "Submit".
    *   Verify that a server-side validation error message appears for the missing "Subject" field.
5.  **Successful Submission:**
    *   Fill all required fields with valid, unique information (e.g., Name: "John Doe", Email: "john.doe@example.com", Subject: "Inquiry about Product X", Message: "I have a question...").
    *   Click "Submit".
    *   Verify that a confirmation message is displayed on screen (e.g., "Thank you for your inquiry, we will get back to you shortly.").
6.  **Database Verification (Post-submission):**
    *   (Requires backend/DB access) Query the PostgreSQL database to confirm the submitted form data (Name, Email, Subject, Message) is securely stored.
7.  **Rate Limiting Test (Exploratory/Performance):**
    *   Attempt to submit the form multiple times in rapid succession (e.g., 5-10 times within 10-15 seconds).
    *   Verify that after a few submissions, subsequent submissions are blocked or receive a rate-limiting error message (e.g., "Too many requests. Please try again later.").
8.  **GDPR/CCPA Compliance Check:**
    *   Review the form and surrounding text for explicit statements on data usage and privacy, ensuring no sensitive personal data beyond inquiry details is requested.
9.  **Responsiveness, Accessibility, HTTPS:**
    *   Repeat steps 3, 4, and 6 from TC_US01_001 (for responsiveness and accessibility of the form itself) and verify form submission is over HTTPS.

**Expected Result:**
*   **Fields:** All specified form fields are present and correctly typed/marked as required.
*   **Validation:** Both client-side (for email format) and server-side (for required fields) validations function correctly, preventing invalid submissions and providing clear feedback.
*   **Submission:** Valid form submissions result in an on-screen confirmation message.
*   **Data Storage:** Submitted data is securely stored in the PostgreSQL database.
*   **Rate Limiting:** Backend API successfully enforces rate limiting, preventing abuse.
*   **Compliance:** Form adheres to GDPR/CCPA principles.
*   **Non-Functional:** The form is responsive, WCAG 2.2 AA accessible, and submission occurs over HTTPS.

**Priority:** High
**Status:**

### Test Case ID: TC_US09_001
**User Story:** US9: Newsletter Signup
**Test Case Title:** Verify Newsletter Signup Functionality, Validation, Consent, Submission, and Data Storage

**Preconditions:**
*   Website is deployed and accessible.
*   Newsletter signup form/widget is present (e.g., in the footer).
*   Backend API for subscription is operational and connected to the PostgreSQL database.

**Test Steps:**
1.  Navigate to any page displaying the newsletter signup form/widget (e.g., homepage footer).
2.  **Form Field and Consent Verification:**
    *   Verify the presence of an "Email Address" field.
    *   Ensure the email field is marked as required.
    *   Verify the presence of a checkbox for explicit consent for marketing communications (e.g., "I agree to receive marketing communications").
    *   Ensure clear text explaining what the user is signing up for is present.
3.  **Client-Side Validation (Invalid Email):**
    *   Enter an invalid email format (e.g., "invalid@") into the "Email Address" field.
    *   Check the consent box.
    *   Click "Subscribe".
    *   Verify that a client-side validation error message appears for the email field.
4.  **Server-Side Validation (Missing Consent):**
    *   Enter a valid email address (e.g., "test@example.com").
    *   Leave the consent checkbox unchecked.
    *   Click "Subscribe".
    *   Verify that a server-side validation error message appears, requiring explicit consent.
5.  **Successful Submission:**
    *   Enter a valid, unique email address (e.g., "newsubscriber@example.com").
    *   Check the consent box.
    *   Click "Subscribe".
    *   Verify that a confirmation message is displayed on screen (e.g., "Thank you for subscribing!").
6.  **Database Verification (Post-submission):**
    *   (Requires backend/DB access) Query the PostgreSQL database to confirm the submitted email address is securely stored.
7.  **Rate Limiting Test (Exploratory/Performance):**
    *   Attempt to submit the form multiple times in rapid succession.
    *   Verify that after a few submissions, subsequent submissions are blocked or receive a rate-limiting error message.
8.  **GDPR/CCPA Compliance Check:**
    *   Review the form for clear purpose, explicit consent, and no collection of unnecessary data.
9.  **Responsiveness, Accessibility, HTTPS:**
    *   Repeat steps 3, 4, and 6 from TC_US01_001 (for responsiveness and accessibility of the form itself) and verify form submission is over HTTPS.

**Expected Result:**
*   **Fields & Consent:** Email field and explicit consent checkbox are present. Clear signup statement.
*   **Validation:** Both client-side (for email format) and server-side (for consent) validations function correctly.
*   **Submission:** Valid submissions with consent result in an on-screen confirmation message.
*   **Data Storage:** Submitted email address is securely stored in the PostgreSQL database.
*   **Rate Limiting:** Backend API successfully enforces rate limiting.
*   **Compliance:** Form adheres to GDPR/CCPA principles for consent.
*   **Non-Functional:** The form is responsive, WCAG 2.2 AA accessible, and submission occurs over HTTPS.

**Priority:** High
**Status:**

### Test Case ID: TC_US10_001
**User Story:** US10: Sticky Important Safety Information (ISI)
**Test Case Title:** Verify Sticky ISI Functionality, Responsiveness, and Accessibility

**Preconditions:**
*   Website is deployed and accessible.
*   User is on a Product Detail Page (US7 verified) that contains an ISI section.

**Test Steps:**
1.  Navigate to a Product Detail Page that has a visible ISI section.
2.  **Sticky Functionality:**
    *   Observe the initial position of the ISI section.
    *   Scroll down the page significantly, ensuring the main content scrolls past.
    *   Verify that the ISI section remains fixed in a visible position on the screen (e.g., sticky footer, sidebar).
    *   Scroll back up and down to confirm its persistence.
3.  **Responsiveness Check:**
    *   Open browser developer tools and switch to responsive design mode.
    *   Select various common device screen sizes (e.g., iPhone SE, iPad Air) and orientations.
    *   Scroll the page on each device size.
    *   Verify that the sticky ISI component remains visible and does not obstruct other critical content (e.g., product details, PI PDF link).
4.  **Accessibility Check (WCAG 2.2 AA):**
    *   Use an accessibility testing tool (e.g., Lighthouse, Axe DevTools) to scan the sticky ISI component.
    *   Manually test keyboard navigation into and out of the sticky ISI component. Ensure it's reachable and focus is visible.
    *   Verify sufficient color contrast for the ISI text and background.
    *   Check for proper semantic markup (e.g., appropriate ARIA roles if dynamically handled).

**Expected Result:**
*   **Sticky:** The ISI section remains fixed and visible on the screen as the user scrolls, providing continuous reference.
*   **Responsiveness:** The sticky ISI component adapts correctly to various screen sizes, never obscuring other critical page content.
*   **Accessibility:** The sticky ISI component passes automated accessibility checks, is keyboard navigable, has sufficient contrast, and uses proper semantic markup.

**Priority:** High
**Status:**

### Test Case ID: TC_US11_001
**User Story:** US11: Product Information (PI) PDF Download
**Test Case Title:** Verify PI PDF Download Functionality and Security

**Preconditions:**
*   Website is deployed and accessible.
*   User is on a Product Detail Page (US7 verified) with a "Download PI PDF" link.
*   The corresponding PDF file is available and accessible via the backend endpoint.

**Test Steps:**
1.  Navigate to a Product Detail Page.
2.  **Link Verification:**
    *   Verify the presence of a clear link or button labeled "Download PI PDF" (or similar).
    *   (Accessibility) Hover over the link/button and ensure its purpose is clear. If using a screen reader, verify descriptive text.
3.  **Download Functionality:**
    *   Click the "Download PI PDF" link/button.
    *   Observe browser behavior.
    *   Verify that the PDF file either opens in a new browser tab/window or initiates a direct download to the device.
4.  **Security Verification:**
    *   If the PDF opens in a new tab, verify that the URL for the PDF also uses `https://`.
    *   (Optional, if possible) Intercept network traffic to confirm the PDF request is made over HTTPS and served from the expected secure object storage solution via the backend.

**Expected Result:**
*   **Link:** A clear, accessible "Download PI PDF" link/button is present.
*   **Download:** Clicking the link/button successfully opens the corresponding PDF in a new tab or initiates a direct download.
*   **Security:** The PDF is served securely over HTTPS.

**Priority:** High
**Status:**

### Test Case ID: TC_US12_001
**User Story:** US12: Site Search Functionality
**Test Case Title:** Verify Site Search Bar, Results Page, Relevance, Responsiveness, and Accessibility

**Preconditions:**
*   Website is deployed and accessible.
*   Search functionality is integrated with the backend API.
*   At least 2-3 products/pages are indexed for search.

**Test Steps:**
1.  Navigate to any page of the website (e.g., Homepage).
2.  **Search Bar/Icon Verification:**
    *   Verify the presence of a prominent search bar or an easily identifiable search icon (e.g., magnifying glass) in the header.
    *   If an icon, click it to ensure it expands or reveals the search bar.
3.  **Search and Redirection:**
    *   Type a relevant search query (e.g., a product name like "Product X" or "PharmaCorp mission") into the search bar.
    *   Submit the query (e.g., by pressing Enter or clicking a search button).
    *   Verify that the browser redirects to a dedicated search results page.
4.  **Search Results Verification:**
    *   On the search results page, verify that a list of relevant content snippets is displayed (e.g., product names, page titles, brief descriptions).
    *   Verify that each result snippet includes a clickable link to the full content.
    *   Verify that results are ordered by relevance to the query (manual assessment).
    *   Test with a query that should yield no results (e.g., "nonexistent product"). Verify an appropriate "No results found" message is displayed.
5.  **Responsiveness, Accessibility, HTTPS:**
    *   Repeat steps 3, 4, and 6 from TC_US01_001 for the search bar (if it's a modal/overlay) and the search results page.
    *   Verify search queries are processed over HTTPS.

**Expected Result:**
*   **Search Interface:** A prominent and functional search bar/icon is present.
*   **Redirection:** Submitting a query redirects to a dedicated search results page.
*   **Results:** The search results page displays relevant content snippets with links, ordered by relevance. A clear message is shown for no results.
*   **Non-Functional:** The search functionality (bar and results page) is responsive, WCAG 2.2 AA accessible, and operates over HTTPS.

**Priority:** High
**Status:**

### Test Case ID: TC_US13_001
**User Story:** US13: Cookie Consent Management
**Test Case Title:** Verify Cookie Consent Banner, Preference Management, and Compliance

**Preconditions:**
*   Website is deployed and accessible.
*   User has never visited the site before, or browser cookies have been cleared.

**Test Steps:**
1.  Clear browser cookies and local storage for the website.
2.  Navigate to the website's root URL.
3.  **Banner Display and Options Verification:**
    *   Verify that a clear, non-intrusive cookie consent banner or pop-up appears.
    *   Verify that the banner/pop-up informs about cookie usage.
    *   Verify the presence of distinct options: "Accept All", "Reject All", "Manage Preferences".
4.  **"Accept All" Flow:**
    *   (Starting from step 1 again) Clear cookies.
    *   Click "Accept All" on the banner.
    *   Verify the banner disappears.
    *   Navigate to other pages; verify the banner does not reappear.
    *   (Optional) Check browser cookies; verify non-essential cookies (e.g., analytics) are set.
5.  **"Reject All" Flow:**
    *   (Starting from step 1 again) Clear cookies.
    *   Click "Reject All" on the banner.
    *   Verify the banner disappears.
    *   Navigate to other pages; verify the banner does not reappear.
    *   (Optional) Check browser cookies; verify only strictly necessary cookies are set, and non-essential ones are absent.
6.  **"Manage Preferences" Flow:**
    *   (Starting from step 1 again) Clear cookies.
    *   Click "Manage Preferences" on the banner.
    *   Verify that a detailed interface appears, allowing users to enable/disable different categories of cookies (e.g., strictly necessary, analytics, marketing) with clear descriptions.
    *   Disable "Analytics" and "Marketing" cookies, but keep "Strictly Necessary" enabled.
    *   Click "Save Preferences" or similar button.
    *   Verify the preference management interface closes, and the banner disappears.
    *   Navigate to other pages; verify the banner does not reappear.
    *   (Optional) Check browser cookies; verify only strictly necessary cookies are set, and categories explicitly disabled are absent.
7.  **Withdraw Consent (Re-accessing Preferences):**
    *   Verify there is a way to re-access cookie preferences (e.g., a small link in the footer or a dedicated "Cookie Settings" page).
    *   Click this link/button.
    *   Verify the preference management interface reappears, showing previously saved preferences.
    *   Change preferences (e.g., enable "Marketing" cookies) and save.
    *   Verify the changes are applied (via cookie inspection or observing related functionality).
8.  **GDPR/CCPA Compliance Check:**
    *   Review the banner and preference interface for clear language, explicit consent mechanisms, and easy withdrawal of consent.
9.  **Responsiveness, Accessibility:**
    *   Repeat steps 3 and 4 from TC_US01_001 for the cookie consent banner and preference management interface.

**Expected Result:**
*   **Banner:** A clear, non-intrusive cookie consent banner appears on first visit/cleared cookies, offering "Accept All", "Reject All", and "Manage Preferences" options.
*   **Preference Management:** "Manage Preferences" leads to a detailed, categorized interface for granular control.
*   **Consent Persistence:** Chosen preferences (Accept, Reject, Custom) are remembered for subsequent visits.
*   **Withdrawal:** Users can easily re-access and modify their cookie preferences at any time.
*   **Compliance:** The mechanism fully complies with GDPR and CCPA, including explicit consent and withdrawal.
*   **Non-Functional:** The banner and preference interface are responsive and WCAG 2.2 AA accessible.

**Priority:** High
**Status:**

---

## 3. Automation Test Scripts (Python, Selenium WebDriver, Pytest)

This section provides automation test scripts for critical user stories. The scripts are structured using the Page Object Model (POM) for maintainability and scalability.

**Assumptions:**
*   Python 3.x is installed.
*   `pip` is installed.
*   `selenium` and `pytest` are installed (`pip install selenium pytest`).
*   ChromeDriver (or equivalent for your browser) is downloaded and its path is added to system PATH or specified in `conftest.py`.
*   The website is running at `http://localhost:8000` (or specified `BASE_URL`).

### Project Structure:

```
PharmaCorp_Automation/
├── config.py
├── conftest.py
├── pages/
│   ├── base_page.py
│   ├── homepage.py
│   ├── contact_us_page.py
│   └── newsletter_form_component.py
└── tests/
    ├── test_homepage.py
    ├── test_contact_us.py
    └── test_newsletter_signup.py
```

### 3.1. `config.py`

```python
# config.py
class Config:
    BASE_URL = "https://www.pharmacorpsite.com/" # Replace with actual URL
    BROWSER = "chrome" # Or "firefox", "edge"
    IMPLICIT_WAIT_TIME = 10
    PAGE_LOAD_TIMEOUT = 30

    # Test Data for Contact Form
    CONTACT_NAME = "Automation Tester"
    CONTACT_EMAIL = "test@automation.com"
    CONTACT_SUBJECT = "Automated Inquiry"
    CONTACT_MESSAGE = "This is an automated test message for PharmaCorp."

    # Test Data for Newsletter Signup
    NEWSLETTER_EMAIL = "newsletter_test@automation.com"
```

### 3.2. `conftest.py`

```python
# conftest.py
import pytest
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.firefox.service import Service as FirefoxService
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager
from config import Config

@pytest.fixture(scope="session")
def setup_browser(request):
    """
    Fixture to set up and tear down the WebDriver instance.
    Supports Chrome and Firefox.
    """
    browser_name = Config.BROWSER.lower()
    driver = None

    if browser_name == "chrome":
        service = ChromeService(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service)
    elif browser_name == "firefox":
        service = FirefoxService(GeckoDriverManager().install())
        driver = webdriver.Firefox(service=service)
    else:
        raise ValueError(f"Unsupported browser: {browser_name}")

    driver.implicitly_wait(Config.IMPLICIT_WAIT_TIME)
    driver.set_page_load_timeout(Config.PAGE_LOAD_TIMEOUT)
    driver.maximize_window()

    yield driver
    driver.quit()

@pytest.fixture(scope="function")
def browser(setup_browser):
    """
    Fixture to provide a fresh browser state for each test function.
    Navigates to BASE_URL before each test.
    """
    driver = setup_browser
    driver.get(Config.BASE_URL)
    yield driver
    # Optional: Clear cookies or perform other cleanup if needed for true isolation
    # driver.delete_all_cookies()
```

### 3.3. `pages/base_page.py`

```python
# pages/base_page.py
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from config import Config

class BasePage:
    """Base class for all Page Objects."""

    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, Config.IMPLICIT_WAIT_TIME)

    def go_to_url(self, url):
        self.driver.get(url)

    def get_title(self):
        return self.driver.title

    def get_current_url(self):
        return self.driver.current_url

    def is_element_present(self, by_locator):
        try:
            self.driver.find_element(*by_locator)
            return True
        except:
            return False

    def wait_for_element_visible(self, by_locator):
        return self.wait.until(EC.visibility_of_element_located(by_locator))

    def wait_for_element_clickable(self, by_locator):
        return self.wait.until(EC.element_to_be_clickable(by_locator))

    def click_element(self, by_locator):
        self.wait_for_element_clickable(by_locator).click()

    def enter_text(self, by_locator, text):
        element = self.wait_for_element_visible(by_locator)
        element.clear()
        element.send_keys(text)

    def get_element_text(self, by_locator):
        return self.wait_for_element_visible(by_locator).text

    def check_https(self):
        return self.get_current_url().startswith("https://")

    # Common navigation elements
    NAV_HOME = (By.LINK_TEXT, "Home")
    NAV_ABOUT_US = (By.LINK_TEXT, "About Us")
    NAV_PRODUCTS = (By.LINK_TEXT, "Products")
    NAV_CONTACT_US = (By.LINK_TEXT, "Contact Us")
    FOOTER_PRIVACY_POLICY = (By.LINK_TEXT, "Privacy Policy")
    FOOTER_TERMS_OF_USE = (By.LINK_TEXT, "Terms of Use")
```

### 3.4. `pages/homepage.py`

```python
# pages/homepage.py
from selenium.webdriver.common.by import By
from pages.base_page import BasePage
from config import Config

class HomePage(BasePage):
    """Page Object for the PharmaCorp Homepage."""

    # Locators
    HEADER = (By.TAG_NAME, "header")
    HERO_SECTION = (By.CSS_SELECTOR, ".hero-section") # Assuming a class for hero section
    FOOTER = (By.TAG_NAME, "footer")
    NEWSLETTER_SIGNUP_SECTION = (By.ID, "newsletter-signup-footer") # Assuming an ID for footer newsletter

    def __init__(self, driver):
        super().__init__(driver)
        self.go_to_url(Config.BASE_URL)

    def verify_homepage_elements(self):
        """Verifies the presence of key homepage elements."""
        assert self.is_element_present(self.HEADER), "Header not found on homepage."
        assert self.is_element_present(self.HERO_SECTION), "Hero section not found on homepage."
        assert self.is_element_present(self.FOOTER), "Footer not found on homepage."
        assert self.is_element_present(self.NAV_ABOUT_US), "About Us link not found in header."
        assert self.is_element_present(self.NAV_PRODUCTS), "Products link not found in header."
        assert self.is_element_present(self.NAV_CONTACT_US), "Contact Us link not found in header."
        assert self.is_element_present(self.FOOTER_PRIVACY_POLICY), "Privacy Policy link not found in footer."
        assert self.is_element_present(self.FOOTER_TERMS_OF_USE), "Terms of Use link not found in footer."
        assert self.is_element_present(self.NEWSLETTER_SIGNUP_SECTION), "Newsletter signup section not found in footer."

    def verify_https(self):
        """Verifies that the homepage is served over HTTPS."""
        assert self.check_https(), "Homepage is not served over HTTPS."

    # Note: Responsiveness and LCP checks are harder to fully automate reliably with pure Selenium.
    # They usually involve integration with tools like Lighthouse or manual checks.
    # For responsiveness, we can check basic layout changes, but visual verification is key.
    # For LCP, Selenium doesn't directly expose this, though tools like PageSpeed Insights API could be integrated.
```

### 3.5. `pages/contact_us_page.py`

```python
# pages/contact_us_page.py
from selenium.webdriver.common.by import By
from pages.base_page import BasePage
from config import Config

class ContactUsPage(BasePage):
    """Page Object for the Contact Us Page."""

    # Locators
    CONTACT_FORM_SECTION = (By.ID, "contact-form-section") # Assuming an ID for the form section
    NAME_FIELD = (By.ID, "contact-name") # Assuming IDs for form fields
    EMAIL_FIELD = (By.ID, "contact-email")
    SUBJECT_FIELD = (By.ID, "contact-subject")
    MESSAGE_FIELD = (By.ID, "contact-message")
    SUBMIT_BUTTON = (By.ID, "contact-submit-button")
    CONFIRMATION_MESSAGE = (By.ID, "contact-confirmation-message") # Assuming an ID for confirmation
    ERROR_MESSAGE_EMAIL = (By.ID, "error-contact-email") # Assuming IDs for error messages
    ERROR_MESSAGE_SUBJECT = (By.ID, "error-contact-subject")

    def __init__(self, driver):
        super().__init__(driver)
        # Navigate to Contact Us page
        self.driver.get(f"{Config.BASE_URL}contact-us") # Assuming /contact-us URL

    def fill_form(self, name, email, subject, message):
        self.enter_text(self.NAME_FIELD, name)
        self.enter_text(self.EMAIL_FIELD, email)
        self.enter_text(self.SUBJECT_FIELD, subject)
        self.enter_text(self.MESSAGE_FIELD, message)

    def submit_form(self):
        self.click_element(self.SUBMIT_BUTTON)

    def get_confirmation_message(self):
        return self.get_element_text(self.CONFIRMATION_MESSAGE)

    def get_email_error_message(self):
        return self.get_element_text(self.ERROR_MESSAGE_EMAIL)

    def get_subject_error_message(self):
        return self.get_element_text(self.ERROR_MESSAGE_SUBJECT)

    def verify_form_fields_present(self):
        assert self.is_element_present(self.NAME_FIELD), "Name field not found."
        assert self.is_element_present(self.EMAIL_FIELD), "Email field not found."
        assert self.is_element_present(self.SUBJECT_FIELD), "Subject field not found."
        assert self.is_element_present(self.MESSAGE_FIELD), "Message field not found."
        assert self.is_element_present(self.SUBMIT_BUTTON), "Submit button not found."
```

### 3.6. `pages/newsletter_form_component.py`

```python
# pages/newsletter_form_component.py
from selenium.webdriver.common.by import By
from pages.base_page import BasePage
from config import Config

class NewsletterFormComponent(BasePage):
    """Component Object for the Newsletter Signup Form (e.g., in footer)."""

    # Locators
    NEWSLETTER_EMAIL_FIELD = (By.ID, "newsletter-email-input") # Assuming an ID for email field
    NEWSLETTER_CONSENT_CHECKBOX = (By.ID, "newsletter-consent-checkbox") # Assuming an ID for consent checkbox
    NEWSLETTER_SUBSCRIBE_BUTTON = (By.ID, "newsletter-subscribe-button")
    NEWSLETTER_CONFIRMATION_MESSAGE = (By.ID, "newsletter-confirmation-message")
    NEWSLETTER_ERROR_MESSAGE_EMAIL = (By.ID, "error-newsletter-email")
    NEWSLETTER_ERROR_MESSAGE_CONSENT = (By.ID, "error-newsletter-consent") # Assuming an ID for consent error

    def __init__(self, driver):
        super().__init__(driver)
        # Assuming this component is present on the homepage footer or other general pages
        self.driver.get(Config.BASE_URL) # Start on homepage to ensure component presence

    def fill_email(self, email):
        self.enter_text(self.NEWSLETTER_EMAIL_FIELD, email)

    def check_consent(self):
        self.click_element(self.NEWSLETTER_CONSENT_CHECKBOX)

    def submit_subscription(self):
        self.click_element(self.NEWSLETTER_SUBSCRIBE_BUTTON)

    def get_confirmation_message(self):
        return self.get_element_text(self.NEWSLETTER_CONFIRMATION_MESSAGE)

    def get_email_error_message(self):
        return self.get_element_text(self.NEWSLETTER_ERROR_MESSAGE_EMAIL)

    def get_consent_error_message(self):
        return self.get_element_text(self.NEWSLETTER_ERROR_MESSAGE_CONSENT)

    def verify_form_elements_present(self):
        assert self.is_element_present(self.NEWSLETTER_EMAIL_FIELD), "Newsletter email field not found."
        assert self.is_element_present(self.NEWSLETTER_CONSENT_CHECKBOX), "Newsletter consent checkbox not found."
        assert self.is_element_present(self.NEWSLETTER_SUBSCRIBE_BUTTON), "Newsletter subscribe button not found."
```

### 3.7. `tests/test_homepage.py` (for US1)

```python
# tests/test_homepage.py
import pytest
from pages.homepage import HomePage
from config import Config

def test_homepage_elements_and_https(browser):
    """
    Test Case: Verify Homepage content and HTTPS. (TC_US01_001 partial automation)
    User Story: US1: Homepage Display
    """
    homepage = HomePage(browser)

    # Verify key elements are present
    homepage.verify_homepage_elements()

    # Verify HTTPS
    homepage.verify_https()

    print(f"\nHomepage Title: {homepage.get_title()}")
    print(f"Homepage URL: {homepage.get_current_url()}")

    # Note: Responsiveness, Accessibility, and LCP are typically verified manually or with specialized tools.
    # Selenium can check for element visibility and presence across different viewport sizes, but not visual layout.
    # For a basic responsiveness check, you could try resizing the window:
    # browser.set_window_size(768, 1024) # Tablet size
    # assert homepage.is_element_present((By.CSS_SELECTOR, ".mobile-nav-toggle")), "Mobile navigation not present on tablet size."
    # browser.set_window_size(375, 667) # Mobile size
    # assert homepage.is_element_present((By.CSS_SELECTOR, ".mobile-nav-toggle")), "Mobile navigation not present on mobile size."
```

### 3.8. `tests/test_contact_us.py` (for US8)

```python
# tests/test_contact_us.py
import pytest
from pages.contact_us_page import ContactUsPage
from config import Config
import time # For rate limiting simulation

def test_contact_form_valid_submission(browser):
    """
    Test Case: Verify successful contact form submission. (TC_US08_001)
    User Story: US8: Contact Form Submission
    """
    contact_page = ContactUsPage(browser)
    contact_page.verify_form_fields_present()

    contact_page.fill_form(
        Config.CONTACT_NAME,
        Config.CONTACT_EMAIL,
        Config.CONTACT_SUBJECT,
        Config.CONTACT_MESSAGE
    )
    contact_page.submit_form()

    confirmation_message = contact_page.get_confirmation_message()
    assert "Thank you for your inquiry" in confirmation_message, \
        f"Expected confirmation message, but got: {confirmation_message}"
    assert contact_page.check_https(), "Contact form submission not over HTTPS."

    print(f"\nContact Form Confirmation: {confirmation_message}")

def test_contact_form_invalid_email_validation(browser):
    """
    Test Case: Verify client-side validation for invalid email. (TC_US08_001)
    User Story: US8: Contact Form Submission
    """
    contact_page = ContactUsPage(browser)
    contact_page.fill_form(
        Config.CONTACT_NAME,
        "invalid-email", # Invalid email
        Config.CONTACT_SUBJECT,
        Config.CONTACT_MESSAGE
    )
    contact_page.submit_form()

    email_error = contact_page.get_email_error_message()
    assert "valid email format" in email_error or "invalid email" in email_error, \
        f"Expected email validation error, but got: {email_error}"

def test_contact_form_missing_subject_validation(browser):
    """
    Test Case: Verify server-side validation for missing required field (Subject). (TC_US08_001)
    User Story: US8: Contact Form Submission
    """
    contact_page = ContactUsPage(browser)
    contact_page.fill_form(
        Config.CONTACT_NAME,
        Config.CONTACT_EMAIL,
        "", # Missing subject
        Config.CONTACT_MESSAGE
    )
    contact_page.submit_form()

    subject_error = contact_page.get_subject_error_message()
    assert "required" in subject_error or "cannot be empty" in subject_error, \
        f"Expected subject validation error, but got: {subject_error}"

@pytest.mark.skip(reason="Requires specific backend setup to test rate limiting effectively.")
def test_contact_form_rate_limiting(browser):
    """
    Test Case: Verify rate limiting on contact form submission. (TC_US08_001)
    User Story: US8: Contact Form Submission
    Note: This is a basic simulation; actual rate limiting tests might need API-level testing or more advanced HTTP client.
    """
    contact_page = ContactUsPage(browser)
    num_submissions = 5 # Number of rapid submissions to trigger rate limit

    for i in range(num_submissions):
        contact_page.fill_form(
            Config.CONTACT_NAME,
            f"rate_limit_test_{i}@automation.com",
            Config.CONTACT_SUBJECT,
            f"Rate limit message {i}"
        )
        contact_page.submit_form()
        time.sleep(0.5) # Simulate rapid submission

    # After rapid submissions, try one more and expect a rate limit message
    contact_page.fill_form(
        Config.CONTACT_NAME,
        "rate_limit_final@automation.com",
        Config.CONTACT_SUBJECT,
        "Final rate limit check"
    )
    contact_page.submit_form()

    # The exact error message depends on implementation, e.g., "Too many requests" or a specific HTTP status code
    # This might require checking network responses or specific UI error messages.
    # For now, we'll assume a generic error message appears or the confirmation message is NOT present.
    try:
        error_message = contact_page.get_element_text((By.ID, "rate-limit-error-message")) # Assuming such an ID
        assert "Too many requests" in error_message or "Please try again later" in error_message, \
            "Rate limit error message not displayed."
    except:
        # If no explicit error message, check if confirmation message is absent
        with pytest.raises(Exception): # Expecting element not found or similar for confirmation
            contact_page.get_confirmation_message()
        print("Rate limit likely triggered, no confirmation message received.")
```

### 3.9. `tests/test_newsletter_signup.py` (for US9)

```python
# tests/test_newsletter_signup.py
import pytest
from pages.newsletter_form_component import NewsletterFormComponent
from config import Config
import time # For rate limiting simulation

def test_newsletter_valid_signup(browser):
    """
    Test Case: Verify successful newsletter signup with consent. (TC_US09_001)
    User Story: US9: Newsletter Signup
    """
    newsletter_form = NewsletterFormComponent(browser)
    newsletter_form.verify_form_elements_present()

    newsletter_form.fill_email(Config.NEWSLETTER_EMAIL)
    newsletter_form.check_consent()
    newsletter_form.submit_subscription()

    confirmation_message = newsletter_form.get_confirmation_message()
    assert "Thank you for subscribing!" in confirmation_message, \
        f"Expected newsletter confirmation, but got: {confirmation_message}"
    assert newsletter_form.check_https(), "Newsletter signup not over HTTPS."

    print(f"\nNewsletter Confirmation: {confirmation_message}")

def test_newsletter_invalid_email_validation(browser):
    """
    Test Case: Verify client-side validation for invalid email in newsletter signup. (TC_US09_001)
    User Story: US9: Newsletter Signup
    """
    newsletter_form = NewsletterFormComponent(browser)
    newsletter_form.fill_email("invalid-newsletter-email")
    newsletter_form.check_consent()
    newsletter_form.submit_subscription()

    email_error = newsletter_form.get_email_error_message()
    assert "valid email format" in email_error or "invalid email" in email_error, \
        f"Expected email validation error, but got: {email_error}"

def test_newsletter_missing_consent_validation(browser):
    """
    Test Case: Verify server-side validation for missing consent in newsletter signup. (TC_US09_001)
    User Story: US9: Newsletter Signup
    """
    newsletter_form = NewsletterFormComponent(browser)
    newsletter_form.fill_email("no_consent@automation.com")
    # Do NOT check consent
    newsletter_form.submit_subscription()

    consent_error = newsletter_form.get_consent_error_message()
    assert "consent is required" in consent_error or "please agree" in consent_error, \
        f"Expected consent validation error, but got: {consent_error}"

@pytest.mark.skip(reason="Requires specific backend setup to test rate limiting effectively.")
def test_newsletter_rate_limiting(browser):
    """
    Test Case: Verify rate limiting on newsletter signup. (TC_US09_001)
    User Story: US9: Newsletter Signup
    """
    newsletter_form = NewsletterFormComponent(browser)
    num_submissions = 5 # Number of rapid submissions to trigger rate limit

    for i in range(num_submissions):
        newsletter_form.fill_email(f"rate_limit_newsletter_{i}@automation.com")
        newsletter_form.check_consent()
        newsletter_form.submit_subscription()
        time.sleep(0.5) # Simulate rapid submission

    # After rapid submissions, try one more and expect a rate limit message
    newsletter_form.fill_email("rate_limit_newsletter_final@automation.com")
    newsletter_form.check_consent()
    newsletter_form.submit_subscription()

    try:
        error_message = newsletter_form.get_element_text((By.ID, "newsletter-rate-limit-error-message")) # Assuming such an ID
        assert "Too many requests" in error_message or "Please try again later" in error_message, \
            "Rate limit error message not displayed for newsletter signup."
    except:
        with pytest.raises(Exception):
            newsletter_form.get_confirmation_message()
        print("Newsletter rate limit likely triggered, no confirmation message received.")
```