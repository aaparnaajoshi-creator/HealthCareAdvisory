# High-Level Design (HLD) Document: PharmaCorp Commercial Website

## 1. Introduction

This High-Level Design (HLD) document outlines the architectural blueprint for the PharmaCorp Commercial Website. It details the system's components, their interactions, data models, API specifications, and deployment strategies, ensuring alignment with the provided user stories and technical constraints.

### 1.1 Purpose
The purpose of this document is to provide a comprehensive overview of the system architecture, serving as a guide for development, infrastructure, and quality assurance teams. It addresses the functional and non-functional requirements derived from the user stories and technical constraints.

### 1.2 Scope
This HLD covers the design of the core website pages, key functionalities like search and newsletter signup, and essential technical enablers such as CI/CD, database setup, and security implementation. It focuses on the high-level components and their interfaces.

### 1.3 Audience
This document is intended for Solutions Architects, Software Engineers (Frontend, Backend), DevOps Engineers, QA Engineers, and Project Managers involved in the development and deployment of the PharmaCorp Commercial Website.

## 2. System Overview

The PharmaCorp Commercial Website will be built using a **Layered Monolithic Architecture**. This approach provides a clear separation of concerns between the presentation (frontend), application logic (backend API), and data layers. It offers simplicity in deployment and management, which is suitable for the current scope, while allowing for future modularization if needed.

### 2.1 High-Level Architecture Diagram

```mermaid
graph TD
    subgraph Client Layer
        User[Website Visitor]
    end

    subgraph Presentation Layer
        WebBrowser[Web Browser]
        FrontendApp[Frontend Web Application (HTML5, CSS, JS)]
    end

    subgraph Application Layer
        BackendAPI[Python API Service (FastAPI/Flask)]
    end

    subgraph Data Layer
        PostgreSQLDB[PostgreSQL Database]
        ObjectStorage[Object Storage (PharmaCorp PDFs)]
    end

    subgraph Infrastructure & Operations
        CDN[Content Delivery Network]
        LoadBalancer[Load Balancer]
        CI_CD[CI/CD Pipeline]
        GitRepo[Git Repository]
        DevEnv[Development Environment]
        StagingEnv[Staging Environment]
        ProdEnv[Production Environment]
        Monitoring[Monitoring & Logging]
    end

    User --> WebBrowser
    WebBrowser -->|Accesses website via HTTPS| CDN
    CDN -->|Serves Static Assets| FrontendApp
    FrontendApp -->|API Calls (HTTPS)| LoadBalancer
    LoadBalancer -->|Routes Requests| BackendAPI
    BackendAPI -->|Reads/Writes Data| PostgreSQLDB
    BackendAPI -->|Manages/Serves PDF Links| ObjectStorage
    Developer[Developer] -->|Commits Code| GitRepo
    GitRepo -->|Triggers Build & Test| CI_CD
    CI_CD -->|Automated Deploy to| DevEnv
    CI_CD -->|Automated Deploy to| StagingEnv
    CI_CD -->|Manual Approval for| ProdEnv
    ProdEnv & StagingEnv & DevEnv --> Monitoring
```

### 2.2 Architectural Style Justification
A layered monolithic architecture is chosen due to its:
*   **Simplicity:** Easier to develop, deploy, and manage for a project of this scale compared to microservices.
*   **Clear Separation of Concerns:** Distinct layers for presentation, business logic, and data storage.
*   **Unified Deployment:** A single codebase and deployment unit simplify CI/CD pipelines.
*   **Performance:** Reduced network overhead between internal components.

## 3. Component Breakdown

### 3.1 Frontend Application
*   **Technologies:** HTML5, CSS3, JavaScript. No specific JavaScript framework is mandated, allowing for a lightweight, performant implementation.
*   **Key Responsibilities:**
    *   Rendering responsive web pages.
    *   Handling user interactions (navigation, form submissions).
    *   Making API calls to the Backend API Service to fetch and submit data.
    *   Client-side input validation for forms (e.g., email format, required fields).
    *   Implementing WCAG 2.2 AA accessibility guidelines.
    *   Managing cookie consent preferences and controlling third-party scripts.
    *   Displaying the "Important Safety Information (ISI)" section as sticky on product detail pages.
    *   Implementing the site search user interface and displaying results.
*   **Performance:** Optimizations for fast loading times, particularly for the Home Page (LCP < 2.5 seconds), including efficient asset loading and caching.
*   **Responsiveness & Accessibility:** Extensive use of CSS media queries and adherence to WCAG 2.2 AA standards for all page elements.

### 3.2 Backend API Service
*   **Technologies:** Python (FastAPI or Flask). FastAPI is recommended for its performance, built-in data validation (Pydantic), and automatic API documentation (OpenAPI/Swagger UI).
*   **Key Responsibilities:**
    *   Serving RESTful API endpoints for content retrieval, product data, and form submissions.
    *   Interacting with the PostgreSQL database for all dynamic content and user submissions.
    *   Integrating with the object storage solution for managing and serving PDF documents.
    *   Performing comprehensive server-side input validation for all user-submitted data to prevent security vulnerabilities (e.g., SQL injection, XSS).
    *   Implementing rate limiting for form submission endpoints.
    *   Integrating with reCAPTCHA (or similar) service for anti-spam.
    *   Handling CORS (Cross-Origin Resource Sharing) to allow requests from the frontend domain.
    *   Implementing robust error handling and logging mechanisms.
*   **Security:** Enforcing secure communication (HTTPS), implementing Content Security Policy (CSP) headers, and other recommended HTTP security headers.

### 3.3 Database (PostgreSQL)
*   **Purpose:** The primary data store for all dynamic website content, product information, contact form submissions, and newsletter signups.
*   **Responsibilities:**
    *   Securely storing structured data.
    *   Ensuring data integrity and consistency.
    *   Providing efficient data retrieval through appropriate indexing.
    *   Supporting CRUD operations via the Backend API.
*   **Security:** Configured with strong authentication, encryption in transit (SSL/TLS), and restricted network access (e.g., only from the Backend API service).

### 3.4 Object Storage
*   **Purpose:** Dedicated storage for large static files, specifically Product Information (PI) and MedGuide PDF documents.
*   **Responsibilities:**
    *   Efficiently storing and serving PDF files.
    *   Providing public, secure URLs for direct access from the frontend.
    *   Supporting versioning and access control for documents.
    *   Scalable to accommodate future growth in PDF volume.
*   **Integration:** The Backend API will store references (URLs) to these PDFs in the PostgreSQL database and manage upload/retrieval operations.

### 3.5 CI/CD & Deployment
*   **Environments:** Separate and secure environments will be provisioned:
    *   **Development (Dev):** For individual developer testing and rapid iteration.
    *   **Staging (Staging):** A pre-production environment mimicking production, used for integration testing, UAT, and stakeholder review.
    *   **Production (Prod):** The live environment accessible to end-users.
*   **CI Pipeline:**
    *   Triggered by code commits to the Git repository.
    *   Automates code linting, unit tests, and integration tests.
    *   Builds Docker images for the Backend API and prepares static assets for the Frontend.
*   **CD Pipeline:**
    *   Automates deployment to Dev and Staging environments upon successful CI builds.
    *   **Manual Approval Gate:** A mandatory manual approval step is required for deployments from Staging to Production, ensuring quality and stability.
*   **Configuration Management:** Environment-specific configurations (e.g., database credentials, API keys, reCAPTCHA keys) will be securely managed using environment variables or a secrets management service (e.g., AWS Secrets Manager, Azure Key Vault, HashiCorp Vault) and injected at deployment time.
*   **Rollback Strategy:** Automated rollback mechanisms will be defined and tested (e.g., reverting to the previous stable release, blue/green deployments) to minimize downtime in case of production issues.

### 3.6 Security Mechanisms
*   **HTTPS:** All website traffic will be forced over HTTPS using SSL/TLS certificates (e.g., via CDN or Load Balancer).
*   **Content Security Policy (CSP):** A robust CSP will be implemented to mitigate XSS and data injection attacks by whitelisting allowed content sources.
*   **Rate Limiting:** Applied to all form submission endpoints (`/api/v1/contact`, `/api/v1/newsletter`) to prevent brute-force attacks and spam.
*   **Server-side Input Validation:** Comprehensive validation on all user-submitted data (e.g., type checking, length constraints, sanitization) to prevent injection attacks (SQL injection, XSS).
*   **Secure HTTP Headers:** Configuration of headers like `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, `Strict-Transport-Security`, and `Referrer-Policy`.
*   **reCAPTCHA:** Integrated with the Contact Us form to deter automated spam submissions.
*   **GDPR/CCPA Compliance:** Addressed through explicit consent mechanisms (cookie banner, newsletter signup checkbox), clear privacy policy, and user rights management.

## 4. Data Models / Database Schema (PostgreSQL)

The PostgreSQL database will contain the following tables:

### 4.1 `products` Table
Stores information about PharmaCorp's products.
*   `id` (UUID/BIGINT, Primary Key)
*   `name` (VARCHAR(255), NOT NULL)
*   `brief_description` (TEXT, NOT NULL)
*   `detailed_description` (TEXT)
*   `indications` (TEXT)
*   `dosage` (TEXT)
*   `side_effects` (TEXT)
*   `pi_pdf_url` (VARCHAR(2048)) -- URL to the PDF in object storage
*   `is_active` (BOOLEAN, DEFAULT TRUE)
*   `created_at` (TIMESTAMP WITH TIME ZONE, DEFAULT NOW())
*   `updated_at` (TIMESTAMP WITH TIME ZONE, DEFAULT NOW())

### 4.2 `website_content` Table
Stores dynamic content for pages like About Us, Privacy Policy, and Terms of Use.
*   `id` (UUID/BIGINT, Primary Key)
*   `content_key` (VARCHAR(100), UNIQUE, NOT NULL) -- e.g., 'about_us', 'privacy_policy', 'terms_of_use'
*   `title` (VARCHAR(255))
*   `content_text` (TEXT, NOT NULL)
*   `last_updated` (TIMESTAMP WITH TIME ZONE, DEFAULT NOW())

### 4.3 `contact_submissions` Table
Stores data from the Contact Us form.
*   `id` (UUID/BIGINT, Primary Key)
*   `name` (VARCHAR(255), NOT NULL)
*   `email` (VARCHAR(255), NOT NULL)
*   `subject` (VARCHAR(255))
*   `message` (TEXT, NOT NULL)
*   `submission_timestamp` (TIMESTAMP WITH TIME ZONE, DEFAULT NOW())
*   `ip_address` (INET) -- For auditing and rate limiting
*   `status` (VARCHAR(50), DEFAULT 'new') -- e.g., 'new', 'processed', 'archived'

### 4.4 `newsletter_signups` Table
Stores email addresses for newsletter subscriptions.
*   `id` (UUID/BIGINT, Primary Key)
*   `email` (VARCHAR(255), UNIQUE, NOT NULL)
*   `consent_given` (BOOLEAN, NOT NULL) -- GDPR/CCPA compliance
*   `signup_timestamp` (TIMESTAMP WITH TIME ZONE, DEFAULT NOW())

## 5. API Endpoints

The Backend API Service (Python FastAPI/Flask) will expose the following RESTful endpoints under a `/api/v1` prefix:

### 5.1 Content Retrieval
*   **GET `/api/v1/content/{key}`**
    *   **Description:** Retrieves the content for a specific general website page.
    *   **Parameters:** `key` (path parameter, string, e.g., `about_us`, `privacy_policy`, `terms_of_use`).
    *   **Response (200 OK):**
        ```json
        {
            "id": "uuid",
            "content_key": "about_us",
            "title": "About PharmaCorp",
            "content_text": "Our mission is...",
            "last_updated": "2023-10-27T10:00:00Z"
        }
        ```
    *   **Response (404 Not Found):** If `key` does not exist.

### 5.2 Product Data
*   **GET `/api/v1/products`**
    *   **Description:** Retrieves a list of all active products.
    *   **Response (200 OK):**
        ```json
        [
            {
                "id": "uuid1",
                "name": "Product A",
                "brief_description": "Brief description of Product A."
            },
            {
                "id": "uuid2",
                "name": "Product B",
                "brief_description": "Brief description of Product B."
            }
        ]
        ```
*   **GET `/api/v1/products/{product_id}`**
    *   **Description:** Retrieves detailed information for a specific product.
    *   **Parameters:** `product_id` (path parameter, UUID/BIGINT).
    *   **Response (200 OK):**
        ```json
        {
            "id": "uuid1",
            "name": "Product A",
            "brief_description": "Brief description of Product A.",
            "detailed_description": "Detailed description...",
            "indications": "Indications...",
            "dosage": "Dosage information...",
            "side_effects": "Potential side effects...",
            "pi_pdf_url": "https://object-storage-url/product-a-pi.pdf"
        }
        ```
    *   **Response (404 Not Found):** If `product_id` does not exist.

### 5.3 Form Submissions
*   **POST `/api/v1/contact`**
    *   **Description:** Submits a contact form inquiry. Includes reCAPTCHA verification and server-side validation.
    *   **Request Body (JSON):**
        ```json
        {
            "name": "John Doe",
            "email": "john.doe@example.com",
            "subject": "Inquiry about Product X",
            "message": "I have a question about...",
            "recaptcha_token": "your_recaptcha_token_here"
        }
        ```
    *   **Response (200 OK):**
        ```json
        {
            "message": "Your inquiry has been submitted successfully."
        }
        ```
    *   **Response (400 Bad Request):** For validation errors.
    *   **Response (403 Forbidden):** For reCAPTCHA failure or rate limit exceeded.

*   **POST `/api/v1/newsletter`**
    *   **Description:** Submits an email for newsletter signup. Includes server-side validation and consent check.
    *   **Request Body (JSON):**
        ```json
        {
            "email": "subscriber@example.com",
            "consent_given": true
        }
        ```
    *   **Response (200 OK):**
        ```json
        {
            "message": "Thank you for signing up for our newsletter!"
        }
        ```
    *   **Response (400 Bad Request):** For validation errors or if consent is not given.
    *   **Response (409 Conflict):** If email already exists.

### 5.4 Site Search
*   **GET `/api/v1/search?query={keywords}`**
    *   **Description:** Searches across product information and general website content.
    *   **Parameters:** `query` (query parameter, string, keywords to search).
    *   **Response (200 OK):**
        ```json
        [
            {
                "type": "product",
                "id": "uuid1",
                "title": "Product A",
                "excerpt": "Brief description of Product A...",
                "url": "/products/uuid1"
            },
            {
                "type": "content",
                "id": "uuid_content",
                "title": "About PharmaCorp",
                "excerpt": "Learn about PharmaCorp's mission and values...",
                "url": "/about-us"
            }
        ]
        ```

### 5.5 Health & Status
*   **GET `/health`**
    *   **Description:** Provides a simple health check for the API service.
    *   **Response (200 OK):** `{"status": "UP"}`
*   **GET `/version`**
    *   **Description:** Returns the current deployed version of the API.
    *   **Response (200 OK):** `{"version": "1.0.0"}`

## 6. Data Flow Diagrams

### 6.1 Contact Us Form Submission Data Flow

```mermaid
sequenceDiagram
    actor User
    User->>Frontend: Fills & Submits Contact Form
    Frontend->>Frontend: Client-side Validation
    alt Validation Success
        Frontend->>BackendAPI: POST /api/v1/contact (Form Data + reCAPTCHA Token)
        BackendAPI->>reCAPTCHA_Service: Verify reCAPTCHA Token
        reCAPTCHA_Service-->>BackendAPI: Verification Result (Success/Failure)
        alt reCAPTCHA Valid AND Server-side Validation Pass
            BackendAPI->>PostgreSQLDB: Store Contact Form Submission
            PostgreSQLDB-->>BackendAPI: Success (Submission ID)
            BackendAPI-->>Frontend: 200 OK (Confirmation Message)
            Frontend->>User: Display Success Message
        else reCAPTCHA Invalid OR Server-side Validation Fails
            BackendAPI-->>Frontend: 400 Bad Request / 403 Forbidden (Error Message)
            Frontend->>User: Display Error Message
        end
    else Validation Failure
        Frontend->>User: Display Client-side Validation Error
    end
```

### 6.2 Product Detail Page Load Data Flow

```mermaid
sequenceDiagram
    actor User
    User->>WebBrowser: Clicks Product Link
    WebBrowser->>Frontend: Request Product Detail Page (/products/{id})
    Frontend->>BackendAPI: GET /api/v1/products/{product_id}
    BackendAPI->>PostgreSQLDB: Query product details by ID
    PostgreSQLDB-->>BackendAPI: Product Data (including PI PDF URL)
    BackendAPI-->>Frontend: 200 OK (Product Data JSON)
    Frontend->>Frontend: Render Product Detail Page
    Frontend->>User: Display Product Name, Description, ISI (sticky), PI PDF Link
    User->>ObjectStorage: (Optional) Clicks PI PDF Link
    ObjectStorage-->>User: Serves PI PDF Document
```

## 7. Non-Functional Requirements Addressed

*   **Performance:** Achieved through efficient API design, proper database indexing, CDN usage for static assets, and client-side optimizations (LCP < 2.5s for homepage).
*   **Security:** Comprehensive measures including HTTPS, CSP, rate limiting, server-side input validation, secure HTTP headers, and reCAPTCHA.
*   **Scalability:** The layered architecture allows for independent scaling of frontend and backend components. PostgreSQL and Object Storage are inherently scalable solutions.
*   **Maintainability:** Clear separation of concerns, well-defined APIs, and structured database schema contribute to easier maintenance and future enhancements.
*   **Accessibility (WCAG 2.2 AA):** Explicitly addressed in frontend development through design and implementation practices.
*   **Compliance (GDPR, CCPA):** Ensured through explicit cookie consent, clear privacy policy, and opt-in mechanisms for newsletter signup.