```dockerfile
# Use a MuleSoft Mule Runtime base image
# The version should match the app.runtime property in pom.xml
FROM mulesoft/mule-runtime:4.4.0-20230220-ubi

# Set the working directory in the container to the Mule apps directory
WORKDIR $MULE_HOME/apps

# Define arguments for application name and version
ARG MULE_APP_NAME=ctms-cdw-sync-api
ARG MULE_APP_VERSION=1.0.0-SNAPSHOT

# Copy the built Mule application JAR into the container.
# This assumes 'mvn package' has already been run and the JAR is in the 'target' directory.
COPY target/${MULE_APP_NAME}-${MULE_APP_VERSION}.jar ./

# Expose the HTTP port used by the Mule application.
# This port is defined in application-dev.yaml (http.port: "8081").
EXPOSE 8081

# Set default environment variables for Mule application configuration.
# These values can be overridden in docker-compose.yml or 'docker run' commands.
# MULE_ENV: Activates the application-dev.yaml configuration file.
# secure.key: Used by the secure-properties module to decrypt properties (if encrypted in YAML).
# Other variables (api.key, db.*, email.*) directly provide values for secure properties,
# overriding any potentially cleartext or encrypted values in application-dev.yaml.
ENV MULE_ENV=dev \
    secure.key="your-super-secret-encryption-key-for-local-dev" \
    api.key="your-ctms-api-key-12345" \
    db.host="postgres" \
    db.port="5432" \
    db.user="postgres" \
    db.password="mysecretpassword" \
    db.name="cdw_db" \
    email.host="mailhog" \
    email.port="1025" \
    email.user="mule_alerts@example.com" \
    email.password="mailhog_password" \
    email.from.address="mule_alerts@example.com" \
    email.it.support.address="it.support@example.com"

# The Mule runtime starts automatically when the container runs
# No CMD instruction is needed if the base image handles it.
```

```yaml
version: '3.8'

services:
  # MuleSoft Application Service
  mule-app:
    build:
      context: .
      dockerfile: Dockerfile
      args:
        # Ensure these arguments match your pom.xml artifactId and version
        MULE_APP_NAME: ctms-cdw-sync-api
        MULE_APP_VERSION: 1.0.0-SNAPSHOT
    container_name: ctms-cdw-sync-api
    ports:
      - "8081:8081" # Map container port 8081 to host port 8081
    environment:
      # MULE_ENV activates application-dev.yaml for local development
      MULE_ENV: dev
      # secure.key is used by the secure-properties module in config.xml
      secure.key: "your-super-secret-encryption-key-for-local-dev"
      # Environment variables to override secure properties defined in application-dev.yaml
      # These names match the logical property names (without 'secure::' prefix)
      api.key: "your-ctms-api-key-12345"
      db.host: "postgres" # Refers to the 'postgres' service name in docker-compose
      db.port: "5432"
      db.user: "postgres"
      db.password: "mysecretpassword" # Use a strong password
      db.name: "cdw_db"
      email.host: "mailhog" # Refers to the 'mailhog' service name in docker-compose
      email.port: "1025" # MailHog's SMTP port
      email.user: "mule_alerts@example.com"
      email.password: "mailhog_password" # Placeholder, MailHog doesn't require auth
      email.from.address: "mule_alerts@example.com"
      email.it.support.address: "it.support@example.com"
    depends_on:
      postgres:
        condition: service_healthy # Ensure PostgreSQL is ready before starting Mule app
      mailhog:
        condition: service_healthy # Ensure MailHog is ready before starting Mule app
    # Optional: Resource limits to simulate CloudHub 0.1 vCores.
    # Note: vCores in CloudHub are not directly equivalent to Docker CPU limits.
    # cpu_shares: 10 # 10% of a single CPU core, very rough approximation of 0.1 vCores
    # mem_limit: 512m # Allocate 512MB RAM

  # PostgreSQL Database Service (Clinical Data Warehouse)
  postgres:
    image: postgres:13 # Using a specific version for stability
    container_name: cdw-postgres
    environment:
      POSTGRES_DB: cdw_db
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: mysecretpassword # Must match db.password in mule-app service
    ports:
      - "5432:5432" # Map container port 5432 to host port 5432
    volumes:
      # Persist database data to avoid data loss on container restart
      - postgres_data:/var/lib/postgresql/data
      # Initialize the database schema using the provided SQL script
      - ./sql/create_table.sql:/docker-entrypoint-initdb.d/create_table.sql
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U postgres -d cdw_db"]
      interval: 10s
      timeout: 5s
      retries: 5
      start_period: 10s

  # MailHog Service (Local SMTP server for email notifications)
  mailhog:
    image: mailhog/mailhog:latest
    container_name: mailhog
    ports:
      - "1025:1025" # SMTP server port for Mule app to send emails
      - "8025:8025" # Web UI port to view sent emails
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8025"]
      interval: 10s
      timeout: 5s
      retries: 5
      start_period: 10s

# Define named volumes for data persistence
volumes:
  postgres_data:
```

```markdown
# CTMS Subject Enrollment to CDW Sync API

This project implements the CTMS Subject Enrollment to CDW Sync Service, a MuleSoft 4 application designed to synchronize new subject enrollment data from a Clinical Trial Management System (CTMS) to a Clinical Data Warehouse (CDW) in near real-time. It exposes an HTTP webhook endpoint, applies security, transforms data, handles errors, and sends notifications.

## Project Design Overview

The service is an event-driven integration built on MuleSoft. It receives JSON payloads via an HTTP POST request, validates an API key, transforms the data to match the CDW schema, and inserts it into a PostgreSQL database. Robust error handling with email notifications is included for failures.

**Key Components:**
- **MuleSoft Application:** `CTMS-CDW-Sync-API`
- **Source System:** Clinical Trial Management System (CTMS)
- **Target System:** Clinical Data Warehouse (CDW) - PostgreSQL
- **Notification:** Email Service (SMTP)
- **API Endpoint:** `/api/subject-enrollment` (HTTP POST)

## Prerequisites

Before you begin, ensure you have the following installed:

*   **Java Development Kit (JDK) 1.8 or later**
*   **Apache Maven 3.6.x or later**
*   **Docker Desktop** (or Docker Engine and Docker Compose)

## Project Structure

```
.
├── Dockerfile
├── docker-compose.yml
├── README.md
├── pom.xml
├── mule-artifact.json
├── log4j2.xml
├── src
│   ├── main
│   │   ├── mule
│   │   │   ├── config.xml
│   │   │   ├── ctms-cdw-sync-api.xml
│   │   │   └── global-error-handler.xml
│   │   ├── resources
│   │   │   ├── api
│   │   │   │   ├── ctms-cdw-sync.raml
│   │   │   │   ├── examples
│   │   │   │   │   └── ctms-enrollment-example.json
│   │   │   │   └── schemas
│   │   │   │       └── ctms-enrollment-request.json
│   │   │   └── application-dev.yaml
│   └── test
│       └── mule
│           └── ctms-cdw-sync-api-test.xml
└── sql
    └── create_table.sql
```

## Build Instructions

1.  **Clone the Repository:**
    ```bash
    git clone <your-repository-url>
    cd ctms-cdw-sync-api
    ```

2.  **Build the Mule Application:**
    Navigate to the project root directory and build the Mule application JAR using Maven:
    ```bash
    mvn clean package
    ```
    This command will compile the application, run MUnit tests, and package it into a `.jar` file in the `target/` directory.

## Configuration

The application uses `application-dev.yaml` for local development configurations and `secure-properties` for sensitive data. In the `docker-compose.yml`, these sensitive properties are overridden using environment variables for better security and flexibility in a containerized environment.

**Important Environment Variables (set in `docker-compose.yml`):**

*   `MULE_ENV`: Set to `dev` to load `application-dev.yaml`.
*   `secure.key`: The encryption key for secure properties (e.g., `your-super-secret-encryption-key-for-local-dev`).
*   `api.key`: The API key required in the `X-API-KEY` header for authentication (e.g., `your-ctms-api-key-12345`).
*   `db.host`, `db.port`, `db.user`, `db.password`, `db.name`: PostgreSQL database connection details.
*   `email.host`, `email.port`, `email.user`, `email.password`, `email.from.address`, `email.it.support.address`: Email server details for sending error notifications.

**Note on `secure.key` and `application-dev.yaml`:**
The `application-dev.yaml` contains cleartext values prefixed with `secure::` for local development convenience. In a Docker environment, the environment variables provided in `docker-compose.yml` for `api.key`, `db.password`, etc., will take precedence, ensuring that sensitive data is passed securely via environment variables rather than being read from the potentially cleartext `application-dev.yaml` within the JAR. The `secure.key` is still required by the `secure-properties` module configuration, even if it's not actively decrypting values in this specific local setup.

## Deployment with Docker Compose

1.  **Ensure Docker is Running:**
    Start Docker Desktop or your Docker daemon.

2.  **Deploy Services:**
    From the project root directory (where `docker-compose.yml` is located), run:
    ```bash
    docker-compose up --build -d
    ```
    *   `--build`: Rebuilds the Docker images (especially for `mule-app`) if changes are detected.
    *   `-d`: Runs the services in detached mode (in the background).

    This command will:
    *   Build the `mule-app` Docker image.
    *   Start three services: `mule-app` (Mule application), `postgres` (PostgreSQL database), and `mailhog` (SMTP server for testing emails).
    *   Initialize the `postgres` database with the `Subjects` table schema using `sql/create_table.sql`.

3.  **Verify Services:**
    Check the status of your running containers:
    ```bash
    docker-compose ps
    ```
    All services should be `Up` and healthy.

## Accessing Services

*   **MuleSoft API Endpoint:**
    The API will be accessible at `http://localhost:8081/api/subject-enrollment`.

*   **MailHog Web UI:**
    View sent emails (including error notifications) at `http://localhost:8025`.

*   **PostgreSQL Database:**
    You can connect to the database using a client like `psql`:
    ```bash
    psql -h localhost -p 5432 -U postgres -d cdw_db
    ```
    Password: `mysecretpassword` (as defined in `docker-compose.yml`).

## Testing the Application

You can test the API using `curl` or any API client.

1.  **Successful Subject Enrollment (HTTP 202 Accepted):**

    ```bash
    curl -X POST \
      http://localhost:8081/api/subject-enrollment \
      -H 'Content-Type: application/json' \
      -H 'X-API-KEY: your-ctms-api-key-12345' \
      -d '{
        "subjectIdentifier": "SUB-001234",
        "protocolId": "PROT-XYZ-001",
        "siteId": "SITE-ABC-05",
        "enrollmentDate": "2023-10-26T10:30:00Z",
        "dateOfBirth": "1990-05-15",
        "sex": "Female",
        "additionalData": {
          "race": "Asian",
          "ethnicity": "Non-Hispanic or Latino",
          "studyArm": "Control Group"
        }
      }'
    ```
    Expected Response: `HTTP 202 Accepted` with a success message and `transactionId`.

2.  **Unauthorized Access (HTTP 401 Unauthorized):**
    Try sending a request with an invalid or missing `X-API-KEY` header.

    ```bash
    curl -X POST \
      http://localhost:8081/api/subject-enrollment \
      -H 'Content-Type: application/json' \
      -H 'X-API-KEY: invalid-key' \
      -d '{ "subjectIdentifier": "SUB-001235", "protocolId": "PROT-XYZ-002", "siteId": "SITE-ABC-06", "enrollmentDate": "2023-10-27T11:00:00Z", "dateOfBirth": "1991-06-16", "sex": "Male" }'
    ```
    Expected Response: `HTTP 401 Unauthorized`.

3.  **Bad Request (HTTP 400 Bad Request):**
    Send a request with a payload that violates the RAML/JSON schema (e.g., invalid `subjectIdentifier` format).

    ```bash
    curl -X POST \
      http://localhost:8081/api/subject-enrollment \
      -H 'Content-Type: application/json' \
      -H 'X-API-KEY: your-ctms-api-key-12345' \
      -d '{ "subjectIdentifier": "INVALID", "protocolId": "PROT-XYZ-003", "siteId": "SITE-ABC-07", "enrollmentDate": "2023-10-28T12:00:00Z", "dateOfBirth": "1992-07-17", "sex": "Female" }'
    ```
    Expected Response: `HTTP 400 Bad Request`.

4.  **Simulating Database Failure (HTTP 500 Internal Server Error & Email Notification):**
    To simulate a database failure, you could temporarily stop the `postgres` service (`docker-compose stop postgres`) and then send a valid request.
    Expected Response: `HTTP 500 Internal Server Error`, and an email notification should appear in the MailHog UI (`http://localhost:8025`).

## Stopping Services

To stop and remove all services and their networks/volumes (except named volumes `postgres_data`):
```bash
docker-compose down
```
To also remove the `postgres_data` volume (which will delete your database data):
```bash
docker-compose down -v
```