# PharmaCorp Website - High-Level Design

This document outlines the high-level design for the PharmaCorp website, addressing the user stories and technical requirements.

## 1. Architecture

The system will utilize a microservices architecture, separating concerns into independent services for scalability and maintainability.  This will also allow for independent deployments and scaling of individual components.

```mermaid
graph LR
    subgraph Frontend
        A[React (Home, About Us, Products, Contact Us, Admin)] --> B(API Gateway);
        style A fill:#ccf,stroke:#333,stroke-width:2px
    end
    subgraph Backend
        B --> C[API - Products];
        B --> D[API - Contact Form];
        B --> E[API - Newsletter];
        B --> F[Admin API (Django/React)];
        B --> G[Search API (Elasticsearch)];
        style B fill:#ccf,stroke:#333,stroke-width:2px
        style C fill:#ccf,stroke:#333,stroke-width:2px
        style D fill:#ccf,stroke:#333,stroke-width:2px
        style E fill:#ccf,stroke:#333,stroke-width:2px
        style F fill:#ccf,stroke:#333,stroke-width:2px
        style G fill:#ccf,stroke:#333,stroke-width:2px

    end
    subgraph Database
        C --> H[PostgreSQL (Products)];
        D --> H;
        E --> H;
        F --> H;
        style H fill:#ccf,stroke:#333,stroke-width:2px
    end
    subgraph Storage
        C --> I[Object Storage (PI PDFs)];
        style I fill:#ccf,stroke:#333,stroke-width:2px
    end
    G --> H;
```


## 2. Data Models

**PostgreSQL Schema:**

* **products:**
    * `id` (SERIAL PRIMARY KEY)
    * `name` (VARCHAR(255) NOT NULL)
    * `description` (TEXT)
    * `pi_url` (VARCHAR(255))
    * `isi` (TEXT NOT NULL)  //Important Safety Information
* **contact_forms:**
    * `id` (SERIAL PRIMARY KEY)
    * `name` (VARCHAR(255))
    * `email` (VARCHAR(255) NOT NULL)
    * `message` (TEXT)
    * `timestamp` (TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP)
* **newsletter_subscribers:**
    * `id` (SERIAL PRIMARY KEY)
    * `email` (VARCHAR(255) UNIQUE NOT NULL)
    * `subscribed_at` (TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP)
    * `consent_given` (BOOLEAN DEFAULT FALSE)
* **cookie_consent:**
    * `user_id` (UUID PRIMARY KEY)
    * `preferences` (JSONB)
    * `timestamp` (TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP)


## 3. API Endpoints

**All APIs will use JSON for request and response formats and include standard HTTP status codes for error handling.  Authentication will use JWT for the Admin API and will be stateless for all other APIs (e.g. using API Keys).**

* **`/products` (GET):**  Returns a list of products.
    * Response: `[{id, name, description}]`
* **`/products/{id}` (GET):** Returns details for a specific product, including `pi_url` and `isi`.
    * Response: `{id, name, description, pi_url, isi}`
* **`/contact` (POST):** Submits a contact form.  Input validation will be performed server-side.
    * Request: `{name, email, message}`
    * Response: `{success: true/false, message}`
* **`/newsletter` (POST):** Subscribes to the newsletter. Input validation will be performed server-side.
    * Request: `{email}`
    * Response: `{success: true/false, message}`
* **Admin API (Django/React):**  Provides CRUD operations for all data models and user management.  Detailed endpoints will be defined separately.  JWT authentication will be used.  Error handling and robust logging will be implemented.

## 4.  Performance Optimization

To meet the LCP target of <2.5 seconds:

* **Content Delivery Network (CDN):**  Utilize a CDN to cache static assets (images, CSS, JavaScript) closer to users.
* **Image Optimization:** Optimize images for web using tools like TinyPNG or similar.
* **Code Splitting:** Implement code splitting in the React frontend to load only necessary code initially.
* **Database Optimization:** Use appropriate database indexes and query optimization techniques.
* **Caching:** Implement caching strategies (e.g., Redis) for frequently accessed data.
* **Server-Side Rendering (SSR):** Consider SSR for improved initial load time.


## 5.  Security

* **HTTPS:** All communication will be secured using HTTPS.
* **Content Security Policy (CSP):** Implement a robust CSP to mitigate XSS attacks.
* **Rate Limiting:** Implement rate limiting to prevent denial-of-service attacks.
* **Input Validation:**  Validate all user inputs on both the client and server sides.
* **JWT Authentication (Admin API):** Secure admin access using JWTs with appropriate token expiration and refresh mechanisms.
* **Data Encryption:** Encrypt sensitive data at rest and in transit.


## 6.  GDPR/CCPA Compliance

* **Cookie Consent:**  The cookie consent banner will allow users to customize their cookie preferences, storing these preferences in the `cookie_consent` table.
* **Data Minimization:** Collect only necessary data.
* **Data Subject Access Requests:** Implement mechanisms to handle data subject access requests.
* **Data Retention Policies:** Define clear data retention policies for all data types.
* **Privacy Policy:**  A clear and concise privacy policy will be displayed on the website.


## 7. CI/CD and Testing

* **CI/CD Pipeline:**  A CI/CD pipeline will be implemented using tools like GitLab CI, Jenkins, or GitHub Actions. This will automate building, testing, and deploying the application to different environments (Dev, Staging, Prod).
* **Testing Strategy:**  A comprehensive testing strategy will be implemented, including unit tests, integration tests, and end-to-end tests.  Automated testing will be prioritized.


## 8.  Sticky ISI and Responsive Design

* **Sticky ISI:**  The sticky ISI section will be implemented using JavaScript to maintain its position at the top of the page while scrolling.  CSS will be used to ensure clear labeling and visual distinction.
* **Responsive Design:**  The responsive design will be implemented using CSS media queries and a mobile-first approach.  All components will be tested across various devices and screen sizes.


## 9. Site Search

Elasticsearch will index product names, descriptions, and other relevant content. The search API will interact with Elasticsearch to provide fast and relevant search results.