```python
# backend/products/models.py
from django.db import models

class Product(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()
    pi_url = models.URLField(blank=True, null=True)
    isi = models.TextField()

class ContactForm(models.Model):
    name = models.CharField(max_length=255, blank=True, null=True)
    email = models.EmailField()
    message = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

class NewsletterSubscriber(models.Model):
    email = models.EmailField(unique=True)
    subscribed_at = models.DateTimeField(auto_now_add=True)
    consent_given = models.BooleanField(default=False)

class CookieConsent(models.Model):
    user_id = models.UUIDField(primary_key=True)
    preferences = models.JSONField()
    timestamp = models.DateTimeField(auto_now_add=True)


# backend/products/serializers.py
from rest_framework import serializers
from .models import Product, ContactForm, NewsletterSubscriber

class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = '__all__'

class ContactFormSerializer(serializers.ModelSerializer):
    class Meta:
        model = ContactForm
        fields = '__all__'

class NewsletterSubscriberSerializer(serializers.ModelSerializer):
    class Meta:
        model = NewsletterSubscriber
        fields = '__all__'

# backend/products/views.py
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Product, ContactForm, NewsletterSubscriber
from .serializers import ProductSerializer, ContactFormSerializer, NewsletterSubscriberSerializer
from django.core.mail import send_mail
from django.conf import settings

class ProductListView(APIView):
    def get(self, request):
        products = Product.objects.all()
        serializer = ProductSerializer(products, many=True)
        return Response(serializer.data)

class ProductDetailView(APIView):
    def get(self, request, pk):
        try:
            product = Product.objects.get(pk=pk)
            serializer = ProductSerializer(product)
            return Response(serializer.data)
        except Product.DoesNotExist:
            return Response({'error': 'Product not found'}, status=status.HTTP_404_NOT_FOUND)

class ContactFormView(APIView):
    def post(self, request):
        serializer = ContactFormSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            send_mail(
                subject=f'Contact Form Submission from {serializer.data.get("name", "Anonymous")}',
                message=serializer.data['message'],
                from_email=serializer.data['email'],
                recipient_list=[settings.DEFAULT_FROM_EMAIL],
            )
            return Response({'success': True}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class NewsletterSignupView(APIView):
    def post(self, request):
        serializer = NewsletterSubscriberSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'success': True}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



# backend/products/tests.py
from django.test import TestCase, Client
from .models import Product, ContactForm, NewsletterSubscriber
from .serializers import ProductSerializer, ContactFormSerializer, NewsletterSubscriberSerializer
import json

class ProductModelTest(TestCase):
    def test_product_creation(self):
        product = Product.objects.create(name="Test Product", description="Test Description", isi="Test ISI")
        self.assertEqual(product.name, "Test Product")

class ProductViewTest(TestCase):
    def setUp(self):
        self.client = Client()
        self.product = Product.objects.create(name="Test Product", description="Test Description", isi="Test ISI")

    def test_product_list(self):
        response = self.client.get('/products/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(json.loads(response.content)), 1)

    def test_product_detail(self):
        response = self.client.get(f'/products/{self.product.id}/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(json.loads(response.content)['name'], "Test Product")


class ContactFormViewTest(TestCase):
    def setUp(self):
        self.client = Client()

    def test_contact_form_submission(self):
        response = self.client.post('/contact/', {'email': 'test@example.com', 'message': 'Test Message'}, content_type='application/json')
        self.assertEqual(response.status_code, 201)

class NewsletterSignupViewTest(TestCase):
    def setUp(self):
        self.client = Client()

    def test_newsletter_signup(self):
        response = self.client.post('/newsletter/', {'email': 'test@example.com'}, content_type='application/json')
        self.assertEqual(response.status_code, 201)

# backend/pharmacorp/settings.py
# ... other settings ...
DEFAULT_FROM_EMAIL = 'your_email@example.com'  # Replace with a valid email address

# ... rest of settings.py ...

# frontend/src/App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import AboutUsPage from './pages/AboutUsPage';
import ProductsPage from './pages/ProductsPage';
import ProductDetailPage from './pages/ProductDetailPage';
import ContactUsPage from './pages/ContactUsPage';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/about" element={<AboutUsPage />} />
        <Route path="/products" element={<ProductsPage />} />
        <Route path="/products/:id" element={<ProductDetailPage />} />
        <Route path="/contact" element={<ContactUsPage />} />
      </Routes>
    </Router>
  );
}

export default App;

# ... other frontend files ...