-- Ensure this extension is enabled if using gen_random_uuid() and not on PostgreSQL 13+ or if your provider requires it.
-- For PostgreSQL 13+, gen_random_uuid() is built-in and does not require uuid-ossp.
-- If using an older version or specific cloud provider, you might need:
-- CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS customers (
    customer_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(), -- Unique identifier for the customer record
    hubspot_company_id   VARCHAR(255) UNIQUE NOT NULL,              -- HubSpot's internal company ID (Ensures no duplicate HubSpot companies)
    customer_name        VARCHAR(255) NOT NULL,                     -- Mapped from HubSpot 'name'
    website              VARCHAR(2048) NULL,                        -- Mapped from HubSpot 'domain', allowing for nulls
    created_at           TIMESTAMP WITH TIME ZONE DEFAULT NOW(),    -- Timestamp of record creation in DB
    updated_at           TIMESTAMP WITH TIME ZONE DEFAULT NOW()     -- Timestamp of last update (though only INSERT is currently supported)
);

-- Index for faster lookups on hubspot_company_id
CREATE INDEX IF NOT EXISTS idx_hubspot_company_id ON customers (hubspot_company_id);