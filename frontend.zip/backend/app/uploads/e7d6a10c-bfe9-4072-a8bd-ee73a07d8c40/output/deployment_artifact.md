```dockerfile
# Use a MuleSoft Runtime base image for Mule 4.4.0
FROM mulesoft/mule-runtime:4.4.0-20230320

# Set the application name (must match artifactId from pom.xml)
ENV MULE_APP_NAME=hubspot-company-sync

# Create application directory (Mule runtime will usually handle this, but explicit is fine)
RUN mkdir -p ${MULE_HOME}/apps/${MULE_APP_NAME}

# Copy the built Mule application archive (JAR file) into the apps directory.
# The `mvn clean package` command (run locally before building the Docker image)
# will generate this JAR in the `target/` directory.
COPY target/${MULE_APP_NAME}-1.0.0-SNAPSHOT.jar ${MULE_HOME}/apps/

# The application's `application-dev.yaml` and `log4j2.xml` are packaged within the JAR.
# Environment variables for configuration are passed at runtime via docker-compose.

# Expose the HTTP port defined in application-dev.yaml (8081)
EXPOSE 8081

# The base image already sets the entrypoint to run Mule,
# so no CMD is explicitly needed here.
```

```docker-compose.yml
version: '3.8'

services:
  postgres-db:
    image: postgres:13
    container_name: hubspot-customer-db
    environment:
      POSTGRES_DB: customer_db
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: postgres
    ports:
      - "5432:5432" # Expose for local access (e.g., pgAdmin, DBeaver)
    volumes:
      - postgres_data:/var/lib/postgresql/data
      # Initialize the database with the customers table
      - ./src/main/resources/db/create-customers-table.sql:/docker-entrypoint-initdb.d/init.sql
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U postgres -d customer_db"]
      interval: 5s
      timeout: 5s
      retries: 5
      start_period: 10s # Give the DB a bit more time to start

  mailhog:
    image: mailhog/mailhog
    container_name: mailhog
    ports:
      - "8025:8025" # MailHog Web UI to view emails
      - "1025:1025" # MailHog SMTP server port

  mule-app:
    build:
      context: .
      dockerfile: Dockerfile
    container_name: hubspot-company-sync-app
    ports:
      - "8081:8081" # MuleSoft API Listener port
    environment:
      # Mule application environment variables, referenced in application-dev.yaml
      MULE_ENV: dev # Activates application-dev.yaml configuration
      
      # Security-related variables (replace placeholders with actual values)
      # For local dev, you can use simple values. For production, these would be encrypted/managed securely.
      SECURE_KEY: "mySuperSecretKey" # Key for secure properties (if any encrypted values were in YAML)
      HUBSPOT_CLIENT_SECRET: "your-hubspot-client-secret" # **REQUIRED: Replace with your actual HubSpot Client Secret**
      
      # Database connection details, referencing the 'postgres-db' service
      DB_HOST: postgres-db
      DB_PORT: 5432
      DB_USER: postgres
      DB_PASSWORD: postgres
      DB_DATABASE: customer_db

      # Email SMTP details, referencing the 'mailhog' service
      EMAIL_HOST: mailhog
      EMAIL_PORT: 1025 # MailHog's default SMTP port
      EMAIL_USER: alert@example.com # MailHog doesn't require auth, but for consistency
      EMAIL_PASSWORD: email-password # MailHog doesn't require auth, but for consistency
      EMAIL_FROM: mulesoft-sync@example.com
      EMAIL_TO: it-admins@example.com
    depends_on:
      postgres-db:
        condition: service_healthy # Ensure DB is ready before starting Mule app
      mailhog:
        condition: service_started # MailHog typically starts quickly
    restart: on-failure # Automatically restart if the Mule app crashes

volumes:
  postgres_data: # Define a volume for persistent PostgreSQL data
```

```markdown
# HubSpot Company to Customer DB Sync Service

This project implements a MuleSoft System API designed to synchronize new Company records created in HubSpot CRM to an internal PostgreSQL customer database. It acts as a secure webhook listener for HubSpot `company.creation` events, validates the webhook's authenticity, transforms the data, and inserts it into the database. Error handling includes email notifications to IT administrators and detailed logging.

This README provides instructions for setting up, configuring, and running the application locally using Docker Compose, as well as notes on CloudHub deployment.

## High-Level Architecture

The system architecture revolves around a MuleSoft System API that:
1.  Receives `company.creation` webhooks from HubSpot CRM.
2.  Validates the webhook signature (`X-HubSpot-Signature`).
3.  Transforms the HubSpot company data into an internal customer format.
4.  Inserts the transformed data into a PostgreSQL database.
5.  Handles errors by logging details and sending email notifications to IT administrators.

For local development, Docker Compose is used to orchestrate the Mule application, a PostgreSQL database, and a MailHog service for catching outgoing emails.

## Project Structure

```
.
├── src
│   ├── main
│   │   ├── api
│   │   │   └── hubspot-company-sync-api.raml
│   │   ├── mule
│   │   │   └── hubspot-company-sync.xml
│   │   ├── resources
│   │   │   ├── application-dev.yaml
│   │   │   ├── dataweave
│   │   │   │   └── transform-hubspot-company.dwl
│   │   │   ├── db
│   │   │   │   └── create-customers-table.sql
│   │   │   └── log4j2.xml
│   │   └── ... (other Mule project files)
│   └── test
│       ├── munit
│       │   └── hubspot-company-sync-test.xml
│       └── resources
│           └── hubspot-company-creation-valid.json
├── pom.xml
├── Dockerfile
└── docker-compose.yml
```

## Local Development Setup with Docker Compose

This section outlines how to set up and run the application locally using Docker Compose, which includes a PostgreSQL database and a MailHog SMTP server for testing email notifications.

### Prerequisites

Ensure you have the following installed:
*   **Java Development Kit (JDK) 8 or newer**: Required for building the Mule application.
*   **Apache Maven 3.6.x or newer**: Used for building the Mule application.
*   **Docker Desktop (or Docker Engine & Docker Compose)**: For running the application in containers.

### 1. Build the Mule Application

Navigate to the project root directory (where `pom.xml` is located) and build the Mule application JAR file using Maven:

```bash
mvn clean package
```
This command compiles the application, runs MUnit tests, and packages it into `target/hubspot-company-sync-1.0.0-SNAPSHOT.jar`. This JAR file is then used by the `Dockerfile`.

### 2. Configure Environment Variables

The `docker-compose.yml` file expects certain environment variables for the `mule-app` service, especially `HUBSPOT_CLIENT_SECRET` and `SECURE_KEY`.

**Action Required:**
*   **`HUBSPOT_CLIENT_SECRET`**: You **must** replace `"your-hubspot-client-secret"` in `docker-compose.yml` with your actual HubSpot Client Secret. This secret is critical for validating incoming webhooks.
*   **`SECURE_KEY`**: For local development, `mySuperSecretKey` is set in `docker-compose.yml` and `application-dev.yaml`. For production, this should be a strong, unique key.

All other database and email configurations are pre-set to connect to the `postgres-db` and `mailhog` services within the Docker network.

### 3. Run with Docker Compose

After building the Mule application and configuring `HUBSPOT_CLIENT_SECRET`, start all services:

```bash
docker-compose up --build
```

*   `--build`: This flag ensures the `mule-app` image is rebuilt if the `Dockerfile` or the application JAR has changed.
*   The `postgres-db` service will initialize the `customers` table using `src/main/resources/db/create-customers-table.sql`.
*   The `mailhog` service will start, providing a local SMTP server and a web UI for viewing emails.
*   The `mule-app` service will deploy the Mule application.

### 4. Access Services

Once the services are running:

*   **MuleSoft API Endpoint**: `http://localhost:8081/hubspot/company-creation`
*   **PostgreSQL Database**: Accessible on `localhost:5432` (e.g., via `psql` or a GUI tool).
    *   Database: `customer_db`
    *   User: `postgres`
    *   Password: `postgres`
*   **MailHog Web UI**: `http://localhost:8025` (to view sent emails)

### 5. Testing the Integration

To test the full synchronization flow:

1.  **Prepare a valid HubSpot webhook payload**:
    Use `src/test/resources/hubspot-company-creation-valid.json` as the payload body.

2.  **Calculate the `X-HubSpot-Signature`**:
    The Mule application validates the `X-HubSpot-Signature` header. You need to compute this signature based on the raw JSON payload and your `HUBSPOT_CLIENT_SECRET`.
    *   **Example**: If your `HUBSPOT_CLIENT_SECRET` is `test-secret` (as used in MUnit tests) and the payload is the exact content of `hubspot-company-creation-valid.json` (without extra whitespace/newlines), the signature would be:
        `d58a59489569736e6761f3640b3c67537e231575089e6587c4f4b93193e622b7`
    *   **Tool**: You can use online HMAC-SHA256 calculators or a command-line tool like `openssl`:
        ```bash
        # Replace 'YOUR_PAYLOAD_JSON_STRING' with the exact JSON content (no formatting)
        # Replace 'YOUR_HUBSPOT_CLIENT_SECRET' with your secret from docker-compose.yml
        echo -n '{"portalId":62515,"eventGroupId":1000,"objectId":512,"subscriptionId":123456789,"appId":12345,"occurredAt":"2023-10-26T14:30:00.000Z","subscriptionType":"company.creation","attemptNumber":1,"objectType":"COMPANY","changeSource":"CRM","changeFlag":"NEW","eventId":987654321,"properties":{"name":"Acme Corp","domain":"acmecorp.com","createdate":"2023-10-26T14:29:00.000Z","hs_object_id":"512"}}' | openssl dgst -sha256 -hmac 'test-secret'
        ```

3.  **Send a `POST` request to the Mule API**:

    ```bash
    curl -X POST \
      http://localhost:8081/hubspot/company-creation \
      -H 'Content-Type: application/json' \
      -H 'X-HubSpot-Signature: d58a59489569736e6761f3640b3c67537e231575089e6587c4f4b93193e622b7' \
      -d @src/test/resources/hubspot-company-creation-valid.json
    ```
    (Ensure the `X-HubSpot-Signature` matches your `HUBSPOT_CLIENT_SECRET` and the payload).

4.  **Verify Data in PostgreSQL**:
    Connect to your PostgreSQL database (e.g., using `psql`, `DBeaver`, or `pgAdmin`) and query the `customers` table:
    ```sql
    SELECT * FROM customers;
    ```
    You should see the "Acme Corp" entry.

5.  **Test Error Handling (Optional)**:
    *   Send a request with an **invalid `X-HubSpot-Signature`** to verify the `401 Unauthorized` response.
    *   To simulate a database failure, stop the `postgres-db` service (`docker-compose stop postgres-db`) and then send a valid webhook request. You should receive a `500 Internal Server Error` response from the Mule API, and an error notification email should appear in the MailHog UI (`http://localhost:8025`).

### 6. Cleaning Up

To stop and remove the Docker containers and networks:

```bash
docker-compose down
```
To also remove the persistent PostgreSQL data volume (this will delete your database data):

```bash
docker-compose down -v
```

## CloudHub Deployment

For production deployments, this application is designed to be deployed to MuleSoft CloudHub. The `pom.xml` contains a `cloudHubDeployment` configuration for the `mule-maven-plugin`.

Key steps for CloudHub deployment:
1.  **Configure `pom.xml`**: Update the `<cloudHubDeployment>` section with your Anypoint Platform credentials, `environment`, `workerType`, `workers`, etc.
2.  **Encrypt Sensitive Properties**: Use MuleSoft's secure properties tool to encrypt values like `hubspot.client.secret`, database credentials, and email credentials. Store these encrypted values in environment-specific configuration files or directly as CloudHub application properties.
3.  **Set `secure.key`**: The `secure.key` used for encryption **must** be set as an environment variable in CloudHub for the application to decrypt secure properties at runtime.
4.  **Deploy**: Run `mvn clean deploy` from your project root.

Refer to the official MuleSoft documentation for detailed CloudHub deployment instructions and best practices for managing secure properties in production.
```