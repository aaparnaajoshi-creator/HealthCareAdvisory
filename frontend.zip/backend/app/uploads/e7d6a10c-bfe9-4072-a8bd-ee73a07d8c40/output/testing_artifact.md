# Test Strategy and Plan: HubSpot Company to Customer DB Sync Service

## 1. Test Strategy

### 1.1. Introduction
This document outlines the test strategy and plan for the HubSpot Company to Customer DB Sync Service. The service, implemented as a MuleSoft System API, aims to securely synchronize new company records from HubSpot to an internal PostgreSQL database. This strategy ensures comprehensive testing across functional and non-functional aspects, adhering to the project requirements and high-level design.

### 1.2. Test Scope
The testing scope covers the entire end-to-end synchronization process, including:
*   **HubSpot Webhook Reception**: Verification of the MuleSoft API's ability to receive and process `company.creation` webhooks.
*   **Webhook Authenticity Validation**: Testing the security mechanism for validating `X-HubSpot-Signature`.
*   **Data Transformation**: Ensuring accurate mapping and conversion of HubSpot company data to the internal customer database schema.
*   **PostgreSQL Database Integration**: Verifying successful insertion of new customer records into the target database.
*   **Error Handling and Notifications**: Testing the global error handler, email notifications for critical failures, and detailed error logging.
*   **Operational Logging**: Validating comprehensive logging for key events, correlation ID propagation, and sensitive data masking.
*   **Deployment and Configuration**: Basic verification of CloudHub deployment and secure property utilization.

### 1.3. Test Objectives
The primary objectives of testing are to:
*   Verify that all user stories and acceptance criteria are met.
*   Ensure the MuleSoft API securely receives and processes HubSpot webhooks.
*   Confirm data integrity and accuracy during transformation and insertion into the PostgreSQL database.
*   Validate the robustness and effectiveness of the error handling and notification mechanisms.
*   Ensure comprehensive and accurate logging for monitoring and troubleshooting.
*   Confirm the application's stability and performance under expected load (light-touch performance testing).
*   Identify and report defects early in the development lifecycle.

### 1.4. Test Phases and Types

| Test Phase              | Description                                                                                                                                                                                                                                                                         | Focus Areas                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             **Unit Testing**: Individual functions/components.
    *   **Integration Testing**: Interaction between the MuleSoft API and external systems (HubSpot, PostgreSQL, Email). This will be a major focus.
    *   **System Testing**: End-to-end flow testing, ensuring the entire system meets requirements.
    *   **API Testing**: Directly interacting with the MuleSoft API endpoint using various request payloads and headers.
    *   **Security Testing**:
        *   Webhook signature validation robustness (positive/negative scenarios).
        *   Secure properties usage verification (e.g., credentials not exposed).
    *   **Error Handling Testing**: Verifying that all defined error scenarios trigger the correct error responses, logging, and notifications.
    *   **Logging and Monitoring Testing**: Confirming that all required log entries are generated, contain correct information, correlation IDs are present, and sensitive data is masked.
    *   **Performance Testing (Light-Touch)**: Basic load testing to ensure the 0.1 vCore allocation can handle expected webhook volume with acceptable response times. (Not detailed in test cases, but part of strategy).
    *   **Regression Testing**: Re-running relevant tests after any code changes or new feature deployments to ensure existing functionality remains intact.

### 1.5. Test Environment
*   **Development/Sandbox Environment**: For initial development and unit testing.
*   **Staging Environment**: A replica of the production environment for comprehensive integration, system, and performance testing. This environment will have:
    *   Deployed MuleSoft System API (CloudHub, Mule 4.4+, 0.1 vCores).
    *   Dedicated HubSpot Developer Account/Sandbox configured to send webhooks to the Staging API endpoint.
    *   Dedicated PostgreSQL Database instance.
    *   Configured Email Service for notifications.
    *   Anypoint Monitoring enabled and configured.

### 1.6. Test Data Management
*   **HubSpot Data**: Creation of test company records in HubSpot to trigger webhooks.
*   **PostgreSQL Data**: Test data for the `customers` table, including existing records to test unique constraints.
*   **Secure Properties**: Test values for `hubspot.client.secret`, database credentials, and email recipients, securely configured for each environment.
*   **Payload Examples**: Prepared JSON payloads for direct API testing, covering various scenarios (e.g., missing optional fields).

### 1.7. Tools and Technologies
*   **API Testing**: Postman, cURL, Python `requests` library.
*   **Database Verification**: PostgreSQL client (e.g., `psql`, DBeaver).
*   **Logging/Monitoring**: Anypoint Monitoring.
*   **Automation Framework**: Python with `requests` for API interaction and `psycopg2` for database verification.
*   **Email Verification**: Manual check of IT Admin email inbox (for automated tests, potentially a mock SMTP server or a dedicated email testing service).

### 1.8. Roles and Responsibilities
*   **QA Automation Engineer**: Develops test strategy, creates test cases, writes and executes automation scripts, reports defects, manages test data.
*   **MuleSoft Developer**: Performs unit testing, supports QA with environment setup and issue diagnosis, fixes defects.
*   **DevOps Engineer**: Manages deployment, environment configuration, and monitoring tools.
*   **Product Owner**: Reviews test cases and results to ensure alignment with business requirements.

### 1.9. Exit Criteria
*   All critical and major defects are resolved and retested.
*   All functional and non-functional test cases (manual and automated) are executed with at least 95% pass rate for critical paths.
*   Test coverage targets are met.
*   Performance benchmarks are achieved (if applicable).
*   All stakeholders have signed off on the test results.

---

## 2. Manual Test Cases

**Pre-requisites for all test cases:**
*   MuleSoft API deployed to CloudHub with the `/hubspot/company-creation` endpoint accessible.
*   HubSpot Client Secret, PostgreSQL credentials, and Email server credentials securely configured in the Mule application.
*   Access to a HubSpot developer account to create companies and configure webhooks.
*   Access to the target PostgreSQL database to query data.
*   Access to Anypoint Monitoring for log verification.
*   Access to the IT Admin email inbox for notification verification.

**Common Test Data:**
*   **HubSpot Client Secret**: `your_hubspot_client_secret_for_testing`
*   **MuleSoft API Base URL**: `http://app-name.region.cloudhub.io/api/v1` (replace with actual URL)
*   **Webhook Endpoint**: `/hubspot/company-creation`
*   **IT Admin Email**: `it.admin@example.com`

---

### **Test Suite: HubSpot Company Creation Webhook Reception and Processing**

| Test Case ID | Test Case Name                                       | User Story | Priority | Type        |
| :----------- | :--------------------------------------------------- | :--------- | :------- | :---------- |
| TC-001       | Receive Valid HubSpot Company Creation Webhook (E2E) | US-1,2,3,4,6 | High     | Integration |
| TC-002       | Reject Webhook with Invalid X-HubSpot-Signature      | US-2,5,6   | High     | Security    |
| TC-003       | Reject Webhook with Missing X-HubSpot-Signature      | US-2,5,6   | High     | Security    |
| TC-004       | Handle HubSpot Payload with Missing Optional Fields  | US-3,4,6   | Medium   | Functional  |
| TC-005       | Database Insertion Failure - Duplicate HubSpot ID    | US-4,5,6   | High     | Error       |
| TC-006       | Database Insertion Failure - Connection Error        | US-4,5,6   | High     | Error       |
| TC-007       | Verify Comprehensive Operational Logging             | US-6       | High     | Non-Func    |
| TC-008       | Verify Error Notification Content and Logging        | US-5       | High     | Error       |
| TC-009       | Verify Secure Property Usage (Observation)           | US-2,4,5   | High     | Security    |

---

**TC-001: Receive Valid HubSpot Company Creation Webhook (End-to-End Success)**

*   **Description**: Verify the end-to-end process from HubSpot company creation to successful record insertion in PostgreSQL, including webhook reception, validation, transformation, and logging.
*   **Steps**:
    1.  Prepare a valid HubSpot company creation webhook payload.
        ```json
        {
          "portalId": 62515,
          "eventGroupId": 1000,
          "objectId": 1001,
          "subscriptionId": 123456789,
          "appId": 12345,
          "occurredAt": "2023-11-01T10:00:00.000Z",
          "subscriptionType": "company.creation",
          "attemptNumber": 1,
          "objectType": "COMPANY",
          "changeSource": "CRM",
          "changeFlag": "NEW",
          "eventId": 987654321,
          "properties": {
            "name": "Global Widgets Inc.",
            "domain": "globalwidgets.com",
            "createdate": "2023-11-01T09:55:00.000Z",
            "hs_object_id": "1001"
          }
        }
        ```
    2.  Calculate the `X-HubSpot-Signature` for the payload using `your_hubspot_client_secret_for_testing`.
    3.  Send a `POST` request to `[MuleSoft API Base URL]/hubspot/company-creation` with the payload and the calculated `X-HubSpot-Signature` header.
    4.  Verify the HTTP response from the MuleSoft API.
    5.  Connect to the PostgreSQL database.
    6.  Execute `SELECT * FROM customers WHERE hubspot_company_id = '1001';`
    7.  Access Anypoint Monitoring for the MuleSoft API.
    8.  Search logs using the correlation ID (if returned in response or inferred from logs).
*   **Expected Results**:
    1.  MuleSoft API returns HTTP `200 OK` with body: `{"status": "success", "message": "Company creation event received and processing initiated."}`.
    2.  The `SELECT` query returns one record.
    3.  The record in `customers` table has:
        *   `hubspot_company_id`: '1001'
        *   `customer_name`: 'Global Widgets Inc.'
        *   `website`: 'globalwidgets.com'
    4.  Anypoint Monitoring logs show:
        *   A log entry for "Transaction Start" with a unique correlation ID.
        *   A log entry for "Incoming Payload" with the received JSON (sensitive data masked, if applicable).
        *   A log entry confirming "DB Insert Success" for `hubspot_company_id '1001'`.
        *   A log entry for "Transaction End" with "SUCCESS" status and the correlation ID.

---

**TC-002: Reject Webhook with Invalid X-HubSpot-Signature**

*   **Description**: Verify that the MuleSoft API rejects webhooks with an invalid `X-HubSpot-Signature` and provides an appropriate error response and logging.
*   **Steps**:
    1.  Prepare a valid HubSpot company creation webhook payload (same as TC-001, Step 1).
    2.  Generate an *incorrect* `X-HubSpot-Signature` (e.g., by using a wrong secret or modifying a character).
    3.  Send a `POST` request to `[MuleSoft API Base URL]/hubspot/company-creation` with the payload and the incorrect `X-HubSpot-Signature` header.
    4.  Verify the HTTP response from the MuleSoft API.
    5.  Check the IT Admin email inbox for an error notification.
    6.  Access Anypoint Monitoring for the MuleSoft API.
*   **Expected Results**:
    1.  MuleSoft API returns HTTP `401 Unauthorized` with body: `{"status": "error", "message": "Invalid or missing X-HubSpot-Signature."}`.
    2.  An email notification is sent to `it.admin@example.com` with details about "Invalid Signature" (US-5).
    3.  Anypoint Monitoring logs show:
        *   A log entry for "Transaction Start" with a unique correlation ID.
        *   A log entry indicating "Signature Validation Failed" or similar security alert.
        *   A log entry for "Transaction End" with "FAILURE" status and the correlation ID.
        *   Full error stack trace and the problematic payload (masked) are logged.

---

**TC-003: Reject Webhook with Missing X-HubSpot-Signature**

*   **Description**: Verify that the MuleSoft API rejects webhooks that are missing the `X-HubSpot-Signature` header.
*   **Steps**:
    1.  Prepare a valid HubSpot company creation webhook payload (same as TC-001, Step 1).
    2.  Send a `POST` request to `[MuleSoft API Base URL]/hubspot/company-creation` with the payload, but **without** the `X-HubSpot-Signature` header.
    3.  Verify the HTTP response from the MuleSoft API.
    4.  Check the IT Admin email inbox for an error notification.
    5.  Access Anypoint Monitoring for the MuleSoft API.
*   **Expected Results**:
    1.  MuleSoft API returns HTTP `401 Unauthorized` with body: `{"status": "error", "message": "Invalid or missing X-HubSpot-Signature."}`.
    2.  An email notification is sent to `it.admin@example.com` with details about "Missing Signature" (US-5).
    3.  Anypoint Monitoring logs show:
        *   A log entry for "Transaction Start" with a unique correlation ID.
        *   A log entry indicating "Missing Signature Header" or similar security alert.
        *   A log entry for "Transaction End" with "FAILURE" status and the correlation ID.
        *   Full error stack trace and the problematic payload (masked) are logged.

---

**TC-004: Handle HubSpot Payload with Missing Optional Fields**

*   **Description**: Verify that the transformation logic correctly handles HubSpot payloads where optional fields (e.g., `domain`) are missing, mapping them to `NULL` or appropriate default values in the PostgreSQL database.
*   **Steps**:
    1.  Prepare a HubSpot company creation webhook payload where `properties.domain` is explicitly missing or `null`.
        ```json
        {
          "portalId": 62515,
          "eventGroupId": 1000,
          "objectId": 1002,
          "subscriptionId": 123456789,
          "appId": 12345,
          "occurredAt": "2023-11-01T10:10:00.000Z",
          "subscriptionType": "company.creation",
          "attemptNumber": 1,
          "objectType": "COMPANY",
          "changeSource": "CRM",
          "changeFlag": "NEW",
          "eventId": 987654322,
          "properties": {
            "name": "No Domain Company",
            "createdate": "2023-11-01T10:05:00.000Z",
            "hs_object_id": "1002"
          }
        }
        ```
    2.  Calculate the `X-HubSpot-Signature` for the payload.
    3.  Send a `POST` request to `[MuleSoft API Base URL]/hubspot/company-creation` with the payload and the calculated signature.
    4.  Verify the HTTP response from the MuleSoft API.
    5.  Connect to the PostgreSQL database.
    6.  Execute `SELECT customer_name, website FROM customers WHERE hubspot_company_id = '1002';`
    7.  Access Anypoint Monitoring and search logs for correlation ID.
*   **Expected Results**:
    1.  MuleSoft API returns HTTP `200 OK`.
    2.  The `SELECT` query returns one record.
    3.  The record shows `customer_name`: 'No Domain Company' and `website`: `NULL`.
    4.  Anypoint Monitoring logs show successful processing and DB insertion.

---

**TC-005: Database Insertion Failure - Duplicate HubSpot ID**

*   **Description**: Verify that if an attempt is made to insert a `hubspot_company_id` that already exists (due to the UNIQUE constraint), the transaction fails gracefully, triggers error handling, and sends a notification.
*   **Steps**:
    1.  First, successfully insert a company with `hubspot_company_id = '1003'` (using steps from TC-001).
        ```json
        { "objectId": 1003, "properties": { "name": "Initial Company", "domain": "initial.com", "hs_object_id": "1003" } }
        ```
    2.  Prepare a *second* HubSpot company creation webhook payload with the *same* `objectId` and `hs_object_id` (`1003`).
        ```json
        { "objectId": 1003, "properties": { "name": "Duplicate Company", "domain": "duplicate.com", "hs_object_id": "1003" } }
        ```
    3.  Calculate the `X-HubSpot-Signature` for the second payload.
    4.  Send a `POST` request to `[MuleSoft API Base URL]/hubspot/company-creation` with the second payload and calculated signature.
    5.  Verify the HTTP response from the MuleSoft API.
    6.  Connect to the PostgreSQL database.
    7.  Execute `SELECT * FROM customers WHERE hubspot_company_id = '1003';`
    8.  Check the IT Admin email inbox for an error notification.
    9.  Access Anypoint Monitoring for the MuleSoft API.
*   **Expected Results**:
    1.  MuleSoft API returns HTTP `500 Internal Server Error` with a `transactionId`.
    2.  The `SELECT` query returns only *one* record for `hubspot_company_id '1003'` (the initial insertion), confirming no duplicate was inserted.
    3.  An email notification is sent to `it.admin@example.com` with details about "Database Insertion Failure" (e.g., "duplicate key value violates unique constraint") and the `transactionId`.
    4.  Anypoint Monitoring logs show:
        *   A log entry for "Transaction Start" with a unique correlation ID.
        *   A log entry indicating "DB Insertion Failure" with details of the unique constraint violation.
        *   A log entry for "Transaction End" with "FAILURE" status and the correlation ID.
        *   Full error stack trace and the problematic payload (masked) are logged.

---

**TC-006: Database Insertion Failure - Connection Error**

*   **Description**: Verify that if the database connection fails, the transaction is handled by the global error handler, and appropriate notifications and logging occur. (This may require simulating a DB outage or incorrect credentials in a test environment).
*   **Steps**:
    1.  (Pre-condition) Temporarily misconfigure the PostgreSQL connection details in the MuleSoft application's secure properties (e.g., wrong password or host) or briefly shut down the DB.
    2.  Prepare a valid HubSpot company creation webhook payload.
        ```json
        { "objectId": 1004, "properties": { "name": "DB Fail Company", "domain": "dbfail.com", "hs_object_id": "1004" } }
        ```
    3.  Calculate the `X-HubSpot-Signature` for the payload.
    4.  Send a `POST` request to `[MuleSoft API Base URL]/hubspot/company-creation` with the payload and calculated signature.
    5.  Verify the HTTP response from the MuleSoft API.
    6.  Check the IT Admin email inbox for an error notification.
    7.  Access Anypoint Monitoring for the MuleSoft API.
*   **Expected Results**:
    1.  MuleSoft API returns HTTP `500 Internal Server Error` with a `transactionId`.
    2.  An email notification is sent to `it.admin@example.com` with details about "Database Connection Failure" or similar error message and the `transactionId`.
    3.  Anypoint Monitoring logs show:
        *   A log entry for "Transaction Start" with a unique correlation ID.
        *   A log entry indicating "Database Connection Error" or similar.
        *   A log entry for "Transaction End" with "FAILURE" status and the correlation ID.
        *   Full error stack trace and the problematic payload (masked) are logged.

---

**TC-007: Verify Comprehensive Operational Logging**

*   **Description**: Verify that all required log entries are generated at various stages of a successful transaction, including correlation ID, masked payload, and DB operation status.
*   **Steps**:
    1.  Execute TC-001 (End-to-End Success) to generate a successful transaction.
    2.  Access Anypoint Monitoring for the MuleSoft API.
    3.  Filter logs by the correlation ID of the executed transaction.
*   **Expected Results**:
    1.  Logs clearly show a unique correlation ID at the start and end of the transaction.
    2.  The incoming webhook payload is logged, and any potentially sensitive fields (e.g., `portalId`, `appId` if considered sensitive, or actual PII if added later) are masked (e.g., `****`).
    3.  A log entry specifically indicates the "DB Insert Success" including the `hubspot_company_id` or number of records.
    4.  Logs show the final status of the transaction as "SUCCESS".
    5.  No sensitive data (e.g., `X-HubSpot-Signature` value, client secret, DB credentials) is visible in plain text in the logs.

---

**TC-008: Verify Error Notification Content and Logging**

*   **Description**: Verify that error notifications sent to IT Admins contain necessary details and that full error details are logged to Anypoint Monitoring.
*   **Steps**:
    1.  Execute TC-002 (Invalid Signature) or TC-005 (Duplicate HubSpot ID) to trigger a critical error.
    2.  Check the IT Admin email inbox for the error notification.
    3.  Access Anypoint Monitoring for the MuleSoft API and filter logs by the transaction ID from the error email.
*   **Expected Results**:
    1.  The email notification subject line clearly indicates an error (e.g., "CRITICAL: HubSpot Sync Failure").
    2.  The email body contains:
        *   Transaction ID (matching the one in the HTTP 500 response, if applicable).
        *   Timestamp of the error.
        *   A brief, descriptive message of the failure (e.g., "Invalid X-HubSpot-Signature" or "PostgreSQL unique constraint violation").
    3.  Anypoint Monitoring logs for the corresponding transaction ID contain:
        *   The full error stack trace.
        *   The problematic payload (with sensitive data masked).
        *   A log entry indicating the error notification was sent.

---

**TC-009: Verify Secure Property Usage (Observation)**

*   **Description**: Observe the application's configuration and behavior to confirm that sensitive credentials are not exposed and are accessed securely.
*   **Steps**:
    1.  Review the Mule application configuration files (e.g., `mule-app.properties`, `config.yaml`, `secure-properties.yaml`) and deployment settings in CloudHub.
    2.  Execute various test cases (e.g., TC-001, TC-002, TC-005) that involve accessing secure properties (HubSpot secret, DB creds, Email creds).
    3.  Monitor application logs in Anypoint Monitoring and CloudHub runtime manager.
*   **Expected Results**:
    1.  Configuration files show references to secure properties (e.g., `p('hubspot.client.secret')`) rather than plain-text values.
    2.  CloudHub environment properties are used for sensitive values, and they are marked as secure.
    3.  No sensitive credential values (HubSpot Client Secret, DB password, Email password) are visible in plain text in any application logs, console output, or error messages.
    4.  The application successfully uses these credentials for authentication and connection.

---

## 3. Automation Test Scripts (Python)

These automation scripts use Python with `requests` for API interaction and `psycopg2` for PostgreSQL database verification.

**Pre-requisites for running scripts:**
*   Python 3.x installed.
*   `requests` library installed (`pip install requests`).
*   `psycopg2-binary` library installed (`pip install psycopg2-binary`).
*   MuleSoft API deployed and accessible.
*   PostgreSQL database accessible.
*   Environment variables set for sensitive data.

**Setup `config.py` (or environment variables):**

```python
# config.py
import os

# API Configuration
MULE_API_BASE_URL = os.getenv("MULE_API_BASE_URL", "http://localhost:8081/api/v1") # Replace with actual CloudHub URL
HUBSPOT_WEBHOOK_ENDPOINT = "/hubspot/company-creation"
HUBSPOT_CLIENT_SECRET = os.getenv("HUBSPOT_CLIENT_SECRET", "your_test_hubspot_client_secret") # IMPORTANT: Use environment variable in real scenario

# PostgreSQL Configuration
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "customerdb")
DB_USER = os.getenv("DB_USER", "postgres")
DB_PASSWORD = os.getenv("DB_PASSWORD", "password") # IMPORTANT: Use environment variable in real scenario

# Example: How to set environment variables (e.g., in your shell or CI/CD)
# export MULE_API_BASE_URL="http://app-name.region.cloudhub.io/api/v1"
# export HUBSPOT_CLIENT_SECRET="your_actual_client_secret"
# export DB_HOST="your_db_host"
# export DB_USER="your_db_user"
# export DB_PASSWORD="your_db_password"
```

**Utility Functions (`utils.py`):**

```python
# utils.py
import hmac
import hashlib
import json
import psycopg2
from config import DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD

def calculate_hubspot_signature(client_secret, request_body_json):
    """Calculates the X-HubSpot-Signature for a given payload."""
    hashed = hmac.new(
        client_secret.encode('utf-8'),
        json.dumps(request_body_json, separators=(',', ':')).encode('utf-8'), # HubSpot expects compact JSON
        hashlib.sha256
    ).hexdigest()
    return hashed

def get_db_connection():
    """Establishes and returns a PostgreSQL database connection."""
    try:
        conn = psycopg2.connect(
            host=DB_HOST,
            port=DB_PORT,
            database=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD
        )
        return conn
    except Exception as e:
        print(f"Error connecting to database: {e}")
        return None

def verify_customer_in_db(hubspot_company_id, expected_name, expected_website):
    """Verifies if a customer record exists in the DB with expected details."""
    conn = None
    try:
        conn = get_db_connection()
        if not conn:
            return False

        cursor = conn.cursor()
        cursor.execute(
            "SELECT customer_name, website FROM customers WHERE hubspot_company_id = %s",
            (hubspot_company_id,)
        )
        result = cursor.fetchone()
        cursor.close()
        conn.close()

        if result:
            db_name, db_website = result
            print(f"DB Record: Name='{db_name}', Website='{db_website}'")
            return db_name == expected_name and db_website == expected_website
        return False
    except Exception as e:
        print(f"Error verifying customer in DB: {e}")
        return False
    finally:
        if conn:
            conn.close()

def delete_customer_from_db(hubspot_company_id):
    """Deletes a customer record from the DB by hubspot_company_id."""
    conn = None
    try:
        conn = get_db_connection()
        if not conn:
            return False
        cursor = conn.cursor()
        cursor.execute(
            "DELETE FROM customers WHERE hubspot_company_id = %s",
            (hubspot_company_id,)
        )
        conn.commit()
        deleted_count = cursor.rowcount
        cursor.close()
        conn.close()
        return deleted_count > 0
    except Exception as e:
        print(f"Error deleting customer from DB: {e}")
        return False
    finally:
        if conn:
            conn.close()
```

---

### **Automation Script 1: End-to-End Success (TC-001)**

*   **Description**: Automates the positive flow: sending a valid HubSpot webhook, verifying the 200 OK response, and confirming the record's creation in PostgreSQL.
*   **File**: `test_e2e_success.py`

```python
# test_e2e_success.py
import requests
import json
import time
from config import MULE_API_BASE_URL, HUBSPOT_WEBHOOK_ENDPOINT, HUBSPOT_CLIENT_SECRET
from utils import calculate_hubspot_signature, verify_customer_in_db, delete_customer_from_db

def test_e2e_successful_sync():
    print("\n--- Running Automated Test: End-to-End Successful Sync (TC-001) ---")

    company_id = "AUTO_COMP_" + str(int(time.time()))
    company_name = "Automated Test Company"
    company_domain = "autotestcompany.com"

    # Ensure clean state: delete if already exists from a previous failed run
    if delete_customer_from_db(company_id):
        print(f"Cleaned up existing record for {company_id}")

    payload = {
        "portalId": 62515,
        "eventGroupId": 1000,
        "objectId": int(company_id.split('_')[-1]), # HubSpot expects integer, using timestamp part
        "subscriptionId": 123456789,
        "appId": 12345,
        "occurredAt": "2023-11-01T10:00:00.000Z",
        "subscriptionType": "company.creation",
        "attemptNumber": 1,
        "objectType": "COMPANY",
        "changeSource": "CRM",
        "changeFlag": "NEW",
        "eventId": 987654321,
        "properties": {
            "name": company_name,
            "domain": company_domain,
            "createdate": "2023-11-01T09:55:00.000Z",
            "hs_object_id": company_id # Use string for unique ID in DB
        }
    }

    signature = calculate_hubspot_signature(HUBSPOT_CLIENT_SECRET, payload)

    headers = {
        "Content-Type": "application/json",
        "X-HubSpot-Signature": signature
    }

    api_url = f"{MULE_API_BASE_URL}{HUBSPOT_WEBHOOK_ENDPOINT}"
    print(f"Sending POST request to: {api_url}")
    print(f"Payload: {json.dumps(payload, indent=2)}")
    print(f"Signature: {signature}")

    response = requests.post(api_url, headers=headers, json=payload)

    print(f"API Response Status Code: {response.status_code}")
    print(f"API Response Body: {response.text}")

    # Assert API response
    assert response.status_code == 200, f"Expected HTTP 200 OK, but got {response.status_code}"
    response_json = response.json()
    assert response_json.get("status") == "success", f"Expected status 'success', but got {response_json.get('status')}"
    print("API Response: PASSED (200 OK and status 'success')")

    # Wait a bit for async processing to complete
    time.sleep(5)

    # Verify database insertion
    print(f"Verifying record in PostgreSQL for hubspot_company_id: {company_id}")
    db_verified = verify_customer_in_db(company_id, company_name, company_domain)
    assert db_verified, f"Customer record not found or data mismatch in DB for {company_id}"
    print("Database Verification: PASSED (record found with correct data)")

    # Clean up the created record
    if delete_customer_from_db(company_id):
        print(f"Cleaned up record for {company_id}")
    else:
        print(f"Failed to clean up record for {company_id}")

    print("--- End of End-to-End Successful Sync Test ---")

if __name__ == "__main__":
    test_e2e_successful_sync()
```

---

### **Automation Script 2: Invalid X-HubSpot-Signature (TC-002)**

*   **Description**: Automates sending a webhook with an invalid `X-HubSpot-Signature` and verifies the `401 Unauthorized` response.
*   **File**: `test_invalid_signature.py`

```python
# test_invalid_signature.py
import requests
import json
import time
from config import MULE_API_BASE_URL, HUBSPOT_WEBHOOK_ENDPOINT, HUBSPOT_CLIENT_SECRET
from utils import calculate_hubspot_signature

def test_invalid_hubspot_signature():
    print("\n--- Running Automated Test: Invalid X-HubSpot-Signature (TC-002) ---")

    company_id = "AUTO_INV_" + str(int(time.time()))
    company_name = "Invalid Signature Test"
    company_domain = "invalid-sig.com"

    payload = {
        "portalId": 62515,
        "eventGroupId": 1000,
        "objectId": int(company_id.split('_')[-1]),
        "subscriptionId": 123456789,
        "appId": 12345,
        "occurredAt": "2023-11-01T10:00:00.000Z",
        "subscriptionType": "company.creation",
        "attemptNumber": 1,
        "objectType": "COMPANY",
        "changeSource": "CRM",
        "changeFlag": "NEW",
        "eventId": 987654321,
        "properties": {
            "name": company_name,
            "domain": company_domain,
            "createdate": "2023-11-01T09:55:00.000Z",
            "hs_object_id": company_id
        }
    }

    # Calculate a valid signature, then intentionally corrupt it
    valid_signature = calculate_hubspot_signature(HUBSPOT_CLIENT_SECRET, payload)
    invalid_signature = valid_signature[:-1] + ('Z' if valid_signature[-1] != 'Z' else 'A') # Corrupt last char

    headers = {
        "Content-Type": "application/json",
        "X-HubSpot-Signature": invalid_signature
    }

    api_url = f"{MULE_API_BASE_URL}{HUBSPOT_WEBHOOK_ENDPOINT}"
    print(f"Sending POST request to: {api_url}")
    print(f"Payload: {json.dumps(payload, indent=2)}")
    print(f"Invalid Signature: {invalid_signature}")

    response = requests.post(api_url, headers=headers, json=payload)

    print(f"API Response Status Code: {response.status_code}")
    print(f"API Response Body: {response.text}")

    # Assert API response
    assert response.status_code == 401, f"Expected HTTP 401 Unauthorized, but got {response.status_code}"
    response_json = response.json()
    assert response_json.get("status") == "error", f"Expected status 'error', but got {response_json.get('status')}"
    assert "Invalid or missing X-HubSpot-Signature" in response_json.get("message", ""), \
        f"Expected specific error message, but got {response_json.get('message')}"
    print("API Response: PASSED (401 Unauthorized with correct error message)")

    # Optional: Verify no record was created in DB
    time.sleep(2) # Give some time to ensure no record was processed
    db_verified = verify_customer_in_db(company_id, company_name, company_domain)
    assert not db_verified, f"Unexpectedly found customer record in DB for {company_id}"
    print("Database Verification: PASSED (no record created)")

    print("--- End of Invalid X-HubSpot-Signature Test ---")

if __name__ == "__main_": # Changed to _ to avoid auto-run if both are in same folder
    test_invalid_hubspot_signature()
```

---

### **Automation Script 3: Missing X-HubSpot-Signature (TC-003)**

*   **Description**: Automates sending a webhook with a missing `X-HubSpot-Signature` header and verifies the `401 Unauthorized` response.
*   **File**: `test_missing_signature.py`

```python
# test_missing_signature.py
import requests
import json
import time
from config import MULE_API_BASE_URL, HUBSPOT_WEBHOOK_ENDPOINT
from utils import verify_customer_in_db

def test_missing_hubspot_signature():
    print("\n--- Running Automated Test: Missing X-HubSpot-Signature (TC-003) ---")

    company_id = "AUTO_MISS_" + str(int(time.time()))
    company_name = "Missing Signature Test"
    company_domain = "missing-sig.com"

    payload = {
        "portalId": 62515,
        "eventGroupId": 1000,
        "objectId": int(company_id.split('_')[-1]),
        "subscriptionId": 123456789,
        "appId": 12345,
        "occurredAt": "2023-11-01T10:00:00.000Z",
        "subscriptionType": "company.creation",
        "attemptNumber": 1,
        "objectType": "COMPANY",
        "changeSource": "CRM",
        "changeFlag": "NEW",
        "eventId": 987654321,
        "properties": {
            "name": company_name,
            "domain": company_domain,
            "createdate": "2023-11-01T09:55:00.000Z",
            "hs_object_id": company_id
        }
    }

    headers = {
        "Content-Type": "application/json"
        # X-HubSpot-Signature is intentionally missing
    }

    api_url = f"{MULE_API_BASE_URL}{HUBSPOT_WEBHOOK_ENDPOINT}"
    print(f"Sending POST request to: {api_url}")
    print(f"Payload: {json.dumps(payload, indent=2)}")
    print("X-HubSpot-Signature header is intentionally missing.")

    response = requests.post(api_url, headers=headers, json=payload)

    print(f"API Response Status Code: {response.status_code}")
    print(f"API Response Body: {response.text}")

    # Assert API response
    assert response.status_code == 401, f"Expected HTTP 401 Unauthorized, but got {response.status_code}"
    response_json = response.json()
    assert response_json.get("status") == "error", f"Expected status 'error', but got {response_json.get('status')}"
    assert "Invalid or missing X-HubSpot-Signature" in response_json.get("message", ""), \
        f"Expected specific error message, but got {response_json.get('message')}"
    print("API Response: PASSED (401 Unauthorized with correct error message)")

    # Optional: Verify no record was created in DB
    time.sleep(2) # Give some time to ensure no record was processed
    db_verified = verify_customer_in_db(company_id, company_name, company_domain)
    assert not db_verified, f"Unexpectedly found customer record in DB for {company_id}"
    print("Database Verification: PASSED (no record created)")

    print("--- End of Missing X-HubSpot-Signature Test ---")

if __name__ == "__main__":
    test_missing_hubspot_signature()
```