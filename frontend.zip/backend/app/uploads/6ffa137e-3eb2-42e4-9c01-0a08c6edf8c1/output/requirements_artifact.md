# PharmaCorp Commercial Website User Stories

This document outlines the user stories for the development of the PharmaCorp commercial website for patients and healthcare professionals (HCPs).

### **Epic: Core Website Structure & Pages**

---

#### **User Story 1: Homepage Foundation**

*   **As a** patient or HCP,
*   **I want to** view a clear and engaging homepage,
*   **so that** I can quickly understand the purpose of the site and navigate to key information about PharmaCorp and its products.

**Acceptance Criteria:**

1.  **Given** I am a first-time visitor, **when** I land on the homepage, **then** I should see a prominent hero section with a clear value proposition.
2.  **Given** I am on the homepage, **when** I look for navigation, **then** the main site header should be visible with links to Home, About Us, Products, and Contact Us.
3.  **Given** I am on the homepage, **when** I scroll down, **then** I should see distinct sections for featured products or therapeutic areas.
4.  **Given** I am on any page, **when** I scroll to the bottom, **then** a site footer must be present with links to Privacy Policy, Terms of Use, and Contact Us.
5.  **Given** I am viewing the homepage, **when** I resize my browser or change devices, **then** the layout must be fully responsive and usable on mobile, tablet, and desktop screens.
6.  **Given** I am using assistive technology, **when** I navigate the homepage, **then** all elements must be WCAG 2.2 AA compliant (e.g., images have alt text, sufficient color contrast, keyboard navigable).
7.  **Given** I am measuring performance, **when** the homepage loads, **then** the Largest Contentful Paint (LCP) must be under 2.5 seconds.

---

#### **User Story 2: About Us Page**

*   **As a** potential patient or partner,
*   **I want to** access an "About Us" page,
*   **so that** I can learn about PharmaCorp's mission, values, and history to build trust in the company.

**Acceptance Criteria:**

1.  **Given** I have navigated to the "About Us" page, **when** the page loads, **then** I should see a clear page title "About Us".
2.  **Given** I am on the "About Us" page, **when** I view the content, **then** there should be distinct sections for the company's mission, history, and leadership (using placeholder content initially).
3.  **Given** I am on the "About Us" page, **when** I look for navigation, **then** the standard site header and footer must be present.
4.  **Given** I am viewing the page, **when** I resize my browser, **then** the layout must be fully responsive.
5.  **Given** I am using a screen reader, **when** I navigate the page, **then** all content must be accessible and compliant with WCAG 2.2 AA standards.

---

#### **User Story 3: Legal & Compliance Pages**

*   **As a** site visitor,
*   **I want to** easily find and read the Privacy Policy and Terms of Use,
*   **so that** I can understand my rights and the company's policies regarding data and site usage.

**Acceptance Criteria:**

1.  **Given** I am on any page, **when** I view the footer, **then** I must see separate links for "Privacy Policy" and "Terms of Use".
2.  **Given** I click the "Privacy Policy" link, **when** the page loads, **then** I am taken to a dedicated `/privacy-policy` page displaying the relevant legal text.
3.  **Given** I click the "Terms of Use" link, **when** the page loads, **then** I am taken to a dedicated `/terms-of-use` page displaying the relevant legal text.
4.  **Given** I am on a legal page, **when** I view the page, **then** the content must be clearly formatted for readability (e.g., proper headings, paragraphs, lists).
5.  **Given** I am on a legal page, **when** I resize my browser, **then** the layout must be fully responsive.

### **Epic: Product Information**

---

#### **User Story 4: Product Listing Page**

*   **As a** patient or HCP,
*   **I want to** see a list of all available PharmaCorp products,
*   **so that** I can easily browse them and select one to learn more about.

**Acceptance Criteria:**

1.  **Given** I navigate to the "Products" section, **when** the page loads, **then** I am presented with a grid or list of all available products.
2.  **Given** I am viewing the product list, **when** I look at a product entry, **then** I should see its name, a representative image, and a brief, one-sentence description.
3.  **Given** I am viewing a product entry, **when** I click on it, **then** I am navigated to the corresponding Product Detail Page.
4.  **Given** I am viewing the product list, **when** I resize my browser, **then** the grid/list must adjust responsively.
5.  **Given** I am using assistive technology, **when** I navigate the product list, **then** all elements must be WCAG 2.2 AA compliant.

---

#### **User Story 5: Product Detail Page**

*   **As a** patient or HCP,
*   **I want to** view a detailed page for a specific product,
*   **so that** I can find comprehensive information about its use, benefits, and safety.

**Acceptance Criteria:**

1.  **Given** I have navigated to a product detail page, **when** the page loads, **then** I can see the product's name, images, and detailed descriptive text.
2.  **Given** I am on a product detail page, **when** I look for documentation, **then** I must see a clear and prominent link to download the full Prescribing Information (PI) PDF.
3.  **Given** I am on a product detail page, **when** I scroll, **then** the Important Safety Information (ISI) section must remain visible (see separate story).
4.  **Given** I am viewing the page, **when** I resize my browser, **then** the layout must be fully responsive.
5.  **Given** I am measuring performance, **when** the page loads, **then** the LCP must be under 2.5 seconds.
6.  **Given** I am using a screen reader, **when** I navigate the page, **then** all content must be accessible per WCAG 2.2 AA.

---

#### **User Story 6: Sticky Important Safety Information (ISI)**

*   **As a** patient or HCP on a product page,
*   **I want** the Important Safety Information (ISI) to always be visible,
*   **so that** I am constantly aware of the critical safety warnings associated with the product.

**Acceptance Criteria:**

1.  **Given** I am on a product detail page, **when** the page loads, **then** an ISI container is displayed on the page (e.g., in a side column or at the bottom).
2.  **Given** I scroll down the product detail page, **when** the ISI container would normally scroll out of view, **then** it becomes "sticky" and remains fixed in the viewport.
3.  **Given** the ISI content is longer than its container, **when** I hover over or focus on the container, **then** a vertical scrollbar must appear to allow me to read all of it.
4.  **Given** I am on a mobile device, **when** I view a product page, **then** the sticky ISI must not obstruct the main content and should be easily scrollable and readable.
5.  **Given** I am using a keyboard, **when** I navigate the page, **then** the ISI container and its contents must be focusable and scrollable using only the keyboard.

---

#### **User Story 7: Prescribing Information (PI) PDF Download**

*   **As an** HCP,
*   **I want to** download the full Prescribing Information (PI) as a PDF,
*   **so that** I can have the official, comprehensive documentation for clinical reference.

**Acceptance Criteria:**

1.  **Given** I am on a product detail page, **when** I click the "Download PI" or "Full Prescribing Information" link, **then** the associated PDF document opens in a new browser tab.
2.  **Given** the PI link is clicked, **when** the PDF is served, **then** it must be retrieved from a secure object storage service (e.g., S3, Azure Blob Storage).
3.  **Given** a product is created in the CMS, **when** a PI PDF is uploaded, **then** it must be associated with the correct product.

### **Epic: User Engagement & Communication**

---

#### **User Story 8: Contact Us Form**

*   **As a** site visitor,
*   **I want to** submit a message through a contact form,
*   **so that** I can easily send inquiries to PharmaCorp without using my email client.

**Acceptance Criteria:**

1.  **Given** I am on the "Contact Us" page, **when** I view the page, **then** I see a form with fields for "Full Name" (required), "Email Address" (required, must be valid format), "Subject" (optional), and "Message" (required).
2.  **Given** I have not filled out all required fields, **when** I click "Submit", **then** I see clear, inline error messages indicating which fields are required.
3.  **Given** I have filled out the form correctly, **when** I click "Submit", **then** the form data is sent via a POST request to a secure backend API endpoint.
4.  **Given** the submission is successful, **when** the API responds, **then** I see a success message on the page (e.g., "Thank you for your message!").
5.  **Given** the submission fails due to a server error, **when** the API responds, **then** I see an error message (e.g., "Sorry, something went wrong. Please try again later.").
6.  **Given** the form is submitted, **when** the data is processed, **then** the submission details (name, email, subject, message, timestamp) are stored in the PostgreSQL database.
7.  **Given** an attacker attempts to submit the form rapidly, **when** the API receives multiple requests from the same IP, **then** rate limiting is applied to prevent abuse.

---

#### **User Story 9: Newsletter Signup**

*   **As a** site visitor,
*   **I want to** subscribe to a newsletter,
*   **so that** I can stay informed about news and updates from PharmaCorp.

**Acceptance Criteria:**

1.  **Given** I am on any page, **when** I view the footer, **then** I see a newsletter signup form containing an "Email Address" field and a "Subscribe" button.
2.  **Given** I enter a valid email and click "Subscribe", **when** the form is submitted, **then** a success message is displayed near the form.
3.  **Given** I enter an invalid email, **when** I click "Subscribe", **then** an inline error message is displayed.
4.  **Given** I am in a region covered by GDPR/CCPA, **when** I view the form, **then** I must see a checkbox to consent to my data being stored and used for marketing communications, which must be checked to subscribe.
5.  **Given** a successful submission, **when** the data is processed, **then** the email address and consent status are sent to a secure API and stored.

### **Epic: Site-wide Functionality & Compliance**

---

#### **User Story 10: Site Search**

*   **As a** site visitor,
*   **I want to** use a search bar to find content on the site,
*   **so that** I can quickly locate information without browsing through the navigation.

**Acceptance Criteria:**

1.  **Given** I am on any page, **when** I look at the header, **then** I see a search input field.
2.  **Given** I type a query into the search field and press Enter or click a search icon, **when** the action is triggered, **then** I am taken to a dedicated search results page (`/search?q=my-query`).
3.  **Given** the search results page loads, **when** there are matching results, **then** I see a list of pages with their title, a brief content snippet, and a clickable link to the page.
4.  **Given** the search results page loads, **when** there are no matching results, **then** I see a clear message stating "No results found for '[my-query]'".
5.  **Given** a search is performed, **when** the backend processes it, **then** the API should query indexed content from the database to return relevant results.

---

#### **User Story 11: Cookie Consent Banner**

*   **As a** first-time visitor,
*   **I want to** be informed about the use of cookies and provide my consent,
*   **so that** I have control over my data in compliance with GDPR and CCPA.

**Acceptance Criteria:**

1.  **Given** I am visiting the site for the first time, **when** any page loads, **then** a cookie consent banner is displayed.
2.  **Given** the banner is displayed, **when** I inspect it, **then** it must contain a brief explanation of cookie usage, a link to the Privacy Policy, and buttons to "Accept All", "Reject All", and "Customize".
3.  **Given** I have not yet interacted with the banner, **when** I check my browser's cookies, **then** no non-essential (e.g., analytics, marketing) cookies should be set.
4.  **Given** I click "Accept All", **when** the action is processed, **then** all cookies are enabled and the banner is dismissed.
5.  **Given** I click "Reject All", **when** the action is processed, **then** only strictly necessary cookies are used and the banner is dismissed.
6.  **Given** I have made a choice, **when** I navigate to other pages or revisit the site later, **then** the banner does not reappear and my consent preference is remembered.

---

#### **User Story 12: Foundational Security Hardening**

*   **As** the PharmaCorp Security Officer,
*   **I want** the website to implement fundamental security best practices,
*   **so that** the company, its data, and its users are protected from common web attacks.

**Acceptance Criteria:**

1.  **Given** any user accesses the site via HTTP, **when** the request is received, **then** they are automatically redirected to the HTTPS equivalent.
2.  **Given** any page is served, **when** I inspect the HTTP headers, **then** a strict Content-Security-Policy (CSP) header is present to mitigate XSS attacks.
3.  **Given** any API endpoint that accepts user input is deployed, **when** it receives data, **then** all input is sanitized on the backend to prevent injection attacks.
4.  **Given** any form submission API is deployed, **when** it is called, **then** it must be protected by rate limiting to prevent denial-of-service or spam attacks.