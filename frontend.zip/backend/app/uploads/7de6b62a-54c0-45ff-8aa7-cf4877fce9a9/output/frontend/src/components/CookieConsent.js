import React, { useState, useEffect } from 'react';
import { Button, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle } from '@mui/material';

const CookieConsent = ({ onConsent }) => {
    const [open, setOpen] = useState(false);
    const [hasConsented, setHasConsented] = useState(() => localStorage.getItem('cookieConsent') === 'true');

    useEffect(() => {
        if (localStorage.getItem('cookieConsent') === null) {
            setOpen(true);
        }
    }, []);

    const handleAccept = () => {
        localStorage.setItem('cookieConsent', 'true');
        setHasConsented(true);
        setOpen(false);
        onConsent(true);
    };

    const handleDecline = () => {
        localStorage.setItem('cookieConsent', 'false');
        setHasConsented(false);
        setOpen(false);
        // Remove non-essential cookies here
        // Example: document.cookie = "cookieName=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
        onConsent(false);
    };

    if (hasConsented) {
        return null;
    }

    return (
        <Dialog open={open} onClose={() => {}}>
            <DialogTitle>Cookie Consent</DialogTitle>
            <DialogContent>
                <DialogContentText>
                    This website uses cookies to enhance your experience. By accepting, you agree to our use of cookies.
                </DialogContentText>
            </DialogContent>
            <DialogActions>
                <Button onClick={handleDecline} color="primary">
                    Decline
                </Button>
                <Button onClick={handleAccept} color="primary" autoFocus>
                    Accept
                </Button>
            </DialogActions>
        </Dialog>
    );
};

export default CookieConsent;