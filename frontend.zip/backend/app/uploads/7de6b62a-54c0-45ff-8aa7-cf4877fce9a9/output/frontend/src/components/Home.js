import React from 'react';
import { Typography, Container, Box } from '@mui/material';

const Home = () => {
    return (
        <Container>
            <Box my={4}>
                <Typography variant="h4" component="h1" gutterBottom>
                    Welcome to PharmaCorp
                </Typography>
                <Typography variant="body1">
                    At PharmaCorp, our mission is to improve patient lives by developing and delivering innovative
                    medicines and healthcare solutions. We are dedicated to advancing medical science, ensuring access
                    to our products, and making a positive impact on communities worldwide.
                </Typography>
            </Box>
        </Container>
    );
};

export default Home;