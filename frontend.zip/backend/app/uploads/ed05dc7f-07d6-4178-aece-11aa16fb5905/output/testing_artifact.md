# PharmaCorp Website Testing Document

## 1. Test Strategy

**1.1 Scope:** This document outlines the testing strategy for the PharmaCorp website, encompassing functional, performance, security, accessibility, and compliance testing.  The scope includes all features defined in the Software Requirements Specification (SRS) and High-Level Design (HLD) documents.

**1.2 Objectives:**

* Verify that all functionalities of the PharmaCorp website meet the requirements specified in the SRS.
* Ensure the website performs optimally and meets established performance targets.
* Identify and mitigate potential security vulnerabilities.
* Confirm the website's accessibility for users with disabilities, adhering to WCAG 2.2 AA guidelines.
* Validate compliance with GDPR and CCPA regulations.
* Deliver a high-quality, reliable, and secure website.

**1.3 Types of Testing:**

* **Functional Testing:**  Verifying that all features and functionalities work as expected.  This includes unit, integration, and end-to-end testing.
* **Performance Testing:** Evaluating website responsiveness, load time, and scalability.  This includes Load Testing and Large Content Page (LCP) testing.
* **Security Testing:** Identifying and mitigating potential security vulnerabilities, including penetration testing and vulnerability scanning.
* **Accessibility Testing:** Ensuring the website is accessible to users with disabilities, adhering to WCAG 2.2 AA guidelines.  This includes automated testing and manual audits.
* **Compliance Testing:** Verifying adherence to GDPR and CCPA regulations.
* **Database Testing:** Validating the integrity and consistency of data stored in the PostgreSQL database.
* **API Testing:**  Validating the functionality and performance of the backend APIs.


## 2. Test Plan

**2.1 Test Environment:**

* **Development Environment:** Local development machines.
* **Testing Environment:**  Staging server mirroring the production environment.
* **Production Environment:** Live website.

**2.2 Test Data:**  Test data will be generated to cover various scenarios, including valid and invalid inputs, edge cases, and boundary conditions.  Sensitive data will be anonymized.

**2.3 Test Tools:**

* **Selenium (Java):**  For automated UI testing.
* **REST-Assured (Java):** For API testing.
* **Postman:** For API testing and manual testing.
* **Jmeter:** For performance testing.
* **Lighthouse:** For performance (LCP) testing and accessibility testing.
* **axe-core:** For automated accessibility testing.
* **SonarQube:** For code quality analysis.
* **GitLab CI:** For CI/CD pipeline integration.
* **SQL Developer/pgAdmin:** For database testing.
* **OWASP ZAP:** For security testing.

**2.4 Test Cases:**

**User Story 1: About Us Page**

| Test Case ID | Test Case Name | Steps | Expected Result |
|---|---|---|---|
| TC_AboutUs_01 | Access About Us Page | 1. Navigate to the website.<br>2. Click on "About Us" in the main navigation. | About Us page loads successfully. |
| TC_AboutUs_02 | Verify Page Content | 1. Navigate to the About Us page.<br>2. Check for information on mission, values, history, and team. |  All sections are present and contain relevant information. |
| TC_AboutUs_03 | WCAG 2.2 AA Compliance | 1. Run Lighthouse accessibility audit on the About Us page. |  Lighthouse reports no critical or serious accessibility violations. |
| TC_AboutUs_04 | Page Load Time | 1. Use Lighthouse to measure LCP. | LCP is under 2.5 seconds. |


**User Story 2: Products Page**

| Test Case ID | Test Case Name | Steps | Expected Result |
|---|---|---|---|
| TC_Products_01 | Access Products Page | 1. Navigate to the website.<br>2. Click on "Products" in the main navigation. | Products page loads successfully. |
| TC_Products_02 | Verify Product Listings | 1. Navigate to the Products page.<br>2. Check for product listings with descriptions and images. | All products are listed with descriptions and images. |
| TC_Products_03 | Access Product Details | 1. Click on a product from the Products page.<br>2. Check for detailed information (indications, contraindications, dosage, prescribing information). | Product details page loads successfully with complete information. |
| TC_Products_04 | Download PI/MedGuide | 1. Navigate to a product details page.<br>2. Download the PI/MedGuide PDF. | PDF downloads successfully. |
| TC_Products_05 | Sticky ISI Functionality | 1. Navigate to a product details page.<br>2. Scroll the page. | The ISI section remains visible while scrolling on various screen sizes.  |
| TC_Products_06 | WCAG 2.2 AA Compliance | 1. Run Lighthouse accessibility audit on the Products page and product details pages. | Lighthouse reports no critical or serious accessibility violations. |
| TC_Products_07 | Page Load Time | 1. Use Lighthouse to measure LCP for Products page and product details pages. | LCP is under 2.5 seconds for both pages. |


**User Story 3: Contact Us Form**

| Test Case ID | Test Case Name | Steps | Expected Result |
|---|---|---|---|
| TC_Contact_01 | Submit Valid Form | 1. Navigate to Contact Us page.<br>2. Fill in all fields with valid data.<br>3. Submit the form. | Confirmation message displayed.  Form submission logged in the database. Email sent successfully. |
| TC_Contact_02 | Submit Invalid Email | 1. Navigate to Contact Us page.<br>2. Fill in all fields, entering an invalid email address.<br>3. Submit the form. | Clear error message indicating invalid email format. |
| TC_Contact_03 | Submit Empty Fields | 1. Navigate to Contact Us page.<br>2. Submit the form without filling any fields.<br>3. Submit the form. | Clear error messages for each empty field. |
| TC_Contact_04 | Form Submission Logging | 1. Submit a valid contact form.<br>2. Check the PostgreSQL database. | Form submission data is logged in the database. |
| TC_Contact_05 | Email Notification | 1. Submit a valid contact form.<br>2. Check the email inbox. | Email notification is received. |
| TC_Contact_06 | Error Logging | 1. Submit a form with an invalid email address.<br>2. Check the error logs. | Error message is logged. |


**(Test cases for User Stories 4-11 will follow a similar format, covering all acceptance criteria and edge cases.)**


**2.5 Test Schedule:** (A detailed schedule with specific dates and milestones would be included here.  This is omitted for brevity.)


## 3. Test Automation Scripts (Examples)

**(Note: These are simplified examples.  A complete suite would include many more tests and more robust error handling.)**

**3.1 Selenium (Java) - User Story 1 (About Us Page):**

```java
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


public class AboutUsTest {

    private WebDriver driver;

    @BeforeTest
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "/path/to/chromedriver");
        driver = new ChromeDriver();
    }

    @Test
    public void testAboutUsPage() {
        driver.get("https://www.pharmacorp.com"); //Replace with actual URL
        WebElement aboutUsLink = driver.findElement(By.linkText("About Us")); //Replace with actual locator
        aboutUsLink.click();
        //Assertions to check for content, etc.
        Assert.assertTrue(driver.findElement(By.xpath("//h1[text()='About Us']")).isDisplayed()); //Example Assertion
        // Add more assertions to verify the presence of mission, values, history, team etc.
    }


    @AfterTest
    public void tearDown() {
        driver.quit();
    }
}
```

**3.2 REST-Assured (Java) - User Story 8 (Product API):**

```java
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class ProductApiTest {

    @Test
    public void testGetProducts() {
        RestAssured.baseURI = "https://api.pharmacorp.com"; //Replace with actual API base URL

        Response response = get("/products");
        response.then().statusCode(200).body("size()", greaterThan(0));
    }

    @Test
    public void testGetProductById(){
        RestAssured.baseURI = "https://api.pharmacorp.com"; //Replace with actual API base URL
        Response response = get("/products/1"); //Replace with actual product ID
        response.then().statusCode(200).body("product_id", equalTo(1)); //Replace with assertion based on expected response
    }

}
```


**3.3 Python (pytest) - User Story 5 (Search Functionality):** (This example uses `requests` for API interaction and assumes a search API endpoint exists.  Selenium would be used for UI interaction if the search was directly on the website)


```python
import pytest
import requests

def test_search_valid_term():
    url = "https://api.pharmacorp.com/search?query=productA" #Replace with actual API endpoint
    response = requests.get(url)
    assert response.status_code == 200
    assert len(response.json()) > 0 #Check that at least one result is returned

def test_search_invalid_term():
    url = "https://api.pharmacorp.com/search?query=asdfsdfasdf" #Replace with actual API endpoint
    response = requests.get(url)
    assert response.status_code == 200
    assert len(response.json()) == 0 #Check that no results are returned

# Add more tests for edge cases and boundary conditions
```


## 4. Database Testing

Database testing will verify data integrity, consistency, and accuracy across all tables (`products`, `contact_forms`, `newsletter_subscribers`, `content`).  This will involve:

* **Data Validation:**  Verifying that data inserted, updated, and deleted is accurate and consistent with the application logic.
* **Data Integrity:**  Checking for referential integrity and data constraints.
* **Data Consistency:**  Ensuring data consistency across different tables.
* **SQL Queries:**  Executing SQL queries to retrieve and validate data.
* **Stored Procedures:**  Testing stored procedures to ensure they function correctly.


## 5. Security Testing

Security testing will include:

* **Vulnerability Scanning:** Using automated tools like OWASP ZAP to identify potential vulnerabilities (SQL injection, XSS, CSRF, etc.).
* **Penetration Testing:** Simulating real-world attacks to identify security weaknesses.
* **Authentication and Authorization Testing:**  Verifying that only authorized users can access sensitive information.
* **Input Validation Testing:**  Checking that the application properly validates user inputs to prevent injection attacks.
* **HTTPS and SSL/TLS testing:** Verifying that all communication is encrypted.


## 6. Compliance Testing

Compliance testing will ensure the website meets WCAG 2.2 AA accessibility guidelines, GDPR, and CCPA requirements.  This will involve:

* **WCAG 2.2 AA Compliance:**
    * **Automated Testing:** Using tools like axe-core and Lighthouse.
    * **Manual Audits:**  By certified accessibility specialists.
* **GDPR/CCPA Compliance:**
    * **Data Privacy:**  Verifying that data is collected, processed, and stored in accordance with GDPR/CCPA regulations.
    * **Consent Management:**  Testing the cookie consent banner to ensure that it complies with regulations.
    * **Data Subject Access Requests:**  Verifying that users can access and manage their data.


## 7. Performance Testing

Performance testing will focus on Large Content Paint (LCP) to ensure the website meets the target of under 2.5 seconds.  We will use Lighthouse integrated into the CI/CD pipeline to measure LCP on the staging environment before deployment to production.  Performance testing will also include load testing using JMeter to simulate high user traffic and identify potential bottlenecks.