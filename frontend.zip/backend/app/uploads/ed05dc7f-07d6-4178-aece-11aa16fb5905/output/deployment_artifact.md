```markdown
# PharmaCorp Website Deployment

This document outlines the deployment artifacts for the PharmaCorp website.  The architecture employs a microservices approach, leveraging Docker and Docker Compose for local development and deployment.  Production deployment is targeted towards AWS.

## Project Structure

```
pharmacorp-website/
├── backend/
│   ├── product_api/
│   │   ├── main.py
│   │   ├── database.py
│   │   ├── models.py
│   │   ├── Dockerfile
│   │   └── tests/
│   │       └── test_main.py
│   ├── content_api/
│   │   ├── ...
│   ├── newsletter_api/
│   │   ├── ...
│   └── contact_form_api/
│       ├── ...
├── frontend/
│   ├── src/
│   │   ├── App.js
│   │   ├── components/
│   │   │   ├── ProductList.js
│   │   │   └── ProductDetails.js
│   │   └── ...
│   └── package.json
│   └── ...
├── docker-compose.yml
├── nginx/
│   └── nginx.conf
└── README.md

```

## 1. Dockerfiles

### backend/product_api/Dockerfile

```dockerfile
FROM python:3.9-slim-buster

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

### backend/content_api/Dockerfile (Example - Repeat for other APIs)

```dockerfile
FROM python:3.9-slim-buster

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8001"]
```


## 2. docker-compose.yml

```yaml
version: "3.9"
services:
  db:
    image: postgres:13
    restart: always
    environment:
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=password
      - POSTGRES_DB=pharmacorp
    ports:
      - "5432:5432"
    volumes:
      - db_data:/var/lib/postgresql/data
  product_api:
    build: ./backend/product_api
    ports:
      - "8000:8000"
    depends_on:
      - db
    environment:
      - DATABASE_URL=postgresql://user:password@db:5432/pharmacorp
  content_api:
    build: ./backend/content_api
    ports:
      - "8001:8001"
    depends_on:
      - db
    environment:
      - DATABASE_URL=postgresql://user:password@db:5432/pharmacorp
  newsletter_api:
    build: ./backend/newsletter_api
    ports:
      - "8002:8002"
    depends_on:
      - db
    environment:
      - DATABASE_URL=postgresql://user:password@db:5432/pharmacorp
  contact_form_api:
    build: ./backend/contact_form_api
    ports:
      - "8003:8003"
    depends_on:
      - db
    environment:
      - DATABASE_URL=postgresql://user:password@db:5432/pharmacorp
  elasticsearch:
    image: elasticsearch:7.17.6
    ports:
      - "9200:9200"
      - "9300:9300"
  nginx:
    image: nginx:latest
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/conf.d/default.conf
    depends_on:
      - product_api
      - content_api
      - newsletter_api
      - contact_form_api

volumes:
  db_data:
```

### nginx/nginx.conf

```nginx
server {
    listen 80;
    listen [::]:80;
    server_name localhost;

    location / {
        proxy_pass http://product_api:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Add similar location blocks for other APIs (content_api, newsletter_api, contact_form_api)
    location /content {
        proxy_pass http://content_api:8001;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    location /newsletter {
        proxy_pass http://newsletter_api:8002;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    location /contact {
        proxy_pass http://contact_form_api:8003;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

}

server {
    listen 443 ssl;
    listen [::]:443 ssl;
    server_name localhost;
    ssl_certificate /etc/ssl/certs/localhost.crt; # Replace with your certificate
    ssl_certificate_key /etc/ssl/private/localhost.key; # Replace with your key

    location / {
        proxy_pass http://product_api:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
        # Add similar location blocks for other APIs (content_api, newsletter_api, contact_form_api) as above
}
```

## 3. README.md

```markdown
# PharmaCorp Website Deployment

This document provides instructions for building, configuring, and deploying the PharmaCorp website.

## Prerequisites

* Docker
* Docker Compose
* AWS Account (for production deployment)
* Node.js and npm (for frontend)

## Local Development

1. **Clone the repository:**
   ```bash
   git clone <repository_url>
   cd pharmacorp-website
   ```

2. **Build the backend images:**
   ```bash
   docker-compose up --build -d
   ```

3. **Install frontend dependencies:**
   ```bash
   cd frontend
   npm install
   ```

4. **Start the frontend development server:**
   ```bash
   npm start
   ```

## Production Deployment (AWS)

1. **Create AWS resources:**
   * **RDS instance:** Create a PostgreSQL RDS instance.  Configure appropriate security groups to allow access from your EC2 instances.  Note the endpoint.
   * **S3 bucket:** Create an S3 bucket to store product images and PDFs.
   * **Elasticsearch Service:** Create an Elasticsearch domain.
   * **EC2 instances:** Create at least three EC2 instances (one for each API and one for Nginx). Configure security groups to allow communication between instances and access to RDS and S3. Assign appropriate IAM roles with necessary permissions.

2. **Update environment variables:** Update the `DATABASE_URL` environment variable in the `docker-compose.yml` file to point to your RDS instance.

3. **Build Docker images:**

4. **Deploy to EC2:** Deploy the Dockerized applications to your EC2 instances using Docker Compose or a similar orchestration tool (e.g., ECS, EKS).

5. **Configure Nginx:** Configure Nginx as a reverse proxy to handle HTTPS and load balancing.  Obtain an SSL certificate (e.g., from AWS Certificate Manager).

6. **Configure Elasticsearch:**  Index product and content data into Elasticsearch.


## API Key Management

API keys will be managed through the admin panel (currently not implemented in this example).  This will involve a secure mechanism for generating, revoking, and managing API keys associated with users.


## CI/CD (GitLab CI)

*(Implementation details for GitLab CI would go here, including `.gitlab-ci.yml` configuration)*


## Testing

**Unit Tests:** Run unit tests using `pytest` for each backend API.  Example: `pytest backend/product_api/tests/`

**End-to-End Tests:** (Implementation details for E2E testing would go here, possibly using Cypress or similar framework)

## Security

* HTTPS is configured using Nginx.
* Input validation is implemented in all APIs.
* Content Security Policy (CSP) headers are included in the Nginx configuration.
* Rate limiting can be implemented using Nginx or API gateway features.



```