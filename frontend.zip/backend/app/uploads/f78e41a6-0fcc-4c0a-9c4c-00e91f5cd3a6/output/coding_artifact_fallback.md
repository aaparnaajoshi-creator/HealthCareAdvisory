```markdown
frontend/index.html
```
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PharmaCorp</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="products.html">Products</a></li>
                <li><a href="contact.html">Contact Us</a></li>
                <li><a href="privacy.html">Privacy/Terms</a></li>
                <li><a href="search.html">Search</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section id="hero">
            <h1>Welcome to PharmaCorp</h1>
            <p>Leading the way in pharmaceutical innovation.</p>
            <a href="products.html" class="cta-button">Explore Our Products</a>
        </section>

        <section id="featured-products">
            <h2>Featured Products</h2>
            <div class="products-container">
                </div>
        </section>

        <section id="about-us-brief">
            <h2>About Us</h2>
            <p>PharmaCorp is dedicated to improving health and well-being through innovative pharmaceutical solutions...</p>
            <a href="about.html" class="cta-button">Learn More</a>
        </section>
    </main>

    <footer>
        <section id="newsletter-signup">
            <h3>Sign Up for Our Newsletter</h3>
            <form id="newsletterForm">
                <input type="email" id="newsletterEmail" placeholder="Enter your email">
                <input type="checkbox" id="newsletterConsent">
                <label for="newsletterConsent">I consent to receiving marketing emails.</label>
                <button type="submit">Subscribe</button>
                <p id="newsletterMessage"></p>
            </form>
        </section>
        <p>&copy; 2024 PharmaCorp. All rights reserved.</p>
    </footer>

    <div id="cookie-banner">
        <p>This website uses cookies to enhance your experience. <a href="privacy.html">Learn more</a></p>
        <button id="accept-cookies">Accept All</button>
        <button id="reject-cookies">Reject All</button>
        <button id="customize-cookies">Customize</button>
    </div>

    <script src="script.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            loadFeaturedProducts();
            checkCookieConsent();
        });
    </script>
</body>
</html>
```

```markdown
frontend/about.html
```
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - PharmaCorp</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="products.html">Products</a></li>
                <li><a href="contact.html">Contact Us</a></li>
                <li><a href="privacy.html">Privacy/Terms</a></li>
                <li><a href="search.html">Search</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section id="about-us">
            <h1>About PharmaCorp</h1>
            <p>PharmaCorp is a leading pharmaceutical company dedicated to discovering, developing, and commercializing innovative therapies to improve patient health...</p>

            <h2>Our Mission</h2>
            <p>To improve the lives of patients by providing access to safe and effective medicines.</p>

            <h2>Our Values</h2>
            <ul>
                <li>Integrity</li>
                <li>Innovation</li>
                <li>Collaboration</li>
                <li>Patient Focus</li>
            </ul>

            <h2>Leadership</h2>
            <p>Our leadership team is comprised of experienced professionals with a proven track record of success in the pharmaceutical industry...</p>
        </section>
    </main>

    <footer>
        <section id="newsletter-signup">
            <h3>Sign Up for Our Newsletter</h3>
            <form id="newsletterForm">
                <input type="email" id="newsletterEmail" placeholder="Enter your email">
                <input type="checkbox" id="newsletterConsent">
                <label for="newsletterConsent">I consent to receiving marketing emails.</label>
                <button type="submit">Subscribe</button>
                <p id="newsletterMessage"></p>
            </form>
        </section>
        <p>&copy; 2024 PharmaCorp. All rights reserved.</p>
    </footer>

    <div id="cookie-banner">
        <p>This website uses cookies to enhance your experience. <a href="privacy.html">Learn more</a></p>
        <button id="accept-cookies">Accept All</button>
        <button id="reject-cookies">Reject All</button>
        <button id="customize-cookies">Customize</button>
    </div>

    <script src="script.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            checkCookieConsent();
        });
    </script>
</body>
</html>
```

```markdown
frontend/products.html
```
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - PharmaCorp</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="products.html">Products</a></li>
                <li><a href="contact.html">Contact Us</a></li>
                <li><a href="privacy.html">Privacy/Terms</a></li>
                 <li><a href="search.html">Search</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section id="products">
            <h1>Our Products</h1>
            <div id="product-list">
                </div>
        </section>
    </main>

    <footer>
        <section id="newsletter-signup">
            <h3>Sign Up for Our Newsletter</h3>
            <form id="newsletterForm">
                <input type="email" id="newsletterEmail" placeholder="Enter your email">
                <input type="checkbox" id="newsletterConsent">
                <label for="newsletterConsent">I consent to receiving marketing emails.</label>
                <button type="submit">Subscribe</button>
                 <p id="newsletterMessage"></p>
            </form>
        </section>
        <p>&copy; 2024 PharmaCorp. All rights reserved.</p>
    </footer>

    <div id="cookie-banner">
        <p>This website uses cookies to enhance your experience. <a href="privacy.html">Learn more</a></p>
        <button id="accept-cookies">Accept All</button>
        <button id="reject-cookies">Reject All</button>
        <button id="customize-cookies">Customize</button>
    </div>

    <script src="script.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            loadProducts();
            checkCookieConsent();
        });
    </script>
</body>
</html>
```

```markdown
frontend/product_detail.html
```
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Detail - PharmaCorp</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .isi-section {
            position: sticky;
            top: 0;
            background-color: #f9f9f9;
            padding: 10px;
            border-bottom: 1px solid #ccc;
            z-index: 100;
        }
    </style>
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="products.html">Products</a></li>
                <li><a href="contact.html">Contact Us</a></li>
                <li><a href="privacy.html">Privacy/Terms</a></li>
                 <li><a href="search.html">Search</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section id="product-detail">
            <div class="isi-section">
                <h3>Important Safety Information</h3>
                <p id="isi-content"></p>
            </div>

            <h1 id="product-name"></h1>
            <p id="product-description"></p>
            <p id="product-indications"></p>
            <p id="product-dosage"></p>
            <p id="product-administration"></p>

            <a id="pi-download-link" href="#" target="_blank">Download Prescribing Information (PI)</a>
        </section>
    </main>

    <footer>
        <section id="newsletter-signup">
            <h3>Sign Up for Our Newsletter</h3>
            <form id="newsletterForm">
                <input type="email" id="newsletterEmail" placeholder="Enter your email">
                <input type="checkbox" id="newsletterConsent">
                <label for="newsletterConsent">I consent to receiving marketing emails.</label>
                <button type="submit">Subscribe</button>
                 <p id="newsletterMessage"></p>
            </form>
        </section>
        <p>&copy; 2024 PharmaCorp. All rights reserved.</p>
    </footer>

    <div id="cookie-banner">
        <p>This website uses cookies to enhance your experience. <a href="privacy.html">Learn more</a></p>
        <button id="accept-cookies">Accept All</button>
        <button id="reject-cookies">Reject All</button>
        <button id="customize-cookies">Customize</button>
    </div>

    <script src="script.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const urlParams = new URLSearchParams(window.location.search);
            const productId = urlParams.get('id');
            loadProductDetail(productId);
            checkCookieConsent();
        });
    </script>
</body>
</html>
```

```markdown
frontend/contact.html
```
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - PharmaCorp</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="products.html">Products</a></li>
                <li><a href="contact.html">Contact Us</a></li>
                <li><a href="privacy.html">Privacy/Terms</a></li>
                 <li><a href="search.html">Search</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section id="contact-form">
            <h1>Contact Us</h1>
            <form id="contactForm">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>

                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>

                <label for="subject">Subject:</label>
                <input type="text" id="subject" name="subject" required>

                <label for="message">Message:</label>
                <textarea id="message" name="message" rows="5" required></textarea>

                <button type="submit">Submit</button>
                <p id="contactMessage"></p>
            </form>
        </section>
    </main>

    <footer>
        <section id="newsletter-signup">
            <h3>Sign Up for Our Newsletter</h3>
            <form id="newsletterForm">
                <input type="email" id="newsletterEmail" placeholder="Enter your email">
                <input type="checkbox" id="newsletterConsent">
                <label for="newsletterConsent">I consent to receiving marketing emails.</label>
                <button type="submit">Subscribe</button>
                 <p id="newsletterMessage"></p>
            </form>
        </section>
        <p>&copy; 2024 PharmaCorp. All rights reserved.</p>
    </footer>

    <div id="cookie-banner">
        <p>This website uses cookies to enhance your experience. <a href="privacy.html">Learn more</a></p>
        <button id="accept-cookies">Accept All</button>
        <button id="reject-cookies">Reject All</button>
        <button id="customize-cookies">Customize</button>
    </div>

    <script src="script.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            checkCookieConsent();
        });
    </script>
</body>
</html>
```

```markdown
frontend/privacy.html
```
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy/Terms - PharmaCorp</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="products.html">Products</a></li>
                <li><a href="contact.html">Contact Us</a></li>
                <li><a href="privacy.html">Privacy/Terms</a></li>
                 <li><a href="search.html">Search</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section id="privacy-terms">
            <h1>Privacy Policy & Terms of Use</h1>

            <h2>Privacy Policy</h2>
            <p>Your privacy is important to us. This privacy policy explains how we collect, use, and protect your personal information...</p>

            <h2>Terms of Use</h2>
            <p>By using this website, you agree to the following terms and conditions...</p>
        </section>
    </main>

    <footer>
        <section id="newsletter-signup">
            <h3>Sign Up for Our Newsletter</h3>
            <form id="newsletterForm">
                <input type="email" id="newsletterEmail" placeholder="Enter your email">
                <input type="checkbox" id="newsletterConsent">
                <label for="newsletterConsent">I consent to receiving marketing emails.</label>
                <button type="submit">Subscribe</button>
                 <p id="newsletterMessage"></p>
            </form>
        </section>
        <p>&copy; 2024 PharmaCorp. All rights reserved.</p>
    </footer>

    <div id="cookie-banner">
        <p>This website uses cookies to enhance your experience. <a href="privacy.html">Learn more</a></p>
        <button id="accept-cookies">Accept All</button>
        <button id="reject-cookies">Reject All</button>
        <button id="customize-cookies">Customize</button>
    </div>

    <script src="script.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            checkCookieConsent();
        });
    </script>
</body>
</html>
```

```markdown
frontend/search.html
```
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search - PharmaCorp</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="products.html">Products</a></li>
                <li><a href="contact.html">Contact Us</a></li>
                <li><a href="privacy.html">Privacy/Terms</a></li>
                <li><a href="search.html">Search</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section id="search">
            <h1>Search Results</h1>
            <input type="text" id="search-input" placeholder="Enter search term">
            <button onclick="performSearch()">Search</button>
            <div id="search-results">
                </div>
        </section>
    </main>

    <footer>
        <section id="newsletter-signup">
            <h3>Sign Up for Our Newsletter</h3>
            <form id="newsletterForm">
                <input type="email" id="newsletterEmail" placeholder="Enter your email">
                <input type="checkbox" id="newsletterConsent">
                <label for="newsletterConsent">I consent to receiving marketing emails.</label>
                <button type="submit">Subscribe</button>
                <p id="newsletterMessage"></p>
            </form>
        </section>
        <p>&copy; 2024 PharmaCorp. All rights reserved.</p>
    </footer>

    <div id="cookie-banner">
        <p>This website uses cookies to enhance your experience. <a href="privacy.html">Learn more</a></p>
        <button id="accept-cookies">Accept All</button>
        <button id="reject-cookies">Reject All</button>
        <button id="customize-cookies">Customize</button>
    </div>

    <script src="script.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            checkCookieConsent();
        });

        function performSearch() {
            const searchTerm = document.getElementById('search-input').value;
            const encodedSearchTerm = encodeURIComponent(searchTerm);
            loadSearchResults(encodedSearchTerm);
        }
    </script>
</body>
</html>
```

```markdown
frontend/style.css
```
```css
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
    color: #333;
}

header {
    background-color: #007bff;
    color: #fff;
    padding: 10px 0;
    text-align: center;
}

nav ul {
    list-style: none;
    padding: 0;
}

nav ul li {
    display: inline;
    margin: 0 20px;
}

nav ul li a {
    color: #fff;
    text-decoration: none;
}

main {
    padding: 20px;
    min-height: 500px;
}

#hero {
    background-color: #e9ecef;
    padding: 30px;
    text-align: center;
    margin-bottom: 20px;
}

.cta-button {
    background-color: #28a745;
    color: #fff;
    padding: 10px 20px;
    text-decoration: none;
    border-radius: 5px;
}

#featured-products {
    margin-bottom: 20px;
}

.products-container {
    display: flex;
    justify-content: space-around;
    flex-wrap: wrap;
}

.product-card {
    width: 30%;
    background-color: #fff;
    padding: 15px;
    margin-bottom: 15px;
    border-radius: 5px;
}

footer {
    background-color: #343a40;
    color: #fff;
    text-align: center;
    padding: 20px 0;
}

#newsletter-signup {
    margin-bottom: 20px;
}

#newsletterForm {
    display: flex;
    justify-content: center;
    align-items: center;
}

#newsletterEmail {
    padding: 10px;
    margin-right: 10px;
    border-radius: 5px;
    border: 1px solid #ccc;
}

#newsletterForm button {
    background-color: #dc3545;
    color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

#cookie-banner {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    background-color: #f0f0f0;
    color: #333;
    padding: 10px;
    text-align: center;
    z-index: 1000;
}

#cookie-banner button {
    margin: 0 5px;
    padding: 5px 10px;
    border: none;
    background-color: #007bff;
    color: white;
    cursor: pointer;
}
```

```markdown
frontend/script.js
```
```javascript
const API_BASE_URL = '/api';

function checkCookieConsent() {
    if (localStorage.getItem('cookieConsent') !== 'true') {
        document.getElementById('cookie-banner').style.display = 'block';

        document.getElementById('accept-cookies').addEventListener('click', function() {
            setCookieConsent(true, true, true);
            document.getElementById('cookie-banner').style.display = 'none';
        });

        document.getElementById('reject-cookies').addEventListener('click', function() {
            setCookieConsent(false, false, false);
            document.getElementById('cookie-banner').style.display = 'none';
        });

        document.getElementById('customize-cookies').addEventListener('click', function() {
            alert('Cookie customization options coming soon!');
            // Ideally, this would open a modal to customize cookie preferences
            document.getElementById('cookie-banner').style.display = 'none';
        });
    }
}

function setCookieConsent(analytics, marketing, functional) {
    localStorage.setItem('cookieConsent', 'true');

    const consentData = {
        user_id: 'default_user', // Replace with actual user ID if available
        analytics_consent: analytics,
        marketing_consent: marketing,
        functional_consent: functional
    };

    try {
        fetch(`${API_BASE_URL}/cookie_consent`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(consentData)
        }).then(response => {
            if (!response.ok) {
                console.error('Error saving cookie consent:', response.status);
            }
        });
    } catch (error) {
        console.error('Network error while saving cookie consent:', error);
    }
}

function loadProducts() {
    try {
        fetch(`${API_BASE_URL}/products`)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(products => {
                const productListDiv = document.getElementById('product-list');
                productListDiv.innerHTML = ''; // Clear existing content

                products.forEach(product => {
                    const productDiv = document.createElement('div');
                    productDiv.classList.add('product-card');
                    productDiv.innerHTML = `
                        <h3>${product.name}</h3>
                        <p>${product.description}</p>
                        <a href="product_detail.html?id=${product.product_id}">Learn More</a>
                    `;
                    productListDiv.appendChild(productDiv);
                });
            })
            .catch(error => {
                console.error('Error loading products:', error);
                document.getElementById('product-list').innerHTML = '<p>Failed to load products.</p>';
            });
    } catch (error) {
        console.error('Network error while loading products:', error);
        document.getElementById('product-list').innerHTML = '<p>Failed to load products due to a network error.</p>';
    }
}

function loadFeaturedProducts() {
    try {
        fetch(`${API_BASE_URL}/products`)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(products => {
                const featuredProductsContainer = document.querySelector('#featured-products .products-container');
                featuredProductsContainer.innerHTML = '';

                // Display a maximum of 3 featured products
                const featured = products.slice(0, 3);

                featured.forEach(product => {
                    const productDiv = document.createElement('div');
                    productDiv.classList.add('product-card');
                    productDiv.innerHTML = `
                        <h3>${product.name}</h3>
                        <p>${product.description}</p>
                        <a href="product_detail.html?id=${product.product_id}">Learn More</a>
                    `;
                    featuredProductsContainer.appendChild(productDiv);
                });
            })
            .catch(error => {
                console.error('Error loading featured products:', error);
                document.querySelector('#featured-products .products-container').innerHTML = '<p>Failed to load featured products.</p>';
            });
    } catch (error) {
        console.error('Network error while loading featured products:', error);
        document.querySelector('#featured-products .products-container').innerHTML = '<p>Failed to load featured products due to a network error.</p>';
    }
}

function loadProductDetail(productId) {
    try {
        fetch(`${API_BASE_URL}/products/${productId}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(product => {
                document.getElementById('product-name').textContent = product.name;
                document.getElementById('product-description').textContent = product.description;
                document.getElementById('product-indications').textContent = `Indications: ${product.indications}`;
                document.getElementById('product-dosage').textContent = `Dosage: ${product.dosage}`;
                document.getElementById('product-administration').textContent = `Administration: ${product.administration}`;
                document.getElementById('isi-content').textContent = product.important_safety_information;
                document.getElementById('pi-download-link').href = product.pi_pdf_url;
            })
            .catch(error => {
                console.error('Error loading product detail:', error);
                document.getElementById('product-detail').innerHTML = '<p>Failed to load product details.</p>';
            });
    } catch (error) {
        console.error('Network error while loading product detail:', error);
        document.getElementById('product-detail').innerHTML = '<p>Failed to load product details due to a network error.</p>';
    }
}

document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const subject = document.getElementById('subject').value;
    const message = document.getElementById('message').value;

    const contactData = {
        name: name,
        email: email,
        subject: subject,
        message: message
    };

    try {
        fetch(`${API_BASE_URL}/contact`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(contactData)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            document.getElementById('contactMessage').textContent = data.message;
            document.getElementById('contactForm').reset();
        })
        .catch(error => {
            console.error('Error submitting contact form:', error);
            document.getElementById('contactMessage').textContent = 'Failed to submit the form. Please try again.';
        });
    } catch (error) {
        console.error('Network error while submitting contact form:', error);
        document.getElementById('contactMessage').textContent = 'Failed to submit the form due to a network error. Please check your internet connection.';
    }
});

document.getElementById('newsletterForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const email = document.getElementById('newsletterEmail').value;
    const consentGiven = document.getElementById('newsletterConsent').checked;

    const newsletterData = {
        email: email,
        consent_given: consentGiven
    };

    try {
        fetch(`${API_BASE_URL}/newsletter`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(newsletterData)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            document.getElementById('newsletterMessage').textContent = data.message;
            document.getElementById('newsletterForm').reset();
        })
        .catch(error => {
            console.error('Error submitting newsletter signup:', error);
            document.getElementById('newsletterMessage').textContent = 'Failed to sign up for the newsletter. Please try again.';
        });
    } catch (error) {
        console.error('Network error while submitting newsletter signup:', error);
        document.getElementById('newsletterMessage').textContent = 'Failed to sign up for the newsletter due to a network error. Please check your internet connection.';
    }
});

function loadSearchResults(searchTerm) {
    try {
        fetch(`${API_BASE_URL}/search?q=${searchTerm}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(results => {
                const searchResultsDiv = document.getElementById('search-results');
                searchResultsDiv.innerHTML = ''; // Clear previous results

                if (results.length === 0) {
                    searchResultsDiv.innerHTML = '<p>No results found.</p>';
                    return;
                }

                results.forEach(result => {
                    const resultDiv = document.createElement('div');
                    resultDiv.classList.add('search-result');

                    // Sanitize the snippet to prevent XSS
                    const sanitizedSnippet = DOMPurify.sanitize(result.snippet);

                    let url;
                    if (result.url.startsWith("page/")) {
                        url = result.url.replace("page/", "") + ".html";
                    } else if (result.url.startsWith("product/")) {
                        const productId = result.url.replace("product/", "");
                        url = "product_detail.html?id=" + productId;
                    } else {
                        url = result.url; // Handle other URLs appropriately, or ignore
                    }

                    resultDiv.innerHTML = `
                        <h3><a href="${url}">${result.title}</a></h3>
                        <p>${sanitizedSnippet}</p>
                    `;
                    searchResultsDiv.appendChild(resultDiv);
                });
            })
            .catch(error => {
                console.error('Error loading search results:', error);
                document.getElementById('search-results').innerHTML = '<p>Failed to load search results.</p>';
            });
    } catch (error) {
        console.error('Network error while loading search results:', error);
        document.getElementById('search-results').innerHTML = '<p>Failed to load search results due to a network error.</p>';
    }
}
```

```markdown
backend/main.py
```
```python
from fastapi import FastAPI, HTTPException, Form, Depends
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, validator
from typing import Optional
import databases
import sqlalchemy
import datetime
import os
from dotenv import load_dotenv
import logging
from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.sql import func
from psycopg2 import errors as pg_errors

load_dotenv()

# Logging setup
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Database configuration
DATABASE_URL = os.getenv("DATABASE_URL")

if not DATABASE_URL:
    logging.error("DATABASE_URL is not set. Exiting.")
    exit()

database = databases.Database(DATABASE_URL)
metadata = sqlalchemy.MetaData()

# Define database tables
pages = sqlalchemy.Table(
    "pages",
    metadata,
    sqlalchemy.Column("page_id", sqlalchemy.Integer, primary_key=True),
    sqlalchemy.Column("title", sqlalchemy.String(255)),
    sqlalchemy.Column("content", sqlalchemy.Text),
    sqlalchemy.Column("slug", sqlalchemy.String(255), unique=True),
    sqlalchemy.Column("created_at", sqlalchemy.DateTime, default=datetime.datetime.utcnow),
    sqlalchemy.Column("updated_at", sqlalchemy.DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow),
    sqlalchemy.Column("is_published", sqlalchemy.Boolean, default=True),
)

products = sqlalchemy.Table(
    "products",
    metadata,
    sqlalchemy.Column("product_id", sqlalchemy.Integer, primary_key=True),
    sqlalchemy.Column("name", sqlalchemy.String(255)),
    