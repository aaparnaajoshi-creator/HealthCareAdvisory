```markdown
# High-Level Design: PharmaCorp Commercial Website

## 1. Introduction

This document outlines the high-level design (HLD) for the PharmaCorp commercial website. The website will serve both patients and Healthcare Professionals (HCPs), providing information about PharmaCorp, its products, and related resources. This HLD addresses the user stories outlined in the Software Requirements Specification (SRS) document, while adhering to the specified technical requirements.

## 2. Architecture Overview

The website will be built using a monolithic architecture, leveraging a Python-based backend (FastAPI) and a traditional HTML5/JavaScript frontend. This approach simplifies development and deployment for a website of this scale, while still providing a robust and scalable solution.

```mermaid
graph LR
    subgraph Client
        A[User Browser]
    end

    subgraph CDN
        B[Content Delivery Network]
    end

    subgraph Backend Server
        C[FastAPI Application]
        D[PostgreSQL Database]
        E[Object Store (e.g., AWS S3)]
    end

    A -- HTTPS --> B
    B -- HTTPS --> C
    C -- PostgreSQL --> D
    C -- Object Storage --> E
```

## 3. Components

*   **Frontend (HTML5, JavaScript):**  Responsible for rendering the user interface, handling user interactions, and making API requests to the backend.  Responsive design principles will be used to ensure compatibility across various devices.
*   **Backend (Python - FastAPI):** Provides the API endpoints for the frontend to retrieve and manage data.  Handles business logic, data validation, and interacts with the database and object store.
*   **Database (PostgreSQL):** Stores website content (pages, product information), user data (contact form submissions, newsletter subscriptions), and metadata.
*   **Object Store (e.g., AWS S3):** Stores Prescribing Information (PI) PDFs and other static assets.
*   **Content Delivery Network (CDN):**  Caches and delivers static assets (images, CSS, JavaScript files, PDFs) to users from geographically distributed servers, improving website performance.

## 4. Data Model

### 4.1. Database Schema (PostgreSQL)

```mermaid
erDiagram
    Page {
        int page_id PK
        varchar title
        text content
        varchar slug
        timestamp created_at
        timestamp updated_at
        boolean is_published
    }

    Product {
        int product_id PK
        varchar name
        text description
        varchar indications
        varchar dosage
        varchar administration
        varchar important_safety_information
        varchar pi_pdf_url
        timestamp created_at
        timestamp updated_at
    }

    ContactFormSubmission {
        int submission_id PK
        varchar name
        varchar email
        varchar subject
        text message
        timestamp submitted_at
    }

    NewsletterSubscription {
        int subscription_id PK
        varchar email unique
        timestamp subscribed_at
        boolean is_active
        boolean consent_given
    }

    CookieConsent {
        int consent_id PK
        varchar user_id
        timestamp consent_given_at
        boolean analytics_consent
        boolean marketing_consent
        boolean functional_consent
    }
```

*   **Page:** Stores content for static pages (Home, About Us, Contact Us, Privacy/Terms). `slug` is used for URL routing. `is_published` controls visibility.
*   **Product:** Stores product information, including ISI and the URL to the PI PDF in the object store.
*   **ContactFormSubmission:** Stores data submitted through the contact form.
*   **NewsletterSubscription:** Stores email addresses of users who have subscribed to the newsletter, along with their subscription status and consent. `consent_given` is essential for GDPR/CCPA compliance.
*   **CookieConsent:** Stores user cookie consent preferences.  `user_id` can be a session ID or a more persistent identifier if available. The three boolean fields track consent for different cookie categories.

## 5. API Endpoints

The backend will expose the following API endpoints using FastAPI:

*   **GET /pages/{slug}:** Retrieves a page by its slug.
    *   Request: None
    *   Response:
        ```json
        {
            "page_id": 1,
            "title": "About Us",
            "content": "<h1>About PharmaCorp</h1><p>...</p>",
            "slug": "about-us",
            "created_at": "2024-01-01T00:00:00",
            "updated_at": "2024-01-01T00:00:00",
            "is_published": true
        }
        ```
*   **GET /products:** Retrieves a list of all products. Supports filtering and sorting.
    *   Request: (Optional) `?therapeutic_area=cardiology&sort=name`
    *   Response:
        ```json
        [
            {
                "product_id": 1,
                "name": "Product A",
                "description": "...",
                "indications": "...",
                "dosage": "...",
                "administration": "...",
                "important_safety_information": "...",
                "pi_pdf_url": "https://s3.amazonaws.com/pharmacor/product_a_pi.pdf",
                "created_at": "2024-01-01T00:00:00",
                "updated_at": "2024-01-01T00:00:00"
            },
            {
                "product_id": 2,
                "name": "Product B",
                "description": "...",
                "indications": "...",
                "dosage": "...",
                "administration": "...",
                "important_safety_information": "...",
                "pi_pdf_url": "https://s3.amazonaws.com/pharmacor/product_b_pi.pdf",
                "created_at": "2024-01-01T00:00:00",
                "updated_at": "2024-01-01T00:00:00"
            }
        ]
        ```
*   **GET /products/{product_id}:** Retrieves a specific product by its ID.
    *   Request: None
    *   Response: (Same format as individual product in `/products` response)
*   **POST /contact:**  Submits a contact form.
    *   Request:
        ```json
        {
            "name": "John Doe",
            "email": "john.doe@example.com",
            "subject": "Inquiry",
            "message": "..."
        }
        ```
    *   Response:
        ```json
        {
            "message": "Thank you for your submission!"
        }
        ```
*   **POST /newsletter:** Subscribes an email address to the newsletter.
    *   Request:
        ```json
        {
            "email": "john.doe@example.com",
            "consent_given": true
        }
        ```
    *   Response:
        ```json
        {
            "message": "Subscription pending verification. Please check your email."
        }
        ```
*   **POST /cookie_consent:** Records user's cookie consent preferences.
    *   Request:
        ```json
        {
            "user_id": "session123",
            "analytics_consent": true,
            "marketing_consent": false,
            "functional_consent": true
        }
        ```
    *   Response:
        ```json
        {
            "message": "Cookie consent recorded."
        }
        ```

## 6. Content Management System (CMS)

The website will use a simple, custom-built CMS integrated into the backend application. This CMS will allow administrators to:

*   Create, edit, and delete pages and product information.
*   Manage images and other media files.
*   Schedule content updates.
*   View an audit log of content changes.
*   Manage alternative text for images. The CMS will enforce that alternative text is provided for all images uploaded to the system. This will be a mandatory field when uploading or editing images.

The CMS will be secured with proper authentication and authorization, ensuring that only authorized users can access and modify website content.

## 7. Search Functionality

The search functionality will be implemented using PostgreSQL's full-text search capabilities.

1.  **Indexing:** The `title` and `content` fields of the `Page` and `Product` tables will be indexed using a full-text index. The PI PDFs stored in the object store will NOT be indexed due to the complexity of indexing PDF content within the specified tech stack.
2.  **Search Query:** When a user enters a search query, the query will be converted into a PostgreSQL full-text search query.
3.  **Results:** Search results will be displayed in a clear and organized manner, with a snippet of text from the relevant page or product description.
4.  **Relevance Ranking:** PostgreSQL's ranking functions will be used to order search results by relevance.

## 8. Accessibility (WCAG 2.2 AA Compliance)

The website will be designed and developed to comply with WCAG 2.2 AA guidelines. Key accessibility features include:

*   Semantic HTML: Using semantic HTML elements to structure content logically.
*   Alternative Text: Providing descriptive alternative text for all images. As mentioned in Section 6, the CMS will enforce the addition of alt text to images.
*   Color Contrast: Ensuring sufficient color contrast between text and background colors.
*   Keyboard Navigation: Ensuring that all website functionality is accessible using a keyboard.
*   Screen Reader Compatibility: Testing the website with screen readers to ensure compatibility.
*   Clear and Consistent Navigation: Implementing a clear and consistent navigation menu.

## 9. GDPR and CCPA Compliance

The website will be designed to comply with GDPR and CCPA regulations. Key compliance measures include:

*   Privacy Policy: Providing a clear and comprehensive privacy policy that explains how user data is collected, used, and protected.
*   Cookie Consent: Obtaining explicit consent from users before setting cookies.
*   Data Subject Rights: Providing users with the right to access, correct, and delete their personal data.
*   Consent Management:  Capturing and managing user consent for marketing emails and cookies using the `NewsletterSubscription` and `CookieConsent` tables. The frontend will display appropriate consent forms and track user choices. The backend will enforce these choices. Users can withdraw consent at any time through a clear and accessible mechanism (e.g., unsubscribe link in newsletter emails, cookie settings).
*   Data Security: Implementing appropriate security measures to protect user data from unauthorized access or disclosure.

## 10. Cookie Consent Banner

The website will display a cookie consent banner upon the user's first visit. The banner will:

*   Explain the website's use of cookies and provide a link to the privacy policy.
*   Provide options to accept all cookies, reject all cookies, or customize cookie preferences.
*   Store the user's consent preferences in the `CookieConsent` table in the database.
*   Only set cookies after the user has provided their consent.
*   The cookie consent banner will be implemented using JavaScript and will interact with the backend API to store and retrieve consent preferences.

## 11. Important Safety Information (ISI) Implementation

The sticky ISI section on the product detail pages will be implemented using CSS and JavaScript.

1.  **HTML Structure:** The ISI section will be placed at the top of the product detail page.
2.  **CSS Styling:** The ISI section will be styled with `position: sticky; top: 0;` to make it stick to the top of the screen when the user scrolls down.
3.  **JavaScript (Optional):** JavaScript may be used to dynamically adjust the styling of the ISI section based on the screen size or other factors.

## 12. Deployment and CI/CD

The website will be deployed to three environments: Dev, Staging, and Prod. A CI/CD pipeline will be configured to automate the deployment process.

1.  **Version Control:** Git will be used for version control.
2.  **CI/CD Pipeline:** A CI/CD pipeline will be set up using a tool like Jenkins or GitLab CI.
3.  **Automated Testing:** The CI/CD pipeline will include automated unit tests and integration tests.
4.  **Deployment Process:** The CI/CD pipeline will automatically build, test, and deploy website updates to the appropriate environment based on Git branch.
5.  **Rollback Capabilities:** The CI/CD pipeline will include rollback capabilities in case of deployment failures.

## 13. Security Measures

The website will implement the following security measures:

*   HTTPS: All data transmitted between the user's browser and the server will be encrypted using HTTPS.
*   Content Security Policy (CSP): CSP will be implemented to prevent cross-site scripting (XSS) attacks.
*   Rate Limiting: Rate limiting will be implemented to prevent denial-of-service (DoS) attacks.
*   Input Validation: All user input will be validated to prevent injection attacks.
*   Regular Security Audits: The website will undergo regular security audits and penetration testing.