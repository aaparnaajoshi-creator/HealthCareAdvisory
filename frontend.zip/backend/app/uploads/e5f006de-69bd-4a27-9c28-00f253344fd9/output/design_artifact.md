# High-Level Design Document: HubSpot Company to Customer DB Sync Service

## 1. Introduction

This High-Level Design (HLD) document outlines the architecture and key components for the HubSpot Company to Customer DB Sync Service. The primary objective of this service is to synchronize new company records created in HubSpot with an internal PostgreSQL customer database. The solution leverages MuleSoft Anypoint Platform deployed on CloudHub to act as a secure webhook listener, data transformer, and database integrator.

## 2. Architecture Overview

The system will be implemented as a MuleSoft System API deployed to CloudHub. This API will expose a single, secure HTTP endpoint to receive webhook notifications from HubSpot upon the creation of new company records. The Mule application will then process these notifications by validating their authenticity, transforming the HubSpot payload into the internal customer database schema, and inserting the data into a PostgreSQL database. Comprehensive logging will be sent to Anypoint Monitoring, and error notifications will be sent via email.

### 2.1. System Architecture Diagram

```mermaid
graph TD
    subgraph External Systems
        A[HubSpot CRM] -->|1. New Company Created| B(Webhook POST Request)
    end

    subgraph MuleSoft Anypoint Platform (CloudHub)
        B --> C[MuleSoft System API]
        C -- HTTP Listener --> D{Webhook Authenticity Validation (X-HubSpot-Signature)}
        D -- Valid --> E{Inbound Payload Validation & Transformation (DataWeave 2.0)}
        D -- Invalid --> H(Error Handling & Notification)
        E -- Valid & Transformed --> F[Customer Record Creation (PostgreSQL DB Connector)]
        E -- Invalid --> H
        F -- Success --> G[Comprehensive Logging (Anypoint Monitoring)]
        F -- Failure --> H
        H --> I[Email Notification (Email Connector)]
        G --> J(Monitoring & Audit)
        H --> J
    end

    subgraph Internal Systems
        F --> K[PostgreSQL Customer Database]
        I --> L[Sales Operations Team Email]
    end

    style A fill:#f9f,stroke:#333,stroke-width:2px
    style K fill:#ccf,stroke:#333,stroke-width:2px
    style L fill:#f9f,stroke:#333,stroke-width:2px
```

### 2.2. Data Flow Diagram

```mermaid
sequenceDiagram
    participant HS as HubSpot CRM
    participant MS as MuleSoft System API (CloudHub)
    participant PG as PostgreSQL DB
    participant AM as Anypoint Monitoring
    participant EM as Email System
    participant SO as Sales Operations Team

    HS->>MS: 1. POST /hubspot/company/created (Webhook Notification)
    activate MS
    MS->>MS: 2. Validate X-HubSpot-Signature
    alt Signature Valid
        MS->>MS: 3. Validate Inbound Payload Structure
        alt Payload Valid
            MS->>MS: 4. Transform Payload (DataWeave 2.0)
            MS->>PG: 5. INSERT New Customer Record
            activate PG
            PG-->>MS: 6. DB Operation Result
            deactivate PG
            alt DB Insert Success
                MS->>AM: 7. Log Success (HubSpot ID, Internal ID)
                MS-->>HS: 8. HTTP 200 OK
            else DB Insert Failure
                MS->>AM: 7a. Log Error (Stack Trace, Payload)
                MS->>EM: 7b. Send Error Notification
                EM->>SO: 7c. Email Notification
                MS-->>HS: 8a. HTTP 500 Internal Server Error
            end
        else Payload Invalid
            MS->>AM: 4a. Log Error (Missing/Malformed Fields)
            MS->>EM: 4b. Send Error Notification
            EM->>SO: 4c. Email Notification
            MS-->>HS: 4d. HTTP 400 Bad Request
        end
    else Signature Invalid
        MS->>AM: 2a. Log Security Error (Unauthorized Access Attempt)
        MS-->>HS: 2b. HTTP 401 Unauthorized / 403 Forbidden
    end
    deactivate MS
```

## 3. Data Models and Database Schema

The target database is PostgreSQL. A single table, `customers`, will be created to store the synchronized company data from HubSpot.

### 3.1. `customers` Table Schema

```sql
CREATE TABLE customers (
    id BIGSERIAL PRIMARY KEY,
    hubspot_company_id BIGINT UNIQUE NOT NULL,
    company_name VARCHAR(255) NOT NULL,
    company_domain VARCHAR(255) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Index for efficient lookups on HubSpot Company ID
CREATE INDEX idx_customers_hubspot_company_id ON customers (hubspot_company_id);

-- Trigger to automatically update 'updated_at' on record modification (if updates were in scope, for future extension)
-- CREATE OR REPLACE FUNCTION update_updated_at_column()
-- RETURNS TRIGGER AS $$
-- BEGIN
--    NEW.updated_at = NOW();
--    RETURN NEW;
-- END;
-- $$ language 'plpgsql';
--
-- CREATE TRIGGER update_customer_updated_at
-- BEFORE UPDATE ON customers
-- FOR EACH ROW
-- EXECUTE FUNCTION update_updated_at_column();
```

### 3.2. Data Mapping (High-Level)

| HubSpot Webhook Payload Field (JSON Path) | Target DB Column (`customers` table) | Data Type (PostgreSQL) | Notes                                                                                                                                                                                                                                                                                                                                                               |
| :---------------------------------------- | :----------------------------------- | :--------------------- | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `objectId`                                | `hubspot_company_id`                 | `BIGINT`               | Unique identifier for the Company in HubSpot. Used to prevent duplicate entries and link back to HubSpot.                                                                                                                                                                                                                                                           |
| `properties.name.value`                   | `company_name`                       | `VARCHAR(255)`         | The primary name of the company. Mandatory field.                                                                                                                                                                                                                                                                                                   |
| `properties.domain.value`                 | `company_domain`                     | `VARCHAR(255)`         | The primary domain of the company (e.g., `example.com`). Mandatory field.                                                                                                                                                                                                                                                                           |
| N/A                                       | `created_at`                         | `TIMESTAMP WITH TIME ZONE` | Automatically set by the database upon insertion.                                                                                                                                                                                                                                                                                                   |
| N/A                                       | `updated_at`                         | `TIMESTAMP WITH TIME ZONE` | Automatically set by the database upon insertion and potentially on updates (though updates are not in scope for this HLD, the column is included for completeness and future extensibility).                                                                                                                                                     |

*Note: The exact structure of the `properties` block in HubSpot webhooks can vary. For `company.creation`, the `properties` array within the `event` object typically contains objects like `{"propertyName": "name", "propertyValue": "Acme Corp"}`. DataWeave 2.0 will be used to extract these values.*

## 4. API Endpoints

The MuleSoft System API will expose a single HTTP endpoint to serve as the webhook listener.

### 4.1. Webhook Listener Endpoint

*   **API Specification:** RAML 1.0 (to be defined)
*   **Endpoint:** `/hubspot/company/created`
*   **Method:** `POST`
*   **Description:** Receives webhook notifications from HubSpot for new company creation events.

#### 4.1.1. Request

*   **URL:** `https://<cloudhub-app-domain>/api/hubspot/company/created`
*   **Method:** `POST`
*   **Headers:**
    *   `Content-Type: application/json`
    *   `X-HubSpot-Signature: <HMAC-SHA256 signature>` (Mandatory for authenticity validation)
*   **Body (Example HubSpot Webhook Payload for Company Creation):**

    ```json
    [
      {
        "eventId": 1234567890,
        "subscriptionId": 987654321,
        "portalId": 1234567,
        "appId": 7654321,
        "occurredAt": "2024-01-01T12:00:00.000Z",
        "subscriptionType": "company.creation",
        "attemptNumber": 0,
        "objectId": 5001,
        "changeSource": "CRM",
        "properties": {
          "name": {
            "newValue": "Acme Corporation",
            "oldValue": null,
            "sourceType": "CRM",
            "sourceId": "USER_123",
            "updatedAt": "2024-01-01T12:00:00.000Z"
          },
          "domain": {
            "newValue": "acmecorp.com",
            "oldValue": null,
            "sourceType": "CRM",
            "sourceId": "USER_123",
            "updatedAt": "2024-01-01T12:00:00.000Z"
          }
        },
        "propertyChanges": [
          {
            "propertyName": "name",
            "newValue": "Acme Corporation",
            "oldValue": null
          },
          {
            "propertyName": "domain",
            "newValue": "acmecorp.com",
            "oldValue": null
          }
        ]
      }
    ]
    ```
    *Note: The `objectId` field will be mapped to `hubspot_company_id`. The `properties.name.newValue` and `properties.domain.newValue` will be mapped to `company_name` and `company_domain` respectively. The MuleSoft application will iterate through the array if multiple events are sent in a single webhook.*

#### 4.1.2. Response

*   **Success Responses:**
    *   `HTTP 200 OK` (Body: Empty or simple JSON `{ "message": "Webhook processed successfully" }`)
        *   **Condition:** Webhook signature is valid, payload is valid, and database insertion is successful.
*   **Error Responses:**
    *   `HTTP 401 Unauthorized` (Body: `{ "message": "Invalid X-HubSpot-Signature" }`)
        *   **Condition:** `X-HubSpot-Signature` header is missing or does not match the computed signature.
    *   `HTTP 403 Forbidden` (Body: `{ "message": "Forbidden access to resource" }`)
        *   **Condition:** Similar to 401, could be used for more generic authentication/authorization failures.
    *   `HTTP 400 Bad Request` (Body: `{ "message": "Invalid payload: Missing mandatory fields", "details": ["name is required", "domain is required"] }`)
        *   **Condition:** Inbound HubSpot payload is missing mandatory fields (`objectId`, `properties.name.newValue`, `properties.domain.newValue`) or is malformed.
    *   `HTTP 500 Internal Server Error` (Body: `{ "message": "An unexpected error occurred during processing", "correlationId": "..." }`)
        *   **Condition:** Any unhandled exception during transformation, database insertion, or other internal processing steps. Error notification email will be sent.

## 5. Security Considerations

*   **Webhook Authenticity:** The `X-HubSpot-Signature` header will be verified using the HMAC-SHA256 algorithm and a securely stored HubSpot Client Secret.
*   **Credential Management:** All sensitive credentials (HubSpot Client Secret, PostgreSQL username, PostgreSQL password) will be stored using MuleSoft's Secure Configuration Properties feature, encrypted at rest, and retrieved at runtime. No credentials will be hardcoded.
*   **Endpoint Security:** The CloudHub-deployed API will utilize HTTPS for secure communication.
*   **Input Validation:** Robust validation of inbound JSON payloads will prevent injection attacks and ensure data integrity.
*   **Logging:** Sensitive data within inbound payloads (if any, though not explicitly identified in this scope) will be masked before logging to Anypoint Monitoring.

## 6. Error Handling and Notifications

A global error handler will be implemented in the Mule application to catch and manage all processing exceptions.

*   **Signature Validation Failure:** Logs an error to Anypoint Monitoring and returns `HTTP 401/403`. No email notification as it's a security rejection.
*   **Payload Validation Failure:** Logs an error (including the original payload and missing fields) to Anypoint Monitoring, sends an email notification to `salesops@company.com`, and returns `HTTP 400`.
*   **Data Transformation Failure:** Logs an error (including the original payload and transformation details) to Anypoint Monitoring, sends an email notification to `salesops@company.com`, and returns `HTTP 500`.
*   **Database Insertion Failure:** Logs a detailed error (including the transformed payload, SQL error, and HubSpot Company ID) to Anypoint Monitoring, sends an email notification to `salesops@company.com`, and returns `HTTP 500`.
*   **Email Notification Content:** Will include timestamp, concise error message, HubSpot Company ID (if available), company name (if available), and a direct link to the relevant Anypoint Monitoring log entry.

## 7. Logging and Monitoring

Comprehensive logging will be implemented using MuleSoft's default logging mechanisms, which integrate with Anypoint Monitoring.

*   **Transaction Start/End:** Log entries for the beginning and end of each webhook transaction, including the HubSpot Company ID.
*   **Inbound Payload:** Log the raw inbound JSON payload from HubSpot, with any potentially sensitive data masked.
*   **Validation Results:** Log the outcome of signature and payload validation.
*   **Transformation Details:** Log details of the transformation process, potentially including the transformed payload (masked if sensitive).
*   **Database Operations:** Log the success or failure of database `INSERT` operations, including the HubSpot Company ID and the newly generated internal customer ID.
*   **Errors:** Full error stack traces, relevant context, and the problematic payload will be logged for all caught exceptions.
*   **Accessibility:** All logs will be accessible and searchable via Anypoint Monitoring.