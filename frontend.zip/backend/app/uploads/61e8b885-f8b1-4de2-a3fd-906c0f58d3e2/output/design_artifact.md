# High-Level Design: Pharma Inc. Corporate Website

**Version:** 1.1
**Status:** Updated

---

## 1. Introduction

This document provides the High-Level Design (HLD) for the Pharma Inc. corporate website. The system is designed to be a fast, secure, and reliable static website that provides essential company information and a method for contact. The architecture leverages a modern Jamstack approach for optimal performance and scalability.

## 2. Architecture Overview

The proposed architecture is a serverless, static-first approach. The website will be built as a static site and deployed to a global Content Delivery Network (CDN). Dynamic functionality, specifically the contact form, will be handled by a serverless function.

### 2.1. System Diagram

```
+-----------+      +----------------+      +------------------------+