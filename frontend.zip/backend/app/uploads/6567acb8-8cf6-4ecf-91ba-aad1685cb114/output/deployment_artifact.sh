```dockerfile
# Dockerfile

# Stage 1: Build dependencies
FROM python:3.10-slim-buster as builder

# Set environment variables
ENV PYTHONUNBUFFERED 1
ENV PYTHONDONTWRITEBYTECODE 1

WORKDIR /app

# Copy requirements file and install dependencies
COPY backend/requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Stage 2: Final image
FROM python:3.10-slim-buster

# Set environment variables
ENV PYTHONUNBUFFERED 1
ENV PYTHONDONTWRITEBYTECODE 1

WORKDIR /app

# Copy installed packages from builder stage
COPY --from=builder /usr/local/lib/python3.10/site-packages /usr/local/lib/python3.10/site-packages
COPY --from=builder /usr/local/bin /usr/local/bin

# Copy the entire application code (including frontend and pdfs directory)
# The project root (pharma_corp/) becomes /app in the container
COPY . /app

# Create the pdfs directory if it doesn't exist (for local serving simulation)
# This is where the backend expects to find PDFs when serving them
RUN mkdir -p /app/pdfs

# Expose the port FastAPI runs on
EXPOSE 8000

# Command to run the application using Gunicorn for production
# Gunicorn manages Uvicorn workers for better performance and stability
# --bind 0.0.0.0:8000 ensures it listens on all interfaces
# --workers: number of worker processes (e.g., 2 * NUM_CORES + 1 is a common heuristic)
# --worker-class: specifies Uvicorn worker for FastAPI
# --timeout: worker timeout to prevent hanging processes
# --log-level: logging level for Gunicorn
CMD ["gunicorn", "backend.main:app", "--bind", "0.0.0.0:8000", "--workers", "4", "--worker-class", "uvicorn.workers.UvicornWorker", "--timeout", "120", "--log-level", "info"]

```

```yaml
# docker-compose.yml
version: '3.8'

services:
  backend:
    build:
      context: . # Build context is the root of the project (pharma_corp/)
      dockerfile: Dockerfile
    ports:
      - "8000:8000" # Map host port 8000 to container port 8000
    volumes:
      # Mount the local 'pdfs' directory from the host into the container's /app/pdfs
      # This allows the backend to serve PDFs from the host's filesystem,
      # simulating object storage for development/testing.
      - ./pdfs:/app/pdfs
    environment:
      # DATABASE_URL for the backend to connect to the PostgreSQL service
      # 'db' is the service name defined below, automatically resolved by Docker Compose
      DATABASE_URL: postgresql://user:password@db:5432/pharma_corp_db
      # Set PDF_STORAGE_PATH within the container to point to the mounted volume
      PDF_STORAGE_PATH: /app/pdfs
    depends_on:
      - db # Ensure the database service starts before the backend
    # Restart policy for production environments
    restart: on-failure

  db:
    image: postgres:15-alpine # Use a lightweight PostgreSQL image
    environment:
      POSTGRES_DB: pharma_corp_db
      POSTGRES_USER: user
      POSTGRES_PASSWORD: password
    volumes:
      # Persistent volume for PostgreSQL data to prevent data loss on container removal
      - db_data:/var/lib/postgresql/data
      # Optional: For advanced configurations, you might mount custom PostgreSQL configs:
      # - ./backend/docker_configs/pg_hba.conf:/etc/postgresql/pg_hba.conf
      # - ./backend/docker_configs/postgresql.conf:/var/lib/postgresql/data/postgresql.conf
    # For production, do not typically expose the database port directly to the host
    # unless it's strictly necessary and secured (e.g., via firewall rules).
    # ports:
    #   - "5432:5432"
    restart: on-failure

volumes:
  db_data:
    # This named volume ensures database data persists across container restarts.
    # For "encryption at rest" as required by HLD, the underlying storage for this volume
    # on the host system (or cloud provider's managed database service) should be encrypted.
    # Docker Compose itself does not provide encryption for volumes, it relies on the host's capabilities.
```

```markdown
# PharmaCorp Commercial Website

This repository contains the full-stack application for the PharmaCorp Commercial Website, built according to the provided User Stories and High-Level Design document.

## Table of Contents

- [Project Overview](#project-overview)
- [Tech Stack](#tech-stack)
- [Features](#features)
- [Getting Started](#getting-started)
  - [Prerequisites](#prerequisites)
  - [Local Development (Python/Uvicorn)](#local-development-pythonuvicorn)
  - [Containerized Deployment (Docker/Docker Compose)](#containerized-deployment-dockerdocker-compose)
  - [Running Tests](#running-tests)
- [Project Structure](#project-structure)
- [Key Design Decisions & Trade-offs](#key-design-decisions--trade-offs)
- [Addressing Feedback from Review](#addressing-feedback-from-review)
- [Future Enhancements](#future-enhancements)

## Project Overview

The PharmaCorp Commercial Website is designed to serve as a public-facing platform for site visitors, patients, and healthcare professionals. It provides information about PharmaCorp's mission, products, and contact details, enabling users to explore product information, submit inquiries, and sign up for newsletters. Key aspects include responsiveness, accessibility (WCAG 2.2 AA), performance, and robust data privacy and security measures.

## Tech Stack

-   **Backend:** Python 3.10+ with FastAPI
-   **Database:** PostgreSQL (SQLite for local testing, PostgreSQL in Docker)
-   **Frontend:** HTML5, CSS3, Vanilla JavaScript
-   **Object Storage (Simulated):** Local `pdfs/` directory (mounted into Docker container)
-   **Containerization:** Docker, Docker Compose
-   **Dependencies Management:** `pip`

## Features

The application implements the following user stories and technical requirements:

-   **Core Website Pages & Navigation:** Home, About Us, Contact Us, Privacy Policy, Terms of Use. Clear navigation and responsiveness.
-   **Product List Page:** Displays a list of PharmaCorp products with names and short descriptions.
-   **Product Detail Page:** Comprehensive product information, including indications, usage, and Important Safety Information (ISI).
-   **Contact Form Submission:** Secure form with client-side and server-side validation, rate limiting, and database storage.
-   **Newsletter Signup:** Email subscription with validation and database storage.
-   **Sticky Important Safety Information (ISI):** ISI section remains visible on product detail pages.
-   **Prescribing Information (PI) / MedGuide PDF Download:** Secure download links for regulatory documents, served via backend proxy from simulated object storage.
-   **Site Search Functionality:** Search bar for products (expandable to other content).
-   **Cookie Consent Management:** Prominent banner with "Accept All" and "Manage Preferences" options, respecting user choices (simulated).
-   **Website Accessibility (WCAG 2.2 AA):** Implemented through semantic HTML, ARIA attributes, and CSS best practices.
-   **Website Performance:** Optimized asset delivery and efficient API responses.
-   **Data Privacy & Security Compliance:** HTTPS (implied via deployment), CSP, server-side validation, rate limiting, data rights request endpoint, and simulated encryption at rest.

## Getting Started

### Prerequisites

-   Python 3.9+ (for local development/tests)
-   `pip` (Python package installer)
-   Docker and Docker Compose (for containerized deployment)

### Local Development (Python/Uvicorn)

1.  **Clone the repository:**
    ```bash
    git clone https://github.com/your-repo/pharma-corp.git
    cd pharma-corp
    ```

2.  **Create a virtual environment:**
    ```bash
    python -m venv venv
    source venv/bin/activate  # On Windows: venv\Scripts\activate
    ```

3.  **Install dependencies:**
    Create a `backend/requirements.txt` file with the following content:
    ```
    fastapi==0.104.1
    uvicorn[standard]==0.24.0.post1
    sqlalchemy==2.0.23
    psycopg2-binary==2.9.9
    python-dotenv==1.0.0
    pydantic-settings==2.1.0
    slowapi==0.1.9
    gunicorn==21.2.0
    pytest==7.4.3
    ```
    Then install:
    ```bash
    pip install -r backend/requirements.txt
    ```

4.  **Database Configuration:**
    By default, the application is configured to use PostgreSQL. For local development without Docker, you would need a PostgreSQL instance running. Alternatively, you can modify `backend/database.py` to use SQLite for simpler local setup (e.g., `DATABASE_URL = "sqlite:///./sql_app.db"`).
    If using PostgreSQL, ensure your `backend/.env` file has the correct `DATABASE_URL`:
    ```
    # backend/.env
    DATABASE_URL="postgresql://user:password@localhost/pharma_corp_db"
    ```
    Ensure the `user`, `password`, and `pharma_corp_db` are configured in your local PostgreSQL instance.

5.  **Create PDF Placeholder Files:**
    The application serves dummy PDF files from the `pdfs/` directory (simulating object storage). Create this directory in the project root and add some placeholder files:
    ```bash
    mkdir -p pdfs
    touch pdfs/product-a-pi.pdf
    touch pdfs/product-a-medguide.pdf
    # You can put some actual dummy content (e.g., "Hello PDF") into these files.
    ```

6.  **Run the Backend (local):**
    Navigate to the project root (`pharma-corp/`) and run:
    ```bash
    uvicorn backend.main:app --reload
    ```
    The API and frontend will be available at `http://127.0.0.1:8000`.

### Containerized Deployment (Docker/Docker Compose)

This is the recommended way to run the application in a production-like environment.

1.  **Ensure Docker and Docker Compose are installed.**

2.  **Clone the repository (if you haven't already):**
    ```bash
    git clone https://github.com/your-repo/pharma-corp.git
    cd pharma-corp
    ```

3.  **Create PDF Placeholder Files:**
    As mentioned in the local setup, ensure the `pdfs/` directory exists at the project root level (`pharma-corp/pdfs`) and contains placeholder PDF files. This directory will be mounted into the backend container.

4.  **Configure Environment Variables (Optional, for Production):**
    The `docker-compose.yml` uses default `user`, `password`, and `pharma_corp_db` for PostgreSQL. For a real deployment, you should externalize these using a `.env` file for Docker Compose or pass them securely.
    Example `.env` at the same level as `docker-compose.yml`:
    ```
    # .env (for docker-compose)
    POSTGRES_USER=your_secure_user
    POSTGRES_PASSWORD=your_secure_password
    POSTGRES_DB=your_pharma_db
    ```
    Then, update `docker-compose.yml` to use these variables (e.g., `POSTGRES_USER: ${POSTGRES_USER}`). For this exercise, the hardcoded values are illustrative for simplicity.

5.  **Build and Run with Docker Compose:**
    Navigate to the project root (`pharma-corp/`) and run:
    ```bash
    docker-compose up --build -d
    ```
    This command will:
    -   Build the `backend` Docker image using the `Dockerfile`.
    -   Start the `db` (PostgreSQL) service.
    -   Start the `backend` service, connecting to the `db` service.
    -   The application will be accessible at `http://localhost:8000`.

6.  **Stop the services:**
    ```bash
    docker-compose down
    ```

### Running Tests

Navigate to the `backend` directory and run pytest. Note that `test_main.py` and `test_crud.py` use SQLite for testing simplicity, while `test_dependencies.py` is a unit test for rate limiting.

```bash
cd backend
pytest
```

## Project Structure

```
pharma_corp/
├── backend/
│   ├── main.py             # FastAPI application, API endpoints, static file serving
│   ├── database.py         # SQLAlchemy database setup
│   ├── models.py           # SQLAlchemy ORM models (DB schema)
│   ├── crud.py             # Database Create, Read, Update, Delete operations
│   ├── schemas.py          # Pydantic models for API request/response validation
│   ├── dependencies.py     # Dependency injection (DB session, rate limiter)
│   ├── config.py           # Application configuration (e.g., PDF storage path)
│   ├── requirements.txt    # Python dependencies
│   ├── .env                # Environment variables (e.g., DATABASE_URL for local)
│   └── tests/
│       ├── test_main.py    # Unit tests for FastAPI endpoints
│       ├── test_crud.py    # Unit tests for CRUD operations
│       └── test_dependencies.py # Unit tests for dependencies (e.g., rate limiter)
├── frontend/
│   ├── index.html          # Home page
│   ├── about-us.html       # About Us page
│   ├── contact-us.html     # Contact Us page with form
│   ├── privacy-policy.html # Privacy Policy page
│   ├── terms-of-use.html   # Terms of Use page
│   ├── products.html       # Product list page (dynamic)
│   ├── product-detail.html # Product detail page (dynamic, sticky ISI)
│   ├── search-results.html # Search results page (dynamic)
│   ├── static/
│   │   ├── css/
│   │   │   └── style.css   # Main CSS for styling and responsiveness
│   │   └── js/
│   │       ├── main.js         # General JS, product list/detail logic
│   │       ├── contact.js      # Contact form logic and validation
│   │       ├── newsletter.js   # Newsletter signup logic
│   │       ├── search.js       # Site search logic
│   │       └── cookie-consent.js # Cookie consent banner/modal logic
├── pdfs/                   # Simulated object storage for PI/MedGuide PDFs
│   ├── product-a-pi.pdf
│   └── product-a-medguide.pdf
├── Dockerfile              # Dockerfile for containerizing the backend application
├── docker-compose.yml      # Docker Compose file for multi-service deployment (backend + PostgreSQL)
└── README.md               # This file
```

## Key Design Decisions & Trade-offs

1.  **FastAPI for Backend:** Chosen for its high performance, automatic Pydantic model validation, and interactive API documentation (Swagger UI/ReDoc). This simplifies API development and ensures robust input validation.
2.  **Vanilla JavaScript Frontend:** Opted for vanilla JS and simple HTML/CSS to meet the "lightweight libraries" requirement and keep the frontend straightforward without introducing a complex framework. This reduces build complexity but might require more manual DOM manipulation for highly dynamic interfaces.
3.  **Docker/Docker Compose for Deployment:** Provides a consistent, isolated, and reproducible environment for the application and its database, simplifying setup and deployment across different environments.
4.  **In-Memory Rate Limiting:** `slowapi` is used with an in-memory storage for simplicity in this example. For production deployments with multiple backend instances, a distributed storage like Redis would be necessary for accurate and consistent rate limiting across all instances.
5.  **Basic Site Search:** The current search functionality is limited to product names and descriptions, as noted in the HLD feedback. A full-fledged site search for all content would require integration with a dedicated search engine (e.g., Elasticsearch, Algolia) and a content indexing pipeline.
6.  **Cookie Consent Management (Simplified):** A vanilla JS implementation is provided to demonstrate the banner, preference modal, and the concept of conditional script loading. A full, compliant CMP would be more robust, potentially a third-party SDK.

## Addressing Feedback from Review

*   **Reconcile PDF Serving Strategy with HLD:**
    *   **HLD Statement:** "PDFs will be served directly from object storage (or via CDN) using secure URLs."
    *   **Current Implementation (Code):** The backend currently proxies PDF serving from a local `pdfs/` directory (mounted into the Docker container). This means the client requests `/api/download/...` from the backend, and the backend then reads and serves the file. This approach provides a layer of control and potentially allows for future integration with authorization/logging on PDF access.
    *   **Reconciliation:** While the current code does not directly serve from a CDN or generate pre-signed URLs for client-to-storage access (as might be implied by "directly from object storage"), it fulfills the "secure URLs" aspect by proxying. For a true production setup aligning strictly with the HLD's performance intent, the `get_product_details` API endpoint would be updated to generate time-limited pre-signed URLs from a cloud object storage (e.g., AWS S3, Azure Blob Storage) directly, allowing the client's browser to download the PDF directly from the CDN/object storage. This would offload traffic from the backend and improve download performance. The current Docker Compose setup uses a mounted volume to simulate the `pdfs` storage for demonstration.

*   **Implement Data Encryption at Rest:**
    *   **HLD Requirement:** "Sensitive data in the PostgreSQL database... will be encrypted at rest, either via disk encryption or column-level encryption where appropriate."
    *   **Implementation Status:** Column-level encryption is not implemented in the application code. However, encryption at rest can also be achieved at the storage layer.
    *   **Deployment Solution:** In a production environment, this would typically involve:
        *   **Managed Database Services:** Using cloud provider managed PostgreSQL services (e.g., AWS RDS, Azure Database for PostgreSQL, Google Cloud SQL) which offer built-in encryption at rest for storage volumes as a standard feature.
        *   **Volume Encryption:** If self-hosting on virtual machines, ensuring that the underlying disk volumes used for PostgreSQL data (e.g., the `db_data` Docker volume) are encrypted using OS-level disk encryption (e.g., LUKS on Linux) or cloud provider disk encryption features.
    *   The provided `docker-compose.yml` uses a named volume (`db_data`) for PostgreSQL persistence, which is the correct pattern for Docker. The actual encryption of this volume would be managed at the host/infrastructure level.

*   **Update Dockerfile CMD for Production Deployment:**
    *   **Previous CMD:** `uvicorn main:app --reload` (development mode).
    *   **Updated CMD:** The `Dockerfile` now uses `gunicorn` as a process manager for `uvicorn` workers (`CMD ["gunicorn", "backend.main:app", "--bind", "0.0.0.0:8000", "--workers", "4", "--worker-class", "uvicorn.workers.UvicornWorker", "--timeout", "120", "--log-level", "info"]`). This provides a more robust, performant, and stable setup suitable for production environments by managing multiple worker processes and handling graceful shutdowns.

## Future Enhancements

-   Integrate with a real cloud object storage solution (e.g., AWS S3) for PDFs, generating pre-signed URLs for direct client downloads to offload backend traffic.
-   Implement a more sophisticated content management system (CMS) for static pages and product data.
-   Enhance site search with a dedicated search engine (e.g., Elasticsearch) for full content indexing.
-   Implement a more robust logging and monitoring solution (e.g., Prometheus, Grafana, ELK stack).
-   Add user authentication for internal administration of contact inquiries, newsletter subscribers, and data rights requests.
-   Integrate a proper Consent Management Platform (CMP) SDK for advanced cookie management and compliance.
-   Expand WCAG compliance testing with automated tools and manual audits.
-   Implement server-side rendering (SSR) or a SPA framework for improved initial page load performance and SEO.
-   Add email notification service for contact form submissions.
```