# High-Level Design: PharmaCorp Commercial Website

## 1. Introduction

This High-Level Design (HLD) document outlines the architectural approach for the PharmaCorp commercial website, based on the provided user stories and technical constraints. It details the system's components, data models, API endpoints, and security considerations, aiming to deliver a secure, performant, and accessible user experience.

## 2. System Overview

The PharmaCorp commercial website will be a public-facing web application designed to inform site visitors, patients, and healthcare professionals about PharmaCorp, its mission, and its products. It will facilitate contact inquiries, newsletter subscriptions, and provide detailed product information with regulatory documents.

### 2.1 System Context Diagram

```mermaid
graph TD
    A[Site Visitor / HCP] --> B{Web Browser};
    B -- HTTPS --> C[CDN / Load Balancer];
    C -- HTTPS --> D[Backend API (Python FastAPI/Flask)];
    D -- SQL --> E[PostgreSQL Database];
    D -- S3 API --> F[Object Storage (PDFs)];
    C -- HTTPS --> F;
```

## 3. Architectural Style

The system will adopt a **N-Tier Client-Server Architecture**.

*   **Presentation Tier (Frontend):** A client-side application primarily built with HTML5, CSS, and JavaScript, responsible for rendering the user interface, handling client-side interactions, and consuming backend APIs. It will be designed for responsiveness and accessibility.
*   **Application Tier (Backend):** A Python-based API (FastAPI/Flask) application responsible for business logic, data validation, interaction with the database, and serving static assets (HTML, CSS, JS, images). It will expose RESTful API endpoints.
*   **Data Tier (Database & Storage):** PostgreSQL database for structured data (products, inquiries, signups) and an Object Storage solution for large binary assets (PDFs).

## 4. Component Breakdown

### 4.1 Frontend (Client-side HTML5 + JavaScript)

*   **Technology:** HTML5, CSS3, JavaScript (vanilla or lightweight libraries).
*   **Responsibilities:**
    *   Rendering all website pages, including responsive layouts for various devices.
    *   Handling client-side routing for seamless navigation.
    *   Performing client-side form validation (e.g., email format, required fields).
    *   Making API calls to the Backend for dynamic content (products, search) and form submissions.
    *   Implementing UI/UX features such as sticky Important Safety Information (ISI) (User Story 6).
    *   Managing cookie consent and dynamically loading non-essential scripts (User Story 9).
    *   Ensuring WCAG 2.2 AA accessibility standards are met (User Story 10).
    *   Optimizing asset loading for performance (User Story 11).

*   **Cookie Consent Management (Addressing User Story 9 Feedback):**
    *   The frontend will integrate with a Consent Management Platform (CMP) SDK (e.g., a lightweight open-source solution or a commercial offering).
    *   Upon first visit, the CMP banner/pop-up will be displayed.
    *   The CMP will manage user preferences (accept, decline, manage) and store consent in a client-side cookie.
    *   All non-essential third-party scripts (e.g., analytics, marketing pixels) will be configured to load *only after* the CMP has confirmed explicit user consent for the respective cookie categories. This is achieved by initially blocking these scripts and then dynamically injecting or unblocking them based on the CMP's events/APIs.

### 4.2 Backend (Python FastAPI/Flask)

*   **Technology:** Python (FastAPI or Flask).
*   **Responsibilities:**
    *   Serving static website assets (HTML, CSS, JavaScript, images) for core pages.
    *   Implementing RESTful APIs for:
        *   Retrieving product lists and details.
        *   Processing contact form submissions.
        *   Handling newsletter signups.
        *   Executing site-wide search queries.
        *   Receiving data rights requests.
    *   Performing server-side input validation for all incoming data to prevent security vulnerabilities (XSS, SQL Injection).
    *   Implementing rate limiting for form submission and newsletter signup endpoints.
    *   Interacting with the PostgreSQL database for data persistence.
    *   Interacting with the Object Storage for PDF file retrieval/linking.
    *   Generating appropriate HTTP headers for security (CSP) and caching.

### 4.3 Database (PostgreSQL)

*   **Technology:** PostgreSQL.
*   **Responsibilities:**
    *   Storing all structured data: product information, contact inquiries, newsletter subscriber emails, and data rights requests.
    *   Ensuring data integrity and consistency.
    *   Supporting efficient data retrieval for API endpoints.
    *   Enforcing data security through encryption at rest for sensitive fields (User Story 12).

### 4.4 Object Storage

*   **Technology:** Cloud-based object storage (e.g., AWS S3, Azure Blob Storage, Google Cloud Storage).
*   **Responsibilities:**
    *   Securely storing large binary files such as Prescribing Information (PI) and MedGuide PDFs.
    *   Providing scalable and highly available storage for these documents.
    *   PDFs will be served directly from object storage (or via CDN) using secure URLs, optimizing download performance.

### 4.5 Content Delivery Network (CDN)

*   **Technology:** Any standard CDN (e.g., Cloudflare, Akamai, AWS CloudFront).
*   **Responsibilities:**
    *   Caching static assets (HTML, CSS, JS, images, PDFs) geographically closer to end-users.
    *   Reducing latency and improving page load times (User Story 11).
    *   Offloading traffic from the backend server.
    *   Acts as the primary entry point for web traffic, sitting in front of the backend and object storage.

### 4.6 CI/CD Pipeline

*   **Technology:** Tools like GitLab CI/CD, GitHub Actions, Jenkins.
*   **Responsibilities:**
    *   Automating the build, testing (unit, integration, end-to-end), and deployment processes for both frontend and backend codebases.
    *   Ensuring consistent deployments across Development, Staging, and Production environments.

## 5. Data Model / Database Schema

The PostgreSQL database will host the following tables:

### 5.1 `products` Table

Stores detailed information about PharmaCorp's products.

| Field Name             | Data Type   | Constraints                                   | Description                                      |
| :--------------------- | :---------- | :-------------------------------------------- | :----------------------------------------------- |
| `id`                   | UUID / INT  | PRIMARY KEY                                   | Unique identifier for the product.               |
| `name`                 | VARCHAR(255)| NOT NULL                                      | Product name.                                    |
| `short_description`    | TEXT        | NOT NULL                                      | Concise product description for list view.       |
| `detailed_description` | TEXT        |                                               | Comprehensive product description.               |
| `indications`          | TEXT        |                                               | Medical indications for the product.             |
| `usage_instructions`   | TEXT        |                                               | Instructions on how to use the product.          |
| `important_safety_info`| TEXT        |                                               | Critical safety information (for sticky display).|
| `pi_pdf_url`           | VARCHAR(512)|                                               | URL to the Prescribing Information PDF in object storage. |
| `medguide_pdf_url`     | VARCHAR(512)|                                               | URL to the MedGuide PDF in object storage.       |
| `created_at`           | TIMESTAMP   | DEFAULT NOW()                                 | Timestamp of record creation.                    |
| `updated_at`           | TIMESTAMP   | DEFAULT NOW() ON UPDATE NOW()                 | Timestamp of last update.                        |

### 5.2 `contact_inquiries` Table

Stores submissions from the contact form.

| Field Name    | Data Type   | Constraints                                   | Description                                      |
| :------------ | :---------- | :-------------------------------------------- | :----------------------------------------------- |
| `id`          | UUID / INT  | PRIMARY KEY                                   | Unique inquiry identifier.                       |
| `name`        | VARCHAR(255)| NOT NULL                                      | Submitter's name.                                |
| `email`       | VARCHAR(255)| NOT NULL, ENCRYPTED AT REST                   | Submitter's email address.                       |
| `subject`     | VARCHAR(255)| NOT NULL                                      | Subject of the inquiry.                          |
| `message`     | TEXT        | NOT NULL                                      | Detailed message from the submitter.             |
| `ip_address`  | INET        |                                               | IP address of the submitter (for rate limiting/abuse detection). |
| `submitted_at`| TIMESTAMP   | DEFAULT NOW()                                 | Timestamp of submission.                         |
| `status`      | VARCHAR(50) | DEFAULT 'new'                                 | Internal status of the inquiry (e.g., 'new', 'in_progress', 'resolved'). |

### 5.3 `newsletter_signups` Table

Stores email addresses for newsletter subscribers.

| Field Name      | Data Type   | Constraints                                   | Description                                      |
| :-------------- | :---------- | :-------------------------------------------- | :----------------------------------------------- |
| `id`            | UUID / INT  | PRIMARY KEY                                   | Unique signup identifier.                        |
| `email`         | VARCHAR(255)| NOT NULL, UNIQUE, ENCRYPTED AT REST           | Subscriber's email address.                      |
| `ip_address`    | INET        |                                               | IP address of the subscriber.                    |
| `subscribed_at` | TIMESTAMP   | DEFAULT NOW()                                 | Timestamp of subscription.                       |
| `status`        | VARCHAR(50) | DEFAULT 'active'                              | Subscription status (e.g., 'active', 'unsubscribed', 'pending_confirmation'). |

### 5.4 `data_rights_requests` Table (NEW - Addressing User Story 12 Feedback)

Stores requests from users exercising their data privacy rights.

| Field Name      | Data Type   | Constraints                                   | Description                                      |
| :-------------- | :---------- | :-------------------------------------------- | :----------------------------------------------- |
| `id`            | UUID / INT  | PRIMARY KEY                                   | Unique request identifier.                       |
| `request_type`  | VARCHAR(50) | NOT NULL, CHECK (request_type IN ('access', 'rectification', 'erasure')) | Type of data right requested.                  |
| `email`         | VARCHAR(255)| NOT NULL, ENCRYPTED AT REST                   | User's email for identification.                 |
| `details`       | TEXT        |                                               | Specific details/clarification for the request.  |
| `status`        | VARCHAR(50) | DEFAULT 'pending'                             | Internal status of the request (e.g., 'pending', 'in_progress', 'completed', 'rejected'). |
| `requested_at`  | TIMESTAMP   | DEFAULT NOW()                                 | Timestamp when the request was made.             |
| `processed_at`  | TIMESTAMP   |                                               | Timestamp when the request was processed.        |
| `admin_notes`   | TEXT        |                                               | Internal notes by administrators.                |

## 6. API Endpoints

All API endpoints will be served over HTTPS and return JSON responses.

### 6.1 Product APIs

*   **GET /api/products**
    *   **Description:** Retrieves a list of all available PharmaCorp products with their names and short descriptions.
    *   **Response (200 OK):**
        ```json
        [
            {"id": "uuid-1", "name": "Product A", "short_description": "A brief overview of Product A."},
            {"id": "uuid-2", "name": "Product B", "short_description": "Product B helps with..."}
        ]
        ```

*   **GET /api/products/{product_id}**
    *   **Description:** Retrieves comprehensive details for a specific product.
    *   **Path Parameters:** `product_id` (UUID/INT)
    *   **Response (200 OK):**
        ```json
        {
            "id": "uuid-1",
            "name": "Product A",
            "detailed_description": "This is a comprehensive description of Product A...",
            "indications": "Indicated for...",
            "usage_instructions": "Take 1 pill daily...",
            "important_safety_info": "Important safety warning: ...",
            "pi_pdf_url": "https://cdn.example.com/pdfs/product-a-pi.pdf",
            "medguide_pdf_url": "https://cdn.example.com/pdfs/product-a-medguide.pdf"
        }
        ```
    *   **Error Response (404 Not Found):** `{"message": "Product not found."}`

### 6.2 Contact Form API

*   **POST /api/contact**
    *   **Description:** Submits a new contact inquiry to PharmaCorp.
    *   **Request Body:**
        ```json
        {
            "name": "John Doe",
            "email": "john.doe@example.com",
            "subject": "General Inquiry",
            "message": "I have a question about your products."
        }
        ```
    *   **Response (201 Created):** `{"message": "Your inquiry has been successfully submitted."}`
    *   **Error Response (400 Bad Request):** `{"message": "Validation error: Invalid email format."}`
    *   **Error Response (429 Too Many Requests):** `{"message": "Too many requests. Please try again later."}`

### 6.3 Newsletter Signup API

*   **POST /api/newsletter**
    *   **Description:** Registers an email address for the PharmaCorp newsletter.
    *   **Request Body:**
        ```json
        {
            "email": "subscribe@example.com"
        }
        ```
    *   **Response (201 Created):** `{"message": "You have successfully signed up for the newsletter."}`
    *   **Error Response (400 Bad Request):** `{"message": "Validation error: Invalid email format."}`
    *   **Error Response (409 Conflict):** `{"message": "This email address is already subscribed."}`

### 6.4 Site Search API

*   **GET /api/search**
    *   **Description:** Searches for content across products and potentially other indexed website content.
    *   **Query Parameters:** `q` (string, the search query)
    *   **Response (200 OK):**
        ```json
        [
            {"title": "Product A", "snippet": "...", "url": "/products/uuid-1"},
            {"title": "About Us Page", "snippet": "...", "url": "/about-us"}
        ]
        ```
    *   **Response (200 OK, no results):** `[]`

### 6.5 Data Rights Request API (NEW - Addressing User Story 12 Feedback)

*   **POST /api/data-rights-request**
    *   **Description:** Allows users to submit requests related to their data privacy rights (Access, Rectification, Erasure). This initiates an internal process.
    *   **Request Body:**
        ```json
        {
            "request_type": "access", // "access", "rectification", or "erasure"
            "email": "user@example.com",
            "details": "I would like to request all data associated with this email address."
        }
        ```
    *   **Response (202 Accepted):** `{"message": "Your data rights request has been received and will be processed according to our privacy policy."}`
    *   **Error Response (400 Bad Request):** `{"message": "Validation error: Invalid request type or email."}`

## 7. Data Flow Diagrams

### 7.1 Contact Form Submission Data Flow

```mermaid
sequenceDiagram
    actor User
    participant Frontend
    participant Backend
    participant Database

    User->>Frontend: Fills out and submits Contact Form
    Frontend->>Frontend: Client-side validation (e.g., email format)
    alt Client-side Validation Fails
        Frontend-->>User: Display client-side error message
    else Client-side Validation Success
        Frontend->>Backend: POST /api/contact (JSON payload)
        Backend->>Backend: Server-side validation (e.g., required fields, XSS/SQLi prevention)
        Backend->>Backend: Rate limiting check (based on IP)
        alt Server-side Validation or Rate Limit Fails
            Backend-->>Frontend: 400 Bad Request / 429 Too Many Requests
            Frontend-->>User: Display informative error message
        else Server-side Validation and Rate Limit Success
            Backend->>Database: Insert new record into contact_inquiries table
            Database-->>Backend: Confirmation of insert
            Backend-->>Frontend: 201 Created (Success message)
            Frontend-->>User: Display confirmation message
        end
    end
```

### 7.2 Product Detail Page & PDF Download Data Flow

```mermaid
sequenceDiagram
    actor User
    participant Frontend
    participant Backend
    participant Database
    participant CDN
    participant ObjectStorage

    User->>Frontend: Navigates to /products/{product_id}
    Frontend->>Backend: GET /api/products/{product_id}
    Backend->>Database: Query product details by ID
    Database-->>Backend: Product data (including pi_pdf_url, medguide_pdf_url)
    Backend-->>Frontend: Product data JSON
    Frontend->>User: Renders Product Detail Page (including sticky ISI, download links)

    User->>Frontend: Clicks "Download PI PDF" link
    Frontend->>CDN: Request PDF via pi_pdf_url (e.g., https://cdn.example.com/pdfs/pi.pdf)
    alt PDF cached in CDN
        CDN-->>Frontend: Serve PDF from cache
    else PDF not in CDN
        CDN->>ObjectStorage: Fetch PDF from origin
        ObjectStorage-->>CDN: PDF file
        CDN-->>Frontend: Serve PDF
    end
    Frontend-->>User: Browser downloads/opens PDF
```

### 7.3 Site Search Functionality Data Flow

```mermaid
sequenceDiagram
    actor User
    participant Frontend
    participant Backend
    participant Database

    User->>Frontend: Enters search query in prominent search bar
    Frontend->>Backend: GET /api/search?q=user_query
    Backend->>Database: Execute search query against products and other indexed content
    Database-->>Backend: Relevant search results (e.g., product name, snippet, URL)
    Backend-->>Frontend: 200 OK (JSON array of search results)
    Frontend->>User: Displays list of search results or "No results found" message
```

## 8. Security Considerations

*   **HTTPS Everywhere:** All communication between clients, CDN, backend, and internal services will be encrypted using TLS/SSL.
*   **Content Security Policy (CSP):** The Backend will implement a robust CSP in HTTP headers to mitigate XSS and data injection attacks, specifying allowed sources for scripts, styles, images, and other resources.
*   **Input Validation:** Strict server-side validation will be performed on all user inputs (contact forms, newsletter signups, search queries) to prevent malicious data, including XSS, SQL injection, and buffer overflows. Client-side validation will enhance UX but never replace server-side validation.
*   **Rate Limiting:** Implemented at the Backend level for `POST /api/contact` and `POST /api/newsletter` to prevent abuse, brute-force attacks, and DoS attempts.
*   **Data Encryption at Rest:** Sensitive data in the PostgreSQL database (e.g., `email` in `contact_inquiries`, `newsletter_signups`, `data_rights_requests`) will be encrypted at rest, either via disk encryption or column-level encryption where appropriate.
*   **Object Storage Security:** PDFs will be stored in private buckets with controlled access policies. Access will be granted via secure URLs, potentially time-limited pre-signed URLs if direct public access via CDN is not desired for all documents.
*   **GDPR & CCPA Compliance (User Story 12):**
    *   **Privacy Policy:** Clearly linked on all data collection points, detailing data collection, usage, storage, and user rights.
    *   **Cookie Consent:** As detailed in section 4.1, a CMP will manage explicit user consent before setting non-essential cookies.
    *   **Data Rights (Access, Rectification, Erasure):** The `POST /api/data-rights-request` endpoint will facilitate user requests. Backend will log these requests in the `data_rights_requests` table. Fulfillment of these requests will involve an internal, human-assisted process (e.g., via an internal admin tool or manual verification/action by a data privacy officer) to ensure proper identity verification and data handling. The API itself does not directly expose user data or modification capabilities.
*   **Secure Coding Practices:** Adherence to OWASP Top 10 guidelines during development.

## 9. Performance Considerations

*   **CDN Usage:** All static assets (HTML, CSS, JS, images, PDFs) will be served via a CDN for fast global delivery and reduced latency.
*   **Image Optimization:** Images will be optimized for web delivery (compressed, responsive sizes using `srcset`, appropriate formats like WebP/AVIF) and lazy-loaded to improve initial page load times.
*   **Minification & Bundling:** Frontend CSS and JavaScript files will be minified and bundled to reduce file sizes and the number of HTTP requests.
*   **Browser Caching:** Appropriate HTTP caching headers (`Cache-Control`, `ETag`) will be set for static assets to leverage browser caching.
*   **Backend Optimization:** Efficient database queries, indexing, and potentially in-memory caching for frequently accessed, less volatile data (e.g., product lists) will minimize server-side response times.
*   **Asynchronous Operations:** Backend processes (e.g., sending notification emails after form submission) can be offloaded to asynchronous queues to improve API response times.

## 10. Deployment & Operations

*   **Environments:** Dedicated Development, Staging, and Production environments will be maintained to ensure proper testing and quality assurance before deployment to live.
*   **CI/CD Pipeline:** An automated CI/CD pipeline will manage code integration, automated testing, and deployments across environments.
*   **Monitoring & Logging:** Comprehensive monitoring will be implemented for application performance, server health, API response times, and error rates. Centralized logging will be used for effective troubleshooting and auditing.
*   **Backup & Recovery:** Regular backups of the PostgreSQL database and object storage will be performed, with a tested recovery plan.