# PharmaCorp Commercial Website - Comprehensive Testing Document

## 1. Test Strategy

### 1.1. Introduction
This document outlines the testing strategy for the PharmaCorp Commercial Website. It details the approach, scope, objectives, types of testing, and tools to ensure the delivered product meets all functional, non-functional, and compliance requirements as specified in the Project Requirements (SRS) and High-Level Design (HLD) documents.

### 1.2. Scope of Testing
The testing scope encompasses all components and interactions described in the SRS and HLD:
*   **Frontend (UI/UX):** All user-facing pages, navigation, interactive elements (forms, search, cookie banner), responsiveness, and visual consistency across devices and browsers.
*   **Backend API:** All RESTful API endpoints, including data retrieval, form submissions, search functionality, input validation, and rate limiting.
*   **Database (PostgreSQL):** Data integrity, schema adherence, correct data storage and retrieval for products, inquiries, and subscriptions.
*   **Object Storage:** Secure storage and retrieval of Prescribing Information (PI) PDFs.
*   **Integrations:** Interaction with CDN/WAF, and secure PDF delivery via pre-signed URLs.
*   **Non-Functional Aspects:** Performance (LCP, load times), Security (HTTPS, CSP, OWASP Top 10), Accessibility (WCAG 2.2 AA), Data Privacy (GDPR/CCPA compliance).
*   **Deployment Pipeline:** Verification of CI/CD stages (build, test, deploy to Dev, Staging, Production).

**Out of Scope:**
*   Third-party system integrations not explicitly mentioned (e.g., external analytics beyond basic cookie consent management).
*   Infrastructure management beyond verifying deployed application behavior.

### 1.3. Test Objectives
The primary objectives of the testing effort are to:
*   **Verify Functional Correctness:** Ensure all user stories and acceptance criteria are met.
*   **Ensure Non-Functional Compliance:** Guarantee the website meets performance, security, accessibility, and data privacy standards.
*   **Validate Data Integrity:** Confirm that data is correctly stored, retrieved, and managed in the database.
*   **Confirm System Reliability & Stability:** Identify and mitigate defects to ensure a robust and stable application.
*   **Assure User Experience:** Verify that the website is intuitive, responsive, and easy to navigate for all users.
*   **Support CI/CD:** Integrate automated tests into the CI/CD pipeline for continuous quality assurance.

### 1.4. Test Phases
Testing will be conducted across multiple phases:
1.  **Unit Testing:** Developers will write unit tests for individual functions and components (frontend and backend).
2.  **Integration Testing:** Verify interactions between different modules (e.g., frontend with backend API, backend API with database/object storage).
3.  **System Testing:** Comprehensive end-to-end testing of the entire integrated system to ensure it meets all specified requirements.
4.  **User Acceptance Testing (UAT):** Business stakeholders will validate the system against their expectations in the Staging environment.
5.  **Performance Testing:** Assess system responsiveness, stability, and scalability under various load conditions.
6.  **Security Testing:** Identify vulnerabilities and ensure adherence to security best practices.
7.  **Accessibility Testing:** Verify compliance with WCAG 2.2 AA standards.
8.  **Compliance Testing:** Ensure adherence to GDPR/CCPA and other relevant regulations.

### 1.5. Types of Testing
*   **Functional Testing:**
    *   **UI Testing:** Verifying the visual elements, layout, navigation, and interactive components through the browser.
    *   **API Testing:** Direct testing of backend API endpoints for correctness, response structure, and error handling.
    *   **Database Testing:** Validating data storage, retrieval, and integrity directly in PostgreSQL.
*   **Non-Functional Testing:**
    *   **Performance Testing:**
        *   **Load Testing:** Assessing system behavior under expected peak load conditions.
        *   **Stress Testing:** Determining the system's breaking point beyond normal operating conditions.
        *   **Speed Optimization:** Monitoring Largest Contentful Paint (LCP) and other Core Web Vitals.
    *   **Security Testing:**
        *   **Vulnerability Scanning:** Automated tools to identify known vulnerabilities.
        *   **Penetration Testing:** Ethical hacking to identify exploitable weaknesses.
        *   **Static Application Security Testing (SAST):** Code analysis for security flaws.
        *   **Dynamic Application Security Testing (DAST):** Runtime analysis for security flaws.
        *   **Manual Security Review:** Checking for CSP, HTTPS, rate limiting, input validation.
    *   **Accessibility Testing (WCAG 2.2 AA):**
        *   **Automated Checks:** Using tools like Axe-core.
        *   **Manual Review:** Keyboard navigation, screen reader compatibility (NVDA, JAWS, VoiceOver), color contrast checks.
    *   **Compatibility Testing:**
        *   **Browser Compatibility:** Testing across major browsers (Chrome, Firefox, Edge, Safari).
        *   **Device Compatibility:** Testing responsiveness on various screen sizes (desktop, tablet, mobile).
    *   **Data Privacy Compliance Testing (GDPR/CCPA):**
        *   **Cookie Consent:** Verifying banner display, preference management, and persistence.
        *   **Privacy Policy:** Reviewing content for clarity and completeness regarding data handling.
        *   **Form Consent:** Checking explicit consent mechanisms on data collection forms.

### 1.6. Automation Strategy
*   **UI Automation:** Critical user journeys, regression tests, and responsive design checks will be automated using Playwright (Python). This includes navigation, form submissions, and cookie consent interactions.
*   **API Automation:** All backend API endpoints will have automated tests using `pytest` and `requests` to ensure functionality, data validation, error handling, and performance.
*   **Performance Automation:** Integration of Lighthouse CI or similar tools into the CI/CD pipeline to continuously monitor Core Web Vitals, especially LCP.
*   **Accessibility Automation:** Integration of Axe-core into UI automation tests to catch common accessibility violations early.
*   **CI/CD Integration:** All automated tests will be integrated into the CI/CD pipeline, running on every code push to `develop` and `main` branches to provide immediate feedback.

### 1.7. Manual Testing Focus
While automation is prioritized, manual testing will be crucial for:
*   **Exploratory Testing:** Discovering unexpected issues and edge cases.
*   **Complex UI/UX Flows:** Scenarios difficult to automate or requiring human judgment.
*   **Accessibility (Screen Reader Testing):** Verifying the experience for users with assistive technologies.
*   **Usability Testing:** Gathering feedback on the overall user experience.
*   **UAT:** Business-driven validation of features in a production-like environment.
*   **Content Verification:** Ensuring accuracy and quality of displayed text and images.

### 1.8. Test Environments
*   **Development Environment:** Local developer machines for unit and component testing.
*   **Dev Environment:** Automatically deployed via CI/CD for feature branch testing and early integration.
*   **Staging Environment:** Production-like environment, automatically deployed from `main` branch, used for comprehensive QA, performance, security, accessibility, and UAT.
*   **Production Environment:** Live environment accessible to end-users, with deployment requiring manual approval after Staging validation.

### 1.9. Tools & Technologies
*   **Test Management:** Jira / TestRail (for test case management, defect tracking).
*   **UI Automation:** Playwright (Python).
*   **API Automation:** `pytest`, `requests` (Python).
*   **Performance Testing:** Lighthouse CI, Google PageSpeed Insights, K6 / JMeter (for load testing).
*   **Security Testing:** OWASP ZAP, Snyk (dependency scanning), manual penetration testing.
*   **Accessibility Testing:** Axe-core (automated), NVDA/JAWS/VoiceOver (manual screen reader testing).
*   **Version Control:** Git.
*   **CI/CD:** GitHub Actions / GitLab CI / Jenkins (as per HLD).

### 1.10. Entry and Exit Criteria
**Test Entry Criteria (for System/Staging Testing):**
*   All user stories are implemented and deployed to the Staging environment.
*   All critical and high-priority bugs from previous phases are resolved.
*   Unit and integration tests are passing with a minimum 80% code coverage.
*   Test environment is stable and configured as per requirements.
*   Test data is available and ready.

**Test Exit Criteria (for Staging to Production Promotion):**
*   All functional test cases (manual and automated) are executed with a 95% pass rate.
*   All critical and high-priority bugs are resolved and retested.
*   Performance targets (e.g., LCP < 2.5s) are consistently met.
*   Security scans show no critical vulnerabilities.
*   WCAG 2.2 AA compliance is verified.
*   UAT is completed and signed off by stakeholders.
*   Regression test suite passes with 100% success.
*   Documentation (test reports, defect logs) is complete.

## 2. Manual Test Cases

### Epic: Website Foundation & Navigation

**Test Case ID:** TC-HOME-001
*   **User Story:** US1: Display Core Website Pages
*   **Test Objective:** Verify navigation to the Home page.
*   **Preconditions:** Website is accessible.
*   **Steps:**
    1.  Navigate to the website URL.
    2.  Click on the "Home" link in the main navigation.
*   **Expected Result:** The user is taken to the homepage, and the page title is "PharmaCorp - Home" or similar.
*   **Priority:** High
*   **Test Type:** Functional (UI)

**Test Case ID:** TC-ABOUT-001
*   **User Story:** US1: Display Core Website Pages
*   **Test Objective:** Verify navigation to the About Us page and content display.
*   **Preconditions:** Website is accessible.
*   **Steps:**
    1.  Navigate to the website URL.
    2.  Click on the "About Us" link in the main navigation.
*   **Expected Result:** The user is taken to the About Us page. The page title is "PharmaCorp - About Us" and relevant company information is displayed.
*   **Priority:** High
*   **Test Type:** Functional (UI)

**Test Case ID:** TC-CONTACT-001
*   **User Story:** US1: Display Core Website Pages
*   **Test Objective:** Verify navigation to the Contact Us page.
*   **Preconditions:** Website is accessible.
*   **Steps:**
    1.  Navigate to the website URL.
    2.  Click on the "Contact Us" link in the main navigation.
*   **Expected Result:** The user is taken to the Contact Us page. The page title is "PharmaCorp - Contact Us" and the contact form is visible.
*   **Priority:** High
*   **Test Type:** Functional (UI)

**Test Case ID:** TC-PRIVACY-001
*   **User Story:** US1: Display Core Website Pages
*   **Test Objective:** Verify navigation to the Privacy Policy page from the footer.
*   **Preconditions:** Website is accessible.
*   **Steps:**
    1.  Navigate to the website URL.
    2.  Scroll to the footer.
    3.  Click on the "Privacy Policy" link.
*   **Expected Result:** The user is taken to the Privacy Policy page. The page title is "PharmaCorp - Privacy Policy" and legal text is displayed.
*   **Priority:** High
*   **Test Type:** Functional (UI)

**Test Case ID:** TC-TERMS-001
*   **User Story:** US1: Display Core Website Pages
*   **Test Objective:** Verify navigation to the Terms of Use page from the footer.
*   **Preconditions:** Website is accessible.
*   **Steps:**
    1.  Navigate to the website URL.
    2.  Scroll to the footer.
    3.  Click on the "Terms of Use" link.
*   **Expected Result:** The user is taken to the Terms of Use page. The page title is "PharmaCorp - Terms of Use" and legal text is displayed.
*   **Priority:** High
*   **Test Type:** Functional (UI)

**Test Case ID:** TC-RESPONSIVE-001
*   **User Story:** US1: Display Core Website Pages
*   **Test Objective:** Verify responsiveness of core pages across devices.
*   **Preconditions:** Website is accessible.
*   **Steps:**
    1.  Navigate to Home, About Us, Contact Us, Privacy Policy, and Terms of Use pages.
    2.  For each page, resize the browser window to simulate tablet and mobile screen sizes.
    3.  Alternatively, open pages on actual tablet and mobile devices.
*   **Expected Result:** All core pages display correctly without horizontal scrolling, overlapping content, or broken layouts on desktop, tablet, and mobile dimensions. Navigation elements adapt appropriately (e.g., hamburger menu on mobile).
*   **Priority:** High
*   **Test Type:** Non-Functional (Compatibility)

**Test Case ID:** TC-ACCESSIBILITY-001
*   **User Story:** US1: Display Core Website Pages
*   **Test Objective:** Verify WCAG 2.2 AA compliance for core pages.
*   **Preconditions:** Website is accessible. Screen reader software (e.g., NVDA, JAWS, VoiceOver) is installed and running.
*   **Steps:**
    1.  Navigate to Home, About Us, Contact Us, Privacy Policy, and Terms of Use pages.
    2.  Use keyboard navigation (Tab, Shift+Tab, Enter) to navigate through all interactive elements (links, buttons).
    3.  Activate screen reader and listen to the page content and interactive elements.
    4.  Manually check for sufficient color contrast using a contrast checker tool.
*   **Expected Result:**
    *   All interactive elements are reachable and operable via keyboard, with clear focus indicators.
    *   Screen reader accurately announces page titles, headings, link purposes, and content.
    *   All text and interactive elements have sufficient color contrast (WCAG AA).
    *   Images have appropriate alt text.
*   **Priority:** High
*   **Test Type:** Non-Functional (Accessibility)

**Test Case ID:** TC-PERF-001
*   **User Story:** US1: Display Core Website Pages
*   **Test Objective:** Verify LCP score for core pages.
*   **Preconditions:** Website is deployed to Staging.
*   **Steps:**
    1.  Use Google Lighthouse or PageSpeed Insights on the Staging environment.
    2.  Run tests for Home, About Us, Contact Us, Privacy Policy, and Terms of Use pages.
*   **Expected Result:** Each core page achieves a Largest Contentful Paint (LCP) score of < 2.5 seconds on typical network conditions.
*   **Priority:** High
*   **Test Type:** Non-Functional (Performance)

### Epic: Product Information Display

**Test Case ID:** TC-PRODLIST-001
*   **User Story:** US2: View Product List
*   **Test Objective:** Verify display of active products on the Products page.
*   **Preconditions:** At least one active product exists in the database.
*   **Steps:**
    1.  Navigate to the "Products" page (e.g., via main navigation).
*   **Expected Result:** A list of all active PharmaCorp products is displayed. Each product item clearly shows its name and a brief description.
*   **Priority:** High
*   **Test Type:** Functional (UI, API)

**Test Case ID:** TC-PRODLIST-002
*   **User Story:** US2: View Product List
*   **Test Objective:** Verify clickability of product items to their detail pages.
*   **Preconditions:** TC-PRODLIST-001 passed.
*   **Steps:**
    1.  On the Products page, click on any product item in the list.
*   **Expected Result:** The user is navigated to the dedicated product detail page for the selected product.
*   **Priority:** High
*   **Test Type:** Functional (UI)

**Test Case ID:** TC-PRODLIST-003
*   **User Story:** US2: View Product List
*   **Test Objective:** Verify product list is retrieved via backend API.
*   **Preconditions:** Website is accessible. Network monitoring tools (e.g., browser DevTools) are open.
*   **Steps:**
    1.  Navigate to the "Products" page.
    2.  Observe network requests in DevTools.
*   **Expected Result:** An API call to `GET /api/products` is made, and the product data is returned in the response, populating the product list on the page.
*   **Priority:** Medium
*   **Test Type:** Functional (API)

**Test Case ID:** TC-PRODDETAIL-001
*   **User Story:** US3: View Product Detail and Download Prescribing Information
*   **Test Objective:** Verify display of detailed product information.
*   **Preconditions:** User is on the Product List page.
*   **Steps:**
    1.  Click on a specific product from the Product List page.
*   **Expected Result:** The dedicated product detail page loads, displaying the product name, detailed description, and relevant medical information.
*   **Priority:** High
*   **Test Type:** Functional (UI, API)

**Test Case ID:** TC-PRODDETAIL-002
*   **User Story:** US3: View Product Detail and Download Prescribing Information
*   **Test Objective:** Verify the presence of the PI PDF download button/link.
*   **Preconditions:** TC-PRODDETAIL-001 passed.
*   **Steps:**
    1.  On the product detail page, visually inspect the content.
*   **Expected Result:** A prominent "Download Prescribing Information (PI) PDF" button or link is visible.
*   **Priority:** High
*   **Test Type:** Functional (UI)

**Test Case ID:** TC-PRODDETAIL-003
*   **User Story:** US3: View Product Detail and Download Prescribing Information
*   **Test Objective:** Verify PI PDF download functionality from a secure URL.
*   **Preconditions:** TC-PRODDETAIL-002 passed. A PI PDF is associated with the product in object storage.
*   **Steps:**
    1.  Click the "Download Prescribing Information (PI) PDF" button/link.
    2.  Observe the network request for the PDF download (e.g., in DevTools).
*   **Expected Result:**
    *   The browser initiates the download of a PDF document.
    *   The download URL is an HTTPS URL, likely a pre-signed URL from the CDN or object storage.
    *   The downloaded file is a valid PDF document.
*   **Priority:** High
*   **Test Type:** Functional (UI, API, Security)

**Test Case ID:** TC-PRODDETAIL-004
*   **User Story:** US3: View Product Detail and Download Prescribing Information
*   **Test Objective:** Verify LCP score for product detail pages.
*   **Preconditions:** Website is deployed to Staging.
*   **Steps:**
    1.  Use Google Lighthouse or PageSpeed Insights on the Staging environment.
    2.  Run tests for several product detail pages.
*   **Expected Result:** Each product detail page achieves a Largest Contentful Paint (LCP) score of < 2.5 seconds on typical network conditions.
*   **Priority:** High
*   **Test Type:** Non-Functional (Performance)

**Test Case ID:** TC-ISI-001
*   **User Story:** US4: Display Sticky Important Safety Information (ISI)
*   **Test Objective:** Verify ISI section is displayed on product detail pages.
*   **Preconditions:** User is on a product detail page.
*   **Steps:**
    1.  Observe the page content upon loading.
*   **Expected Result:** A distinct section containing Important Safety Information (ISI) is displayed, typically in a footer or sidebar position.
*   **Priority:** High
*   **Test Type:** Functional (UI)

**Test Case ID:** TC-ISI-002
*   **User Story:** US4: Display Sticky Important Safety Information (ISI)
*   **Test Objective:** Verify ISI section remains fixed while scrolling.
*   **Preconditions:** TC-ISI-001 passed. The product detail page content is long enough to require scrolling.
*   **Steps:**
    1.  Scroll down the product detail page.
    2.  Observe the ISI section.
*   **Expected Result:** The ISI section remains fixed in its visible position (e.g., sticky footer or sidebar) as the user scrolls, always remaining on screen.
*   **Priority:** High
*   **Test Type:** Functional (UI)

**Test Case ID:** TC-ISI-003
*   **User Story:** US4: Display Sticky Important Safety Information (ISI)
*   **Test Objective:** Verify sticky ISI does not obscure critical content.
*   **Preconditions:** TC-ISI-002 passed.
*   **Steps:**
    1.  Scroll through the product detail page on various screen sizes (desktop, tablet, mobile).
    2.  Visually inspect the content, especially the main product details, to ensure it's not covered by the ISI.
*   **Expected Result:** The sticky ISI section does not overlap or obscure any critical content on the page, regardless of screen size.
*   **Priority:** High
*   **Test Type:** Functional (UI), Non-Functional (Compatibility)

**Test Case ID:** TC-ISI-004
*   **User Story:** US4: Display Sticky Important Safety Information (ISI)
*   **Test Objective:** Verify sticky ISI accessibility.
*   **Preconditions:** TC-ISI-001 passed.
*   **Steps:**
    1.  Use keyboard navigation (Tab, Shift+Tab) to try and reach interactive elements within the ISI (if any).
    2.  Check for sufficient color contrast of text within the ISI.
    3.  Use a screen reader to ensure the ISI content is properly announced.
*   **Expected Result:** The sticky ISI section is keyboard-navigable (if applicable), has sufficient color contrast, and its content is correctly announced by screen readers.
*   **Priority:** Medium
*   **Test Type:** Non-Functional (Accessibility)

### Epic: Interactive Features

**Test Case ID:** TC-FORM-001
*   **User Story:** US5: Submit a Contact Form Inquiry
*   **Test Objective:** Verify successful submission of the contact form with valid data.
*   **Preconditions:** User is on the Contact Us page.
*   **Steps:**
    1.  Enter valid data into all required fields:
        *   Name: "John Doe"
        *   Email: "john.doe@example.com"
        *   Subject: "General Inquiry"
        *   Message: "I would like to know more about PharmaCorp."
    2.  Click the "Submit" button.
*   **Expected Result:**
    *   A success message (e.g., "Inquiry submitted successfully.") is displayed to the user.
    *   The form fields are cleared or disabled.
    *   (Backend/DB check): The inquiry data is successfully stored in the `contact_inquiries` table in PostgreSQL.
*   **Priority:** High
*   **Test Type:** Functional (UI, API, DB)

**Test Case ID:** TC-FORM-002
*   **User Story:** US5: Submit a Contact Form Inquiry
*   **Test Objective:** Verify client-side and server-side validation for missing required fields.
*   **Preconditions:** User is on the Contact Us page.
*   **Steps:**
    1.  Leave one or more required fields (e.g., Name, Email, Subject, Message) empty.
    2.  Click the "Submit" button.
*   **Expected Result:**
    *   Client-side validation errors are displayed for each missing required field (e.g., "This field is required.").
    *   The form is not submitted.
    *   (If client-side validation is bypassed or absent): An API call is made, but the backend returns a 400 Bad Request response with appropriate validation error messages, and these are displayed to the user.
*   **Priority:** High
*   **Test Type:** Functional (UI, API)

**Test Case ID:** TC-FORM-003
*   **User Story:** US5: Submit a Contact Form Inquiry
*   **Test Objective:** Verify client-side and server-side validation for invalid email format.
*   **Preconditions:** User is on the Contact Us page.
*   **Steps:**
    1.  Enter valid data in all fields except the Email field.
    2.  Enter an invalid email format (e.g., "invalid-email", "test@") in the Email field.
    3.  Click the "Submit" button.
*   **Expected Result:**
    *   Client-side validation error is displayed for the Email field (e.g., "Please enter a valid email address.").
    *   The form is not submitted.
    *   (If client-side validation is bypassed or absent): An API call is made, but the backend returns a 400 Bad Request response with an "invalid email format" error, and this is displayed to the user.
*   **Priority:** High
*   **Test Type:** Functional (UI, API)

**Test Case ID:** TC-FORM-004
*   **User Story:** US5: Submit a Contact Form Inquiry, US12: Ensure Data Privacy Compliance (GDPR/CCPA)
*   **Test Objective:** Verify GDPR/CCPA compliance for the contact form.
*   **Preconditions:** User is on the Contact Us page.
*   **Steps:**
    1.  Observe the contact form for any data usage statements or consent checkboxes.
    2.  If a consent checkbox is present, attempt to submit the form without checking it.
*   **Expected Result:**
    *   A clear statement about data usage (e.g., "By submitting this form, you agree to our Privacy Policy...") is visible near the form.
    *   If an explicit consent checkbox is required, attempting to submit without checking it results in a validation error.
    *   A link to the Privacy Policy is easily accessible.
*   **Priority:** High
*   **Test Type:** Non-Functional (Compliance)

**Test Case ID:** TC-FORM-005
*   **User Story:** US5: Submit a Contact Form Inquiry, US9: Ensure Core Website Security
*   **Test Objective:** Verify server-side input validation and rate limiting for the contact form API.
*   **Preconditions:** Backend API is deployed.
*   **Steps:**
    1.  Use an API client (e.g., Postman) to send requests directly to `POST /api/contact`.
    2.  Send requests with invalid data (e.g., missing fields, invalid email, excessively long text).
    3.  Send a large number of requests in a short period to trigger rate limiting.
*   **Expected Result:**
    *   Invalid data requests receive a 400 Bad Request response with specific error messages for validation failures.
    *   After exceeding the rate limit, subsequent requests receive a 429 Too Many Requests response.
*   **Priority:** High
*   **Test Type:** Functional (API), Non-Functional (Security)

**Test Case ID:** TC-NEWS-001 (Updated)
*   **User Story:** US6: Sign Up for Newsletter, US12: Ensure Data Privacy Compliance (GDPR/CCPA)
*   **Test Objective:** Verify successful newsletter subscription with valid data and GDPR/CCPA compliance.
*   **Preconditions:** Newsletter signup form is visible (e.g., in footer).
*   **Steps:**
    1.  Observe the newsletter signup form for a clear data usage statement and/or consent checkbox.
    2.  Enter a valid, unique email address (e.g., "newsubscriber@example.com").
    3.  If a consent checkbox is present, ensure it is checked.
    4.  Click "Subscribe" button.
*   **Expected Result:**
    *   A clear data usage statement (e.g., "We will use your email to send you updates...") is visible.
    *   A success message (e.g., "Subscribed successfully.") is displayed.
    *   The email address is successfully stored in the `newsletter_subscribers` table, along with a `consent_given_at` timestamp.
    *   The `is_active` field is set to `TRUE`.
*   **Priority:** High
*   **Test Type:** Functional (UI, API, DB), Non-Functional (Compliance)

**Test Case ID:** TC-NEWS-002 (Added)
*   **User Story:** US6: Sign Up for Newsletter
*   **Test Objective:** Verify validation for invalid email format during newsletter signup.
*   **Preconditions:** Newsletter signup form is visible.
*   **Steps:**
    1.  Enter an invalid email address (e.g., "invalid-email", "test@") into the email field.
    2.  (If applicable) Check the consent checkbox.
    3.  Click "Subscribe".
*   **Expected Result:**
    *   A client-side validation error is displayed (e.g., "Please enter a valid email address.").
    *   The form is not submitted.
    *   (If client-side validation is bypassed/absent): Backend returns a 400 Bad Request with an "invalid email format" error.
*   **Priority:** High
*   **Test Type:** Functional (UI, API)

**Test Case ID:** TC-NEWS-003 (Added)
*   **User Story:** US6: Sign Up for Newsletter
*   **Test Objective:** Verify validation for missing email address during newsletter signup.
*   **Preconditions:** Newsletter signup form is visible.
*   **Steps:**
    1.  Leave the email address field empty.
    2.  (If applicable) Check the consent checkbox.
    3.  Click "Subscribe".
*   **Expected Result:**
    *   A client-side validation error is displayed (e.g., "This field is required." or "Email address cannot be empty.").
    *   The form is not submitted.
    *   (If client-side validation is bypassed/absent): Backend returns a 400 Bad Request with a "missing email" error.
*   **Priority:** High
*   **Test Type:** Functional (UI, API)

**Test Case ID:** TC-NEWS-004
*   **User Story:** US6: Sign Up for Newsletter, US9: Ensure Core Website Security
*   **Test Objective:** Verify server-side input validation and rate limiting for the newsletter API.
*   **Preconditions:** Backend API is deployed.
*   **Steps:**
    1.  Use an API client (e.g., Postman) to send requests directly to `POST /api/newsletter`.
    2.  Send requests with invalid data (e.g., missing email, invalid email, `consent_given: false`).
    3.  Send a large number of requests in a short period to trigger rate limiting.
*   **Expected Result:**
    *   Invalid data requests receive a 400 Bad Request response with specific error messages for validation failures.
    *   After exceeding the rate limit, subsequent requests receive a 429 Too Many Requests response.
*   **Priority:** High
*   **Test Type:** Functional (API), Non-Functional (Security)

**Test Case ID:** TC-SEARCH-001
*   **User Story:** US7: Search Website Content
*   **Test Objective:** Verify basic search functionality and display of results.
*   **Preconditions:** Search bar is present (e.g., in header). Website contains searchable content/products.
*   **Steps:**
    1.  Locate the search bar.
    2.  Enter a search query (e.g., "Product Alpha", "About Us").
    3.  Press Enter or click the search icon.
*   **Expected Result:**
    *   The user is taken to a search results page.
    *   A list of relevant pages or products with excerpts is displayed.
    *   The search query is reflected in the URL (e.g., `/search?q=query`).
*   **Priority:** High
*   **Test Type:** Functional (UI, API)

**Test Case ID:** TC-SEARCH-002
*   **User Story:** US7: Search Website Content
*   **Test Objective:** Verify navigation by clicking a search result.
*   **Preconditions:** TC-SEARCH-001 passed with results displayed.
*   **Steps:**
    1.  On the search results page, click on one of the displayed search results.
*   **Expected Result:** The user is navigated to the corresponding page or product detail page.
*   **Priority:** High
*   **Test Type:** Functional (UI)

**Test Case ID:** TC-SEARCH-003
*   **User Story:** US7: Search Website Content
*   **Test Objective:** Verify relevance of search results.
*   **Preconditions:** TC-SEARCH-001 passed.
*   **Steps:**
    1.  Perform various searches using different keywords (e.g., product names, terms from About Us/Privacy Policy, common medical terms).
    2.  Manually review the displayed results for relevance to the search query.
*   **Expected Result:** The search results are highly relevant to the entered query, prioritizing exact matches and key terms.
*   **Priority:** Medium
*   **Test Type:** Functional (UI, API)

**Test Case ID:** TC-COOKIE-001
*   **User Story:** US8: Manage Cookie Consent, US12: Ensure Data Privacy Compliance (GDPR/CCPA)
*   **Test Objective:** Verify cookie consent banner is displayed on first visit.
*   **Preconditions:** Browser cache and cookies are cleared.
*   **Steps:**
    1.  Navigate to the website URL for the first time.
*   **Expected Result:** A prominent cookie consent banner or pop-up is displayed, informing about cookie usage and providing options like "Accept All", "Reject All", "Manage Preferences".
*   **Priority:** High
*   **Test Type:** Functional (UI), Non-Functional (Compliance)

**Test Case ID:** TC-COOKIE-002
*   **User Story:** US8: Manage Cookie Consent
*   **Test Objective:** Verify "Accept All" functionality of the cookie banner.
*   **Preconditions:** TC-COOKIE-001 passed.
*   **Steps:**
    1.  On the cookie consent banner, click "Accept All".
    2.  Refresh the page or navigate to another page.
*   **Expected Result:**
    *   The cookie banner disappears.
    *   All non-essential cookies are enabled (can be verified via browser developer tools).
    *   The banner does not reappear on subsequent page loads or visits (for a defined period).
*   **Priority:** High
*   **Test Type:** Functional (UI), Non-Functional (Compliance)

**Test Case ID:** TC-COOKIE-003 (Added)
*   **User Story:** US8: Manage Cookie Consent
*   **Test Objective:** Verify "Manage Preferences" functionality and saving specific cookie categories.
*   **Preconditions:** TC-COOKIE-001 passed.
*   **Steps:**
    1.  On the cookie consent banner, click "Manage Preferences".
    2.  A detailed cookie settings panel should appear.
    3.  Disable one specific category of non-essential cookies (e.g., Analytics Cookies) while leaving others enabled.
    4.  Click "Save Preferences" or similar button.
    5.  Refresh the page or navigate to another page.
*   **Expected Result:**
    *   The cookie settings panel closes, and the main banner disappears.
    *   Only the essential cookies and the explicitly enabled non-essential cookie categories are active.
    *   The disabled cookie category's cookies are not set (can be verified via browser developer tools).
    *   The banner does not reappear on subsequent page loads.
*   **Priority:** High
*   **Test Type:** Functional (UI), Non-Functional (Compliance)

**Test Case ID:** TC-COOKIE-004 (Added)
*   **User Story:** US8: Manage Cookie Consent
*   **Test Objective:** Verify cookie consent preferences are remembered across subsequent visits.
*   **Preconditions:** Browser cache and cookies are cleared.
*   **Steps:**
    1.  Navigate to the website. The cookie banner appears.
    2.  Click "Accept All" (or "Reject All", or save specific preferences via "Manage Preferences").
    3.  Close the browser, then reopen it and navigate to the website again.
*   **Expected Result:** The cookie consent banner does *not* reappear, and the previously set preferences (e.g., all cookies accepted, specific categories enabled/disabled) are respected and active.
*   **Priority:** High
*   **Test Type:** Functional (UI), Non-Functional (Compliance)

**Test Case ID:** TC-COOKIE-005
*   **User Story:** US8: Manage Cookie Consent
*   **Test Objective:** Verify "Reject All" functionality of the cookie banner.
*   **Preconditions:** TC-COOKIE-001 passed. Browser cache and cookies are cleared.
*   **Steps:**
    1.  Navigate to the website. The cookie banner appears.
    2.  Click "Reject All".
    3.  Refresh the page or navigate to another page.
*   **Expected Result:**
    *   The cookie banner disappears.
    *   Only essential cookies are enabled; all non-essential cookies are disabled (can be verified via browser developer tools).
    *   The banner does not reappear on subsequent page loads or visits (for a defined period).
*   **Priority:** High
*   **Test Type:** Functional (UI), Non-Functional (Compliance)

## 3. Automation Test Scripts (Python Playwright & Requests)

### 3.1. Setup Instructions
1.  **Install Python:** Ensure Python 3.8+ is installed.
2.  **Create Virtual Environment:**
    ```bash
    python -m venv venv
    source venv/bin/activate # On Windows: .\venv\Scripts\activate
    ```
3.  **Install Dependencies:**
    ```bash
    pip install pytest playwright requests
    playwright install
    ```
4.  **Directory Structure:**
    ```
    pharma_corp_tests/
    ├── tests/
    │   ├── ui/
    │   │   ├── test_navigation.py
    │   │   ├── test_products.py
    │   │   ├── test_forms.py
    │   │   └── test_cookies.py
    │   └── api/
    │       ├── test_api_products.py
    │       └── test_api_forms.py
    ├── pages/
    │   ├── base_page.py
    │   ├── home_page.py
    │   ├── contact_page.py
    │   ├── newsletter_form.py
    │   ├── products_page.py
    │   ├── product_detail_page.py
    │   └── cookie_banner.py
    └── conftest.py
    ```
5.  **Run Tests:**
    *   To run all UI tests: `pytest tests/ui/`
    *   To run all API tests: `pytest tests/api/`
    *   To run all tests: `pytest`

### 3.2. `conftest.py`
```python
import pytest
from playwright.sync_api import sync_playwright

@pytest.fixture(scope="session")
def browser_context_args(browser_context_args):
    """Fixture to set common browser context arguments."""
    return {
        **browser_context_args,
        "ignore_https_errors": True,
        "viewport": {"width": 1920, "height": 1080}, # Default desktop viewport
    }

@pytest.fixture(scope="session")
def browser():
    """Provides a Playwright browser instance for all tests."""
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True) # Set headless=False for visual debugging
        yield browser
        browser.close()

@pytest.fixture(scope="function")
def page(browser, request):
    """Provides a fresh Playwright page for each test function."""
    context = browser.new_context()
    page = context.new_page()

    # Clear cookies for each test to ensure fresh state for cookie consent tests
    if "test_cookie" in request.node.name:
        context.clear_cookies()
        page.goto("about:blank") # Navigate away to ensure cookies are cleared before actual test navigation

    yield page
    context.close()

@pytest.fixture(scope="session")
def base_url():
    """Base URL for the website under test."""
    return "https://your-pharma-corp-website.com" # Replace with actual URL

@pytest.fixture(scope="session")
def api_base_url():
    """Base URL for the API under test."""
    return "https://your-pharma-corp-website.com/api" # Replace with actual API URL
```

### 3.3. Page Object Model (POM) Definitions (`pages/`)

#### `pages/base_page.py`
```python
from playwright.sync_api import Page, expect

class BasePage:
    def __init__(self, page: Page, base_url: str):
        self.page = page
        self.base_url = base_url
        self.nav_home_link = page.locator("nav a", has_text="Home")
        self.nav_about_us_link = page.locator("nav a", has_text="About Us")
        self.nav_contact_us_link = page.locator("nav a", has_text="Contact Us")
        self.nav_products_link = page.locator("nav a", has_text="Products")
        self.footer_privacy_link = page.locator("footer a", has_text="Privacy Policy")
        self.footer_terms_link = page.locator("footer a", has_text="Terms of Use")
        self.search_bar = page.locator("[aria-label='Search website']") # Assuming an ARIA label for accessibility

    def goto(self, path: str = ""):
        self.page.goto(f"{self.base_url}{path}")

    def get_title(self) -> str:
        return self.page.title()

    def navigate_to_home(self):
        self.nav_home_link.click()
        expect(self.page).to_have_url(f"{self.base_url}/")

    def navigate_to_about_us(self):
        self.nav_about_us_link.click()
        expect(self.page).to_have_url(f"{self.base_url}/about-us")

    def navigate_to_contact_us(self):
        self.nav_contact_us_link.click()
        expect(self.page).to_have_url(f"{self.base_url}/contact-us")

    def navigate_to_products(self):
        self.nav_products_link.click()
        expect(self.page).to_have_url(f"{self.base_url}/products")

    def navigate_to_privacy_policy(self):
        self.footer_privacy_link.click()
        expect(self.page).to_have_url(f"{self.base_url}/privacy-policy")

    def navigate_to_terms_of_use(self):
        self.footer_terms_link.click()
        expect(self.page).to_have_url(f"{self.base_url}/terms-of-use")

    def perform_search(self, query: str):
        self.search_bar.fill(query)
        self.search_bar.press("Enter")
        expect(self.page).to_have_url(f"{self.base_url}/search?q={query}")
```

#### `pages/home_page.py`
```python
from playwright.sync_api import Page
from pages.base_page import BasePage

class HomePage(BasePage):
    def __init__(self, page: Page, base_url: str):
        super().__init__(page, base_url)
        # Add any specific locators for the homepage here
        self.welcome_message = page.locator("h1", has_text="Welcome to PharmaCorp") # Example locator
```

#### `pages/contact_page.py`
```python
from playwright.sync_api import Page, expect
from pages.base_page import BasePage

class ContactPage(BasePage):
    def __init__(self, page: Page, base_url: str):
        super().__init__(page, base_url)
        self.name_field = page.locator("#name")
        self.email_field = page.locator("#email")
        self.subject_field = page.locator("#subject")
        self.message_field = page.locator("#message")
        self.submit_button = page.locator("button[type='submit']", has_text="Submit")
        self.success_message = page.locator(".success-message") # Assuming a class for success messages
        self.error_message = page.locator(".error-message") # Assuming a class for error messages
        self.gdpr_statement = page.locator("text=By submitting this form, you agree to our Privacy Policy.") # Example
        self.privacy_policy_link = page.locator("a", has_text="Privacy Policy")

    def fill_contact_form(self, name: str, email: str, subject: str, message: str):
        self.name_field.fill(name)
        self.email_field.fill(email)
        self.subject_field.fill(subject)
        self.message_field.fill(message)

    def submit_form(self):
        self.submit_button.click()

    def expect_success_message(self, message: str = "Inquiry submitted successfully."):
        expect(self.success_message).to_be_visible()
        expect(self.success_message).to_have_text(message)

    def expect_error_message(self, field_name: str, message: str):
        expect(self.page.locator(f"#{field_name} + .error-message")).to_be_visible()
        expect(self.page.locator(f"#{field_name} + .error-message")).to_have_text(message)

    def expect_gdpr_statement_present(self):
        expect(self.gdpr_statement).to_be_visible()
        expect(self.privacy_policy_link).to_be_visible()
```

#### `pages/newsletter_form.py`
```python
from playwright.sync_api import Page, expect

class NewsletterForm:
    def __init__(self, page: Page):
        self.page = page
        self.email_field = page.locator("footer input[type='email']") # Assuming in footer
        self.subscribe_button = page.locator("footer button[type='submit']", has_text="Subscribe")
        self.success_message = page.locator("footer .newsletter-success-message")
        self.error_message = page.locator("footer .newsletter-error-message")
        self.consent_checkbox = page.locator("footer input[type='checkbox'][name='newsletter_consent']") # Added for GDPR
        self.gdpr_statement = page.locator("footer text=By subscribing, you agree to our Privacy Policy.") # Added for GDPR

    def fill_email(self, email: str):
        self.email_field.fill(email)

    def check_consent(self):
        self.consent_checkbox.check()

    def submit(self):
        self.subscribe_button.click()

    def expect_success_message(self, message: str = "Subscribed successfully."):
        expect(self.success_message).to_be_visible()
        expect(self.success_message).to_have_text(message)

    def expect_error_message(self, message: str):
        expect(self.error_message).to_be_visible()
        expect(self.error_message).to_have_text(message)

    def expect_gdpr_elements_present(self):
        expect(self.gdpr_statement).to_be_visible()
        expect(self.consent_checkbox).to_be_visible()
```

#### `pages/products_page.py`
```python
from playwright.sync_api import Page, expect
from pages.base_page import BasePage

class ProductsPage(BasePage):
    def __init__(self, page: Page, base_url: str):
        super().__init__(page, base_url)
        self.product_list_items = page.locator(".product-list-item") # Assuming a class for product list items
        self.product_name = lambda name: page.locator(".product-list-item h3", has_text=name)
        self.product_description = lambda name: page.locator(".product-list-item", has_text=name).locator(".product-description")

    def expect_product_list_visible(self):
        expect(self.product_list_items.first).to_be_visible()

    def get_product_count(self) -> int:
        return self.product_list_items.count()

    def click_product_by_name(self, name: str):
        self.page.locator(".product-list-item", has_text=name).click()
```

#### `pages/product_detail_page.py`
```python
from playwright.sync_api import Page, expect
from pages.base_page import BasePage

class ProductDetailPage(BasePage):
    def __init__(self, page: Page, base_url: str):
        super().__init__(page, base_url)
        self.product_name_header = page.locator("h1.product-name")
        self.detailed_description = page.locator(".product-detailed-description")
        self.medical_information = page.locator(".product-medical-information")
        self.download_pi_pdf_button = page.locator("a", has_text="Download Prescribing Information (PI) PDF")
        self.isi_section = page.locator(".important-safety-information") # Assuming a class for ISI

    def expect_product_details_visible(self, name: str):
        expect(self.product_name_header).to_have_text(name)
        expect(self.detailed_description).to_be_visible()
        expect(self.medical_information).to_be_visible()
        expect(self.download_pi_pdf_button).to_be_visible()

    def click_download_pi_pdf(self):
        return self.download_pi_pdf_button.click() # Returns Promise for download

    def expect_isi_visible(self):
        expect(self.isi_section).to_be_visible()

    def expect_isi_sticky_on_scroll(self):
        # This is a conceptual check, actual implementation might involve checking CSS position
        # or visual assertion after scroll. For now, we'll check its visibility after scrolling.
        initial_position = self.isi_section.bounding_box()
        self.page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        self.page.wait_for_timeout(500) # Give time for sticky effect
        final_position = self.isi_section.bounding_box()
        # Expect the Y position to be roughly the same or within a sticky range
        expect(self.isi_section).to_be_in_viewport()
        assert initial_position and final_position
        # More robust check would involve comparing Y coordinates relative to viewport,
        # but simple visibility check after scroll implies stickiness for this level of automation.
```

#### `pages/cookie_banner.py`
```python
from playwright.sync_api import Page, expect

class CookieBanner:
    def __init__(self, page: Page):
        self.page = page
        self.banner = page.locator("#cookie-consent-banner") # Assuming ID for the banner
        self.accept_all_button = self.banner.locator("button", has_text="Accept All")
        self.reject_all_button = self.banner.locator("button", has_text="Reject All")
        self.manage_preferences_button = self.banner.locator("button", has_text="Manage Preferences")
        self.preferences_panel = page.locator("#cookie-preferences-panel") # Assuming ID for the panel
        self.analytics_toggle = self.preferences_panel.locator("label", has_text="Analytics Cookies").locator("input[type='checkbox']")
        self.marketing_toggle = self.preferences_panel.locator("label", has_text="Marketing Cookies").locator("input[type='checkbox']")
        self.save_preferences_button = self.preferences_panel.locator("button", has_text="Save Preferences")

    def expect_banner_visible(self):
        expect(self.banner).to_be_visible()

    def expect_banner_hidden(self):
        expect(self.banner).to_be_hidden()

    def accept_all(self):
        self.accept_all_button.click()
        self.expect_banner_hidden()

    def reject_all(self):
        self.reject_all_button.click()
        self.expect_banner_hidden()

    def open_manage_preferences(self):
        self.manage_preferences_button.click()
        expect(self.preferences_panel).to_be_visible()

    def toggle_analytics_cookies(self, enable: bool):
        if enable and not self.analytics_toggle.is_checked():
            self.analytics_toggle.check()
        elif not enable and self.analytics_toggle.is_checked():
            self.analytics_toggle.uncheck()

    def toggle_marketing_cookies(self, enable: bool):
        if enable and not self.marketing_toggle.is_checked():
            self.marketing_toggle.check()
        elif not enable and self.marketing_toggle.is_checked():
            self.marketing_toggle.uncheck()

    def save_preferences(self):
        self.save_preferences_button.click()
        self.expect_banner_hidden()
        expect(self.preferences_panel).to_be_hidden()

    def get_cookie_value(self, name: str) -> str:
        """Helper to get a specific cookie's value after interaction."""
        cookies = self.page.context.cookies()
        for cookie in cookies:
            if cookie['name'] == name:
                return cookie['value']
        return None
```

### 3.4. UI Automation Tests (`tests/ui/`)

#### `tests/ui/test_navigation.py`
```python
import pytest
from pages.home_page import HomePage
from pages.base_page import BasePage
from playwright.sync_api import expect

def test_core_page_navigation(page, base_url):
    """Verify navigation to all core pages and their titles."""
    base_page = BasePage(page, base_url)
    base_page.goto()

    # Test Home
    base_page.navigate_to_home()
    expect(page).to_have_title("PharmaCorp - Home") # Adjust expected title

    # Test About Us
    base_page.navigate_to_about_us()
    expect(page).to_have_title("PharmaCorp - About Us") # Adjust expected title

    # Test Contact Us
    base_page.navigate_to_contact_us()
    expect(page).to_have_title("PharmaCorp - Contact Us") # Adjust expected title

    # Test Products (assuming it's in header nav)
    base_page.navigate_to_products()
    expect(page).to_have_title("PharmaCorp - Products") # Adjust expected title

    # Test Privacy Policy (assuming in footer)
    base_page.navigate_to_privacy_policy()
    expect(page).to_have_title("PharmaCorp - Privacy Policy") # Adjust expected title

    # Test Terms of Use (assuming in footer)
    base_page.navigate_to_terms_of_use()
    expect(page).to_have_title("PharmaCorp - Terms of Use") # Adjust expected title
```

#### `tests/ui/test_products.py`
```python
import pytest
from pages.products_page import ProductsPage
from pages.product_detail_page import ProductDetailPage
from playwright.sync_api import expect

def test_product_list_display_and_navigation(page, base_url):
    """Verify product list display and navigation to a detail page."""
    products_page = ProductsPage(page, base_url)
    products_page.goto("/products")
    products_page.expect_product_list_visible()
    assert products_page.get_product_count() > 0, "Expected at least one product in the list"

    # Click on the first product (assuming it exists)
    first_product_name = products_page.product_list_items.first.locator("h3").text_content()
    products_page.click_product_by_name(first_product_name)

    product_detail_page = ProductDetailPage(page, base_url)
    product_detail_page.expect_product_details_visible(first_product_name)

def test_product_detail_and_pdf_download(page, base_url):
    """Verify product detail page elements and PDF download initiation."""
    product_detail_page = ProductDetailPage(page, base_url)
    # Navigate directly to a known product detail page for testing
    # Replace 'product-alpha' with a valid product slug from your test data
    product_detail_page.goto("/products/product-alpha")
    product_detail_page.expect_product_details_visible("Product Alpha") # Adjust expected product name

    # Test PDF download initiation
    with page.expect_download() as download_info:
        product_detail_page.click_download_pi_pdf()
    download = download_info.value
    expect(download.url).to_start_with("https://cdn.example.com/signed-url/") # Verify signed URL pattern
    expect(download.suggested_filename).to_end_with(".pdf")
    # You can also save the file and verify its content/size if needed
    # download.save_as(f"temp/{download.suggested_filename}")

def test_sticky_isi_visibility_on_scroll(page, base_url):
    """Verify the Important Safety Information (ISI) section remains sticky on scroll."""
    product_detail_page = ProductDetailPage(page, base_url)
    # Navigate to a product detail page with enough content to scroll
    product_detail_page.goto("/products/product-alpha") # Adjust product slug
    product_detail_page.expect_product_details_visible("Product Alpha") # Adjust product name

    product_detail_page.expect_isi_visible()
    product_detail_page.expect_isi_sticky_on_scroll()
```

#### `tests/ui/test_forms.py`
```python
import pytest
from pages.contact_page import ContactPage
from pages.newsletter_form import NewsletterForm
from playwright.sync_api import expect

def test_contact_form_submission_success(page, base_url):
    """Verify successful contact form submission."""
    contact_page = ContactPage(page, base_url)
    contact_page.goto("/contact-us")
    contact_page.expect_gdpr_statement_present() # Check for GDPR compliance elements
    contact_page.fill_contact_form(
        name="Automation Test",
        email="auto.test@example.com",
        subject="Automated Inquiry",
        message="This is an automated test message for PharmaCorp."
    )
    contact_page.submit_form()
    contact_page.expect_success_message()

def test_contact_form_validation_invalid_email(page, base_url):
    """Verify client-side validation for invalid email in contact form."""
    contact_page = ContactPage(page, base_url)
    contact_page.goto("/contact-us")
    contact_page.fill_contact_form(
        name="Invalid Email Test",
        email="invalid-email",
        subject="Validation Test",
        message="Checking email validation."
    )
    contact_page.submit_form()
    contact_page.expect_error_message("email", "Please enter a valid email address.") # Adjust message if different

def test_newsletter_signup_success(page, base_url):
    """Verify successful newsletter signup with consent."""
    page.goto(base_url) # Newsletter form is assumed to be on most pages (e.g., footer)
    newsletter_form = NewsletterForm(page)
    newsletter_form.expect_gdpr_elements_present() # Check for GDPR compliance elements
    newsletter_form.fill_email("newsletter.auto@example.com")
    newsletter_form.check_consent() # Explicitly check consent
    newsletter_form.submit()
    newsletter_form.expect_success_message()

def test_newsletter_signup_invalid_email(page, base_url):
    """Verify validation for invalid email during newsletter signup."""
    page.goto(base_url)
    newsletter_form = NewsletterForm(page)
    newsletter_form.fill_email("invalid-newsletter-email")
    newsletter_form.check_consent() # Assume consent is checked if present
    newsletter_form.submit()
    newsletter_form.expect_error_message("Please enter a valid email address.") # Adjust message if different

def test_newsletter_signup_missing_email(page, base_url):
    """Verify validation for missing email during newsletter signup."""
    page.goto(base_url)
    newsletter_form = NewsletterForm(page)
    newsletter_form.fill_email("") # Leave empty
    newsletter_form.check_consent() # Assume consent is checked if present
    newsletter_form.submit()
    newsletter_form.expect_error_message("This field is required.") # Adjust message if different
```

#### `tests/ui/test_cookies.py`
```python
import pytest
from pages.cookie_banner import CookieBanner
from playwright.sync_api import expect

def test_cookie_consent_banner_display_and_accept_all(page, base_url):
    """Verify cookie banner displays on first visit and 'Accept All' works."""
    cookie_banner = CookieBanner(page)
    page.goto(base_url)
    cookie_banner.expect_banner_visible()
    cookie_banner.accept_all()
    cookie_banner.expect_banner_hidden()

    # Verify a cookie is set to remember preference
    consent_cookie = cookie_banner.get_cookie_value("cookie_consent_status") # Assuming cookie name
    assert consent_cookie == "accepted", "Cookie consent status not correctly set to 'accepted'"

def test_cookie_consent_manage_preferences_and_save(page, base_url):
    """Verify 'Manage Preferences' allows toggling and saving specific cookie categories."""
    cookie_banner = CookieBanner(page)
    page.goto(base_url)
    cookie_banner.expect_banner_visible()

    cookie_banner.open_manage_preferences()
    cookie_banner.toggle_analytics_cookies(False) # Disable analytics
    cookie_banner.toggle_marketing_cookies(True) # Ensure marketing is enabled

    cookie_banner.save_preferences()
    cookie_banner.expect_banner_hidden()

    # Verify cookie preference is stored (e.g., in a single preference cookie or multiple)
    # This might require checking specific cookies or a combined preference cookie value
    consent_cookie = cookie_banner.get_cookie_value("cookie_consent_status")
    # Example assertion: depends on actual implementation.
    # Could be 'analytics=false&marketing=true' or 'custom_preferences'
    assert "analytics=false" in consent_cookie or "marketing=true" in consent_cookie

def test_cookie_consent_preferences_remembered(page, base_url):
    """Verify that cookie consent preferences are remembered across visits."""
    cookie_banner = CookieBanner(page)

    # First visit: Accept all cookies
    page.goto(base_url)
    cookie_banner.expect_banner_visible()
    cookie_banner.accept_all()
    cookie_banner.expect_banner_hidden()

    # Second visit: Ensure banner does not reappear
    page.reload() # Or navigate to another page
    cookie_banner.expect_banner_hidden()

    # Clean up (optional, depends on test isolation)
    page.context.clear_cookies()
    page.goto("about:blank") # Ensure cookies are cleared before next test
```

### 3.5. API Automation Tests (`tests/api/`)

#### `tests/api/test_api_products.py`
```python
import pytest
import requests

def test_get_all_products(api_base_url):
    """Verify GET /api/products returns a list of products."""
    response = requests.get(f"{api_base_url}/products")
    assert response.status_code == 200
    products = response.json()
    assert isinstance(products, list)
    assert len(products) > 0
    for product in products:
        assert "id" in product
        assert "name" in product
        assert "brief_description" in product
        assert "url" in product

def test_get_single_product_success(api_base_url):
    """Verify GET /api/products/{productId} returns detailed product info."""
    # First, get a product ID from the list endpoint
    products_response = requests.get(f"{api_base_url}/products")
    product_id = products_response.json()[0]["id"] # Get first product ID

    response = requests.get(f"{api_base_url}/products/{product_id}")
    assert response.status_code == 200
    product_detail = response.json()
    assert product_detail["id"] == product_id
    assert "name" in product_detail
    assert "detailed_description" in product_detail
    assert "medical_information" in product_detail
    assert "pi_pdf_url" in product_detail
    assert product_detail["pi_pdf_url"].startswith("https://")
    assert ".pdf" in product_detail["pi_pdf_url"]

def test_get_single_product_not_found(api_base_url):
    """Verify GET /api/products/{productId} returns 404 for non-existent ID."""
    non_existent_id = "00000000-0000-0000-0000-000000000000" # A valid UUID format but non-existent
    response = requests.get(f"{api_base_url}/products/{non_existent_id}")
    assert response.status_code == 404
    assert "detail" in response.json()
    assert "Product not found" in response.json()["detail"] # Adjust message if different
```

#### `tests/api/test_api_forms.py`
```python
import pytest
import requests
import time

def test_post_contact_form_success(api_base_url):
    """Verify POST /api/contact for successful submission."""
    payload = {
        "name": "API Test User",
        "email": "api.test@example.com",
        "subject": "API Inquiry",
        "message": "This is an automated API test message."
    }
    response = requests.post(f"{api_base_url}/contact", json=payload)
    assert response.status_code == 200
    assert response.json()["message"] == "Inquiry submitted successfully."

def test_post_contact_form_validation_errors(api_base_url):
    """Verify POST /api/contact returns 400 for invalid data."""
    # Test missing fields
    payload_missing_name = {
        "email": "test@example.com",
        "subject": "Missing Name",
        "message": "Test"
    }
    response = requests.post(f"{api_base_url}/contact", json=payload_missing_name)
    assert response.status_code == 400
    assert any("field required" in err["msg"] for err in response.json()["detail"])

    # Test invalid email
    payload_invalid_email = {
        "name": "Test",
        "email": "invalid-email",
        "subject": "Invalid Email",
        "message": "Test"
    }
    response = requests.post(f"{api_base_url}/contact", json=payload_invalid_email)
    assert response.status_code == 400
    assert any("invalid email format" in err["msg"] for err in response.json()["detail"])

def test_post_newsletter_success(api_base_url):
    """Verify POST /api/newsletter for successful subscription with consent."""
    unique_email = f"newsletter.api.{int(time.time())}@example.com"
    payload = {
        "email": unique_email,
        "consent_given": True
    }
    response = requests.post(f"{api_base_url}/newsletter", json=payload)
    assert response.status_code == 200
    assert response.json()["message"] == "Subscribed successfully."

def test_post_newsletter_validation_errors(api_base_url):
    """Verify POST /api/newsletter returns 400 for invalid data."""
    # Test missing email
    payload_missing_email = {
        "consent_given": True
    }
    response = requests.post(f"{api_base_url}/newsletter", json=payload_missing_email)
    assert response.status_code == 400
    assert any("field required" in err["msg"] for err in response.json()["detail"])

    # Test invalid email
    payload_invalid_email = {
        "email": "invalid-newsletter",
        "consent_given": True
    }
    response = requests.post(f"{api_base_url}/newsletter", json=payload_invalid_email)
    assert response.status_code == 400
    assert any("invalid email format" in err["msg"] for err in response.json()["detail"])

    # Test missing consent (if required by backend logic)
    payload_missing_consent = {
        "email": "test@example.com"
    }
    response = requests.post(f"{api_base_url}/newsletter", json=payload_missing_consent)
    assert response.status_code == 400
    assert any("field required" in err["msg"] for err in response.json()["detail"])

    # Test false consent
    payload_false_consent = {
        "email": "test@example.com",
        "consent_given": False
    }
    response = requests.post(f"{api_base_url}/newsletter", json=payload_false_consent)
    assert response.status_code == 400
    assert any("consent must be given" in err["msg"] for err in response.json()["detail"])


def test_post_newsletter_duplicate_email(api_base_url):
    """Verify POST /api/newsletter returns 400 for duplicate email."""
    duplicate_email = f"duplicate.{int(time.time())}@example.com"
    payload = {
        "email": duplicate_email,
        "consent_given": True
    }
    # First successful submission
    response1 = requests.post(f"{api_base_url}/newsletter", json=payload)
    assert response1.status_code == 200

    # Second submission with same email
    response2 = requests.post(f"{api_base_url}/newsletter", json=payload)
    assert response2.status_code == 400
    assert "Email already subscribed." in response2.json()["detail"] # Adjust message if different

# Note: Rate limiting tests would require more complex setup, e.g., using a test proxy
# or mocking the rate limiting mechanism if it's external (WAF).
# For API-level testing within the application, you'd send many requests rapidly.
def test_api_rate_limiting_contact(api_base_url):
    """
    Conceptual test for API rate limiting on contact form.
    Requires server-side rate limiting to be active and configured for a low threshold for testing.
    """
    payload = {
        "name": "Rate Limit Test",
        "email": "rate.limit@example.com",
        "subject": "Rate Limit Check",
        "message": "Testing rate limiting."
    }
    # Send requests until rate limit is hit
    # The actual number depends on the rate limit configuration
    for i in range(10): # Assuming a low rate limit for testing purposes
        response = requests.post(f"{api_base_url}/contact", json=payload)
        if response.status_code == 429:
            assert "Too Many Requests" in response.text
            return # Test passed if 429 is received
        time.sleep(0.1) # Small delay to avoid overwhelming the server too quickly if limit is high
    pytest.fail("Rate limit (429) was not hit after multiple requests.")

def test_api_rate_limiting_newsletter(api_base_url):
    """
    Conceptual test for API rate limiting on newsletter signup.
    Requires server-side rate limiting to be active.
    """
    # Similar to contact form rate limiting test, adapt payload and expected behavior.
    payload = {
        "email": f"ratelimit.{int(time.time())}@example.com",
        "consent_given": True
    }
    for i in range(10):
        response = requests.post(f"{api_base_url}/newsletter", json=payload)
        if response.status_code == 429:
            assert "Too Many Requests" in response.text
            return
        time.sleep(0.1)
    pytest.fail("Rate limit (429) was not hit after multiple requests.")

```