# High-Level Design (HLD) Document: PharmaCorp Commercial Website

## 1. Introduction

This document provides a high-level design for the PharmaCorp commercial website, outlining the system architecture, data models, API endpoints, and key technical considerations based on the provided user stories and technical constraints. The goal is to create a secure, performant, accessible, and compliant platform for displaying product information, engaging with visitors, and managing corporate communications.

## 2. Overall Architecture

The system will follow a modern, cloud-native, client-server architecture, leveraging a clear separation between the frontend and backend. Static assets will be served efficiently via a Content Delivery Network (CDN), while dynamic content and interactive features will be powered by a Python-based API backend interacting with a PostgreSQL database and object storage.

### 2.1. Architectural Style

**Layered Client-Server Architecture with API-driven Backend:**

*   **Frontend Layer:** A responsive web application built with HTML5 and JavaScript, deployed as static assets.
*   **API Layer:** A Python (FastAPI) application providing secure RESTful APIs for data retrieval and form submissions.
*   **Data Layer:** PostgreSQL for structured data and Object Storage for binary assets (PDFs).
*   **Infrastructure Layer:** Cloud services for hosting, networking, and security, managed via a robust CI/CD pipeline.

### 2.2. Components

```mermaid
graph TD
    subgraph Client
        A[Site Visitor (Browser)]
    end

    subgraph Edge Services
        B[CDN / WAF]
    end

    subgraph Frontend Deployment
        C[Static Web Hosting (HTML, CSS, JS)]
    end

    subgraph Backend Services
        D[Load Balancer]
        E[API Gateway (Optional, for advanced routing/auth)]
        F[Backend API (Python FastAPI)]
    end

    subgraph Data Stores
        G[PostgreSQL Database]
        H[Object Storage (e.g., S3-compatible)]
    end

    subgraph DevOps
        I[CI/CD Pipeline]
        J[Version Control System]
        K[Monitoring & Logging]
    end

    A -- HTTP/S --> B
    B -- Static Assets --> C
    B -- API Requests --> D
    D -- API Requests --> E
    E -- API Requests --> F
    F -- Reads/Writes --> G
    F -- Generates Signed URL --> H
    H -- Direct Download URL --> B
    B -- PDF Download --> A

    J -- Code Push --> I
    I -- Deploys Frontend --> C
    I -- Builds & Deploys Backend --> F

    F -- Emits Logs/Metrics --> K
    C -- Emits Logs/Metrics --> K
    G -- Emits Logs/Metrics --> K
```

**Description of Components:**

*   **Site Visitor (Browser):** End-user accessing the website from various devices (desktop, tablet, mobile).
*   **CDN / WAF:**
    *   **Content Delivery Network (CDN):** Caches and serves static frontend assets (HTML, CSS, JS, optimized images) globally, reducing latency and improving LCP scores. Also serves PI PDFs directly from object storage via secure, time-limited URLs.
    *   **Web Application Firewall (WAF):** Provides protection against common web attacks (e.g., SQL injection, XSS), rate limiting, and DDoS mitigation.
*   **Static Web Hosting:** Stores and serves the compiled, minified, and bundled frontend application.
*   **Load Balancer:** Distributes incoming API traffic across multiple instances of the Backend API for high availability and scalability.
*   **API Gateway (Optional but Recommended):** Provides centralized management for APIs, including authentication, rate limiting, and request/response transformations. For this HLD, we'll assume basic rate limiting is handled within FastAPI or WAF.
*   **Backend API (Python FastAPI):**
    *   Implements the business logic for product retrieval, form submissions, and search.
    *   Handles server-side input validation and data persistence.
    *   Generates secure, pre-signed URLs for direct PDF downloads from Object Storage.
    *   Exposes secure RESTful endpoints.
*   **PostgreSQL Database:** Relational database for storing structured data such as product information, contact inquiries, newsletter subscriptions, and searchable content.
*   **Object Storage:** Stores binary large objects (BLOBs) like Prescribing Information (PI) PDFs, offering high availability, scalability, and cost-effectiveness.
*   **CI/CD Pipeline:** Automates the build, test, and deployment processes for both frontend and backend applications across Dev, Staging, and Production environments.
*   **Version Control System (e.g., Git):** Manages all source code.
*   **Monitoring & Logging:** Centralized system for collecting logs, metrics, and traces from all components to ensure operational visibility and troubleshoot issues.

### 2.3. Data Flow Example (Product Detail Page)

```mermaid
sequenceDiagram
    participant A as Site Visitor
    participant B as CDN/WAF
    participant C as Static Web Hosting
    participant F as Backend API (FastAPI)
    participant G as PostgreSQL
    participant H as Object Storage

    A->>B: Request /products/{productId} (HTML/JS)
    B->>C: Retrieve index.html & JS bundle
    C-->>B: index.html & JS bundle
    B-->>A: Serve index.html & JS bundle
    A->>F: API Request GET /api/products/{productId}
    F->>G: Query product details from PostgreSQL
    G-->>F: Product details
    F->>H: Generate secure, time-limited URL for PI PDF
    H-->>F: PI PDF Signed URL
    F-->>A: Product details (JSON) with PI PDF Signed URL
    A->>A: Render Product Detail Page
    A->>B: User clicks "Download PI PDF" -> Request PI PDF from CDN (using signed URL)
    B->>H: Validate Signed URL and Retrieve PI PDF
    H-->>B: PI PDF
    B-->>A: Serve PI PDF (Download)
```

## 3. Data Models and Database Schema

The following tables will be created in PostgreSQL to store the application's data. UUIDs are used for primary keys to ensure global uniqueness.

### 3.1. `products` Table

Stores information about PharmaCorp's products.

| Field Name           | Data Type             | Constraints                                  | Description                                     |
| :------------------- | :-------------------- | :------------------------------------------- | :---------------------------------------------- |
| `id`                 | `UUID`                | `PRIMARY KEY`, `NOT NULL`, `DEFAULT gen_random_uuid()` | Unique identifier for the product.              |
| `name`               | `VARCHAR(255)`        | `NOT NULL`, `UNIQUE`                         | Name of the product.                            |
| `slug`               | `VARCHAR(255)`        | `NOT NULL`, `UNIQUE`                         | URL-friendly identifier for the product page.   |
| `brief_description`  | `TEXT`                | `NOT NULL`                                   | Short description for product list.             |
| `detailed_description` | `TEXT`                | `NOT NULL`                                   | Comprehensive description for product detail.   |
| `medical_information` | `TEXT`                | `NOT NULL`                                   | Specific medical details.                       |
| `pi_pdf_object_key` | `VARCHAR(2048)`       | `NOT NULL`                                   | Key/path to the PI PDF in object storage.       |
| `is_active`          | `BOOLEAN`             | `NOT NULL`, `DEFAULT TRUE`                   | Indicates if the product is currently active.   |
| `created_at`         | `TIMESTAMPTZ`         | `NOT NULL`, `DEFAULT NOW()`                  | Timestamp of creation.                          |
| `updated_at`         | `TIMESTAMPTZ`         | `NOT NULL`, `DEFAULT NOW()`                  | Timestamp of last update.                       |

### 3.2. `contact_inquiries` Table

Stores submissions from the contact form.

| Field Name       | Data Type             | Constraints                                  | Description                                     |
| :--------------- | :-------------------- | :------------------------------------------- | :---------------------------------------------- |
| `id`             | `UUID`                | `PRIMARY KEY`, `NOT NULL`, `DEFAULT gen_random_uuid()` | Unique identifier for the inquiry.              |
| `name`           | `VARCHAR(255)`        | `NOT NULL`                                   | Name of the inquirer.                           |
| `email`          | `VARCHAR(255)`        | `NOT NULL`                                   | Email address of the inquirer.                  |
| `subject`        | `VARCHAR(500)`        | `NOT NULL`                                   | Subject of the inquiry.                         |
| `message`        | `TEXT`                | `NOT NULL`                                   | Full message content.                           |
| `submitted_at`   | `TIMESTAMPTZ`         | `NOT NULL`, `DEFAULT NOW()`                  | Timestamp of submission.                        |
| `ip_address`     | `INET`                | `NULL` (for GDPR compliance)                 | IP address of the submitter (collected for rate limiting, anonymized/removed if not strictly necessary). |

### 3.3. `newsletter_subscribers` Table

Stores email addresses for newsletter subscriptions.

| Field Name         | Data Type             | Constraints                                  | Description                                     |
| :----------------- | :-------------------- | :------------------------------------------- | :---------------------------------------------- |
| `id`               | `UUID`                | `PRIMARY KEY`, `NOT NULL`, `DEFAULT gen_random_uuid()` | Unique identifier for the subscriber.           |
| `email`            | `VARCHAR(255)`        | `NOT NULL`, `UNIQUE`                         | Subscriber's email address.                     |
| `subscribed_at`    | `TIMESTAMPTZ`         | `NOT NULL`, `DEFAULT NOW()`                  | Timestamp of subscription.                      |
| `is_active`        | `BOOLEAN`             | `NOT NULL`, `DEFAULT TRUE`                   | Indicates if the subscription is active (for opt-out). |
| `consent_given_at` | `TIMESTAMPTZ`         | `NOT NULL`                                   | Timestamp when explicit consent was given (GDPR/CCPA). |

### 3.4. `content_pages` Table

This table stores content for core informational pages and serves as a source for the website's search functionality.

| Field Name         | Data Type             | Constraints                                  | Description                                     |
| :----------------- | :-------------------- | :------------------------------------------- | :---------------------------------------------- |
| `id`               | `UUID`                | `PRIMARY KEY`, `NOT NULL`, `DEFAULT gen_random_uuid()` | Unique identifier for the content item.         |
| `slug`             | `VARCHAR(255)`        | `UNIQUE`, `NOT NULL`                         | URL-friendly identifier (e.g., 'about-us').     |
| `title`            | `VARCHAR(500)`        | `NOT NULL`                                   | Title of the page/content.                      |
| `content`          | `TEXT`                | `NOT NULL`                                   | Full text content of the page.                  |
| `url`              | `VARCHAR(2048)`       | `NOT NULL`                                   | Relative URL to the content.                    |
| `last_modified_at` | `TIMESTAMPTZ`         | `NOT NULL`, `DEFAULT NOW()`                  | Timestamp of last modification.                 |

## 4. API Endpoints

The Backend API (FastAPI) will expose RESTful endpoints for interacting with the website's dynamic features. All endpoints will be served over HTTPS.

### 4.1. Product Endpoints

*   **`GET /api/products`**
    *   **Description:** Retrieves a list of all active PharmaCorp products.
    *   **Authentication:** None (public access).
    *   **Rate Limiting:** Applied.
    *   **Response (200 OK):**
        ```json
        [
            {
                "id": "a1b2c3d4-e5f6-7890-1234-567890abcdef",
                "name": "Product Alpha",
                "brief_description": "A brief overview of Product Alpha, designed for general understanding.",
                "url": "/products/product-alpha"
            },
            {
                "id": "b2c3d4e5-f6a7-8901-2345-67890abcdef0",
                "name": "Product Beta",
                "brief_description": "Discover Product Beta, a new solution for common ailments.",
                "url": "/products/product-beta"
            }
        ]
        ```
*   **`GET /api/products/{productId}`**
    *   **Description:** Retrieves detailed information for a specific product, including a secure, time-limited URL for its PI PDF.
    *   **Authentication:** None (public access).
    *   **Rate Limiting:** Applied.
    *   **Path Parameters:**
        *   `productId` (string, UUID): The unique identifier of the product.
    *   **Response (200 OK):**
        ```json
        {
            "id": "a1b2c3d4-e5f6-7890-1234-567890abcdef",
            "name": "Product Alpha",
            "detailed_description": "This is a comprehensive description of Product Alpha, including its uses, benefits, and target audience...",
            "medical_information": "Detailed medical information, contraindications, and potential side effects...",
            "pi_pdf_url": "https://cdn.example.com/signed-url/product-alpha-pi.pdf?expires=...",
            "last_updated": "2023-10-27T10:00:00Z"
        }
        ```
    *   **Response (404 Not Found):** If `productId` does not exist.

### 4.2. Contact Form Endpoint

*   **`POST /api/contact`**
    *   **Description:** Submits a contact inquiry.
    *   **Authentication:** None (public access).
    *   **Rate Limiting:** Applied to prevent abuse.
    *   **Request Body (application/json):**
        ```json
        {
            "name": "Jane Doe",
            "email": "jane.doe@example.com",
            "subject": "General Inquiry",
            "message": "I have a question about your products."
        }
        ```
    *   **Validation:** Server-side validation for all fields (e.g., email format, required fields, message length).
    *   **Response (200 OK):**
        ```json
        {
            "message": "Inquiry submitted successfully."
        }
        ```
    *   **Response (400 Bad Request):** If validation fails.
        ```json
        {
            "detail": [
                {
                    "loc": ["body", "email"],
                    "msg": "invalid email format",
                    "type": "value_error.email"
                }
            ]
        }
        ```

### 4.3. Newsletter Subscription Endpoint

*   **`POST /api/newsletter`**
    *   **Description:** Subscribes an email address to the newsletter.
    *   **Authentication:** None (public access).
    *   **Rate Limiting:** Applied.
    *   **Request Body (application/json):**
        ```json
        {
            "email": "subscriber@example.com",
            "consent_given": true
        }
        ```
    *   **Validation:** Server-side validation for email format and `consent_given` (must be `true`).
    *   **Response (200 OK):**
        ```json
        {
            "message": "Subscribed successfully."
        }
        ```
    *   **Response (400 Bad Request):** If validation fails or email already subscribed.
        ```json
        {
            "detail": "Email already subscribed."
        }
        ```

### 4.4. Search Endpoint

*   **`GET /api/search`**
    *   **Description:** Searches website content and products.
    *   **Authentication:** None (public access).
    *   **Rate Limiting:** Applied.
    *   **Query Parameters:**
        *   `q` (string, required): The search query.
    *   **Response (200 OK):**
        ```json
        [
            {
                "title": "Product Alpha - Detailed Information",
                "excerpt": "Learn more about Product Alpha, including its uses and benefits...",
                "url": "/products/product-alpha"
            },
            {
                "title": "About Us",
                "excerpt": "PharmaCorp is a leading pharmaceutical company dedicated to...",
                "url": "/about-us"
            }
        ]
        ```
    *   **Implementation Note:** The backend will query the `products` table (name, brief_description, detailed_description, medical_information) and the `content_pages` table (title, content) for relevant matches. PostgreSQL's built-in Full-Text Search (FTS) capabilities will be leveraged for efficient and relevant search results.

## 5. Security Considerations

*   **HTTPS Everywhere:** All communication will be encrypted using TLS/SSL. The CDN/WAF will handle SSL termination and certificate management.
*   **Content Security Policy (CSP):** Implemented in the frontend (via HTTP headers) to mitigate XSS attacks by restricting sources of content (scripts, styles, images, etc.).
*   **Server-Side Input Validation:** All API endpoints receiving user input will rigorously validate and sanitize data to prevent injection attacks (SQL, XSS) and ensure data integrity.
*   **Rate Limiting:** Applied to all API endpoints handling user submissions (contact, newsletter, search) to prevent abuse and brute-force attacks. This can be implemented at the WAF/API Gateway level or within the FastAPI application.
*   **OWASP Top 10:** Adherence to OWASP Top 10 security best practices, including secure coding guidelines, dependency scanning, and regular security audits.
*   **Least Privilege:** Database users and API service accounts will be configured with the minimum necessary permissions.
*   **Secrets Management:** Sensitive configurations (database credentials, API keys for object storage, etc.) will be stored securely using environment variables and a dedicated secrets management service (e.g., AWS Secrets Manager, Azure Key Vault, HashiCorp Vault) and never hardcoded or committed to version control.
*   **Secure PDF Downloads:** PI PDFs will be served from object storage via secure, time-limited pre-signed URLs generated by the backend, ensuring controlled access.

## 6. Performance Optimization

*   **CDN for Static Assets:** Ensures low latency delivery of HTML, CSS, JavaScript, optimized images, and PDFs globally.
*   **Image Optimization:** All images will be compressed, resized, and served in modern formats (e.g., WebP) to reduce load times. Responsive image techniques (e.g., `srcset`) will be used.
*   **Frontend Asset Optimization:** JavaScript and CSS files will be minified, bundled, and tree-shaken during the build process to reduce payload size.
*   **Server-Side Caching:** The CDN and/or a reverse proxy (e.g., Nginx) will cache API responses for frequently accessed, non-dynamic data (e.g., product list, content pages) to reduce load on the backend and database.
*   **Database Indexing:** Appropriate indexes will be created on PostgreSQL tables to optimize query performance for common lookups and search operations.
*   **LCP < 2.5 seconds:** Continuous monitoring (e.g., using Lighthouse, Web Vitals) and optimization efforts will focus on achieving and maintaining this target for all primary pages.

## 7. Accessibility (WCAG 2.2 AA)

*   **Semantic HTML:** Use of appropriate HTML5 elements to convey meaning and structure.
*   **Keyboard Navigation:** All interactive elements (links, buttons, forms, sticky ISI) will be fully navigable and operable via keyboard, with clear focus indicators.
*   **Color Contrast:** Ensuring sufficient contrast ratios for text and interactive elements.
*   **ARIA Attributes:** Strategic use of ARIA (Accessible Rich Internet Applications) attributes to enhance semantics and provide context for assistive technologies.
*   **Alternative Text:** Providing descriptive `alt` text for all meaningful images.
*   **Form Accessibility:** Clear labels, error messages, and validation feedback accessible to screen readers and visually presented clearly.
*   **Responsive Design:** Ensures content reflows and remains usable across various screen sizes without obscuring critical information (e.g., sticky ISI).
*   **Testing:** Regular testing with common screen readers (NVDA, JAWS, VoiceOver) and automated accessibility tools (e.g., Axe Core) will be performed.

## 8. Data Privacy Compliance (GDPR/CCPA)

*   **Cookie Consent Management:** A prominent, WCAG 2.2 AA compliant cookie consent banner will be displayed on the first visit, allowing users to "Accept All", "Reject All", or "Manage Preferences" for non-essential cookies. Preferences will be stored in a client-side cookie and respected for subsequent visits.
*   **Privacy Policy:** A comprehensive and easily accessible Privacy Policy page detailing data collection, usage, storage, and user rights (access, rectification, erasure, portability).
*   **Explicit Consent:** All forms collecting personal data (Contact, Newsletter) will include clear statements about data usage and, where legally required (e.g., for newsletter), explicit opt-in consent checkboxes.
*   **Data Minimization:** Only necessary personal data will be collected and processed.
*   **Data Subject Rights:** Mechanisms for users to exercise their rights (e.g., a specific contact form or email address for data access/deletion requests) will be clearly outlined in the Privacy Policy.

## 9. CI/CD Pipeline & Deployment

A robust CI/CD pipeline is critical for efficient, reliable, and consistent deployments across environments.

```mermaid
graph TD
    subgraph Developer Workflow
        A[Developer] -- Code Changes --> B(Version Control System - Git)
    end

    subgraph CI/CD Pipeline
        B -- Push to 'develop' --> C{CI Trigger (Webhook)}
        C --> D[Build Frontend & Backend]
        D --> E[Run Unit & Integration Tests]
        E -- Success --> F[Create Docker Images (Backend) & Frontend Artifacts]
        F -- Deploy to Dev --> G[Dev Environment]

        B -- Merge 'develop' to 'main' --> H{CI Trigger (Webhook)}
        H --> I[Build Frontend & Backend]
        I --> J[Run Unit & Integration Tests]
        J -- Success --> K[Create Docker Images (Backend) & Frontend Artifacts]
        K -- Deploy to Staging --> L[Staging Environment]

        L -- Manual Approval --> M{Production Deployment Trigger}
        M --> N[Deploy to Production]
        N --> O[Production Environment]
    end

    subgraph Monitoring
        P[Monitoring & Alerts]
    end

    G -- Functional Tests --> P
    L -- QA & UAT --> P
    O -- Live Monitoring --> P
```

**Pipeline Steps:**

1.  **Version Control (Git):** All source code is managed in a Git repository with designated branches (e.g., `develop` for features, `main` for stable releases).
2.  **CI Trigger:** Pushes to `develop` or merges to `main` (or equivalent) automatically trigger the CI/CD pipeline.
3.  **Build:**
    *   **Frontend:** A Node.js-based build process (e.g., Webpack, Vite) compiles, minifies, bundles JavaScript/CSS, optimizes images, and generates static HTML files.
    *   **Backend:** Python application dependencies are installed, code linted, and a production-ready Docker image is built.
4.  **Test:**
    *   **Unit Tests:** Executed for individual functions/components (frontend and backend).
    *   **Integration Tests:** Verify interactions between components (e.g., API endpoints with database).
    *   **Accessibility Tests:** Automated checks for WCAG compliance.
    *   **Security Scans:** Static Application Security Testing (SAST) on code and dependency vulnerability scanning.
5.  **Artifact Creation:**
    *   **Frontend:** A compressed archive (`.zip`, `.tar.gz`) containing static assets ready for deployment.
    *   **Backend:** A versioned Docker image containing the FastAPI application and its dependencies, pushed to a container registry.
6.  **Deployment:**
    *   **Dev Environment:** Automated deployment of frontend artifacts to static web hosting and backend Docker images to a container orchestration platform (e.g., Kubernetes, ECS, App Service). Used for developer testing.
    *   **Staging Environment:** Automated deployment upon successful merge to `main` (or equivalent). This environment is identical to Production and is used for QA, User Acceptance Testing (UAT), and final functional/performance testing.
    *   **Production Environment:** Requires a **manual approval step** from the Staging environment. This ensures that all changes have been thoroughly vetted before reaching live users.
7.  **Rollback:** Versioned Docker images and static frontend artifacts enable quick and reliable rollbacks to previous stable versions if issues arise in production.
8.  **Monitoring & Logging:** Integrated throughout the pipeline and post-deployment to provide real-time feedback on deployment status, application health, and performance metrics.