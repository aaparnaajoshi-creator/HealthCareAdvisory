# PharmaCorp Commercial Website - Test Strategy & Plan

## 1. Introduction

### 1.1. Purpose
This document outlines the comprehensive testing strategy, plan, and test cases for the new PharmaCorp Commercial Website. The goal is to ensure the website meets all functional, non-functional, and business requirements as defined in the System Requirements Specification (SRS) and High-Level Design (HLD).

This document will guide the QA team in performing structured testing activities, from manual validation to the implementation of an automated regression suite, ensuring a high-quality, compliant, and reliable product is delivered.

### 1.2. Project Overview
The PharmaCorp Commercial Website is a public-facing informational platform for patients and Healthcare Professionals (HCPs). It will provide information about the company, its products, and offer channels for user engagement. The system is built on a Python (FastAPI) backend with a PostgreSQL database, serving server-rendered HTML5 and vanilla JavaScript to the client. Key priorities include performance, security, accessibility (WCAG 2.2 AA), and regulatory compliance.

---

## 2. Test Strategy

### 2.1. Quality Objectives
*   **Functionality:** Ensure all user stories are implemented correctly and all features function as per the acceptance criteria.
*   **Usability & Accessibility:** Verify the website is intuitive, easy to navigate, and compliant with WCAG 2.2 Level AA standards.
*   **Performance:** Confirm the website meets the performance targets for Core Web Vitals (LCP < 2.5s).
*   **Security:** Validate that the application is secure against common web vulnerabilities (XSS, CSRF), user data is handled securely, and API endpoints are protected.
*   **Compatibility:** Ensure a consistent and functional user experience across major web browsers and device types (desktop, tablet, mobile).
*   **Reliability:** Ensure the website is stable and operates without critical defects in the production environment.

### 2.2. Scope of Testing

#### 2.2.1. In Scope
*   **End-to-End Functional Testing:** All user stories (PCW-001 to PCW-016) will be tested.
*   **API Testing:** Direct testing of the `/api/contact` and `/api/newsletter` endpoints for functionality, validation, and security.
*   **UI & Responsive Testing:** Verification of the website's layout and functionality on different screen resolutions (mobile, tablet, desktop).
*   **Accessibility Testing:** Auditing the site against WCAG 2.2 Level AA guidelines.
*   **Performance Testing:** Baseline performance metrics collection using browser-based tools.
*   **Security Testing:** Verification of security measures outlined in the HLD, including rate limiting and Content Security Policy (CSP) headers.
*   **Browser Compatibility Testing:** Testing on the latest versions of Chrome, Firefox, Safari, and Edge.

#### 2.2.2. Out of Scope
*   Underlying infrastructure testing (e.g., cloud provider uptime, database server performance).
*   Third-party service testing (e.g., the internal functionality of the email delivery service for newsletters).
*   Load and Stress Testing (can be considered for a future phase if required).
*   Formal User Acceptance Testing (UAT) by business stakeholders, though the QA team will support this activity.

### 2.3. Testing Levels & Types

| Testing Level/Type | Approach |
| :--- | :--- |
| **Unit Testing** | Performed by developers to verify individual functions and components in the FastAPI backend. |
| **Integration Testing** | Performed by developers and QA to test interactions between the FastAPI application, PostgreSQL database, and Object Storage. |
| **System (E2E) Testing** | The primary focus of this plan. Performed by the QA team on the fully integrated application in the Staging environment to validate complete user flows. |
| **Functional Testing** | Manual and automated tests to verify the features described in the user stories. |
| **API Testing** | Using tools like Postman or automated scripts to test API endpoints directly. |
| **UI & Visual Testing** | Manual checks for layout, styling, and consistency. Automated visual regression testing may be considered for future phases. |
| **Performance Testing** | Using Google Lighthouse and WebPageTest to measure Core Web Vitals and identify performance bottlenecks. |
| **Accessibility Testing** | A combination of automated tools (Axe DevTools) and manual testing (keyboard navigation, screen reader checks). |
| **Security Testing** | Manual and automated checks for specified security requirements (e.g., header validation, API rate limiting). |
| **Regression Testing** | Executing a suite of automated tests before each release to ensure new changes have not broken existing functionality. |

---

## 3. Test Environment & Tools

### 3.1. Test Environments
*   **Development:** Used by developers for unit and initial integration testing.
*   **Staging:** A production-like environment where all formal QA activities (manual and automated) will be conducted. This environment is the target for the CI/CD pipeline before production deployment.
*   **Production:** The live environment. Smoke tests will be performed here post-deployment.

### 3.2. Tools
| Tool Category | Tool Selection |
| :--- | :--- |
| **Test Case Management** | Jira with a test management plugin (e.g., Zephyr, Xray) |
| **Defect Tracking** | Jira |
| **UI Automation** | Python with Playwright and Pytest |
| **API Testing** | Postman (for exploratory testing), Python `requests` library (for automation) |
| **Performance Tools** | Google Lighthouse (via Chrome DevTools), WebPageTest |
| **Accessibility Tools** | Axe DevTools (browser extension), Lighthouse Accessibility Audit |
| **Version Control** | Git (via GitHub/GitLab) |
| **CI/CD** | GitHub Actions (as per HLD) |

---

## 4. Test Execution & Reporting

### 4.1. Entry & Exit Criteria
*   **Entry Criteria (Start of Test Cycle):**
    *   The build is successfully deployed to the Staging environment.
    *   All relevant user stories are marked as "Ready for QA".
    *   Unit and integration tests have passed in the CI pipeline.
*   **Exit Criteria (End of Test Cycle):**
    *   All planned test cases have been executed.
    *   100% of Critical and High severity defects are closed.
    *   No known open defects that would block a key user flow.
    *   The automated regression suite passes with >95% success rate.

### 4.2. Defect Management
Defects will be logged in Jira with the following details:
*   **Title:** Clear and concise summary.
*   **Description:** Detailed explanation of the issue.
*   **Steps to Reproduce:** Numbered list of steps to trigger the bug.
*   **Expected vs. Actual Results:** Clear comparison.
*   **Environment:** (e.g., Staging).
*   **Severity:** (Critical, High, Medium, Low).
*   **Attachments:** Screenshots, logs, or video recordings.

---

## 5. Manual Test Cases

### Epic: Core Website Structure & Pages

| Test ID | User Story | Test Title | Preconditions | Steps | Expected Results |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **TC-001** | PCW-001 | Verify Homepage Elements | Navigate to the website's root URL. | 1. Observe the hero section.<br>2. Look for CTAs.<br>3. Check for main navigation and footer.<br>4. Inspect images. | 1. A prominent hero section with a clear headline is visible.<br>2. CTAs for "Products" and "About Us" are present and clickable.<br>3. The header navigation and footer are displayed.<br>4. All images have descriptive `alt` attributes. |
| **TC-002** | PCW-002 | Verify About Us Page | On the homepage. | 1. Click the "About Us" link in the navigation.<br>2. Observe the page content. | 1. The page successfully navigates to the "About Us" page.<br>2. The browser tab/window title is "About Us".<br>3. Content about the company's mission and values is displayed.<br>4. The standard header and footer are present. |
| **TC-003** | PCW-003 | Verify Contact Us Page | On the homepage. | 1. Click the "Contact Us" link in the navigation.<br>2. Observe the page content. | 1. The page successfully navigates to the "Contact Us" page.<br>2. The company's physical address and phone number are displayed.<br>3. A link to the contact form is visible and clickable.<br>4. The standard header and footer are present. |
| **TC-004** | PCW-004 | Verify Consistent Navigation | Be on any page (e.g., Homepage). | 1. View the header.<br>2. Navigate to another page (e.g., "About Us").<br>3. View the header again. | 1. The header contains links to: Home, About Us, Products, Contact Us.<br>2. The header remains consistent across all pages. |
| **TC-005** | PCW-004 | Verify Consistent Footer | Be on any page (e.g., Homepage). | 1. Scroll to the bottom and view the footer.<br>2. Navigate to another page (e.g., "Products").<br>3. View the footer again. | 1. The footer contains links to: Privacy Policy, Terms of Use, Contact Us.<br>2. Copyright information is present.<br>3. The footer remains consistent across all pages. |

### Epic: Product Information Hub

| Test ID | User Story | Test Title | Preconditions | Steps | Expected Results |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **TC-006** | PCW-005 | Verify Product Listing Page | Navigate to the "Products" page. | 1. Observe the page content.<br>2. Click on a product list item. | 1. A list of products is displayed, each with a name and brief description.<br>2. Clicking a product navigates to its corresponding detail page. |
| **TC-007** | PCW-006 | Verify Product Detail Page | Navigate to a specific Product Detail Page. | 1. Observe the page content.<br>2. Look for the ISI section.<br>3. Look for the PI download link.<br>4. Check the URL in the address bar. | 1. The product name, description, and images are displayed.<br>2. The Important Safety Information (ISI) is clearly visible.<br>3. A link to download the Prescribing Information (PI) PDF is present.<br>4. The URL follows the format `/products/product-name`. |
| **TC-008** | PCW-007 | Verify Sticky ISI on Scroll | Navigate to a Product Detail Page with long content. | 1. Scroll down the page, past the initial position of the ISI section.<br>2. Scroll back up.<br>3. If applicable, click the expand/collapse control within the sticky ISI. | 1. The ISI section becomes "sticky" (fixed to the bottom or side of the viewport) and remains visible.<br>2. The sticky element does not obstruct main content.<br>3. The ISI content expands and collapses correctly. |
| **TC-009** | PCW-008 | Verify PI PDF Download | On a Product Detail Page. | 1. Hover over the "Download Prescribing Information" link.<br>2. Click the link. | 1. The link text clearly indicates it's a PDF download.<br>2. Clicking the link opens the PDF in a new browser tab or starts a download.<br>3. The URL of the PDF points to a secure object storage location. |

### Epic: User Engagement & Communication

| Test ID | User Story | Test Title | Preconditions | Steps | Expected Results |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **TC-010** | PCW-009 | Verify Contact Form - Successful Submission | Navigate to the Contact Us page. | 1. Fill in Name, Email (valid format), and Message fields.<br>2. Click "Submit". | 1. A success message like "Thank you for your message!" is displayed.<br>2. The form data is cleared. |
| **TC-011** | PCW-009 | Verify Contact Form - Invalid Submission | Navigate to the Contact Us page. | 1. Leave the Name field empty.<br>2. Enter an invalid email (e.g., "test@test").<br>3. Click "Submit". | 1. Inline error messages appear next to the invalid fields.<br>2. The form is not submitted. |
| **TC-012** | PCW-010 | Verify Newsletter Signup - Successful | Find the newsletter signup form (e.g., in the footer). | 1. Enter a valid email address.<br>2. Click "Sign Up". | 1. A success message confirming the subscription is displayed. |
| **TC-013** | PCW-010 | Verify Newsletter Signup - Invalid Email | Find the newsletter signup form. | 1. Enter an invalid email address (e.g., "invalid-email").<br>2. Click "Sign Up". | 1. An inline error message is displayed.<br>2. The form is not submitted. |
| **TC-014** | PCW-011 | Verify Site Search - With Results | Find the search bar in the navigation. | 1. Enter a search term that exists on the site (e.g., a product name).<br>2. Press Enter or click the search button. | 1. You are taken to a search results page.<br>2. A list of relevant pages is displayed, each with a clickable title and a content snippet. |
| **TC-015** | PCW-011 | Verify Site Search - No Results | Find the search bar. | 1. Enter a gibberish search term (e.g., "xyzqwerty").<br>2. Press Enter or click the search button. | 1. A message like "No results found" is displayed. |

### Epic: Compliance, Legal & NFRs

| Test ID | User Story | Test Title | Preconditions | Steps | Expected Results |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **TC-016** | PCW-012 | Verify Legal Pages Navigation | Be on any page. | 1. In the footer, click "Privacy Policy".<br>2. Go back. In the footer, click "Terms of Use". | 1. The Privacy Policy page loads with relevant legal text.<br>2. The Terms of Use page loads with relevant legal text. |
| **TC-017** | PCW-013 | Verify Cookie Consent Banner | Clear browser cookies and cache. Visit the site for the first time. | 1. Observe the page on load.<br>2. Click "Accept All".<br>3. Refresh the page or navigate to another page. | 1. A cookie consent banner is displayed.<br>2. The banner provides options like "Accept All", "Reject All".<br>3. After accepting, the banner does not reappear on subsequent page loads. |
| **TC-018** | PCW-014 | Verify Accessibility - Keyboard Navigation | On the homepage. | 1. Press the 'Tab' key repeatedly.<br>2. Press 'Shift+Tab' repeatedly. | 1. All interactive elements (links, buttons, form fields) are focusable in a logical order.<br>2. The currently focused element has a clear visual indicator (e.g., an outline).<br>3. Navigation works in reverse with Shift+Tab. |
| **TC-019** | PCW-014 | Verify Accessibility - Screen Reader Content | Use a screen reader tool (e.g., NVDA, VoiceOver). | 1. Navigate to a page with images (e.g., Homepage).<br>2. Navigate to the Contact Form. | 1. The screen reader announces the descriptive alt-text for images.<br>2. Each form field has an associated label that is read out. |
| **TC-020** | PCW-015 | Verify Website Performance | Use Chrome DevTools Lighthouse. | 1. Open DevTools on the homepage.<br>2. Go to the Lighthouse tab.<br>3. Run a "Performance" report. | 1. The Largest Contentful Paint (LCP) is under 2.5 seconds.<br>2. The site achieves a "Good" score for all Core Web Vitals. |
| **TC-021** | PCW-016 | Verify Responsive Design | Use Chrome DevTools Device Toolbar. | 1. View the homepage in a mobile viewport (e.g., 375px width).<br>2. View the homepage in a tablet viewport (e.g., 820px width). | 1. On mobile, the navigation collapses into a hamburger menu. Content is readable without horizontal scrolling.<br>2. On tablet, the layout adjusts appropriately, using the space effectively. |
| **TC-022** | PCW-009 | **[SECURITY]** Verify API Rate Limiting | Use an API client (e.g., Postman) or a script. | 1. Send 10+ valid POST requests to `/api/contact` in rapid succession (within a few seconds). | 1. The first few requests should receive a `201 Created` response.<br>2. Subsequent requests beyond the defined limit should receive a `429 Too Many Requests` error. |
| **TC-023** | HLD | **[SECURITY]** Verify Content Security Policy Header | Use browser DevTools Network tab. | 1. Navigate to the homepage.<br>2. Inspect the network request for the main document.<br>3. Check the Response Headers. | 1. A `Content-Security-Policy` header is present in the response.<br>2. The policy is restrictive (e.g., `default-src 'self'`). |

---

## 6. Automation Test Scripts

### 6.1. Automation Strategy
The automation strategy will focus on creating a robust regression suite that covers critical user paths and functionality. This includes:
*   **Smoke Tests:** A small suite of tests to run after each deployment to verify the application is up and key pages are accessible.
*   **Critical Path Tests:** End-to-end tests for core user journeys like navigating to a product, viewing details, and submitting the contact form.
*   **API Tests:** Automated checks for API endpoints to ensure contract adherence and correct error handling.
*   **Regression Suite:** The combination of all automated tests, run before a production release to catch any regressions.

### 6.2. Framework Setup
*   **Language:** Python
*   **Test Runner:** Pytest
*   **Browser Automation Library:** Playwright
*   **Structure:** The Page Object Model (POM) will be used to separate UI element locators and actions from the test logic, improving maintainability.

### 6.3. Script Examples (using Python with Playwright)

#### 6.3.1. Script 1: E2E Navigation & Content Verification (Smoke Test)
This script verifies that the main pages are accessible via the header navigation and that their titles are correct.

```python
# tests/test_navigation.py
import re
from playwright.sync_api import Page, expect

def test_header_navigation_and_page_titles(page: Page):
    """
    Tests navigation through the main header links and verifies page titles.
    Covers user stories: PCW-001, PCW-002, PCW-003, PCW-004
    """
    base_url = "https://staging.pharmacorp.com"
    page.goto(base_url)

    # 1. Verify Homepage
    expect(page).to_have_title(re.compile("Home"))
    
    # 2. Navigate to About Us and verify
    page.get_by_role("navigation").get_by_role("link", name="About Us").click()
    expect(page).to_have_url(f"{base_url}/about-us")
    expect(page).to_have_title(re.compile("About Us"))

    # 3. Navigate to Products and verify
    page.get_by_role("navigation").get_by_role("link", name="Products").click()
    expect(page).to_have_url(f"{base_url}/products")
    expect(page).to_have_title(re.compile("Products"))

    # 4. Navigate to Contact Us and verify
    page.get_by_role("navigation").get_by_role("link", name="Contact Us").click()
    expect(page).to_have_url(f"{base_url}/contact-us")
    expect(page).to_have_title(re.compile("Contact Us"))
    
    # 5. Navigate back to Home via logo/link
    page.get_by_role("navigation").get_by_role("link", name="Home").click()
    expect(page).to_have_url(f"{base_url}/")
    expect(page).to_have_title(re.compile("Home"))
```

#### 6.3.2. Script 2: Contact Form Submission (Happy & Sad Paths)
This script tests the contact form functionality, including client-side validation and successful server submission by intercepting the API call.

```python
# tests/test_contact_form.py
import re
from playwright.sync_api import Page, expect

def test_contact_form_successful_submission(page: Page):
    """
    Tests the happy path for the contact form submission.
    Covers user story: PCW-009
    """
    page.goto("https://staging.pharmacorp.com/contact-us")

    name_input = page.get_by_label("Name")
    email_input = page.get_by_label("Email")
    message_input = page.get_by_label("Message")
    submit_button = page.get_by_role("button", name="Submit")

    name_input.fill("John Doe")
    email_input.fill("john.doe@example.com")
    message_input.fill("This is a test message.")

    # Intercept the API call to verify the response
    with page.expect_response("**/api/contact") as response_info:
        submit_button.click()
    
    response = response_info.value
    assert response.status == 201
    
    # Verify success message is visible
    success_message = page.locator("text=Thank you for your message!")
    expect(success_message).to_be_visible()

def test_contact_form_validation_errors(page: Page):
    """
    Tests the sad path for the contact form, checking for validation errors.
    Covers user story: PCW-009
    """
    page.goto("https://staging.pharmacorp.com/contact-us")

    email_input = page.get_by_label("Email")
    submit_button = page.get_by_role("button", name="Submit")

    # Leave name and message empty, provide invalid email
    email_input.fill("invalid-email")
    submit_button.click()

    # Check for error messages
    name_error = page.locator("#name-field-error") # Assuming an ID for the error element
    email_error = page.locator("#email-field-error")
    
    expect(name_error).to_contain_text("This field is required")
    expect(email_error).to_contain_text("Please enter a valid email address")

    # Ensure the success message is not shown
    success_message = page.locator("text=Thank you for your message!")
    expect(success_message).not_to_be_visible()
```

#### 6.3.3. Script 3: Product Page Sticky ISI & PDF Link Verification
This script checks the dynamic behavior of the sticky ISI on scroll and verifies the attributes of the PDF download link.

```python
# tests/test_product_detail.py
from playwright.sync_api import Page, expect

def test_product_page_sticky_isi_and_pdf_link(page: Page):
    """
    Tests sticky ISI on scroll and PI PDF link attributes.
    Covers user stories: PCW-006, PCW-007, PCW-008
    """
    page.goto("https://staging.pharmacorp.com/products/sample-product")

    isi_section = page.locator("#isi-section")
    pdf_link = page.get_by_role("link", name="Download Prescribing Information")

    # 1. Verify PDF link attributes before scroll
    expect(pdf_link).to_be_visible()
    expect(pdf_link).to_have_attribute("href", re.compile(r"\.pdf$"))
    expect(pdf_link).to_have_attribute("target", "_blank")
    
    # 2. Check initial state of ISI (not sticky)
    expect(isi_section).not_to_have_class("is-sticky")

    # 3. Scroll down the page
    page.evaluate("window.scrollBy(0, document.body.scrollHeight)")
    
    # Wait for potential CSS transition
    page.wait_for_timeout(500) 

    # 4. Verify ISI is now sticky
    expect(isi_section).to_have_class("is-sticky")
    expect(isi_section).to_be_visible()

    # 5. Scroll back to the top
    page.evaluate("window.scrollTo(0, 0)")
    page.wait_for_timeout(500)
    
    # 6. Verify ISI is no longer sticky
    expect(isi_section).not_to_have_class("is-sticky")

```