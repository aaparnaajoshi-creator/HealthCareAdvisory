import os
import docx
import requests
import base64
from dotenv import load_dotenv
from typing import List, Tuple # Make sure this is imported at the top of the file
import json

# Load environment variables from .env file
load_dotenv()
UPLOADS_DIR = "uploads"
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")

def read_file_content(file_path: str) -> str:
    """Reads a file, supporting .docx and text-based formats."""
    try:
        if not os.path.exists(file_path):
            return ""
        if file_path.lower().endswith('.docx'):
            doc = docx.Document(file_path)
            full_text = [para.text for para in doc.paragraphs]
            return '\n'.join(full_text)
        else:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                return f.read()
    except Exception as e:
        print(f"Error reading file content from {file_path}: {e}")
        return f"Error reading file: {os.path.basename(file_path)}"

def load_phase_artifact(project_id: str, phase_name: str) -> str:
    """
    Intelligently loads artifacts for a given phase by prioritizing directory
    matches for multi-file artifacts (like code) and falling back to single
    file matches for documents.
    """
    project_dir = os.path.join(UPLOADS_DIR, project_id)
    if not os.path.isdir(project_dir):
        return ""

    # --- Priority 1: Look for a directory named after the phase (for multi-file artifacts) ---
    for root, dirs, _ in os.walk(project_dir):
        if 'output' in dirs:
            dirs.remove('output')  # Don't search in the output directory

        for dir_name in dirs:
            if dir_name.lower() == phase_name.lower():
                phase_dir_path = os.path.join(root, dir_name)
                all_content = []
                # Walk through this specific phase directory and read all files
                for sub_root, _, files_in_phase_dir in os.walk(phase_dir_path):
                    for filename in sorted(files_in_phase_dir):
                        file_path = os.path.join(sub_root, filename)
                        relative_path = os.path.relpath(file_path, phase_dir_path)
                        content = read_file_content(file_path)
                        if content: # Only add if content was read successfully
                            all_content.append(f"--- FILE: {relative_path} ---\n\n{content}")

                if all_content:
                    return "\n\n".join(all_content)

    # --- Priority 2: Look for a single file named after the phase (for documents) ---
    for root, dirs, files in os.walk(project_dir):
        if 'output' in dirs:
            dirs.remove('output')

        for filename in files:
            if os.path.splitext(filename)[0].lower() == phase_name.lower():
                file_path = os.path.join(root, filename)
                return read_file_content(file_path)

    # --- Priority 3: Fallback for special cases like 'new_requirement.txt' ---
    for root, _, files in os.walk(project_dir):
         for filename in files:
            if filename.lower().startswith(phase_name.lower()):
                file_path = os.path.join(root, filename)
                return read_file_content(file_path)

    return ""

def fetch_from_jira(ticket_id: str) -> str:
    """Mock function to fetch data from Jira."""
    print(f"Fetching requirement from Jira ticket: {ticket_id}")
    # In a real app, you would use the Jira API here
    return f"This content is fetched from Jira ticket {ticket_id}.\n\n**User Story:** As a premium user, I want to access exclusive content so that I feel I get value for my subscription.\n\n**Acceptance Criteria:**\n- User must be logged in.\n- User must have an active 'premium' subscription.\n- A new 'Exclusive Content' section is visible in the navigation bar."
def fetch_from_github(repo_url: str, phase_name: str) -> list[tuple[str, bytes]] | str:
    """
    Fetches all files from a specific folder in a GitHub repo.
    Returns a list of (filename, content_bytes) tuples for binary files,
    or an error/warning string.
    """
    headers = {}
    if GITHUB_TOKEN:
        headers["Authorization"] = f"token {GITHUB_TOKEN}"
    
    try:
        parts = repo_url.strip('/').split('/')
        owner, repo = parts[-2], parts[-1]
        
        api_url = f"https://api.github.com/repos/{owner}/{repo}/contents/"
        response = requests.get(api_url, headers=headers)
        response.raise_for_status()
        repo_contents = response.json()

        phase_dir_sha = None
        for item in repo_contents:
            if item['type'] == 'dir' and item['name'].lower() == phase_name.lower():
                phase_dir_sha = item['sha']
                break
        
        if not phase_dir_sha:
            return f"Error: Could not find a directory named '{phase_name}' in the repository."

        tree_url = f"https://api.github.com/repos/{owner}/{repo}/git/trees/{phase_dir_sha}?recursive=1"
        response = requests.get(tree_url, headers=headers)
        response.raise_for_status()
        tree_contents = response.json()

        all_files = []
        # Fetch the content of each file in the tree
        for item in tree_contents.get('tree', []):
            if item['type'] == 'blob': # 'blob' means it's a file
                file_url = item['url']
                file_response = requests.get(file_url, headers=headers)
                file_response.raise_for_status()
                file_data = file_response.json()
                
                if file_data.get('encoding') == 'base64':
                    # Decode from base64 but KEEP as bytes
                    content_bytes = base64.b64decode(file_data['content'])
                    relative_path = item['path']
                    all_files.append((relative_path, content_bytes))

        if not all_files and tree_contents.get('tree', []):
            return f"Warning: The '{phase_name}' directory was found but contains no files."
        elif not all_files:
            return f"Warning: The '{phase_name}' directory was found but it is empty."
            
        return all_files

    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 404:
            return f"Error: Repository not found at {repo_url}. Please check the URL."
        return f"Error fetching from GitHub: {e}"
    except Exception as e:
        return f"An unexpected error occurred: {e}"
    
    
def fetch_github_raw_file(repo_url: str, file_name_pattern: str) -> tuple[str | None, bytes | str | None]:
    """
    Fetches the raw binary content of the first file found in the root of a GitHub repo
    that matches the file_name_pattern, ignoring the extension.
    Returns the full filename and the file content as bytes.
    """
    print(file_name_pattern)
    
    headers = {}
    if GITHUB_TOKEN:
        headers["Authorization"] = f"{GITHUB_TOKEN}"

    try:
        parts = repo_url.strip('/').split('/')
        owner, repo = parts[-2], parts[-1]
        
        api_url = f"https://api.github.com/repos/{owner}/{repo}/contents/"
        response = requests.get(api_url, headers=headers)
        print(headers)
        response.raise_for_status()
        repo_contents = response.json()
        print('respnose****',response)
        target_file_info = None
        for item in repo_contents:
            if item['type'] == 'file':
                item_name_without_ext = os.path.splitext(item['name'])[0]
                if item_name_without_ext.lower() == file_name_pattern.lower():
                    target_file_info = item
                    break
        
        if not target_file_info:
            return None, f"Error: Could not find a file like '{file_name_pattern}.*' in the repository root."

        download_url = target_file_info.get('download_url')
        if not download_url:
            return target_file_info['name'], f"Error: Could not find download_url for {target_file_info['name']}"

        file_response = requests.get(download_url, headers=headers)
        file_response.raise_for_status()
        
        return target_file_info['name'], file_response.content

    except requests.exceptions.HTTPError as e:
        print(f"Error fetching from GitHub: {e}")
        if e.response.status_code == 404:
            return None, f"Error: Repository not found at {repo_url}. Please check the URL."
        
        return None, f"Error fetching from GitHub: {e}"
    except Exception as e:
        return None, f"An unexpected error occurred: {e}"
    
def push_artifact_to_github(repo_url: str, file_path: str, file_content: str, commit_message: str) -> dict:
    """
    Pushes a file to a GitHub repository. Creates the file if it doesn't exist,
    or updates it if it does.
    """
    if not GITHUB_TOKEN:
        return {"error": "GitHub token not configured."}

    headers = {
        "Authorization": f"token {GITHUB_TOKEN}",
        "Accept": "application/vnd.github.v3+json",
    }
    parts = repo_url.strip('/').split('/')
    owner, repo = parts[-2], parts[-1]
    api_url = f"https://api.github.com/repos/{owner}/{repo}/contents/{file_path}"

    # First, try to get the file to see if it exists (for updating)
    sha = None
    try:
        get_response = requests.get(api_url, headers=headers)
        print('get_response...',get_response)
        if get_response.status_code == 200:
            sha = get_response.json().get('sha')
    except requests.exceptions.RequestException as e:
        print('get_response error',e)
        pass # Ignore connection errors, proceed as if file doesn't exist

    # Create or update the file
    content_encoded = base64.b64encode(file_content.encode('utf-8')).decode('utf-8')
    data = {
        "message": commit_message,
        "content": content_encoded,
        "branch": "main" # Or your desired branch
    }
    print('here...',sha)
    if sha:
        data["sha"] = sha # Required for updating an existing file

    try:
        put_response = requests.put(api_url, headers=headers, data=json.dumps(data))
        put_response.raise_for_status()
        return put_response.json()
    except requests.exceptions.HTTPError as e:
        print('Error pushing into githuv', e)
        return {"error": f"GitHub API Error: {e.response.text}"}
    except Exception as e:
        print('Error pushing into githuv', e)
        return {"error": f"An unexpected error occurred: {e}"}
