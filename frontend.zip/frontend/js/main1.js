document.addEventListener('DOMContentLoaded', () => {
    // --- 1. STATE & CONFIG ---
    const API_URL = 'http://localhost:8000';
    const appState = {
        projectId: null,
        pollInterval: null,
        currentView: 'dashboard',
        wizardStep: 1,
        currentExecutionData: null,
        summaryShown: false // Add this flag
    };

    const phaseInputs = {
        "Requirements": ["New Requirement", "High-Level Functional Req", "High-Level Technical Req"],
        "Design": ["Requirements", "High-Level Technical Req"],
        "Testing": ["Requirements", "Design"], // New order
        "Coding": ["Design", "Testing"],       // New order
        "Deployment": ["Design", "Coding"]
    };
    const allPossiblePhases = ["Requirements", "Design", "Testing","Coding",  "Deployment"];
    const agentIcons = {
        "Requirements": `<svg class="agent-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M14 2H6C4.9 2 4 2.9 4 4V20C4 21.1 4.9 22 6 22H18C19.1 22 20 21.1 20 20V8L14 2ZM10.41 17.41L7.59 14.59L9 13.17L10.41 14.59L14.03 10.97L15.44 12.38L10.41 17.41Z" /><path d="M13 3.5V9H18.5L13 3.5Z" /></svg>`,
        "Design": `<svg class="agent-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L3 8V21H21V8L12 2ZM11 19H7V15H11V19ZM11 13H7V9H11V13ZM17 19H13V15H17V19ZM17 13H13V9H17V13Z" /></svg>`,
        "Coding": `<svg class="agent-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M9.4 16.6L4.8 12L9.4 7.4L8 6L2 12L8 18L9.4 16.6ZM14.6 16.6L19.2 12L14.6 7.4L16 6L22 12L16 18L14.6 16.6Z" /></svg>`,
        "Testing": `<svg class="agent-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L3.5 5.5V11.5C3.5 16.5 7.5 21.5 12 22C16.5 21.5 20.5 16.5 20.5 11.5V5.5L12 2ZM10.5 16L6.5 12L8 10.5L10.5 13L16 7.5L17.5 9L10.5 16Z" /></svg>`,
        "Deployment": `<svg class="agent-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M2 21H22V19H2V21ZM21 16H3C2.45 16 2 15.55 2 15V4C2 3.45 2.45 3 3 3H21C21.55 3 22 3.45 22 4V15C22 15.55 21.55 16 21 16ZM5 14H7V11H5V14ZM9 14H11V11H9V14ZM13 14H15V11H13V14Z" /></svg>`
    };

    // --- 2. SELECTORS ---
    const selectors = {
        projectSummaryCard: document.getElementById('project-summary-card'), 
        toastNotification: document.getElementById('toast-notification'),
        dashboardSection: document.getElementById('dashboard-section'),
        executionSection: document.getElementById('execution-section'),
        projectGrid: document.getElementById('project-grid'),
        createProjectBtn: document.getElementById('create-project-btn'),
        backToDashboardBtn: document.getElementById('back-to-dashboard-btn'),
        projectForm: document.getElementById('project-form'),
        projectTitleExecution: document.getElementById('project-title-execution'),
        projectStatus: document.getElementById('project-status'),
        statusIndicator: document.getElementById('status-indicator'),
        timeline: document.getElementById('timeline'),
        downloadOutputsBtn: document.getElementById('download-outputs-btn'),
        humanInterventionBox: document.getElementById('human-intervention-box'),
        humanInterventionPhase: document.getElementById('human-intervention-phase'),
        humanEditArea: document.getElementById('human-edit-area'),
        resumeButton: document.getElementById('resume-button'),
        expandEditorBtn: document.getElementById('expand-editor-btn'),
        editorModal: document.getElementById('editor-modal'),
        closeEditorModalBtn: document.getElementById('close-editor-modal-btn'),
        modalEditorArea: document.getElementById('modal-editor-area'),
        saveEditBtn: document.getElementById('save-edit-btn'),
        cancelEditBtn: document.getElementById('cancel-edit-btn'),
        logModal: document.getElementById('log-modal'),
        logViewer: document.getElementById('log-viewer'),
        closeLogModalBtn: document.getElementById('close-modal-btn'),
        formInputsSource: document.getElementById('form-inputs-source'),
        projectWizardModal: document.getElementById('project-wizard-modal'),
        closeWizardBtn: document.getElementById('close-wizard-btn'),
    };

    function renderExecutionSummary(data) {
        const body = document.getElementById('summary-modal-body');
        const isSuccess = data.overall_status === 'Completed';

        // Build the list of steps
        let stepsHtml = `
            <div class="summary-item">
                <span class="summary-icon success">✔</span>
                <span class="summary-text">Loaded Initial Artifacts</span>
                <span class="status-chip completed">Success</span>
            </div>
        `;

        data.phases.forEach(phase => {
            const isPhaseSuccess = phase.status === 'Completed';
            stepsHtml += `
                <div class="summary-item">
                    <span class="summary-icon ${isPhaseSuccess ? 'success' : 'failed'}">${isPhaseSuccess ? '✔' : '✖'}</span>
                    <span class="summary-text">${phase.phase_name} Agent</span>
                    <span class="status-chip ${isPhaseSuccess ? 'completed' : 'failed'}">${phase.status}</span>
                </div>
            `;
        });
        
        // Add the final output step
        if (isSuccess) {
            if (data.output_destination === 'github' && data.github_repo_url) {
                stepsHtml += `
                    <div class="summary-item">
                        <span class="summary-icon success">✔</span>
                        <span class="summary-text">Pushed Artifacts to <a href="${data.github_repo_url}" target="_blank">GitHub</a></span>
                        <span class="status-chip completed">Success</span>
                    </div>`;
            } else {
                stepsHtml += `
                    <div class="summary-item">
                        <span class="summary-icon success">✔</span>
                        <span class="summary-text">Saved Artifacts to Disk</span>
                        <span class="status-chip completed">Success</span>
                    </div>`;
            }
        }

        // Assemble the final modal content
        body.innerHTML = `
            <div class="summary-header">
                <div class="summary-status-icon ${isSuccess ? 'success' : 'failed'}">
                    ${isSuccess ? '✔' : '✖'}
                </div>
                <h2>Workflow ${data.overall_status}</h2>
                <p>Project: <strong>${data.project_name}</strong></p>
            </div>
            <div class="summary-list">
                ${stepsHtml}
            </div>
        `;
        
        document.getElementById('summary-download-btn').disabled = !isSuccess;
        document.getElementById('summary-modal').classList.remove('hidden');
    }

    function setupPhaseStepper() {
        const stepper = document.getElementById('phase-stepper');
        if (!stepper) return;

        stepper.innerHTML = ''; // Clear previous content
        let selectedStartPhase = null;

        const startPhaseInput = document.getElementById('start-phase-input');
        const endPhaseInput = document.getElementById('end-phase-input');

        // Create a tile for each phase
        allPossiblePhases.forEach(phase => {
            const tile = document.createElement('div');
            tile.className = 'step-tile';
            tile.dataset.phase = phase;
            tile.textContent = phase;
            stepper.appendChild(tile);

            tile.addEventListener('click', () => {
                // Allow resetting the start phase or setting it if not set
                selectedStartPhase = phase;
                updateSelection(phase); // On click, the end phase is the same as the start
            });

            tile.addEventListener('mouseover', () => {
                // Only update the range highlight if a start phase is already chosen
                if (selectedStartPhase) {
                    updateSelection(phase);
                }
            });
        });

        const updateSelection = (endPhase) => {
            const tiles = stepper.querySelectorAll('.step-tile');
            const startIndex = selectedStartPhase ? allPossiblePhases.indexOf(selectedStartPhase) : -1;
            const endIndex = endPhase ? allPossiblePhases.indexOf(endPhase) : -1;

            if (startIndex === -1 || endIndex === -1) return;

            // Ensure the end of the range isn't before the start
            const finalEndIndex = Math.max(startIndex, endIndex);

            tiles.forEach((tile, i) => {
                tile.classList.remove('is-start', 'is-end', 'in-range');
                if (i >= startIndex && i <= finalEndIndex) {
                    tile.classList.add('in-range');
                }
                if (i === startIndex) {
                    tile.classList.add('is-start');
                }
                if (i === finalEndIndex) {
                    tile.classList.add('is-end');
                }
            });

            startPhaseInput.value = allPossiblePhases[startIndex];
            endPhaseInput.value = allPossiblePhases[finalEndIndex];

            // Trigger change event for other parts of the UI to update
            startPhaseInput.dispatchEvent(new Event('change', { bubbles: true }));
        };

        // Initialize with default start and end phases
        selectedStartPhase = 'Requirements';
        updateSelection('Deployment');
    }
    // --- 3. UI RENDERING & UPDATES ---

    function renderProjectSummary(data) {
        if (!data || !selectors.projectSummaryCard) return;
        const hitlSteps = data.human_in_loop_steps;
        const hitlValue = (hitlSteps && hitlSteps.length > 0) ? hitlSteps.join(', ') : 'None';
        const summaryHtml = `
            <h3>Project Configuration</h3>
            <div class="summary-item">
                <span class="label">Project Type:</span>
                <span class="value">${data.project_type || 'N/A'}</span>
            </div>
            <div class="summary-item">
                <span class="label">Start Phase:</span>
                <span class="value">${data.start_phase || 'N/A'}</span>
            </div>
            <div class="summary-item">
                <span class="label">End Phase:</span>
                <span class="value">${data.end_phase || 'N/A'}</span>
            </div>
            <div class="summary-item">
                <span class="label">HITL Checkpoints:</span>
                <span class="value">${hitlValue}</span>
            </div>
        `;
        selectors.projectSummaryCard.innerHTML = summaryHtml;
    }
    function showToast(message, type = 'error') {
        const toast = selectors.toastNotification;
        toast.textContent = message;
        toast.className = `toast show ${type}`;
        setTimeout(() => {
            toast.classList.remove('show');
        }, 4000);
    }

    function showView(viewName) {
        appState.currentView = viewName;
        selectors.dashboardSection.classList.toggle('hidden', viewName !== 'dashboard');
        selectors.executionSection.classList.toggle('hidden', viewName !== 'execution');
        
        if (viewName === 'dashboard') {
            if (appState.pollInterval) clearInterval(appState.pollInterval);
            appState.projectId = null;
            loadAndRenderProjects();
        }
    }

    async function loadAndRenderProjects() {
        try {
            const response = await fetch(`${API_URL}/projects`);
            if (!response.ok) throw new Error('Failed to fetch projects');
            const projects = await response.json();
            selectors.projectGrid.innerHTML = '';
            if (projects.length === 0) {
                selectors.projectGrid.innerHTML = `<p>No projects yet. Click "Create New Project" to get started!</p>`;
                return;
            }
            projects.forEach(p => {
                const card = document.createElement('div');
                card.className = 'project-card';
                card.dataset.id = p.id;
                const statusClass = p.status.toLowerCase().replace(/ .*/, '');
                card.innerHTML = `
                    <div class="project-card-header">
                        <h3>${p.project_name}</h3>
                        <span class="status-chip ${statusClass}">${p.status}</span>
                    </div>
                    <div class="project-card-body">
                        <p>Type: <strong>${p.project_type === 'new' ? 'New Project' : 'Enhancement'}</strong></p>
                    </div>
                    <div class="project-card-footer">
                        <span>ID: ${p.id.substring(0, 8)}...</span>
                        <span>${new Date(p.created_at).toLocaleDateString()}</span>
                    </div>
                `;
                selectors.projectGrid.appendChild(card);
            });
        } catch (error) {
            console.error("Could not fetch project history:", error);
            showToast('Could not load project history.');
        }
    }

    function renderTimeline(container, phasesData, overallStatus) {
        container.innerHTML = '';
        if (!phasesData || phasesData.length === 0) {
            container.innerHTML = '<p>No phases to display for this project.</p>';
            return;
        }
        
         // --- LOGIC TO FIND HIGHLIGHTED PHASE ---
        let activePhaseName = null;
        let pausedPhaseName = null;
        if (overallStatus?.startsWith('In Progress - ')) {
            const fullPhaseName = overallStatus.replace('In Progress - ', '').trim();
            // ✅ FIX: Extract just the phase name before any parenthesis
            activePhaseName = fullPhaseName.split('(')[0].trim();
        } else if (overallStatus?.includes('Paused - Waiting for Human Input at ')) {
            pausedPhaseName = overallStatus.split(' at ')[1]?.trim();
        }
        // --- END LOGIC ---

        phasesData.forEach(phaseInfo => {
            const phaseName = phaseInfo.phase_name;
            const inputs = phaseInputs[phaseName] || [];
            const inputsHtml = inputs.map(input => `<span class="input-chip">${input}</span>`).join('');
        
            const item = document.createElement('div');
            item.className = 'timeline-item';
            item.id = `timeline-phase-${phaseName.toLowerCase()}`;
            
            if (phaseInfo.status === 'Completed') item.classList.add('completed');
            // Apply active or paused class
            if (phaseName === activePhaseName) item.classList.add('active');
            if (phaseName === pausedPhaseName) item.classList.add('paused-for-input');
            
            item.innerHTML = `
            <div class="timeline-item-header">
                <div class="timeline-item-header-title">${agentIcons[phaseName] || ''}<h4>${phaseName} Agent</h4></div>
                <div class="status-container">
                    <span class="phase-duration">${phaseInfo.duration ? `(${phaseInfo.duration}s)` : ''}</span>
                    <span class="status">${phaseInfo.status}</span>
                    <svg class="toggle-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
                </div>
            </div>
            <div class="timeline-item-body">
                <div class="timeline-io-section">
                    <h5>Inputs</h5>
                    <div class="inputs-container">${inputsHtml.length > 0 ? inputsHtml : '<span>Initial phase</span>'}</div>
                </div>
                <div class="timeline-io-section">
                    <h5>Outputs</h5>
                    ${renderOutput(phaseInfo)}
                </div>
                <div class="item-actions ${phaseInfo.details?.length > 0 || phaseInfo.final_output ? '' : 'hidden'}">
                    <button class="download-phase-btn btn-secondary" data-phase="${phaseName}" ${phaseInfo.status !== 'Completed' ? 'disabled' : ''}>Download Output</button>
                    <button class="logs-btn btn-secondary" data-phase="${phaseName}">View Logs</button>
                </div>
            </div>`;
            container.appendChild(item);
        });
    }

    function renderOutput(phaseInfo) {
        const hasDetails = phaseInfo.details && phaseInfo.details.length > 0;
        
        if (hasDetails) {
            return phaseInfo.details.map((log, index) => {
                const isCritic = log.agent_name === 'Critic';
                const summary = log.details || (isCritic ? log.output : 'No summary provided.');
                const fullOutput = log.output || 'No output available.';
                const uniqueId = `output-${phaseInfo.phase_name}-${log.agent_name}-${index}`.replace(/\s/g, '');
    
                if (!summary || summary.trim() === fullOutput.trim()) {
                    return `
                        <div class="output ${isCritic ? 'critic-feedback' : ''}">
                            <div class="output-header"><span>${log.agent_name} Output</span></div>
                            <div class="output-content">${marked.parse(fullOutput)}</div>
                        </div>`;
                }
    
                return `
                    <div class="output ${isCritic ? 'critic-feedback' : ''}">
                        <div class="output-header">
                            <span>${log.agent_name} Summary</span>
                            <button class="toggle-output-btn" data-target="${uniqueId}">View Full Output</button>
                        </div>
                        <div class="output-summary">${marked.parse(summary)}</div>
                        <div id="${uniqueId}" class="output-content hidden">${marked.parse(fullOutput)}</div>
                    </div>`;
            }).join('');
        } else if (phaseInfo.final_output) {
            return `
                <div class="output">
                    <div class="output-header"><span>Final Output</span></div>
                    <div class="output-content">${marked.parse(phaseInfo.final_output)}</div>
                </div>`;
        } else {
            return '<p class="no-output">No output generated yet.</p>';
        }
    }
    

   function updateTimelineView(phasesData, overallStatus) {
        if (!phasesData) return;
        
        // --- LOGIC TO FIND HIGHLIGHTED PHASE ---
        let activePhaseName = null;
        let pausedPhaseName = null;
        if (overallStatus?.startsWith('In Progress - ')) {
            const fullPhaseName = overallStatus.replace('In Progress - ', '').trim();
            // ✅ FIX: Extract just the phase name before any parenthesis
            activePhaseName = fullPhaseName.split('(')[0].trim();
        } else if (overallStatus?.includes('Paused - Waiting for Human Input at ')) {
            pausedPhaseName = overallStatus.split(' at ')[1]?.trim();
        }
        // --- END LOGIC ---
        
        phasesData.forEach(phaseInfo => {
            // ... (the rest of the function remains the same)
            const phaseName = phaseInfo.phase_name;
            const item = document.getElementById(`timeline-phase-${phaseName.toLowerCase()}`);
            if (!item) return;

            const statusEl = item.querySelector('.status');
            const durationEl = item.querySelector('.phase-duration');
            const downloadBtn = item.querySelector('.download-phase-btn');

            if (statusEl.textContent !== phaseInfo.status) {
                statusEl.textContent = phaseInfo.status;
            }
            if (durationEl.textContent !== `(${phaseInfo.duration}s)`) {
                durationEl.textContent = phaseInfo.duration ? `(${phaseInfo.duration}s)` : '';
            }
            if(downloadBtn) {
                downloadBtn.disabled = phaseInfo.status !== 'Completed';
            }

            item.classList.remove('active', 'completed', 'paused-for-input');
            if (phaseInfo.status === 'Completed') {
                item.classList.add('completed');
            }
            if (phaseName === activePhaseName) {
                item.classList.add('active');
            }
            if (phaseName === pausedPhaseName) {
                item.classList.add('paused-for-input');
            }
        });
    }
    // --- 4. EVENT HANDLERS & WIZARD LOGIC ---
    // DELETE your old setupEventListeners function and REPLACE it with this one.

    function setupEventListeners() {
        selectors.createProjectBtn.addEventListener('click', openWizard);
        
        // This is the main event handler for clicks inside the project form
        selectors.projectForm.addEventListener('click', (e) => {
            const target = e.target;
            
            // Handle clicks on project type cards (Step 1)
            if (target.closest('.type-card')) {
                handleProjectTypeSelect(e);
            }
            // Handle Next button
            if (target.closest('#wizard-next-btn')) {
                handleWizardNext();
            }
            // Handle Back button
            if (target.closest('#wizard-back-btn')) {
                handleWizardBack();
            }

            // THIS IS THE CRITICAL MISSING PIECE FOR STEP 4
            // Handle clicks on the output destination cards in Step 4
            const outputCard = target.closest('.mode-card[data-value]');
            if (outputCard && outputCard.closest('#wizard-step-4')) {
                handleOutputModeSelect(outputCard);
            }
        });
        
        // This handles changes for dynamic inputs
        selectors.projectForm.addEventListener('change', (e) => {
            if (e.target.name === 'start_phase' || e.target.closest('.project-type-selector')) {
                updateFormView();
            }
            const inputCardRadio = e.target.closest('.input-mode-cards input[type="radio"]');
            if(inputCardRadio) {
                const fieldsContainer = inputCardRadio.closest('.form-group').querySelector('.input-mode-fields');
                fieldsContainer.querySelector('.file-drop-area').classList.toggle('hidden', e.target.value !== 'file');
                fieldsContainer.querySelector('.github-input').classList.toggle('hidden', e.target.value !== 'github');
            }
        });

        // All other event listeners
        selectors.projectForm.addEventListener('submit', handleProjectFormSubmit);
        selectors.backToDashboardBtn.addEventListener('click', () => showView('dashboard'));
        selectors.projectGrid.addEventListener('click', handleProjectCardClick);
        selectors.timeline.addEventListener('click', handleTimelineClick);
        selectors.resumeButton.addEventListener('click', handleResumeWorkflow);
        selectors.expandEditorBtn.addEventListener('click', openEditorModal);
        selectors.saveEditBtn.addEventListener('click', saveAndCloseEditorModal);
        selectors.downloadOutputsBtn.addEventListener('click', handleDownloadAll);

        setupModalClose(selectors.logModal, selectors.closeLogModalBtn);
        setupModalClose(selectors.editorModal, selectors.closeEditorModalBtn);
        setupModalClose(selectors.projectWizardModal, selectors.closeWizardBtn);
    }
    
    function openEditorModal() {
        selectors.modalEditorArea.value = selectors.humanEditArea.value;
        selectors.editorModal.classList.remove('hidden');
    }

    function closeEditorModal() {
        selectors.editorModal.classList.add('hidden');
    }

    function saveAndCloseEditorModal() {
        selectors.humanEditArea.value = selectors.modalEditorArea.value;
        closeEditorModal();
    }

    // DELETE your existing openWizard and closeWizard functions and REPLACE them with these.

    // DELETE your existing openWizard, closeWizard, and handleOutputModeSelect functions.
// REPLACE them with the three corrected functions below.

function openWizard() {
    appState.wizardStep = 1;
    selectors.projectForm.reset();
    
    const form = selectors.projectForm;
    const source = selectors.formInputsSource;
    form.innerHTML = ''; // Clear the form first

    // This section prepares the wizard by moving all step content
    // from the hidden source div into the visible form.
    form.append(source.querySelector('#wizard-step-1'));
    form.append(source.querySelector('#wizard-step-2'));
    form.append(source.querySelector('#wizard-step-3'));
    form.append(source.querySelector('#wizard-step-4'));
    form.append(source.querySelector('.modal-footer'));
    
    // Reset UI elements to their default state
    const projectTypeInput = form.querySelector('#project_type_input');
    const projectTypeSelector = form.querySelector('.project-type-selector');
    if(projectTypeInput && projectTypeSelector){
        projectTypeInput.value = 'enhancement';
        projectTypeSelector.querySelector('.type-card.selected')?.classList.remove('selected');
        projectTypeSelector.querySelector('.type-card[data-value="enhancement"]').classList.add('selected');
    }
    // Ensure the GitHub config is hidden by default when the wizard opens
    document.getElementById('github-output-config')?.classList.add('hidden');
    
    setupPhaseStepper();
    updateWizardView();
    selectors.projectWizardModal.classList.remove('hidden');
}

    function closeWizard() {
        selectors.projectWizardModal.classList.add('hidden');
        const source = selectors.formInputsSource;
        const form = selectors.projectForm;
        
        // IMPORTANT: This moves all four steps and the footer back to the hidden storage div.
        // This is the critical cleanup step that was failing before.
        source.append(form.querySelector('#wizard-step-1'));
        source.append(form.querySelector('#wizard-step-2'));
        source.append(form.querySelector('#wizard-step-3'));
        source.append(form.querySelector('#wizard-step-4'));
        source.append(form.querySelector('.modal-footer'));
    }

   

    function updateWizardView() {
        const wizard = selectors.projectWizardModal;
        wizard.querySelectorAll('.wizard-step').forEach(step => step.classList.add('hidden'));
        wizard.querySelector(`#wizard-step-${appState.wizardStep}`)?.classList.remove('hidden');

        wizard.querySelectorAll('.wizard-stepper .step').forEach(step => {
            step.classList.remove('active');
            if (parseInt(step.dataset.step) <= appState.wizardStep) {
                step.classList.add('active');
            }
        });

        const footer = selectors.projectForm.querySelector('.modal-footer');
        if (footer) {
            footer.querySelector('#wizard-back-btn').classList.toggle('hidden', appState.wizardStep === 1);
            footer.querySelector('#wizard-next-btn').classList.toggle('hidden', appState.wizardStep === 4);
            footer.querySelector('#wizard-submit-btn').classList.toggle('hidden', appState.wizardStep !== 4);
        }

        if (appState.wizardStep === 3) {
            updateFormView();
        }
    }

    function handleWizardNext() {
        if (appState.wizardStep === 2) {
            if (!selectors.projectForm.querySelector('#project-name').value.trim()) {
                showToast('Project Name is required.');
                return;
            }
            // ✅ ADD THIS: Manually trigger form view update before moving to step 3
            // This ensures the correct artifacts are shown based on the selected start phase.
            updateFormView(); 
        }
        if (appState.wizardStep < 4) {
            appState.wizardStep++;
            updateWizardView();
        }
    }

    function handleWizardBack() {
        if (appState.wizardStep > 1) {
            appState.wizardStep--;
            updateWizardView();
        }
    }

    function handleProjectTypeSelect(e) {
        const card = e.target.closest('.type-card');
        if (!card) return;
        const selector = card.parentElement;
        selector.querySelector('.type-card.selected')?.classList.remove('selected');
        card.classList.add('selected');
        selector.nextElementSibling.value = card.dataset.value;
    }

    function updateFormView() {
        const form = selectors.projectForm;
        const projectType = form.querySelector('#project_type_input').value;
        const startPhase = form.querySelector('#start-phase-input').value; 

        const enhancementInputs = form.querySelector('#enhancement-inputs');
        const newProjectInputs = form.querySelector('#new-project-inputs');

        // Show/hide main containers
        enhancementInputs.classList.toggle('hidden', projectType !== 'enhancement');
        newProjectInputs.classList.toggle('hidden', projectType !== 'new');

        // Clear previous dynamic inputs to prevent duplicates
        enhancementInputs.innerHTML = '';
        newProjectInputs.innerHTML = '<p class="input-guidance">Provide the initial documents required for the selected Start Phase.</p>';

        if (projectType === 'enhancement') {
            createDynamicInput(enhancementInputs, 'new_requirement', 'New Requirement Document');
            createDynamicInput(enhancementInputs, 'existing_artifacts_zip', 'Existing Project Artifacts (.zip)');
        } else { // New Project Logic
            switch (startPhase) {
                case 'Requirements':
                    createDynamicInput(newProjectInputs, 'hl_functional_req', 'High-Level Functional Req');
                    createDynamicInput(newProjectInputs, 'hl_technical_req', 'High-Level Technical Req');
                    break;
                case 'Design':
                    createDynamicInput(newProjectInputs, 'hl_technical_req', 'High-Level Technical Req');
                    createDynamicInput(newProjectInputs, 'user_stories', 'User Stories (SRS)');
                    break;
                case 'Coding':
                    createDynamicInput(newProjectInputs, 'user_stories', 'User Stories (SRS)');
                    createDynamicInput(newProjectInputs, 'design', 'Design Document (HLD)');
                    break;
                case 'Testing':
                    createDynamicInput(newProjectInputs, 'user_stories', 'User Stories (SRS)');
                    createDynamicInput(newProjectInputs, 'design', 'Design Document (HLD)');
                    break;
                case 'Deployment':
                    createDynamicInput(newProjectInputs, 'design', 'Design Document (HLD)');
                    break;
            }
        }
}

    async function handleProjectFormSubmit(e) {
        e.preventDefault(); 
        const submitBtn = e.target.querySelector('#wizard-submit-btn');
        const formData = new FormData(selectors.projectForm);
        const humanStepsArray = Array.from(document.querySelectorAll('input[name="human_steps"]:checked')).map(el => el.value);
        formData.append('human_steps', JSON.stringify(humanStepsArray));
        submitBtn.disabled = true;
        submitBtn.textContent = 'Creating...';

        try {
            const response = await fetch(`${API_URL}/projects`, { method: 'POST', body: formData });
            
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.detail || 'Failed to create project');
            }
            
            const result = await response.json();
            appState.projectId = result.project_id;
            
            closeWizard();
            showToast('Project created successfully!', 'success');
            
            selectors.projectTitleExecution.textContent = formData.get('project_name');
            
            const startPhase = formData.get('start_phase');
            const endPhase = formData.get('end_phase');
            const phasesToDisplay = allPossiblePhases.slice(allPossiblePhases.indexOf(startPhase), allPossiblePhases.indexOf(endPhase) + 1).map(name => ({
                phase_name: name, status: 'Pending', duration: 0, details: []
            }));
            
            renderProjectSummary({
            project_type: formData.get('project_type'),
            start_phase: formData.get('start_phase'),
            end_phase: formData.get('end_phase'),
            human_in_loop_steps: humanStepsArray // <-- ADD THIS LINE
            });
            
            showView('execution');
            updateStatus('Pending', phasesToDisplay, true);
            startExecution();

        } catch (error) { 
            console.error('Form submission error:', error);
            showToast(`Error: ${error.message}`); 
        } finally {
            submitBtn.disabled = false;
            submitBtn.textContent = 'Create and Start Project';
        }
    }

    async function handleProjectCardClick(e) {
    const card = e.target.closest('.project-card');
    if (!card) return;
    
    appState.projectId = card.dataset.id;
    try {
        const response = await fetch(`${API_URL}/projects/${appState.projectId}/status`);
        if (!response.ok) throw new Error('Could not fetch project status.');
        const data = await response.json();
        appState.currentExecutionData = data;
        
        selectors.projectTitleExecution.textContent = data.project_name || 'Project Details';
        
        // Call the new render function here
        renderProjectSummary(data);
        
        updateStatus(data.overall_status, data.phases, true);
        
        showView('execution');

        const status = data.overall_status?.toLowerCase() || '';
        if (status.includes('in progress') || status.includes('paused')) {
             if (appState.pollInterval) clearInterval(appState.pollInterval);
             appState.pollInterval = setInterval(pollStatus, 2000);
        }
    } catch (error) {
        showToast(error.message);
        console.error(error);
    }
}
    // In js/main.js

    async function handleProjectCardClick(e) {
        const card = e.target.closest('.project-card');
        if (!card) return;
        
        appState.projectId = card.dataset.id;
        try {
            const response = await fetch(`${API_URL}/projects/${appState.projectId}/status`);
            if (!response.ok) throw new Error('Could not fetch project status.');
            const data = await response.json();
            appState.currentExecutionData = data;
            
            selectors.projectTitleExecution.textContent = data.project_name || 'Project Details';
            
            // This is the line that was missing for historical projects
            renderProjectSummary(data);
            
            updateStatus(data.overall_status, data.phases, true);
            
            showView('execution');

            const status = data.overall_status?.toLowerCase() || '';
            if (status.includes('in progress') || status.includes('paused')) {
                if (appState.pollInterval) clearInterval(appState.pollInterval);
                appState.pollInterval = setInterval(pollStatus, 2000);
            }
        } catch (error) {
            showToast(error.message);
            console.error(error);
        }
    }
    
    function handleTimelineClick(e) {
        const target = e.target;
        
        const timelineItemHeader = target.closest('.timeline-item-header');
        if (timelineItemHeader) {
            timelineItemHeader.querySelector('.toggle-icon')?.classList.toggle('expanded');
            const body = timelineItemHeader.nextElementSibling;
            if (body?.classList.contains('timeline-item-body')) {
                body.classList.toggle('expanded');
            }
            return;
        }
    
        const toggleOutputBtn = target.closest('.toggle-output-btn');
        if (toggleOutputBtn) {
            const targetId = toggleOutputBtn.dataset.target;
            const targetElement = document.getElementById(targetId);
            if (targetElement) {
                const isHidden = targetElement.classList.toggle('hidden');
                toggleOutputBtn.textContent = isHidden ? 'View Full Output' : 'Hide Full Output';
            }
            return;
        }
    
        const logsBtn = target.closest('.logs-btn');
        if (logsBtn) {
            handleViewLogs(logsBtn.dataset.phase);
            return;
        }
        
        const downloadBtn = target.closest('.download-phase-btn');
        if (downloadBtn) {
            handleDownloadPhaseOutput(downloadBtn.dataset.phase);
            return;
        }
    }

    // ✅ FIX: Reworked this function to create a clean, readable log view
    async function handleViewLogs(phase) {
        if (!appState.projectId || !phase) return;
        try {
            const response = await fetch(`${API_URL}/projects/${appState.projectId}/technical_logs/${phase}`);
            if (!response.ok) throw new Error('Failed to fetch logs.');
            const logs = await response.json();
            
            const logContent = logs.map(log => {
                const metadata = JSON.parse(log.metadata);
                // Create a list of formatted metadata items instead of a raw JSON block
                const metadataItems = Object.entries(metadata).map(([key, value]) => 
                    `<div class="metadata-item">
                        <span class="metadata-key">${key}:</span>
                        <span class="metadata-value">${value}</span>
                    </div>`
                ).join('');

                return `<div class="log-entry">
                    <div class="log-entry-header">
                        <span class="log-timestamp">${new Date(log.timestamp).toLocaleString()}</span>
                        <strong class="log-event">${log.event_description}</strong>
                    </div>
                    <div class="metadata-container">
                        ${metadataItems}
                    </div>
                </div>`
            }).join('') || '<p>No technical logs for this phase.</p>';
            
            selectors.logViewer.innerHTML = logContent;
            selectors.logModal.classList.remove('hidden');
        } catch(error) {
            showToast(error.message);
            console.error(error);
        }
    }
    
    function handleDownloadPhaseOutput(phase) {
        if (!appState.projectId || !phase) return;
        const url = `${API_URL}/projects/${appState.projectId}/download/${phase}`;
        window.open(url, '_blank');
    }
    
    // ✅ FIX: Added handler for the "Download All Outputs" button
    function handleDownloadAll() {
        if (!appState.projectId) return;
        const url = `${API_URL}/projects/${appState.projectId}/download-all`;
        window.open(url, '_blank');
    }

    async function handleResumeWorkflow() {
        if (!appState.projectId) return;
        const phaseOfEdit = selectors.resumeButton.dataset.phaseOfEdit;
        const editedContent = selectors.humanEditArea.value;
        if (!editedContent.trim()) { 
            showToast('The document content cannot be empty.');
            return;
        }
        const formData = new FormData();
        formData.append('edited_content', editedContent);
        formData.append('phase_of_edit', phaseOfEdit);
        try {
            const response = await fetch(`${API_URL}/projects/${appState.projectId}/resume`, { method: 'POST', body: formData });
            if (!response.ok) throw new Error((await response.json()).detail || 'Failed to resume.');
            selectors.humanInterventionBox.classList.add('hidden');
            if (appState.pollInterval) clearInterval(appState.pollInterval);
            appState.pollInterval = setInterval(pollStatus, 2000);
            showToast('Workflow resumed!', 'success');
        } catch (error) { 
            showToast(`Error resuming project: ${error.message}`); 
        }
    }

    function pollStatus() {
        if (!appState.projectId) {
            clearInterval(appState.pollInterval);
            return;
        };
        fetch(`${API_URL}/projects/${appState.projectId}/status`)
            .then(res => res.ok ? res.json() : Promise.reject('Failed to fetch status'))
            .then(data => {
                const oldData = appState.currentExecutionData;
                appState.currentExecutionData = data;
                
                // ✅ IMPROVED LOGIC: Check for any change in status OR number of logs.
                // This ensures a re-render happens whenever a new agent or critic output is available.
                let needsFullRender = false;
                if (!oldData || oldData.phases.length !== data.phases.length) {
                    needsFullRender = true;
                } else {
                    // Compare the number of log entries for each phase
                    for (let i = 0; i < data.phases.length; i++) {
                        const oldPhase = oldData.phases[i];
                        const newPhase = data.phases[i];
                        if (oldPhase.status !== newPhase.status || oldPhase.details.length !== newPhase.details.length) {
                            needsFullRender = true;
                            break;
                        }
                    }
                }
                
                updateStatus(data.overall_status, data.phases, needsFullRender);
            })
            .catch (error => { 
                console.error("Polling error:", error);
                clearInterval(appState.pollInterval);
                updateStatus('Connection Error');
                showToast('Could not get project status. Check connection.');
            });
    }
    
    function updateStatus(overallStatus, phases = [], isFullRender = false) {
        selectors.projectStatus.textContent = overallStatus;
        // --- THIS IS THE CORRECTED LINE ---
        // ✅ MODIFIED LINE: This now correctly handles detailed statuses like "In Progress - Coding (Reviewing)"
        let statusClass = (overallStatus?.toLowerCase() || 'pending').split(' ')[0];
        if (statusClass === 'in') {
            statusClass = 'inprogress';
        }
     
        selectors.statusIndicator.className = `status-indicator ${statusClass}`;
        
        if (isFullRender) {
            renderTimeline(selectors.timeline, phases, overallStatus);
        } else {
            updateTimelineView(phases, overallStatus);
        }

        const isPaused = overallStatus?.includes('Paused');
        if (isPaused) {
            clearInterval(appState.pollInterval);
            const pausedPhaseName = overallStatus.split(' at ')[1]?.trim();
            const phaseInfo = phases?.find(p => p.phase_name === pausedPhaseName);

            if (phaseInfo && phaseInfo.final_output) {
                selectors.humanInterventionPhase.textContent = pausedPhaseName;
                selectors.humanEditArea.value = phaseInfo.final_output;
                selectors.resumeButton.dataset.phaseOfEdit = pausedPhaseName;
                selectors.humanInterventionBox.classList.remove('hidden');
            } else {
                selectors.humanInterventionBox.classList.add('hidden');
            }
        } else {
            selectors.humanInterventionBox.classList.add('hidden');
        }

        const isFinished = overallStatus === 'Completed' || overallStatus === 'Failed';
        if (isFinished) {
            clearInterval(appState.pollInterval);
            if (!appState.summaryShown) {
                renderExecutionSummary(appState.currentExecutionData);
                appState.summaryShown = true; // Prevents the modal from showing again
            }
        }
        selectors.downloadOutputsBtn.disabled = overallStatus !== 'Completed';
    }

    function startExecution() {
        fetch(`${API_URL}/projects/${appState.projectId}/execute`, { method: 'POST' });
        if (appState.pollInterval) clearInterval(appState.pollInterval);
        appState.pollInterval = setInterval(pollStatus, 2000);
    }
    // In js/main.js

    function createDynamicInput(container, name, label) {
        const template = document.getElementById('dynamic-input-template').cloneNode(true);
        template.removeAttribute('id');
        
        template.querySelector('.dynamic-label').textContent = label;
        
        const modeRadios = template.querySelectorAll('input[type="radio"]');
        modeRadios.forEach(radio => radio.name = `input_mode_${name}`);
        
        const fileInput = template.querySelector('.file-input');
        fileInput.name = `${name}_file`;
        
        const githubInput = template.querySelector('.github-input');
        githubInput.name = `${name}_github_url`;

        const fileDropArea = template.querySelector('.file-drop-area');
        const dropAreaText = fileDropArea.querySelector('p');

        // --- MODIFIED EVENT LISTENER ---
        template.addEventListener('change', (e) => {
            // Handle radio button selection
            if (e.target.type === 'radio') {
                const selectedValue = e.target.value;
                fileDropArea.classList.toggle('hidden', selectedValue !== 'file');
                githubInput.classList.toggle('hidden', selectedValue !== 'github');
            }
            // Handle file input change to show the selected file name
            if (e.target.type === 'file' && e.target.files.length > 0) {
                dropAreaText.textContent = e.target.files[0].name;
                fileDropArea.style.borderColor = 'var(--success-color)';
            }
        });

        container.appendChild(template);
    }
    // PASTE THIS ENTIRE NEW FUNCTION INTO YOUR main.js FILE

    function handleOutputModeSelect(selectedCard) {
        const container = selectedCard.closest('.input-mode-cards');
        const hiddenInput = document.getElementById('output-destination-input');
        const gitHubConfigSection = document.getElementById('github-output-config');
        const pushCheckboxesContainer = document.getElementById('github-push-phases-checkboxes');
        
        // Update card selection UI
        container.querySelector('.mode-card.selected')?.classList.remove('selected');
        selectedCard.classList.add('selected');
        
        const selectedValue = selectedCard.dataset.value;
        hiddenInput.value = selectedValue;
        
        // Show or hide the GitHub-specific input fields
        if (selectedValue === 'github') {
            // Populate artifact selection checkboxes if not already there
            pushCheckboxesContainer.innerHTML = ''; // Clear existing checkboxes

        // --- NEW LOGIC STARTS HERE ---
        // Get the start and end phases selected in Step 2
        const startPhase = document.getElementById('start-phase-input').value;
        const endPhase = document.getElementById('end-phase-input').value;
        
        const startIndex = allPossiblePhases.indexOf(startPhase);
        const endIndex = allPossiblePhases.indexOf(endPhase);

        // Create a new array containing only the phases that will be run
        if (startIndex !== -1 && endIndex !== -1) {
            const selectedPhases = allPossiblePhases.slice(startIndex, endIndex + 1);

            // Create checkboxes only for the selected phases
            selectedPhases.forEach(phase => {
                const label = document.createElement('label');
                label.innerHTML = `<input type="checkbox" name="github_push_phases" value="${phase}" checked><span>${phase}</span>`;
                pushCheckboxesContainer.appendChild(label);
            });
        }
            gitHubConfigSection.classList.remove('hidden');
        } else {
            gitHubConfigSection.classList.add('hidden');
        }
    }

    function setupModalClose(modalElement, closeButton) {
        if (!modalElement) return;
        const close = () => {
            if(modalElement.id === 'project-wizard-modal') {
                closeWizard();
            } else {
                modalElement.classList.add('hidden');
            }
        };
        if (closeButton) {
            closeButton.addEventListener('click', close);
        }
        modalElement.addEventListener('click', (e) => {
            if (e.target === modalElement) {
                close();
            }
        });
    }
    
    function initializeApp() {
        setupEventListeners();
        showView('dashboard');
    }
    function setupEventListeners() {
        // ... (inside the function, with other listeners) ...
        setupModalClose(document.getElementById('summary-modal'), document.getElementById('close-summary-btn'));
        document.getElementById('summary-download-btn').addEventListener('click', handleDownloadAll);
    }
    // --- 5. INITIALIZATION ---
    initializeApp();
        async function handleProjectCardClick(e) {
        // ... (at the top of this function) ...
        appState.summaryShown = false; // Reset the flag
        // ... (rest of the function) ...
    }
    async function handleProjectFormSubmit(e) {
        // ... (at the top of this function) ...
        appState.summaryShown = false; // Reset the flag
        // ... (rest of the function) ...
    }
    
});

