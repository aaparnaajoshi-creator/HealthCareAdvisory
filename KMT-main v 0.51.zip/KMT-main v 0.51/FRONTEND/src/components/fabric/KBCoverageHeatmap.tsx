/**
 * KB Coverage Heatmap - Updated
 * ==============================
 * Shows KB article coverage with semantic-based percentages
 * 
 * Features:
 * - Coverage percentage per CI category
 * - Visual progress bars with color coding
 * - Gap identification with severity levels
 * - Drill-down by sub-category
 * - Actionable recommendations
 */

import React, { useEffect, useState } from "react";
import { getKBCoverageMatrix, getKBCoverageBySubcategory } from "../../api/analyticsApi";
import { LoadingSpinner } from "../common/LoadingSpinner";
import { EmptyState } from "../common/EmptyState";
import {
  ChartBarIcon,
  ExclamationTriangleIcon,
  CheckCircleIcon,
  ChevronDownIcon,
  ChevronRightIcon,
  DocumentTextIcon,
  ExclamationCircleIcon,
} from "@heroicons/react/24/outline";

// =============================================================================
// TYPES
// =============================================================================

interface CoverageData {
  categories: string[];
  incidentCounts: number[];
  kbCoverageCounts: number[];
  coveragePercentages: number[];
  gaps: number[];
  kbArticleCounts: number[];
  totalIncidents: number;
  totalKBArticles: number;
  totalCoveredIncidents: number;
  totalGapIncidents: number;
  overallCoveragePercentage: number;
}

interface SubCategoryData {
  [category: string]: {
    [subCategory: string]: {
      total_incidents: number;
      total_steps: number;
      covered_steps: number;
      avg_coverage_percentage: number;
    };
  };
}

interface KBCoverageHeatmapProps {
  fabricId: string;
}

// =============================================================================
// HELPERS
// =============================================================================

const getCoverageColor = (percentage: number): string => {
  if (percentage >= 80) return "bg-green-500";
  if (percentage >= 60) return "bg-yellow-500";
  if (percentage >= 40) return "bg-orange-500";
  if (percentage > 0) return "bg-red-500";
  return "bg-slate-600";
};

const getCoverageTextColor = (percentage: number): string => {
  if (percentage >= 80) return "text-green-400";
  if (percentage >= 60) return "text-yellow-400";
  if (percentage >= 40) return "text-orange-400";
  if (percentage > 0) return "text-red-400";
  return "text-slate-400";
};

const getCoverageStatus = (percentage: number, kbCount: number): { label: string; color: string; icon: string } => {
  if (kbCount === 0) {
    return { label: "NO KB", color: "text-red-400 bg-red-900/30", icon: "🔴" };
  }
  if (percentage >= 80) {
    return { label: "EXCELLENT", color: "text-green-400 bg-green-900/30", icon: "🟢" };
  }
  if (percentage >= 60) {
    return { label: "GOOD", color: "text-yellow-400 bg-yellow-900/30", icon: "🟡" };
  }
  if (percentage >= 40) {
    return { label: "PARTIAL", color: "text-orange-400 bg-orange-900/30", icon: "🟠" };
  }
  return { label: "LOW", color: "text-red-400 bg-red-900/30", icon: "🔴" };
};

// =============================================================================
// COMPONENT
// =============================================================================

export const KBCoverageHeatmap: React.FC<KBCoverageHeatmapProps> = ({ fabricId }) => {
  const [data, setData] = useState<CoverageData | null>(null);
  const [subCategoryData, setSubCategoryData] = useState<SubCategoryData | null>(null);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState<"gap" | "coverage" | "incidents">("gap");
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set());
  const [viewMode, setViewMode] = useState<"table" | "cards">("table");

  // Load data
  const loadCoverageData = async () => {
    setLoading(true);
    try {
      const [coverage, subCoverage] = await Promise.all([
        getKBCoverageMatrix(fabricId),
        getKBCoverageBySubcategory(fabricId).catch(() => null),
      ]);
      setData(coverage);
      setSubCategoryData(subCoverage);
    } catch (err) {
      console.error("Failed to load KB coverage data", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCoverageData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fabricId]);

  // Sort indices
  const getSortedIndices = () => {
    if (!data) return [];

    const indices = data.categories.map((_, i) => i);

    indices.sort((a, b) => {
      if (sortBy === "gap") {
        // Sort by gap count (descending), then by coverage (ascending)
        const gapDiff = data.gaps[b] - data.gaps[a];
        if (gapDiff !== 0) return gapDiff;
        return data.coveragePercentages[a] - data.coveragePercentages[b];
      } else if (sortBy === "coverage") {
        return data.coveragePercentages[a] - data.coveragePercentages[b];
      } else {
        return data.incidentCounts[b] - data.incidentCounts[a];
      }
    });

    return indices;
  };

  // Toggle category expansion
  const toggleCategory = (category: string) => {
    const newExpanded = new Set(expandedCategories);
    if (newExpanded.has(category)) {
      newExpanded.delete(category);
    } else {
      newExpanded.add(category);
    }
    setExpandedCategories(newExpanded);
  };

  // Loading state
  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  // Empty state
  if (!data || data.categories.length === 0) {
    return (
      <EmptyState
        icon={<ChartBarIcon className="w-16 h-16" />}
        title="No Coverage Data"
        message="KB article coverage will be available after incidents and KB articles are ingested."
      />
    );
  }

  const sortedIndices = getSortedIndices();
  const criticalGaps = sortedIndices.filter((idx) => data.kbArticleCounts[idx] === 0);
  const lowCoverage = sortedIndices.filter(
    (idx) => data.kbArticleCounts[idx] > 0 && data.coveragePercentages[idx] < 50
  );

  return (
    <div className="space-y-6">
      {/* Summary Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="card p-4">
          <div className="text-sm text-slate-400">Total Incidents</div>
          <div className="text-2xl font-bold text-slate-100">{data.totalIncidents}</div>
        </div>
        <div className="card p-4">
          <div className="text-sm text-slate-400">Covered (&gt;50%)</div>
          <div className="text-2xl font-bold text-green-400">{data.totalCoveredIncidents}</div>
        </div>
        <div className="card p-4">
          <div className="text-sm text-slate-400">Gap (&lt;50%)</div>
          <div className="text-2xl font-bold text-red-400">{data.totalGapIncidents}</div>
        </div>
        <div className="card p-4">
          <div className="text-sm text-slate-400">KB Articles</div>
          <div className="text-2xl font-bold text-blue-400">{data.totalKBArticles}</div>
        </div>
        <div className="card p-4">
          <div className="text-sm text-slate-400">Avg Coverage</div>
          <div className={`text-2xl font-bold ${getCoverageTextColor(data.overallCoveragePercentage)}`}>
            {data.overallCoveragePercentage}%
          </div>
        </div>
      </div>

      {/* Coverage Alert */}
      {data.overallCoveragePercentage < 60 && (
        <div className="card p-4 bg-red-900/20 border-red-800">
          <div className="flex items-start space-x-3">
            <ExclamationTriangleIcon className="w-6 h-6 text-red-400 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="text-lg font-semibold text-red-300">Low KB Coverage Detected</h3>
              <p className="text-sm text-red-200 mt-1">
                Only <strong>{data.overallCoveragePercentage}%</strong> average coverage. 
                {criticalGaps.length > 0 && (
                  <span className="ml-1">
                    <strong>{criticalGaps.length} categories</strong> have no KB articles at all.
                  </span>
                )}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Controls */}
      <div className="card p-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          {/* Sort Controls */}
          <div className="flex items-center space-x-2">
            <span className="text-sm text-slate-400">Sort by:</span>
            <div className="flex space-x-1">
              {[
                { key: "gap", label: "Biggest Gap", color: "red" },
                { key: "coverage", label: "Lowest Coverage", color: "yellow" },
                { key: "incidents", label: "Most Incidents", color: "blue" },
              ].map(({ key, label, color }) => (
                <button
                  key={key}
                  onClick={() => setSortBy(key as any)}
                  className={`px-3 py-1.5 rounded text-sm font-medium transition-colors ${
                    sortBy === key
                      ? `bg-${color}-600 text-white`
                      : "bg-slate-700 text-slate-300 hover:bg-slate-600"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* View Mode */}
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setViewMode("table")}
              className={`px-3 py-1.5 rounded text-sm ${
                viewMode === "table" ? "bg-blue-600 text-white" : "bg-slate-700 text-slate-300"
              }`}
            >
              Table
            </button>
            <button
              onClick={() => setViewMode("cards")}
              className={`px-3 py-1.5 rounded text-sm ${
                viewMode === "cards" ? "bg-blue-600 text-white" : "bg-slate-700 text-slate-300"
              }`}
            >
              Cards
            </button>
          </div>
        </div>
      </div>

      {/* Coverage Table */}
      {viewMode === "table" ? (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-slate-800">
                  <th className="text-left p-3 text-sm font-semibold text-slate-300">Category (CI)</th>
                  <th className="text-center p-3 text-sm font-semibold text-slate-300 w-24">Incidents</th>
                  <th className="text-center p-3 text-sm font-semibold text-slate-300 w-24">KB Count</th>
                  <th className="text-center p-3 text-sm font-semibold text-slate-300 w-48">Coverage</th>
                  <th className="text-center p-3 text-sm font-semibold text-slate-300 w-24">Gap</th>
                  <th className="text-center p-3 text-sm font-semibold text-slate-300 w-28">Status</th>
                </tr>
              </thead>
              <tbody>
                {sortedIndices.map((idx) => {
                  const category = data.categories[idx];
                  const incidents = data.incidentCounts[idx];
                  const kbCount = data.kbArticleCounts[idx];
                  const coverage = data.coveragePercentages[idx];
                  const gap = data.gaps[idx];
                  const status = getCoverageStatus(coverage, kbCount);
                  const hasSubCategories = subCategoryData && subCategoryData[category];
                  const isExpanded = expandedCategories.has(category);

                  return (
                    <React.Fragment key={idx}>
                      {/* Main Row */}
                      <tr
                        className={`border-b border-slate-800 hover:bg-slate-800/50 transition-colors ${
                          hasSubCategories ? "cursor-pointer" : ""
                        }`}
                        onClick={() => hasSubCategories && toggleCategory(category)}
                      >
                        <td className="p-3">
                          <div className="flex items-center space-x-2">
                            {hasSubCategories && (
                              <span className="text-slate-400">
                                {isExpanded ? (
                                  <ChevronDownIcon className="w-4 h-4" />
                                ) : (
                                  <ChevronRightIcon className="w-4 h-4" />
                                )}
                              </span>
                            )}
                            <span className="font-medium text-slate-200">{category}</span>
                          </div>
                        </td>
                        <td className="p-3 text-center text-slate-300">{incidents}</td>
                        <td className="p-3 text-center">
                          <span className={kbCount === 0 ? "text-red-400 font-bold" : "text-slate-300"}>
                            {kbCount}
                          </span>
                        </td>
                        <td className="p-3">
                          <div className="flex items-center space-x-2">
                            <div className="flex-1 bg-slate-700 rounded-full h-3 overflow-hidden">
                              <div
                                className={`h-full ${getCoverageColor(coverage)} transition-all duration-500`}
                                style={{ width: `${coverage}%` }}
                              />
                            </div>
                            <span className={`text-sm font-semibold w-12 text-right ${getCoverageTextColor(coverage)}`}>
                              {coverage}%
                            </span>
                          </div>
                        </td>
                        <td className="p-3 text-center">
                          <span className={gap > 0 ? "text-red-400 font-bold" : "text-green-400"}>
                            {gap}
                          </span>
                        </td>
                        <td className="p-3 text-center">
                          <span className={`text-xs px-2 py-1 rounded ${status.color}`}>
                            {status.icon} {status.label}
                          </span>
                        </td>
                      </tr>

                      {/* Sub-category Rows */}
                      {isExpanded && hasSubCategories && (
                        <>
                          {Object.entries(subCategoryData![category]).map(([subCat, subData]) => (
                            <tr
                              key={`${idx}-${subCat}`}
                              className="bg-slate-850 border-b border-slate-800/50"
                            >
                              <td className="p-3 pl-10">
                                <span className="text-slate-400 text-sm">↳ {subCat}</span>
                              </td>
                              <td className="p-3 text-center text-slate-400 text-sm">
                                {subData.total_incidents}
                              </td>
                              <td className="p-3 text-center text-slate-500 text-sm">-</td>
                              <td className="p-3">
                                <div className="flex items-center space-x-2">
                                  <div className="flex-1 bg-slate-700 rounded-full h-2 overflow-hidden">
                                    <div
                                      className={`h-full ${getCoverageColor(subData.avg_coverage_percentage)}`}
                                      style={{ width: `${subData.avg_coverage_percentage}%` }}
                                    />
                                  </div>
                                  <span className={`text-xs w-10 text-right ${getCoverageTextColor(subData.avg_coverage_percentage)}`}>
                                    {subData.avg_coverage_percentage}%
                                  </span>
                                </div>
                              </td>
                              <td className="p-3 text-center text-slate-500 text-sm">-</td>
                              <td className="p-3"></td>
                            </tr>
                          ))}
                        </>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
              <tfoot>
                <tr className="bg-slate-800 border-t-2 border-slate-700">
                  <td className="p-3 font-bold text-slate-100">TOTAL</td>
                  <td className="p-3 text-center font-bold text-slate-100">{data.totalIncidents}</td>
                  <td className="p-3 text-center font-bold text-slate-100">{data.totalKBArticles}</td>
                  <td className="p-3">
                    <div className="flex items-center space-x-2">
                      <div className="flex-1 bg-slate-700 rounded-full h-3 overflow-hidden">
                        <div
                          className={`h-full ${getCoverageColor(data.overallCoveragePercentage)}`}
                          style={{ width: `${data.overallCoveragePercentage}%` }}
                        />
                      </div>
                      <span className={`text-sm font-bold w-12 text-right ${getCoverageTextColor(data.overallCoveragePercentage)}`}>
                        {data.overallCoveragePercentage}%
                      </span>
                    </div>
                  </td>
                  <td className="p-3 text-center font-bold text-red-400">{data.totalGapIncidents}</td>
                  <td className="p-3"></td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      ) : (
        /* Cards View */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {sortedIndices.map((idx) => {
            const category = data.categories[idx];
            const incidents = data.incidentCounts[idx];
            const kbCount = data.kbArticleCounts[idx];
            const coverage = data.coveragePercentages[idx];
            const gap = data.gaps[idx];
            const status = getCoverageStatus(coverage, kbCount);

            return (
              <div key={idx} className="card p-4 hover:border-slate-600 transition-colors">
                <div className="flex items-start justify-between mb-3">
                  <h4 className="font-medium text-slate-200 text-sm leading-tight">
                    {category}
                  </h4>
                  <span className={`text-xs px-2 py-0.5 rounded ${status.color}`}>
                    {status.icon}
                  </span>
                </div>

                {/* Coverage Bar */}
                <div className="mb-3">
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="text-slate-400">Coverage</span>
                    <span className={getCoverageTextColor(coverage)}>{coverage}%</span>
                  </div>
                  <div className="bg-slate-700 rounded-full h-2 overflow-hidden">
                    <div
                      className={`h-full ${getCoverageColor(coverage)}`}
                      style={{ width: `${coverage}%` }}
                    />
                  </div>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div>
                    <div className="text-lg font-bold text-slate-200">{incidents}</div>
                    <div className="text-xs text-slate-500">Incidents</div>
                  </div>
                  <div>
                    <div className={`text-lg font-bold ${kbCount === 0 ? "text-red-400" : "text-slate-200"}`}>
                      {kbCount}
                    </div>
                    <div className="text-xs text-slate-500">KB Articles</div>
                  </div>
                  <div>
                    <div className={`text-lg font-bold ${gap > 0 ? "text-red-400" : "text-green-400"}`}>
                      {gap}
                    </div>
                    <div className="text-xs text-slate-500">Gap</div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Action Items */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Critical Gaps - No KB Articles */}
        <div className="card p-4">
          <h4 className="text-sm font-semibold text-red-300 mb-3 flex items-center">
            <ExclamationCircleIcon className="w-5 h-5 mr-2" />
            Critical: No KB Articles ({criticalGaps.length})
          </h4>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {criticalGaps.length === 0 ? (
              <div className="text-sm text-green-400 flex items-center">
                <CheckCircleIcon className="w-4 h-4 mr-2" />
                All categories have KB articles!
              </div>
            ) : (
              criticalGaps.slice(0, 5).map((idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-2 bg-red-900/20 border border-red-800/50 rounded"
                >
                  <div>
                    <div className="text-sm font-medium text-red-200">
                      {data.categories[idx]}
                    </div>
                    <div className="text-xs text-red-300">
                      {data.incidentCounts[idx]} incidents need KB coverage
                    </div>
                  </div>
                  <DocumentTextIcon className="w-5 h-5 text-red-400" />
                </div>
              ))
            )}
            {criticalGaps.length > 5 && (
              <div className="text-xs text-slate-500 text-center pt-2">
                +{criticalGaps.length - 5} more categories
              </div>
            )}
          </div>
        </div>

        {/* Low Coverage */}
        <div className="card p-4">
          <h4 className="text-sm font-semibold text-orange-300 mb-3 flex items-center">
            <ExclamationTriangleIcon className="w-5 h-5 mr-2" />
            Needs Improvement: Low Coverage ({lowCoverage.length})
          </h4>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {lowCoverage.length === 0 ? (
              <div className="text-sm text-green-400 flex items-center">
                <CheckCircleIcon className="w-4 h-4 mr-2" />
                All categories with KB have good coverage!
              </div>
            ) : (
              lowCoverage.slice(0, 5).map((idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-2 bg-orange-900/20 border border-orange-800/50 rounded"
                >
                  <div>
                    <div className="text-sm font-medium text-orange-200">
                      {data.categories[idx]}
                    </div>
                    <div className="text-xs text-orange-300">
                      {data.kbArticleCounts[idx]} KB articles → {data.coveragePercentages[idx]}% coverage
                    </div>
                  </div>
                  <span className="text-sm font-bold text-orange-400">
                    {data.coveragePercentages[idx]}%
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Recommendations */}
      {(criticalGaps.length > 0 || data.overallCoveragePercentage < 70) && (
        <div className="card p-6 bg-blue-900/20 border-blue-800">
          <h3 className="text-lg font-semibold text-blue-300 mb-3">📋 Recommendations</h3>
          <ul className="space-y-2 text-sm text-blue-200">
            {criticalGaps.length > 0 && (
              <li className="flex items-start">
                <span className="mr-2 text-blue-400">1.</span>
                <span>
                  <strong>Create KB articles</strong> for {criticalGaps.length} categories 
                  with no documentation ({data.categories[criticalGaps[0]]}
                  {criticalGaps.length > 1 && `, ${data.categories[criticalGaps[1]]}`}
                  {criticalGaps.length > 2 && `, and ${criticalGaps.length - 2} more`})
                </span>
              </li>
            )}
            {lowCoverage.length > 0 && (
              <li className="flex items-start">
                <span className="mr-2 text-blue-400">2.</span>
                <span>
                  <strong>Expand existing KB articles</strong> to cover more resolution steps 
                  in {lowCoverage.length} categories with low coverage
                </span>
              </li>
            )}
            <li className="flex items-start">
              <span className="mr-2 text-blue-400">3.</span>
              <span>
                <strong>Target coverage goal:</strong> 80% (currently at {data.overallCoveragePercentage}%)
              </span>
            </li>
          </ul>
        </div>
      )}
    </div>
  );
};

export default KBCoverageHeatmap;
