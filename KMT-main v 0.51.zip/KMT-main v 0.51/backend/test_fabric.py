from app import app, db
from models import IngestedContent, CICategory, GraphNode, Fabric

with app.app_context():
    print('=== DATABASE COUNTS ===')
    print('CI Categories:', CICategory.query.count())
    print('KB Articles:', IngestedContent.query.filter_by(source_type='kb').count())
    print('Incidents:', IngestedContent.query.filter_by(source_type='incident').count())
    print('Graph Nodes:', GraphNode.query.count())
    
    print('\n=== FABRIC STATS ===')
    for f in Fabric.query.all():
        print(f'Fabric: {f.name}')
        print(f'  ID: {f.id}')
        print(f'  documents_count: {f.documents_count}')
        print(f'  graph_nodes: {f.graph_nodes}')
        print(f'  graph_edges: {f.graph_edges}')
        
        # Count records for this fabric
        kb = IngestedContent.query.filter_by(fabric_id=f.id, source_type='kb').count()
        inc = IngestedContent.query.filter_by(fabric_id=f.id, source_type='incident').count()
        nodes = GraphNode.query.filter_by(fabric_id=f.id).count()
        print(f'  Actual KB: {kb}')
        print(f'  Actual Incidents: {inc}')
        print(f'  Actual Nodes: {nodes}')
