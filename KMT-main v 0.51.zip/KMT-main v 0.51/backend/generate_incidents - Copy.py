"""
Generate Synthetic ServiceNow Incident Data Files
Creates realistic incident text files that can be uploaded via the UI
"""

import random
from datetime import datetime, timedelta

# ============= SYNTHETIC DATA DEFINITIONS =============

CATEGORIES = [
    "VPN", "Authentication", "Password", "Network", "Email",
    "Hardware", "Software", "Database", "Server", "Firewall"
]

PRIORITIES = ["P1", "P2", "P3", "P4"]

ERROR_CODES = [
    "ERR_CONNECTION_TIMEOUT", "ERR_AUTH_FAILED", "ERR_NETWORK_UNREACHABLE",
    "ERR_SSL_CERTIFICATE", "ERR_DNS_LOOKUP", "ERR_PORT_BLOCKED",
    "ERROR_ACCESS_DENIED", "ERROR_FILE_NOT_FOUND", "ERROR_MEMORY_LIMIT"
]

# Sample incidents with problems and resolutions
INCIDENT_TEMPLATES = [
    {
        "category": "VPN",
        "short_desc": "Unable to connect to VPN from home",
        "description": "User reports ERR_CONNECTION_TIMEOUT when attempting to connect to corporate VPN from home network. Tried restarting laptop and router with no success. Connection worked fine in office yesterday.",
        "resolution": "Issue was caused by outdated VPN client version 2.1 not compatible with new authentication server. Steps taken:\n1. Uninstalled old VPN client\n2. Downloaded and installed VPN client v3.5 from ServicePortal\n3. Configured new profile with user's credentials\n4. Tested connection - successful\n5. Educated user on auto-update feature\nRefer to KB0056789 for detailed VPN setup guide.",
        "priority": "P2"
    },
    {
        "category": "Email",
        "short_desc": "Cannot send emails - stuck in outbox",
        "description": "All outgoing emails are stuck in Outlook outbox. Receiving emails works fine. User can access webmail without issues. Started happening this morning after Windows update.",
        "resolution": "Problem identified as corrupt Outlook profile after Windows update. Resolution steps:\n1. Backed up user's PST file\n2. Created new Outlook profile\n3. Re-added email account\n4. Imported old emails from backup\n5. Configured send/receive settings\n6. Tested sending test email - successful\nSee KB0056791 for Outlook profile recreation procedure.",
        "priority": "P3"
    },
    {
        "category": "Password",
        "short_desc": "Account locked after multiple failed login attempts",
        "description": "User account locked due to 5 consecutive failed password attempts. User claims to be using correct password. ERR_AUTH_FAILED error appears on login screen.",
        "resolution": "Investigation revealed user was using old password saved in browser autofill. Actual password was changed last week per security policy. Resolution:\n1. Unlocked account in Active Directory\n2. Verified current password with user\n3. Cleared saved passwords in browser\n4. User logged in successfully with current password\n5. Advised user to update password manager\nRefer to KB0056790 for password policy details.",
        "priority": "P2"
    },
    {
        "category": "Network",
        "short_desc": "Intermittent network connectivity in conference room B",
        "description": "Multiple users in conference room B experiencing intermittent network drops. WiFi shows connected but ERR_NETWORK_UNREACHABLE when accessing internal resources. Ethernet connections work fine.",
        "resolution": "Root cause: WiFi access point firmware bug causing DHCP lease issues. Resolution steps:\n1. Identified affected AP (AP-B-02)\n2. Checked AP logs - found DHCP exhaustion errors\n3. Updated AP firmware from v2.4.1 to v2.6.3\n4. Rebooted AP\n5. Cleared DHCP reservations\n6. Tested with multiple devices - all stable\n7. Scheduled firmware updates for all APs\nDocumented in KB0056801 for future reference.",
        "priority": "P2"
    },
    {
        "category": "Hardware",
        "short_desc": "Laptop screen flickering and displaying artifacts",
        "description": "User's laptop screen showing random colored lines and flickering. Issue started after laptop was dropped. External monitor works fine when connected.",
        "resolution": "Hardware diagnosis confirmed damaged LCD cable. Resolution:\n1. Ran hardware diagnostics - LCD cable connection unstable\n2. Ordered replacement LCD cable (part #LCD-789)\n3. Scheduled repair with hardware team\n4. Provided loaner laptop (LOAN-456) for 2 days\n5. Replaced LCD cable\n6. Tested display - no flickering\n7. Returned laptop to user\nHardware RMA documented in system.",
        "priority": "P3"
    },
    {
        "category": "Software",
        "short_desc": "Excel crashing when opening large files",
        "description": "Microsoft Excel crashes (ERROR_MEMORY_LIMIT) when attempting to open files larger than 50MB. Smaller files open normally. Issue started after Office 365 update last week.",
        "resolution": "Issue caused by insufficient memory allocation in Excel settings. Resolution:\n1. Checked system RAM: 8GB available\n2. Reviewed Excel advanced options\n3. Increased data model memory limit to 75%\n4. Disabled hardware graphics acceleration\n5. Added Excel to antivirus exclusion list\n6. Cleared Excel cache\n7. Tested with large file - opens successfully\nSee KB0056795 for Excel performance optimization.",
        "priority": "P3"
    },
    {
        "category": "VPN",
        "short_desc": "VPN disconnects every 30 minutes",
        "description": "VPN connection drops exactly every 30 minutes requiring reconnection. User working remotely on critical project. Issue started yesterday. No error code displayed, just silent disconnect.",
        "resolution": "Problem identified as aggressive timeout setting in VPN concentrator. Resolution:\n1. Checked VPN logs - session timeout set to 1800 seconds\n2. Verified against policy - should be 3600 seconds\n3. Updated VPN concentrator timeout setting\n4. Adjusted keep-alive interval to 300 seconds\n5. User tested for 2 hours - no disconnects\n6. Applied setting to all VPN groups\nConfiguration change documented in KB0056789.",
        "priority": "P1"
    },
    {
        "category": "Database",
        "short_desc": "Application slow - database queries timing out",
        "description": "Customer-facing application responding slowly. Database queries taking 30+ seconds, some timing out with ERR_CONNECTION_TIMEOUT. Affecting 200+ users. Started at 9 AM today.",
        "resolution": "Critical issue: Database table locks due to long-running maintenance job. Resolution:\n1. Identified blocking query in pg_stat_activity\n2. Maintenance job (started at 8:55 AM) still running\n3. Killed hanging maintenance process\n4. Cleared table locks\n5. Reindexed affected tables\n6. Application response time returned to <2 seconds\n7. Rescheduled maintenance for off-hours\n8. Implemented query timeout limits\nPost-mortem documented. Monitoring enhanced.",
        "priority": "P1"
    },
    {
        "category": "Authentication",
        "short_desc": "Multi-factor authentication not sending codes",
        "description": "Users not receiving MFA codes via SMS or email. Can't complete login process. Affects approximately 50 users. Auth server logs show ERROR_ACCESS_DENIED when contacting SMS gateway.",
        "resolution": "MFA gateway API key expired. Resolution:\n1. Checked MFA service logs - API auth failures\n2. Contacted MFA vendor - confirmed expired API key\n3. Generated new API key from vendor portal\n4. Updated API key in MFA server config\n5. Restarted MFA service\n6. Tested with multiple users - codes delivered\n7. Set calendar reminder for key rotation (90 days)\n8. Updated KB0056790 with key rotation procedure\nService restored in 15 minutes.",
        "priority": "P1"
    },
    {
        "category": "Server",
        "short_desc": "Web server returning 502 Bad Gateway errors",
        "description": "Production web server intermittently returning 502 errors. Approximately 30% of requests failing. Started after deployment this morning. Rollback not immediately possible.",
        "resolution": "Issue caused by connection pool exhaustion in new code deployment. Resolution:\n1. Reviewed deployment changes - new DB connection code\n2. Checked application server logs - connection pool maxed out\n3. Identified connection leak (connections not being closed)\n4. Applied hotfix: increased pool size temporarily (50 to 200)\n5. Fixed connection leak in code\n6. Deployed hotfix\n7. Monitored for 1 hour - error rate dropped to 0%\n8. Reduced pool size back to optimal (100)\nCode review process updated to catch connection leaks. KB0056802 created.",
        "priority": "P1"
    },
    {
        "category": "Firewall",
        "short_desc": "Cannot access external vendor portal",
        "description": "Users unable to access vendor portal at https://vendor.example.com. Connection times out with ERR_CONNECTION_TIMEOUT. Internal sites work fine. Vendor confirms portal is operational.",
        "resolution": "Firewall rule blocking traffic to vendor's new IP range. Resolution:\n1. Tested connection from firewall - confirmed block\n2. Reviewed firewall logs - traffic denied by rule FW-234\n3. Contacted vendor - they migrated to new datacenter\n4. New IP range: 198.51.100.0/24\n5. Created firewall rule to allow traffic to new range\n6. Tested connection - successful\n7. Removed old IP rule after confirming migration complete\n8. Updated network documentation\nChange ticket CT-2025-1234 approved and implemented.",
        "priority": "P2"
    },
    {
        "category": "Email",
        "short_desc": "Emails going to spam folder for recipients",
        "description": "Multiple external recipients reporting our emails going to spam. Affects all outgoing mail from domain. Started after DNS changes yesterday. Email deliverability impacted.",
        "resolution": "SPF record misconfigured during DNS migration. Resolution:\n1. Checked email headers from recipient - SPF fail\n2. Reviewed DNS records - SPF record incomplete\n3. Correct SPF: 'v=spf1 include:_spf.google.com ~all'\n4. Found: 'v=spf1 ~all' (missing include)\n5. Updated SPF record in DNS\n6. Waited for propagation (15 minutes)\n7. Tested with mail-tester.com - score improved to 10/10\n8. Verified with external recipients - emails now in inbox\n9. Updated KB0056791 with SPF configuration guide\nDNS change process updated to include validation step.",
        "priority": "P2"
    },
    {
        "category": "Password",
        "short_desc": "Cannot reset password via self-service portal",
        "description": "Password reset portal showing ERROR_FILE_NOT_FOUND when users try to reset passwords. Portal was working yesterday. Users forced to call helpdesk.",
        "resolution": "Certificate expired on password reset portal. Resolution:\n1. Checked portal logs - SSL certificate expired at midnight\n2. Generated new certificate from CA\n3. Installed certificate on portal server\n4. Updated certificate in IIS binding\n5. Restarted IIS service\n6. Tested password reset flow - working\n7. Set up certificate expiration monitoring\n8. Calendar reminder set for next renewal (45 days before expiry)\nKB0056790 updated with certificate renewal procedure.",
        "priority": "P2"
    },
    {
        "category": "Network",
        "short_desc": "Slow file transfer speeds to network share",
        "description": "Users reporting very slow file transfers to network share (\\\\fileserver\\shared). Copying 1GB file taking 30+ minutes. Was taking 2-3 minutes last week.",
        "resolution": "Network switch port negotiated at 100Mbps instead of 1Gbps. Resolution:\n1. Tested file transfer speed - 10MB/s (should be 100MB/s)\n2. Checked switch port status - link at 100Mbps half-duplex\n3. Inspected network cable - found damaged connector\n4. Replaced network cable\n5. Link renegotiated to 1Gbps full-duplex\n6. Tested file transfer - 115MB/s\n7. Checked other ports in same area - all good\nCable testing procedure added to monthly maintenance checklist.",
        "priority": "P3"
    },
    {
        "category": "Software",
        "short_desc": "AutoCAD license server not responding",
        "description": "Engineering team unable to launch AutoCAD. Error message: 'License server not responding'. License server appears to be running. 15 users affected.",
        "resolution": "License server date/time incorrect causing license validation failure. Resolution:\n1. Checked license server status - service running\n2. Reviewed license server logs - date/time errors\n3. Found system clock was 3 days behind\n4. Investigated - NTP service stopped\n5. Restarted NTP service\n6. System clock synchronized\n7. Restarted license server service\n8. Tested AutoCAD launch - successful\n9. All 15 users confirmed working\n10. Added license server to monitoring\nKB0056795 updated with license server troubleshooting steps.",
        "priority": "P2"
    },
    {
        "category": "VPN",
        "short_desc": "VPN error: Certificate validation failed",
        "description": "Users receiving ERR_SSL_CERTIFICATE error when connecting to VPN. VPN was working fine yesterday. Multiple users affected across different locations.",
        "resolution": "VPN server certificate expired overnight. Resolution:\n1. Verified certificate expiration in VPN console\n2. Generated new certificate with 2-year validity\n3. Installed new certificate on VPN concentrator\n4. Updated certificate chain\n5. Restarted VPN service\n6. Tested connections from multiple clients - all successful\n7. Notified users via email\n8. Set up automated certificate renewal for future\nIncident prevented by implementing certificate monitoring. See KB0056789.",
        "priority": "P1"
    },
    {
        "category": "Email",
        "short_desc": "Outlook freezes when searching emails",
        "description": "Outlook becomes unresponsive when using search function. Search index appears to be corrupted. Issue affects multiple users after recent Windows update.",
        "resolution": "Windows Search index corruption after update. Resolution:\n1. Stopped Windows Search service\n2. Deleted search index files from %ProgramData%\\Microsoft\\Search\n3. Restarted Windows Search service\n4. Rebuilt Outlook search index (Settings > Search > Indexing Options)\n5. Waited 30 minutes for reindexing\n6. Tested search functionality - working smoothly\n7. Applied fix to other affected users\nDocumented in KB0056791 for future reference.",
        "priority": "P3"
    },
    {
        "category": "Authentication",
        "short_desc": "Single sign-on failing for cloud applications",
        "description": "Users unable to access cloud applications via SSO. Getting ERROR_ACCESS_DENIED. Direct login with password works. Started affecting users this morning.",
        "resolution": "SAML certificate expired on identity provider. Resolution:\n1. Checked IdP configuration - SAML signing certificate expired\n2. Generated new SAML certificate\n3. Updated certificate in IdP\n4. Updated certificate thumbprint in all connected applications\n5. Tested SSO flow - successful\n6. Verified with 5 different applications\n7. Documented certificate rotation procedure\n8. Set up 30-day advance expiration alerts\nRefer to KB0056790 for SSO troubleshooting guide.",
        "priority": "P1"
    },
    {
        "category": "Network",
        "short_desc": "DNS resolution failing for internal domains",
        "description": "Unable to resolve internal domain names (company.local). External DNS working fine. ERR_DNS_LOOKUP error in browsers. Affects entire building.",
        "resolution": "Primary DNS server offline due to failed Windows update. Resolution:\n1. Verified DNS server unresponsive\n2. Accessed server console - stuck at Windows update screen\n3. Performed safe mode boot\n4. Rolled back problematic update (KB5034441)\n5. DNS service started automatically\n6. Verified DNS resolution working\n7. Configured secondary DNS for redundancy\n8. Added DNS servers to monitoring\nRefer to KB0056801 for DNS troubleshooting procedures.",
        "priority": "P1"
    },
    {
        "category": "Hardware",
        "short_desc": "Printer not responding - print jobs stuck in queue",
        "description": "Network printer not processing print jobs. Queue shows jobs as 'Error - Printing'. Printer displays ready status. Multiple users affected.",
        "resolution": "Print spooler service hung on print server. Resolution:\n1. Checked print server - high CPU usage on spooler process\n2. Stopped print spooler service\n3. Cleared print queue folder (C:\\Windows\\System32\\spool\\PRINTERS)\n4. Started print spooler service\n5. Restarted printer\n6. Tested print job - successful\n7. Monitored for 1 hour - no issues\n8. Scheduled weekly spooler service restart\nPrint server performance monitoring implemented.",
        "priority": "P3"
    }
]

def generate_incident_number():
    """Generate random incident number"""
    return f"INC{random.randint(1000000, 9999999)}"

def generate_dates():
    """Generate random created and resolved dates"""
    days_ago = random.randint(1, 180)
    created = datetime.now() - timedelta(days=days_ago)
    resolved = created + timedelta(hours=random.randint(1, 72))
    return created, resolved

def create_incident_file(num_incidents=50, output_file="ServiceNow_Incidents.txt"):
    """Create a text file with synthetic incidents"""
    
    print(f"🔄 Generating {num_incidents} synthetic incidents...")
    
    with open(output_file, 'w', encoding='utf-8') as f:
        # Header
        f.write("=" * 80 + "\n")
        f.write("SERVICENOW INCIDENT RECORDS - SYNTHETIC DATA\n")
        f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Total Incidents: {num_incidents}\n")
        f.write("=" * 80 + "\n\n")
        
        for i in range(num_incidents):
            template = random.choice(INCIDENT_TEMPLATES)
            inc_number = generate_incident_number()
            created, resolved = generate_dates()
            
            # Add some variation - randomly reference KB articles
            resolution = template['resolution']
            if random.random() < 0.3 and 'KB' not in resolution:
                kb_ref = f"KB{random.randint(56789, 56810)}"
                resolution += f"\n\nRefer to {kb_ref} for additional information."
            
            # Randomly reference other incidents
            description = template['description']
            if random.random() < 0.2:
                other_inc = generate_incident_number()
                description += f" Similar issue reported in {other_inc}."
            
            # Write incident
            f.write("-" * 80 + "\n")
            f.write(f"INCIDENT NUMBER: {inc_number}\n")
            f.write(f"CATEGORY: {template['category']}\n")
            f.write(f"PRIORITY: {template['priority']}\n")
            f.write(f"STATE: Resolved\n")
            f.write(f"CREATED: {created.strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"RESOLVED: {resolved.strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"\nSHORT DESCRIPTION:\n{template['short_desc']}\n")
            f.write(f"\nDESCRIPTION:\n{description}\n")
            f.write(f"\nRESOLUTION:\n{resolution}\n")
            f.write("-" * 80 + "\n\n")
            
            if (i + 1) % 10 == 0:
                print(f"   Generated {i + 1}/{num_incidents} incidents...")
    
    print(f"✅ Successfully created {output_file}")
    print(f"   File contains {num_incidents} incidents")
    print(f"   File size: {round(os.path.getsize(output_file) / 1024, 2)} KB")

if __name__ == '__main__':
    import os
    import sys
    
    num_incidents = int(sys.argv[1]) if len(sys.argv) > 1 else 50
    output_file = sys.argv[2] if len(sys.argv) > 2 else "ServiceNow_Incidents.txt"
    
    create_incident_file(num_incidents, output_file)
    print(f"\n📁 Ready to upload! Use this file in your fabric creation wizard.")
