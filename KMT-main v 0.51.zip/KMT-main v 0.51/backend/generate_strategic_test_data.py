"""
Strategic Incident & KB Article Generator
Creates data with intentional coverage gaps to demonstrate heatmap value

This generator lets you:
1. Choose which categories to create KB articles for
2. Control how many incidents per category
3. Create realistic gaps showing where KB articles are needed
"""

import random
from datetime import datetime, timedelta

# ============= CONFIGURATION =============

# Categories where you WANT good KB coverage (will create KB articles)
CATEGORIES_WITH_KB = [
    "VPN",           # Create KB articles
    "Password",      # Create KB articles
    "Email",         # Create KB articles
]

# Categories where you WANT gaps (will NOT create KB articles initially)
CATEGORIES_WITH_GAPS = [
    "Network",       # NO KB articles - will show as gap!
    "Hardware",      # NO KB articles - will show as gap!
    "Authentication",# NO KB articles - will show as gap!
]

# Categories with PARTIAL coverage (create fewer KB articles than needed)
CATEGORIES_PARTIAL = [
    "Software",      # Only 1 KB article for many incidents
    "Database",      # Only 1 KB article for many incidents
]

# All categories
ALL_CATEGORIES = CATEGORIES_WITH_KB + CATEGORIES_WITH_GAPS + CATEGORIES_PARTIAL

# How many incidents to generate per category
INCIDENTS_PER_CATEGORY = {
    "VPN": 20,           # 20 incidents, good KB coverage
    "Password": 15,      # 15 incidents, good KB coverage
    "Email": 15,         # 15 incidents, good KB coverage
    "Network": 25,       # 25 incidents, NO KB coverage - BIG GAP!
    "Hardware": 18,      # 18 incidents, NO KB coverage - gap!
    "Authentication": 20,# 20 incidents, NO KB coverage - gap!
    "Software": 12,      # 12 incidents, only 1 KB - poor coverage
    "Database": 10,      # 10 incidents, only 1 KB - poor coverage
    "Server": 8,         # 8 incidents, maybe 1 KB
    "Firewall": 5,       # 5 incidents, maybe 1 KB
}

# KB articles per category (controls coverage)
KB_ARTICLES_PER_CATEGORY = {
    "VPN": 3,            # Good coverage: 3 KB articles for 20 incidents
    "Password": 2,       # Good coverage: 2 KB articles for 15 incidents
    "Email": 2,          # Good coverage: 2 KB articles for 15 incidents
    "Network": 0,        # GAP: 0 KB articles for 25 incidents!
    "Hardware": 0,       # GAP: 0 KB articles for 18 incidents!
    "Authentication": 0, # GAP: 0 KB articles for 20 incidents!
    "Software": 1,       # Poor: 1 KB for 12 incidents
    "Database": 1,       # Poor: 1 KB for 10 incidents
    "Server": 1,         # Okay: 1 KB for 8 incidents
    "Firewall": 1,       # Okay: 1 KB for 5 incidents
}

# ============= KB ARTICLE TEMPLATES =============

KB_TEMPLATES_BY_CATEGORY = {
    "VPN": [
        {
            "title": "VPN Connection Troubleshooting Guide",
            "problems": ["ERR_CONNECTION_TIMEOUT", "Cannot connect to VPN", "VPN client crashes"],
            "solutions": ["Check firewall", "Update VPN client", "Reset network adapter"]
        },
        {
            "title": "VPN Setup for Remote Workers",
            "problems": ["Installation failed", "Configuration errors", "Certificate issues"],
            "solutions": ["Download latest client", "Import certificate", "Configure settings"]
        },
        {
            "title": "VPN Performance Optimization",
            "problems": ["Slow VPN speed", "Disconnects frequently", "High latency"],
            "solutions": ["Switch protocols", "Adjust MTU", "Use wired connection"]
        }
    ],
    "Password": [
        {
            "title": "Password Reset Self-Service Guide",
            "problems": ["Forgot password", "Account locked", "Password expired"],
            "solutions": ["Use reset portal", "Answer security questions", "Contact IT"]
        },
        {
            "title": "Account Security and MFA Setup",
            "problems": ["Enable MFA", "Lost MFA device", "Cannot receive codes"],
            "solutions": ["Enroll in MFA", "Use backup codes", "Contact IT for reset"]
        }
    ],
    "Email": [
        {
            "title": "Outlook Configuration and Setup",
            "problems": ["Cannot send email", "Cannot receive", "Attachment too large"],
            "solutions": ["Check SMTP settings", "Verify credentials", "Compress attachments"]
        },
        {
            "title": "Email Delivery Issues Resolution",
            "problems": ["Email bounced", "Delayed delivery", "Spam folder"],
            "solutions": ["Check address", "Verify not blacklisted", "Review spam settings"]
        }
    ],
    "Software": [
        {
            "title": "Common Software Installation Issues",
            "problems": ["Installation failed", "License error", "Compatibility"],
            "solutions": ["Run as admin", "Check requirements", "Verify license"]
        }
    ],
    "Database": [
        {
            "title": "Database Connection Troubleshooting",
            "problems": ["Connection timeout", "Authentication failed", "Slow queries"],
            "solutions": ["Check connection string", "Verify credentials", "Optimize queries"]
        }
    ],
    "Server": [
        {
            "title": "Server Access and Connectivity",
            "problems": ["Cannot connect", "Permission denied", "Timeout"],
            "solutions": ["Check network", "Verify permissions", "Test connectivity"]
        }
    ],
    "Firewall": [
        {
            "title": "Firewall Rule Configuration Guide",
            "problems": ["Port blocked", "Application blocked", "Website blocked"],
            "solutions": ["Submit request", "Provide justification", "Contact security"]
        }
    ]
}

# ============= INCIDENT TEMPLATES =============

INCIDENT_TEMPLATES_BY_CATEGORY = {
    "VPN": [
        ("Cannot connect to VPN from home", "ERR_CONNECTION_TIMEOUT when connecting to VPN"),
        ("VPN disconnects every 30 minutes", "VPN connection drops requiring reconnection"),
        ("VPN client won't install", "Installation fails with error code"),
        ("Slow VPN performance", "VPN connection very slow compared to office"),
        ("VPN authentication fails", "ERR_AUTH_FAILED when entering credentials"),
    ],
    "Password": [
        ("Account locked after failed attempts", "Multiple password failures locked account"),
        ("Forgot password need reset", "Cannot remember password for login"),
        ("Password expired notification", "System says password expired"),
        ("Cannot set new password", "New password doesn't meet requirements"),
        ("MFA not sending codes", "Not receiving authentication codes"),
    ],
    "Email": [
        ("Cannot send emails stuck in outbox", "All emails stuck not sending"),
        ("Not receiving emails", "Emails not arriving in inbox"),
        ("Outlook freezes when searching", "Search makes Outlook unresponsive"),
        ("Attachment too large error", "Cannot send files over 10MB"),
        ("Email account setup failed", "Cannot configure email account"),
    ],
    "Network": [
        ("No internet connection", "Cannot access internet or internal resources"),
        ("WiFi keeps disconnecting", "Wireless connection drops constantly"),
        ("Slow network speed", "Very slow file transfers and downloads"),
        ("Cannot access file shares", "Network drives not accessible"),
        ("DNS resolution failing", "ERR_DNS_LOOKUP for all websites"),
        ("Cannot ping gateway", "No network connectivity"),
        ("Ethernet port not working", "Wired connection has no link"),
    ],
    "Hardware": [
        ("Laptop won't turn on", "No power when pressing power button"),
        ("Monitor not displaying", "Black screen but computer on"),
        ("Keyboard keys not working", "Several keys unresponsive"),
        ("Mouse cursor jumping", "Mouse behaving erratically"),
        ("Printer not printing", "Print jobs stuck in queue"),
        ("Computer overheating", "Laptop very hot fans loud"),
    ],
    "Authentication": [
        ("SSO not working", "Single sign-on fails for all apps"),
        ("Cannot login to portal", "ERROR_ACCESS_DENIED on login"),
        ("MFA authentication failed", "Multi-factor auth not accepting codes"),
        ("Token expired error", "Session token expired immediately"),
        ("LDAP authentication slow", "Login takes 2+ minutes"),
    ],
    "Software": [
        ("Application won't start", "Program crashes on startup"),
        ("Software license expired", "License validation failed"),
        ("Update failed", "Cannot install software updates"),
        ("Features missing after update", "Toolbar disappeared after update"),
        ("Excel crashing with large files", "ERROR_MEMORY_LIMIT in Excel"),
    ],
    "Database": [
        ("Database connection timeout", "Application cannot reach database"),
        ("Query very slow", "Report takes 10+ minutes to run"),
        ("Database locked", "Cannot write to database"),
        ("Connection pool exhausted", "Too many connections error"),
    ],
    "Server": [
        ("Cannot access file server", "File shares not accessible"),
        ("Web server 502 errors", "Website returning gateway errors"),
        ("Application server down", "Service not responding"),
    ],
    "Firewall": [
        ("Cannot access external site", "Vendor portal blocked"),
        ("Port blocked by firewall", "Application cannot connect"),
        ("VPN blocked on network", "Firewall blocking VPN traffic"),
    ]
}

# ============= GENERATOR FUNCTIONS =============

def generate_kb_articles(starting_number=56789):
    """Generate KB articles based on configuration"""
    kb_articles = []
    current_number = starting_number
    
    for category in ALL_CATEGORIES:
        count = KB_ARTICLES_PER_CATEGORY.get(category, 0)
        templates = KB_TEMPLATES_BY_CATEGORY.get(category, [])
        
        for i in range(min(count, len(templates))):
            template = templates[i]
            kb_number = f"KB{current_number:07d}"
            
            kb_articles.append({
                "number": kb_number,
                "category": category,
                "template": template,
                "title": template["title"]
            })
            
            current_number += 1
    
    return kb_articles, current_number

def generate_incidents(kb_articles):
    """Generate incidents with controlled KB references"""
    incidents = []
    incident_num = 1000000
    
    # Create KB lookup by category
    kb_by_category = {}
    for kb in kb_articles:
        cat = kb["category"]
        if cat not in kb_by_category:
            kb_by_category[cat] = []
        kb_by_category[cat].append(kb["number"])
    
    for category in ALL_CATEGORIES:
        count = INCIDENTS_PER_CATEGORY.get(category, 10)
        templates = INCIDENT_TEMPLATES_BY_CATEGORY.get(category, [])
        kb_list = kb_by_category.get(category, [])
        
        for i in range(count):
            # Pick random template
            if templates:
                short_desc, description = random.choice(templates)
            else:
                short_desc = f"{category} issue reported"
                description = f"User experiencing {category.lower()} problems"
            
            inc_number = f"INC{incident_num:07d}"
            incident_num += 1
            
            # Create resolution
            # If KB articles exist for this category, reference them sometimes
            if kb_list and random.random() < 0.7:  # 70% of incidents reference KB if available
                referenced_kb = random.choice(kb_list)
                resolution = f"Issue resolved following steps in {referenced_kb}. "
                resolution += "User able to work normally after applying fix."
            else:
                # No KB reference - this creates the gap!
                resolution = "Resolved through manual troubleshooting. "
                resolution += "Steps documented in ticket notes."
            
            incidents.append({
                "number": inc_number,
                "category": category,
                "short_desc": short_desc,
                "description": description,
                "resolution": resolution,
                "priority": random.choice(["P1", "P2", "P3"]),
                "created": datetime.now() - timedelta(days=random.randint(1, 90)),
                "resolved": datetime.now() - timedelta(days=random.randint(0, 85))
            })
    
    return incidents

def write_kb_articles_file(kb_articles, filename="KB_Articles_Strategic.txt"):
    """Write KB articles to file"""
    with open(filename, 'w', encoding='utf-8') as f:
        f.write("=" * 80 + "\n")
        f.write("KNOWLEDGE BASE ARTICLES - STRATEGIC TEST DATA\n")
        f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Total Articles: {len(kb_articles)}\n")
        f.write("=" * 80 + "\n\n")
        
        for kb in kb_articles:
            template = kb["template"]
            
            f.write("=" * 80 + "\n")
            f.write(f"KB ARTICLE: {kb['number']}\n")
            f.write(f"CATEGORY: {kb['category']}\n")
            f.write(f"TITLE: {template['title']}\n")
            f.write(f"PUBLISHED: {datetime.now().strftime('%Y-%m-%d')}\n")
            f.write("=" * 80 + "\n\n")
            
            # Write content
            f.write(f"# {template['title']}\n\n")
            f.write(f"## Category: {kb['category']}\n")
            f.write(f"## KB Number: {kb['number']}\n\n")
            
            f.write("## Common Problems\n\n")
            for problem in template['problems']:
                f.write(f"- {problem}\n")
            
            f.write("\n## Solutions\n\n")
            for i, solution in enumerate(template['solutions'], 1):
                f.write(f"{i}. {solution}\n")
            
            f.write("\n## Step-by-Step Guide\n\n")
            f.write("1. Identify the exact error or symptom\n")
            f.write("2. Follow troubleshooting steps above\n")
            f.write("3. Test the solution\n")
            f.write("4. Contact IT Support if issue persists\n\n")
            
            f.write("## Support Contact\n")
            f.write("- Email: itsupport@company.com\n")
            f.write("- Phone: (555) 123-4567\n\n")
            f.write(f"Last Updated: {datetime.now().strftime('%B %Y')}\n")
            f.write("\n\n")

def write_incidents_file(incidents, filename="Incidents_Strategic.txt"):
    """Write incidents to file"""
    with open(filename, 'w', encoding='utf-8') as f:
        f.write("=" * 80 + "\n")
        f.write("INCIDENT RECORDS - STRATEGIC TEST DATA\n")
        f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Total Incidents: {len(incidents)}\n")
        f.write("=" * 80 + "\n\n")
        
        for inc in incidents:
            f.write("-" * 80 + "\n")
            f.write(f"INCIDENT NUMBER: {inc['number']}\n")
            f.write(f"CATEGORY: {inc['category']}\n")
            f.write(f"PRIORITY: {inc['priority']}\n")
            f.write(f"STATE: Resolved\n")
            f.write(f"CREATED: {inc['created'].strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"RESOLVED: {inc['resolved'].strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"\nSHORT DESCRIPTION:\n{inc['short_desc']}\n")
            f.write(f"\nDESCRIPTION:\n{inc['description']}\n")
            f.write(f"\nRESOLUTION:\n{inc['resolution']}\n")
            f.write("-" * 80 + "\n\n")

def print_coverage_report(kb_articles, incidents):
    """Print expected coverage report"""
    print("\n" + "=" * 80)
    print("EXPECTED HEATMAP COVERAGE")
    print("=" * 80)
    
    kb_by_cat = {}
    for kb in kb_articles:
        cat = kb["category"]
        kb_by_cat[cat] = kb_by_cat.get(cat, 0) + 1
    
    inc_by_cat = {}
    for inc in incidents:
        cat = inc["category"]
        inc_by_cat[cat] = inc_by_cat.get(cat, 0) + 1
    
    inc_with_kb = {}
    for inc in incidents:
        cat = inc["category"]
        if "KB" in inc["resolution"]:
            inc_with_kb[cat] = inc_with_kb.get(cat, 0) + 1
    
    print(f"\n{'Category':<15} {'Incidents':<12} {'With KB':<10} {'Gap':<8} {'KB Cnt':<8} {'Coverage':<10} Status")
    print("-" * 80)
    
    for cat in ALL_CATEGORIES:
        total_inc = inc_by_cat.get(cat, 0)
        covered = inc_with_kb.get(cat, 0)
        gap = total_inc - covered
        kb_count = kb_by_cat.get(cat, 0)
        coverage = (covered / total_inc * 100) if total_inc > 0 else 0
        
        if coverage >= 70:
            status = "🟢 GOOD"
        elif coverage >= 40:
            status = "🟡 MEDIUM"
        elif coverage > 0:
            status = "🟠 POOR"
        else:
            status = "🔴 CRITICAL"
        
        print(f"{cat:<15} {total_inc:<12} {covered:<10} {gap:<8} {kb_count:<8} {coverage:>6.1f}%   {status}")
    
    print("-" * 80)
    total_incidents = sum(inc_by_cat.values())
    total_covered = sum(inc_with_kb.values())
    total_gap = total_incidents - total_covered
    overall_coverage = (total_covered / total_incidents * 100) if total_incidents > 0 else 0
    
    print(f"{'TOTAL':<15} {total_incidents:<12} {total_covered:<10} {total_gap:<8} {len(kb_articles):<8} {overall_coverage:>6.1f}%")
    print("=" * 80)

def main():
    print("🎯 Strategic Test Data Generator")
    print("=" * 80)
    print("\nThis generator creates data with intentional gaps to demonstrate the heatmap:\n")
    
    print("GOOD COVERAGE (will show GREEN/YELLOW):")
    for cat in CATEGORIES_WITH_KB:
        print(f"  ✓ {cat}")
    
    print("\nCRITICAL GAPS (will show RED - NO KB ARTICLES):")
    for cat in CATEGORIES_WITH_GAPS:
        print(f"  ✗ {cat}")
    
    print("\nPOOR COVERAGE (will show ORANGE - few KB articles):")
    for cat in CATEGORIES_PARTIAL:
        print(f"  ⚠ {cat}")
    
    print("\n" + "=" * 80)
    input("\nPress Enter to generate files...")
    
    # Generate KB articles
    print("\n🔄 Generating KB articles...")
    kb_articles, next_number = generate_kb_articles()
    print(f"   Generated {len(kb_articles)} KB articles")
    
    # Generate incidents
    print("\n🔄 Generating incidents...")
    incidents = generate_incidents(kb_articles)
    print(f"   Generated {len(incidents)} incidents")
    
    # Write files
    print("\n📁 Writing files...")
    write_kb_articles_file(kb_articles, "KB_Articles_Strategic.txt")
    print("   ✓ KB_Articles_Strategic.txt")
    
    write_incidents_file(incidents, "Incidents_Strategic.txt")
    print("   ✓ Incidents_Strategic.txt")
    
    # Print expected results
    print_coverage_report(kb_articles, incidents)
    
    print("\n✅ Files generated successfully!")
    print("\n📝 Next Steps:")
    print("1. Upload KB_Articles_Strategic.txt to your fabric")
    print("2. Upload Incidents_Strategic.txt to your fabric")
    print("3. Build the fabric")
    print("4. View Knowledge Graph → KB Coverage Heatmap")
    print("5. You should see:")
    print("   🔴 Network, Hardware, Authentication with large gaps")
    print("   🟠 Software, Database with poor coverage")
    print("   🟢 VPN, Password, Email with good coverage")
    print("\n🎯 This demonstrates the value of the heatmap for identifying gaps!")

if __name__ == '__main__':
    import os
    main()
