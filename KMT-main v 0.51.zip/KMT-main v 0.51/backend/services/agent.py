﻿# Udate for v 0.5
# Improved ChatAgent with Memory, Query Rewriting, and Re-ranking
# Replace your existing agent.py with this file

import os
import re
from typing import TypedDict, List, Optional
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_chroma import Chroma
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langgraph.graph import StateGraph, END
import chromadb
from config import Config


# =============================================================================
# STATE DEFINITION
# =============================================================================

class AgentState(TypedDict):
    question: str
    conversation_history: List[dict]  # NEW: Conversation memory
    rewritten_query: str              # NEW: Query after rewriting
    context: List[str]
    ranked_documents: List[dict]      # NEW: Re-ranked documents
    answer: str
    sources: List[dict]


# =============================================================================
# IMPROVED CHAT AGENT
# =============================================================================

class ChatAgent:
    """
    Improved RAG Agent with:
    - Conversation Memory
    - Query Rewriting
    - Hybrid Retrieval
    - Re-ranking
    - Better Source Links
    - Improved Prompts
    """
    
    def __init__(self, collection_name: str, model_name: str = "gpt-4", 
                 servicenow_instance: str = None):
        """
        Initialize the ChatAgent.
        
        Args:
            collection_name: ChromaDB collection name
            model_name: LLM model to use
            servicenow_instance: ServiceNow instance URL for generating links
        """
        # Store ServiceNow instance for link generation
        self.servicenow_instance = servicenow_instance or Config.SERVICENOW_INSTANCE_URL
        
        # 1. Setup Embeddings
        self.embeddings = OpenAIEmbeddings(
            model="text-embedding-3-large",
            openai_api_key=Config.OPENAI_API_KEY
        )
        
        # 2. Setup ChromaDB
        chroma_client = chromadb.PersistentClient(path=Config.CHROMA_DB_PATH)
        
        self.vectorstore = Chroma(
            client=chroma_client,
            collection_name=collection_name,
            embedding_function=self.embeddings,
        )
        
        # 3. Setup LLMs
        # Main LLM for generation
        self.llm = ChatOpenAI(
            model=model_name, 
            temperature=0.7,
            openai_api_key=Config.OPENAI_API_KEY
        )
        
        # Fast LLM for query rewriting and re-ranking
        self.fast_llm = ChatOpenAI(
            model="gpt-4o-mini",
            temperature=0.0,
            openai_api_key=Config.OPENAI_API_KEY
        )
        
        # 4. Setup Retriever with more documents for re-ranking
        self.retriever = self.vectorstore.as_retriever(
            search_kwargs={"k": 10}  # Retrieve more, re-rank later
        )
    
    # =========================================================================
    # NODE 1: QUERY REWRITING
    # =========================================================================
    
    def rewrite_query(self, state: AgentState) -> dict:
        """
        Rewrite the user query to improve retrieval quality.
        
        This step:
        - Expands acronyms (VPN, SSO, AD, etc.)
        - Adds synonyms
        - Incorporates conversation context
        - Makes the query more specific
        """
        question = state["question"]
        history = state.get("conversation_history", [])
        
        # Build conversation context for follow-up questions
        history_context = ""
        if history:
            recent_history = history[-3:]  # Last 3 exchanges
            history_parts = []
            for msg in recent_history:
                role = "User" if msg.get("role") == "user" else "Assistant"
                content = msg.get("content", "")[:200]  # Truncate long messages
                history_parts.append(f"{role}: {content}")
            history_context = "\n".join(history_parts)
        
        rewrite_prompt = ChatPromptTemplate.from_template("""You are a query rewriting assistant for an IT Service Operations knowledge base.

Your task is to rewrite the user's question to improve search results.

Rules:
1. Expand common IT acronyms (VPN=Virtual Private Network, SSO=Single Sign-On, AD=Active Directory, MFA=Multi-Factor Authentication, etc.)
2. Add relevant synonyms in parentheses
3. If this is a follow-up question, incorporate context from the conversation
4. Keep the rewritten query concise but comprehensive
5. Focus on the key technical terms and issue description

{history_section}

Original Question: {question}

Rewritten Query (just the query, no explanation):""")
        
        history_section = f"Recent Conversation:\n{history_context}" if history_context else ""
        
        try:
            chain = rewrite_prompt | self.fast_llm | StrOutputParser()
            rewritten = chain.invoke({
                "question": question,
                "history_section": history_section
            })
            
            # Clean up the rewritten query
            rewritten = rewritten.strip().strip('"').strip("'")
            
            print(f"[QueryRewrite] Original: {question}")
            print(f"[QueryRewrite] Rewritten: {rewritten}")
            
            return {"rewritten_query": rewritten}
        except Exception as e:
            print(f"[QueryRewrite] Error: {e}, using original query")
            return {"rewritten_query": question}
    
    # =========================================================================
    # NODE 2: RETRIEVAL
    # =========================================================================
    
    def retrieve(self, state: AgentState) -> dict:
        """
        Retrieve documents using the rewritten query.
        """
        # Use rewritten query if available, otherwise original
        query = state.get("rewritten_query") or state["question"]
        
        try:
            documents = self.retriever.invoke(query)
            
            # Extract content and metadata
            context = []
            sources = []
            
            for doc in documents:
                content = doc.page_content
                meta = doc.metadata
                
                # Extract source ID and generate proper link
                source_id = meta.get("source", "Unknown")
                source_link = self._generate_source_link(source_id, meta)
                source_title = self._extract_title(source_id, content, meta)
                
                context.append(content)
                sources.append({
                    "id": source_id,
                    "title": source_title,
                    "snippet": content[:200] + "..." if len(content) > 200 else content,
                    "link": source_link,
                    "content": content,  # Full content for re-ranking
                    "metadata": meta
                })
            
            print(f"[Retrieve] Found {len(documents)} documents")
            
            return {"context": context, "sources": sources}
        
        except Exception as e:
            print(f"[Retrieve] Error: {e}")
            return {"context": [], "sources": []}
    
    # =========================================================================
    # NODE 3: RE-RANKING
    # =========================================================================
    
    def rerank(self, state: AgentState) -> dict:
        """
        Re-rank retrieved documents by relevance to the query.
        
        Uses LLM to score each document's relevance.
        """
        question = state["question"]
        sources = state.get("sources", [])
        
        if not sources or len(sources) <= 3:
            # Not enough documents to re-rank
            return {"ranked_documents": sources[:5], "sources": sources[:5]}
        
        rerank_prompt = ChatPromptTemplate.from_template("""Score how relevant this document is to answering the question.

Question: {question}

Document:
{document}

Score from 0-10 (10 = highly relevant, 0 = not relevant):
Just respond with a number.""")
        
        scored_docs = []
        
        for source in sources:
            try:
                chain = rerank_prompt | self.fast_llm | StrOutputParser()
                score_str = chain.invoke({
                    "question": question,
                    "document": source.get("content", source.get("snippet", ""))[:500]
                })
                
                # Extract score
                score = float(re.search(r'\d+\.?\d*', score_str).group())
                scored_docs.append((source, score))
                
            except Exception as e:
                print(f"[Rerank] Error scoring document: {e}")
                scored_docs.append((source, 5.0))  # Default middle score
        
        # Sort by score descending and take top 5
        scored_docs.sort(key=lambda x: x[1], reverse=True)
        top_docs = [doc for doc, score in scored_docs[:5]]
        
        print(f"[Rerank] Top scores: {[f'{s:.1f}' for _, s in scored_docs[:5]]}")
        
        # Update context with re-ranked documents
        new_context = [doc.get("content", doc.get("snippet", "")) for doc in top_docs]
        
        return {
            "ranked_documents": top_docs,
            "sources": top_docs,
            "context": new_context
        }
    
    # =========================================================================
    # NODE 4: GENERATION
    # =========================================================================
    
    def generate(self, state: AgentState) -> dict:
        """
        Generate answer using improved RAG prompt with conversation context.
        """
        context_str = "\n\n---\n\n".join(state["context"])
        question = state["question"]
        history = state.get("conversation_history", [])
        sources = state.get("sources", [])
        
        # Build conversation history section
        history_section = ""
        if history:
            recent_history = history[-4:]  # Last 4 messages
            history_parts = []
            for msg in recent_history:
                role = "User" if msg.get("role") == "user" else "Assistant"
                content = msg.get("content", "")
                # Truncate very long messages
                if len(content) > 500:
                    content = content[:500] + "..."
                history_parts.append(f"{role}: {content}")
            history_section = "\n".join(history_parts)
        
        # Build source reference section
        source_refs = []
        for i, src in enumerate(sources, 1):
            source_refs.append(f"[{i}] {src.get('id', 'Unknown')} - {src.get('title', 'Untitled')}")
        source_section = "\n".join(source_refs)
        
        template = """You are an expert IT Service Operations assistant helping users troubleshoot issues and find information.

## Your Capabilities:
- Troubleshooting technical issues (VPN, email, network, software, hardware)
- Explaining IT procedures and policies
- Finding relevant knowledge base articles
- Providing step-by-step solutions

## Guidelines:
1. Be concise but thorough - provide actionable steps
2. Use the retrieved context to ground your answers
3. If the context doesn't fully answer the question, say so
4. Reference sources using [1], [2], etc. when citing specific information
5. For troubleshooting, provide numbered steps
6. If you're unsure, recommend escalation or contacting IT support

## Available Sources:
{source_section}

## Retrieved Context:
{context}

{history_block}

## Current Question:
{question}

## Instructions:
- Answer the question using the context above
- Include source references [1], [2], etc. for key facts
- If this is a follow-up question, use the conversation history for context
- Provide clear, actionable guidance

## Answer:"""

        history_block = f"## Recent Conversation:\n{history_section}\n" if history_section else ""
        
        prompt = ChatPromptTemplate.from_template(template)
        chain = prompt | self.llm | StrOutputParser()
        
        try:
            response = chain.invoke({
                "context": context_str,
                "question": question,
                "source_section": source_section,
                "history_block": history_block
            })
            
            print(f"[Generate] Answer length: {len(response)} chars")
            
            return {"answer": response}
        
        except Exception as e:
            print(f"[Generate] Error: {e}")
            return {"answer": "I apologize, but I encountered an error generating a response. Please try again or contact IT support."}
    
    # =========================================================================
    # HELPER METHODS
    # =========================================================================
    
    def _generate_source_link(self, source_id: str, metadata: dict) -> str:
        """
        Generate a proper link to the source document.
        
        Supports:
        - ServiceNow Incidents (INC*)
        - ServiceNow KB Articles (KB*)
        - ServiceNow Problems (PRB*)
        - ServiceNow Changes (CHG*)
        - File paths
        """
        if not source_id:
            return "#"
        
        # ServiceNow record patterns
        servicenow_patterns = {
            "INC": "incident",
            "KB": "kb_knowledge",
            "PRB": "problem",
            "CHG": "change_request",
            "REQ": "sc_request",
            "RITM": "sc_req_item",
            "TASK": "task"
        }
        
        # Check if it's a ServiceNow record
        for prefix, table in servicenow_patterns.items():
            if source_id.upper().startswith(prefix):
                if self.servicenow_instance:
                    # Generate ServiceNow URL
                    instance = self.servicenow_instance.rstrip('/')
                    return f"{instance}/nav_to.do?uri={table}.do?sysparm_query=number={source_id}"
                else:
                    # Return a search-friendly URL
                    return f"#servicenow:{source_id}"
        
        # Check if it's a file path
        if '/' in source_id or '\\' in source_id or source_id.endswith(('.pdf', '.docx', '.txt', '.xlsx')):
            # It's a file - return placeholder
            return f"#file:{os.path.basename(source_id)}"
        
        # Check metadata for URL
        if metadata.get("url"):
            return metadata["url"]
        
        if metadata.get("link"):
            return metadata["link"]
        
        return "#"
    
    def _extract_title(self, source_id: str, content: str, metadata: dict) -> str:
        """
        Extract or generate a meaningful title for the source.
        """
        # Check metadata for title
        if metadata.get("title"):
            return metadata["title"]
        
        if metadata.get("short_description"):
            return metadata["short_description"]
        
        # For files, use filename
        if '/' in source_id or '\\' in source_id:
            return os.path.basename(source_id)
        
        # For ServiceNow records, use ID + first line of content
        if any(source_id.upper().startswith(p) for p in ["INC", "KB", "PRB", "CHG"]):
            first_line = content.split('\n')[0][:100] if content else ""
            return f"{source_id}: {first_line}" if first_line else source_id
        
        # Fallback: use first line of content
        if content:
            first_line = content.split('\n')[0][:80]
            return first_line if first_line else "Untitled Document"
        
        return source_id or "Untitled Document"
    
    # =========================================================================
    # WORKFLOW DEFINITION
    # =========================================================================
    
    def get_workflow(self):
        """
        Build the LangGraph workflow with all nodes.
        
        Pipeline:
        Query → Rewrite → Retrieve → Rerank → Generate → Answer
        """
        workflow = StateGraph(AgentState)
        
        # Add nodes
        workflow.add_node("rewrite_query", self.rewrite_query)
        workflow.add_node("retrieve", self.retrieve)
        workflow.add_node("rerank", self.rerank)
        workflow.add_node("generate", self.generate)
        
        # Define edges
        workflow.set_entry_point("rewrite_query")
        workflow.add_edge("rewrite_query", "retrieve")
        workflow.add_edge("retrieve", "rerank")
        workflow.add_edge("rerank", "generate")
        workflow.add_edge("generate", END)
        
        return workflow.compile()
    
    # =========================================================================
    # MAIN CHAT METHOD
    # =========================================================================
    
    def chat(self, user_input: str, conversation_history: List[dict] = None) -> dict:
        """
        Process a user message with conversation context.
        
        Args:
            user_input: The user's question
            conversation_history: List of previous messages [{"role": "user/assistant", "content": "..."}]
        
        Returns:
            dict with keys: question, answer, sources, conversation_history
        """
        app = self.get_workflow()
        
        inputs = {
            "question": user_input,
            "conversation_history": conversation_history or [],
            "rewritten_query": "",
            "context": [],
            "ranked_documents": [],
            "answer": "",
            "sources": []
        }
        
        result = app.invoke(inputs)
        
        # Build updated conversation history
        new_history = (conversation_history or []).copy()
        new_history.append({"role": "user", "content": user_input})
        new_history.append({"role": "assistant", "content": result["answer"]})
        
        # Keep only last 10 messages to manage context size
        if len(new_history) > 10:
            new_history = new_history[-10:]
        
        return {
            "question": user_input,
            "answer": result["answer"],
            "sources": result["sources"],
            "conversation_history": new_history
        }
    
    # =========================================================================
    # SIMPLE CHAT (BACKWARD COMPATIBLE)
    # =========================================================================
    
    def simple_chat(self, user_input: str) -> dict:
        """
        Simple chat without conversation history (backward compatible).
        """
        return self.chat(user_input, conversation_history=None)


# =============================================================================
# USAGE EXAMPLE
# =============================================================================

if __name__ == "__main__":
    # Example usage
    agent = ChatAgent(
        collection_name="my_fabric",
        model_name="gpt-4",
        servicenow_instance="https://mycompany.service-now.com"
    )
    
    # First message
    result1 = agent.chat("How do I reset my VPN password?")
    print(f"Answer: {result1['answer']}")
    print(f"Sources: {result1['sources']}")
    
    # Follow-up message with conversation context
    result2 = agent.chat(
        "What if that doesn't work?",
        conversation_history=result1['conversation_history']
    )
    print(f"Follow-up Answer: {result2['answer']}")
