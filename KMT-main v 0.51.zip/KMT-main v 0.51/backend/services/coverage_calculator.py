"""
Coverage Calculator Service
============================
Calculates KB article coverage for incidents using semantic similarity.

Coverage Logic:
1. Extract resolution steps from incident (resolution_notes + work_notes)
2. Find KB articles in same category
3. Calculate how well KB article_body covers each resolution step
4. Coverage % = (covered_steps / total_steps) × 100

Uses sentence-transformers for embeddings and cosine similarity for matching.
"""

import re
import numpy as np
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
from functools import lru_cache

# =============================================================================
# CONFIGURATION
# =============================================================================

# Similarity threshold - steps with similarity above this are "covered"
COVERAGE_THRESHOLD = 0.65

# Minimum steps to consider for coverage (avoid single-step skew)
MIN_STEPS_FOR_COVERAGE = 1

# Model for embeddings (will be loaded lazily)
EMBEDDING_MODEL_NAME = "all-MiniLM-L6-v2"

# =============================================================================
# DATA CLASSES
# =============================================================================

@dataclass
class CoverageResult:
    """Result of coverage calculation for a single incident"""
    incident_id: str
    category: str
    sub_category: str
    total_steps: int
    covered_steps: int
    coverage_percentage: float
    best_matching_kb: Optional[str]
    best_kb_similarity: float
    step_details: List[Dict[str, Any]]


@dataclass
class CategoryCoverageStats:
    """Aggregated coverage stats for a category"""
    category: str
    total_incidents: int
    total_steps: int
    covered_steps: int
    avg_coverage_percentage: float
    incidents_with_full_coverage: int  # >= 90%
    incidents_with_partial_coverage: int  # 50-89%
    incidents_with_low_coverage: int  # < 50%
    incidents_with_no_coverage: int  # 0%
    kb_article_count: int


# =============================================================================
# EMBEDDING MODEL MANAGER
# =============================================================================

class EmbeddingModel:
    """Lazy-loaded embedding model singleton"""
    
    _instance = None
    _model = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def get_model(self):
        """Get or load the embedding model"""
        if self._model is None:
            try:
                from sentence_transformers import SentenceTransformer
                print(f"Loading embedding model: {EMBEDDING_MODEL_NAME}")
                self._model = SentenceTransformer(EMBEDDING_MODEL_NAME)
                print("Embedding model loaded successfully")
            except ImportError:
                raise ImportError(
                    "sentence-transformers not installed. "
                    "Run: pip install sentence-transformers"
                )
        return self._model
    
    def encode(self, texts: List[str]) -> np.ndarray:
        """Encode texts to embeddings"""
        model = self.get_model()
        return model.encode(texts, convert_to_numpy=True)
    
    def encode_single(self, text: str) -> np.ndarray:
        """Encode a single text"""
        return self.encode([text])[0]


# Global embedding model instance
_embedding_model = EmbeddingModel()


# =============================================================================
# TEXT PROCESSING FUNCTIONS
# =============================================================================

def extract_steps(text: str) -> List[str]:
    """
    Extract resolution steps from text.
    Handles numbered lists, bullet points, and line-separated steps.
    
    Args:
        text: Resolution notes or work notes text
        
    Returns:
        List of individual steps
    """
    if not text or not text.strip():
        return []
    
    steps = []
    
    # Normalize text
    text = text.strip()
    
    # Pattern 1: Numbered steps (1. Step, 2. Step, etc.)
    numbered_pattern = r'^\s*(\d+)[.\)]\s*(.+?)(?=\n\s*\d+[.\)]|\n\n|\Z)'
    numbered_matches = re.findall(numbered_pattern, text, re.MULTILINE | re.DOTALL)
    
    if numbered_matches:
        for _, step_text in numbered_matches:
            step = step_text.strip()
            if step and len(step) > 5:  # Filter very short entries
                steps.append(step)
    
    # Pattern 2: Bullet points (- Step, • Step, * Step)
    if not steps:
        bullet_pattern = r'^\s*[-•*]\s*(.+?)(?=\n\s*[-•*]|\n\n|\Z)'
        bullet_matches = re.findall(bullet_pattern, text, re.MULTILINE | re.DOTALL)
        
        if bullet_matches:
            for step_text in bullet_matches:
                step = step_text.strip()
                if step and len(step) > 5:
                    steps.append(step)
    
    # Pattern 3: Line-separated (split by newlines)
    if not steps:
        lines = text.split('\n')
        for line in lines:
            line = line.strip()
            # Remove leading numbers/bullets
            line = re.sub(r'^\s*[\d\-•*]+[.\):]?\s*', '', line)
            if line and len(line) > 10:  # Filter short lines
                steps.append(line)
    
    # If still no steps, treat entire text as one step
    if not steps and len(text) > 20:
        # Split by sentences as last resort
        sentences = re.split(r'[.!?]+', text)
        steps = [s.strip() for s in sentences if s.strip() and len(s.strip()) > 15]
    
    return steps


def combine_resolution_text(resolution_notes: str, work_notes: str) -> str:
    """Combine resolution notes and work notes"""
    parts = []
    if resolution_notes and resolution_notes.strip():
        parts.append(resolution_notes.strip())
    if work_notes and work_notes.strip():
        parts.append(work_notes.strip())
    return "\n\n".join(parts)


def preprocess_text(text: str) -> str:
    """Clean and preprocess text for embedding"""
    if not text:
        return ""
    
    # Remove excessive whitespace
    text = re.sub(r'\s+', ' ', text)
    
    # Remove special characters but keep basic punctuation
    text = re.sub(r'[^\w\s.,;:!?\-()]', '', text)
    
    return text.strip()


# =============================================================================
# SIMILARITY FUNCTIONS
# =============================================================================

def cosine_similarity(vec1: np.ndarray, vec2: np.ndarray) -> float:
    """Calculate cosine similarity between two vectors"""
    dot_product = np.dot(vec1, vec2)
    norm1 = np.linalg.norm(vec1)
    norm2 = np.linalg.norm(vec2)
    
    if norm1 == 0 or norm2 == 0:
        return 0.0
    
    return float(dot_product / (norm1 * norm2))


def calculate_step_coverage(
    step_embedding: np.ndarray,
    kb_embedding: np.ndarray,
    kb_chunks: List[np.ndarray] = None
) -> Tuple[float, bool]:
    """
    Calculate if a step is covered by KB article.
    
    Args:
        step_embedding: Embedding of the resolution step
        kb_embedding: Embedding of the full KB article body
        kb_chunks: Optional list of KB chunk embeddings for finer matching
        
    Returns:
        Tuple of (similarity_score, is_covered)
    """
    # Calculate similarity with full KB
    similarity = cosine_similarity(step_embedding, kb_embedding)
    
    # If chunks provided, also check against chunks and take max
    if kb_chunks:
        for chunk_emb in kb_chunks:
            chunk_sim = cosine_similarity(step_embedding, chunk_emb)
            similarity = max(similarity, chunk_sim)
    
    is_covered = similarity >= COVERAGE_THRESHOLD
    
    return similarity, is_covered


# =============================================================================
# COVERAGE CALCULATOR CLASS
# =============================================================================

class CoverageCalculator:
    """
    Calculate KB article coverage for incidents.
    
    Usage:
        calculator = CoverageCalculator()
        calculator.load_kb_articles(kb_articles)
        result = calculator.calculate_incident_coverage(incident)
    """
    
    def __init__(self, threshold: float = COVERAGE_THRESHOLD):
        """
        Initialize coverage calculator.
        
        Args:
            threshold: Similarity threshold for considering a step "covered"
        """
        self.threshold = threshold
        self.kb_articles = []
        self.kb_embeddings = {}  # kb_id -> embedding
        self.kb_by_category = {}  # category -> [kb_articles]
    
    def load_kb_articles(self, kb_articles: List[Dict[str, Any]]):
        """
        Load and pre-compute embeddings for KB articles.
        
        Args:
            kb_articles: List of KB article dicts with keys:
                - article_id
                - article_body
                - category
                - sub_category (optional)
        """
        self.kb_articles = kb_articles
        self.kb_by_category = {}
        
        print(f"Loading {len(kb_articles)} KB articles...")
        
        # Group by category
        for kb in kb_articles:
            category = kb.get('category', 'Uncategorized')
            if category not in self.kb_by_category:
                self.kb_by_category[category] = []
            self.kb_by_category[category].append(kb)
        
        # Pre-compute embeddings
        article_bodies = []
        article_ids = []
        
        for kb in kb_articles:
            article_id = kb.get('article_id', '')
            article_body = kb.get('article_body', '')
            
            if article_body:
                article_bodies.append(preprocess_text(article_body))
                article_ids.append(article_id)
        
        if article_bodies:
            print(f"Computing embeddings for {len(article_bodies)} articles...")
            embeddings = _embedding_model.encode(article_bodies)
            
            for i, article_id in enumerate(article_ids):
                self.kb_embeddings[article_id] = embeddings[i]
        
        print(f"KB articles loaded. Categories: {list(self.kb_by_category.keys())}")
    
    def calculate_incident_coverage(
        self,
        incident: Dict[str, Any],
        match_sub_category: bool = False
    ) -> CoverageResult:
        """
        Calculate coverage for a single incident.
        
        Args:
            incident: Incident dict with keys:
                - number (or incident_id)
                - resolution_notes
                - work_notes
                - category
                - sub_category (optional)
            match_sub_category: If True, only match KB in same sub-category
            
        Returns:
            CoverageResult with coverage details
        """
        incident_id = incident.get('number', incident.get('incident_id', 'unknown'))
        category = incident.get('category', 'Uncategorized')
        sub_category = incident.get('sub_category', '')
        resolution_notes = incident.get('resolution_notes', '')
        work_notes = incident.get('work_notes', '')
        
        # Combine and extract steps
        combined_text = combine_resolution_text(resolution_notes, work_notes)
        steps = extract_steps(combined_text)
        
        # Handle empty steps
        if not steps:
            return CoverageResult(
                incident_id=incident_id,
                category=category,
                sub_category=sub_category,
                total_steps=0,
                covered_steps=0,
                coverage_percentage=0.0,
                best_matching_kb=None,
                best_kb_similarity=0.0,
                step_details=[]
            )
        
        # Get KB articles for this category
        candidate_kbs = self.kb_by_category.get(category, [])
        
        # Optionally filter by sub-category
        if match_sub_category and sub_category:
            candidate_kbs = [
                kb for kb in candidate_kbs 
                if kb.get('sub_category', '') == sub_category
            ]
        
        # If no KB articles in category, return zero coverage
        if not candidate_kbs:
            return CoverageResult(
                incident_id=incident_id,
                category=category,
                sub_category=sub_category,
                total_steps=len(steps),
                covered_steps=0,
                coverage_percentage=0.0,
                best_matching_kb=None,
                best_kb_similarity=0.0,
                step_details=[
                    {"step": s, "covered": False, "similarity": 0.0, "matching_kb": None}
                    for s in steps
                ]
            )
        
        # Compute step embeddings
        step_embeddings = _embedding_model.encode([preprocess_text(s) for s in steps])
        
        # Calculate coverage for each step against all candidate KBs
        step_details = []
        best_overall_kb = None
        best_overall_similarity = 0.0
        
        for i, step in enumerate(steps):
            step_emb = step_embeddings[i]
            best_similarity = 0.0
            best_kb = None
            
            for kb in candidate_kbs:
                kb_id = kb.get('article_id', '')
                kb_emb = self.kb_embeddings.get(kb_id)
                
                if kb_emb is not None:
                    similarity, _ = calculate_step_coverage(step_emb, kb_emb)
                    
                    if similarity > best_similarity:
                        best_similarity = similarity
                        best_kb = kb_id
            
            is_covered = best_similarity >= self.threshold
            
            step_details.append({
                "step": step[:100] + "..." if len(step) > 100 else step,
                "covered": is_covered,
                "similarity": round(best_similarity, 3),
                "matching_kb": best_kb if is_covered else None
            })
            
            if best_similarity > best_overall_similarity:
                best_overall_similarity = best_similarity
                best_overall_kb = best_kb
        
        # Calculate overall coverage
        covered_steps = sum(1 for sd in step_details if sd['covered'])
        coverage_percentage = (covered_steps / len(steps)) * 100 if steps else 0
        
        return CoverageResult(
            incident_id=incident_id,
            category=category,
            sub_category=sub_category,
            total_steps=len(steps),
            covered_steps=covered_steps,
            coverage_percentage=round(coverage_percentage, 1),
            best_matching_kb=best_overall_kb,
            best_kb_similarity=round(best_overall_similarity, 3),
            step_details=step_details
        )
    
    def calculate_batch_coverage(
        self,
        incidents: List[Dict[str, Any]],
        progress_callback: callable = None
    ) -> List[CoverageResult]:
        """
        Calculate coverage for multiple incidents.
        
        Args:
            incidents: List of incident dicts
            progress_callback: Optional callback(current, total) for progress
            
        Returns:
            List of CoverageResult objects
        """
        results = []
        total = len(incidents)
        
        for i, incident in enumerate(incidents):
            result = self.calculate_incident_coverage(incident)
            results.append(result)
            
            if progress_callback and (i + 1) % 10 == 0:
                progress_callback(i + 1, total)
        
        return results
    
    def aggregate_by_category(
        self,
        coverage_results: List[CoverageResult]
    ) -> Dict[str, CategoryCoverageStats]:
        """
        Aggregate coverage results by category.
        
        Args:
            coverage_results: List of CoverageResult objects
            
        Returns:
            Dict of category -> CategoryCoverageStats
        """
        category_data = {}
        
        for result in coverage_results:
            cat = result.category
            
            if cat not in category_data:
                category_data[cat] = {
                    'total_incidents': 0,
                    'total_steps': 0,
                    'covered_steps': 0,
                    'coverage_percentages': [],
                    'full_coverage': 0,
                    'partial_coverage': 0,
                    'low_coverage': 0,
                    'no_coverage': 0,
                }
            
            data = category_data[cat]
            data['total_incidents'] += 1
            data['total_steps'] += result.total_steps
            data['covered_steps'] += result.covered_steps
            data['coverage_percentages'].append(result.coverage_percentage)
            
            if result.coverage_percentage >= 90:
                data['full_coverage'] += 1
            elif result.coverage_percentage >= 50:
                data['partial_coverage'] += 1
            elif result.coverage_percentage > 0:
                data['low_coverage'] += 1
            else:
                data['no_coverage'] += 1
        
        # Build final stats
        stats = {}
        for cat, data in category_data.items():
            kb_count = len(self.kb_by_category.get(cat, []))
            avg_coverage = sum(data['coverage_percentages']) / len(data['coverage_percentages']) if data['coverage_percentages'] else 0
            
            stats[cat] = CategoryCoverageStats(
                category=cat,
                total_incidents=data['total_incidents'],
                total_steps=data['total_steps'],
                covered_steps=data['covered_steps'],
                avg_coverage_percentage=round(avg_coverage, 1),
                incidents_with_full_coverage=data['full_coverage'],
                incidents_with_partial_coverage=data['partial_coverage'],
                incidents_with_low_coverage=data['low_coverage'],
                incidents_with_no_coverage=data['no_coverage'],
                kb_article_count=kb_count
            )
        
        return stats
    
    def aggregate_by_sub_category(
        self,
        coverage_results: List[CoverageResult]
    ) -> Dict[str, Dict[str, CategoryCoverageStats]]:
        """
        Aggregate coverage results by category and sub-category.
        
        Returns:
            Dict of category -> sub_category -> CategoryCoverageStats
        """
        nested_data = {}
        
        for result in coverage_results:
            cat = result.category
            sub_cat = result.sub_category or "Uncategorized"
            
            if cat not in nested_data:
                nested_data[cat] = {}
            
            if sub_cat not in nested_data[cat]:
                nested_data[cat][sub_cat] = {
                    'total_incidents': 0,
                    'total_steps': 0,
                    'covered_steps': 0,
                    'coverage_percentages': [],
                }
            
            data = nested_data[cat][sub_cat]
            data['total_incidents'] += 1
            data['total_steps'] += result.total_steps
            data['covered_steps'] += result.covered_steps
            data['coverage_percentages'].append(result.coverage_percentage)
        
        # Build final stats
        stats = {}
        for cat, sub_cats in nested_data.items():
            stats[cat] = {}
            for sub_cat, data in sub_cats.items():
                avg_coverage = sum(data['coverage_percentages']) / len(data['coverage_percentages']) if data['coverage_percentages'] else 0
                
                stats[cat][sub_cat] = {
                    'total_incidents': data['total_incidents'],
                    'total_steps': data['total_steps'],
                    'covered_steps': data['covered_steps'],
                    'avg_coverage_percentage': round(avg_coverage, 1),
                }
        
        return stats
    
    def get_coverage_matrix(
        self,
        coverage_results: List[CoverageResult]
    ) -> Dict[str, Any]:
        """
        Generate coverage matrix data for heatmap visualization.
        
        Returns:
            Dict with categories, incident counts, coverage percentages, gaps, etc.
        """
        category_stats = self.aggregate_by_category(coverage_results)
        
        # Sort by gap (incidents without coverage)
        sorted_categories = sorted(
            category_stats.values(),
            key=lambda x: x.incidents_with_no_coverage + x.incidents_with_low_coverage,
            reverse=True
        )
        
        categories = []
        incident_counts = []
        kb_coverage_counts = []
        coverage_percentages = []
        gaps = []
        kb_article_counts = []
        
        total_incidents = 0
        total_covered = 0
        total_gap = 0
        
        for stat in sorted_categories:
            categories.append(stat.category)
            incident_counts.append(stat.total_incidents)
            
            # "Covered" = incidents with >= 50% coverage
            covered = stat.incidents_with_full_coverage + stat.incidents_with_partial_coverage
            kb_coverage_counts.append(covered)
            
            coverage_percentages.append(stat.avg_coverage_percentage)
            
            # "Gap" = incidents with < 50% coverage
            gap = stat.incidents_with_low_coverage + stat.incidents_with_no_coverage
            gaps.append(gap)
            
            kb_article_counts.append(stat.kb_article_count)
            
            total_incidents += stat.total_incidents
            total_covered += covered
            total_gap += gap
        
        overall_coverage = (total_covered / total_incidents * 100) if total_incidents > 0 else 0
        
        return {
            "categories": categories,
            "incidentCounts": incident_counts,
            "kbCoverageCounts": kb_coverage_counts,
            "coveragePercentages": coverage_percentages,
            "gaps": gaps,
            "kbArticleCounts": kb_article_counts,
            "totalIncidents": total_incidents,
            "totalKBArticles": len(self.kb_articles),
            "totalCoveredIncidents": total_covered,
            "totalGapIncidents": total_gap,
            "overallCoveragePercentage": round(overall_coverage, 1)
        }


# =============================================================================
# HELPER FUNCTIONS FOR API INTEGRATION
# =============================================================================

def calculate_coverage_for_fabric(
    incidents: List[Dict[str, Any]],
    kb_articles: List[Dict[str, Any]],
    threshold: float = COVERAGE_THRESHOLD
) -> Dict[str, Any]:
    """
    Calculate coverage for all incidents in a fabric.
    
    Args:
        incidents: List of incident dicts
        kb_articles: List of KB article dicts
        threshold: Similarity threshold
        
    Returns:
        Coverage matrix data for heatmap
    """
    calculator = CoverageCalculator(threshold=threshold)
    calculator.load_kb_articles(kb_articles)
    
    print(f"Calculating coverage for {len(incidents)} incidents...")
    coverage_results = calculator.calculate_batch_coverage(incidents)
    
    return calculator.get_coverage_matrix(coverage_results)


def calculate_single_incident_coverage(
    incident: Dict[str, Any],
    kb_articles: List[Dict[str, Any]],
    threshold: float = COVERAGE_THRESHOLD
) -> Dict[str, Any]:
    """
    Calculate coverage for a single incident.
    
    Returns:
        Dict with coverage details
    """
    calculator = CoverageCalculator(threshold=threshold)
    calculator.load_kb_articles(kb_articles)
    
    result = calculator.calculate_incident_coverage(incident)
    
    return {
        "incidentId": result.incident_id,
        "category": result.category,
        "subCategory": result.sub_category,
        "totalSteps": result.total_steps,
        "coveredSteps": result.covered_steps,
        "coveragePercentage": result.coverage_percentage,
        "bestMatchingKb": result.best_matching_kb,
        "bestKbSimilarity": result.best_kb_similarity,
        "stepDetails": result.step_details
    }


# =============================================================================
# MAIN - FOR TESTING
# =============================================================================

if __name__ == "__main__":
    # Test with sample data
    sample_incidents = [
        {
            "number": "INC0001",
            "category": "SC_EXCHANGE",
            "sub_category": "Configuration",
            "resolution_notes": """1. Checked user's Outlook configuration
2. Found incorrect Exchange server settings
3. Updated server to correct address
4. Restarted Outlook
5. Verified email sync working""",
            "work_notes": "User reported emails not syncing. Checked settings and found wrong server."
        },
        {
            "number": "INC0002",
            "category": "SC_EXCHANGE",
            "sub_category": "Network",
            "resolution_notes": "Cleared DNS cache and restarted network adapter.",
            "work_notes": "Network connectivity issue to Exchange."
        }
    ]
    
    sample_kb_articles = [
        {
            "article_id": "KB0001",
            "category": "SC_EXCHANGE",
            "sub_category": "Configuration",
            "article_body": """# Outlook Configuration Guide
            
## Steps to Configure Outlook

1. Open Outlook and go to File > Account Settings
2. Click Add Account
3. Enter Exchange server address: mail.company.com
4. Enter your credentials
5. Click Next and wait for configuration
6. Restart Outlook after setup
7. Verify emails are syncing correctly

## Troubleshooting

If emails don't sync:
- Check server settings are correct
- Verify network connectivity
- Clear Outlook cache and restart
"""
        }
    ]
    
    print("Testing Coverage Calculator...")
    print("=" * 60)
    
    calculator = CoverageCalculator()
    calculator.load_kb_articles(sample_kb_articles)
    
    for incident in sample_incidents:
        result = calculator.calculate_incident_coverage(incident)
        print(f"\nIncident: {result.incident_id}")
        print(f"  Category: {result.category}")
        print(f"  Total Steps: {result.total_steps}")
        print(f"  Covered Steps: {result.covered_steps}")
        print(f"  Coverage: {result.coverage_percentage}%")
        print(f"  Best KB: {result.best_matching_kb}")
        print(f"  Steps:")
        for step in result.step_details:
            status = "✓" if step['covered'] else "✗"
            print(f"    [{status}] {step['step'][:50]}... (sim: {step['similarity']})")
    
    print("\n" + "=" * 60)
    print("Coverage Matrix:")
    matrix = calculator.get_coverage_matrix(
        calculator.calculate_batch_coverage(sample_incidents)
    )
    print(f"  Categories: {matrix['categories']}")
    print(f"  Coverage %: {matrix['coveragePercentages']}")
    print(f"  Gaps: {matrix['gaps']}")
