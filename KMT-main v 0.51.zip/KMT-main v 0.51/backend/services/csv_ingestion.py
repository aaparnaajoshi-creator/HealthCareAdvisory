# =============================================================================
# CSV INGESTION SERVICE -added this in v 0.51
# =============================================================================
# Handles parsing, validation, and ingestion of KB articles, Incidents, and Documents
# Fixed: GraphNode creation now matches actual model (no access_level column)

import os
import csv
import json
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple
import pandas as pd
from config import Config
from models import db, Fabric, CICategory, IngestedContent, GraphNode, GraphEdge

# =============================================================================
# FLEXIBLE COLUMN MAPPINGS
# =============================================================================

KB_COLUMN_MAPPING = {
    'article_id': ['article_id', 'kb_id', 'id'],
    'title': ['title', 'knowledge_article', 'kb_title', 'name'],
    'short_description': ['short_description', 'description', 'summary'],
    'article_body': ['article_body', 'body', 'content', 'text'],
    'access_role': ['access_role', 'role', 'access'],
    'category': ['category', 'category_ci', 'ci_category', 'ci_name'],
    'sub_category': ['sub_category', 'subcategory', 'sub_cat'],
    'created_by': ['created_by', 'author', 'creator'],
    'created_date': ['created_date', 'created', 'date_created', 'created_at'],
    'keywords': ['keywords', 'tags'],
    'task': ['task', 'task_id'],
}

INCIDENT_COLUMN_MAPPING = {
    'number': ['number', 'incident_number', 'inc_number', 'id'],
    'short_description': ['short_description', 'description', 'summary', 'title'],
    'resolution_notes': ['resolution_notes', 'resolution', 'resolution_text'],
    'work_notes': ['work_notes', 'notes', 'comments'],
    'category': ['category', 'category_ci', 'ci_category', 'ci_name'],
    'sub_category': ['sub_category', 'subcategory', 'sub_cat'],
    'state': ['state', 'status', 'incident_state'],
    'access_role': ['access_role', 'role', 'access'],
    'priority': ['priority', 'prio'],
    'assignment_group': ['assignment_group', 'assigned_group', 'group'],
    'assigned_to': ['assigned_to', 'assignee'],
    'reported_date': ['reported_date', 'reported_on', 'opened_at', 'created'],
    'resolved_date': ['resolved_date', 'resolved_on', 'resolved_at', 'closed_at'],
}

VALID_ACCESS_ROLES = ['Admin', 'Support', 'BusinessOps']


def find_column(df: pd.DataFrame, possible_names: List[str]) -> Optional[str]:
    """Find the first matching column name from a list of possibilities."""
    for name in possible_names:
        if name in df.columns:
            return name
    return None


def get_value(row: pd.Series, df: pd.DataFrame, field: str, mapping: Dict, default: Any = '') -> Any:
    """Get value from row using flexible column mapping."""
    col_name = find_column(df, mapping.get(field, [field]))
    if col_name and col_name in row and not pd.isna(row[col_name]):
        return str(row[col_name]).strip()
    return default


# =============================================================================
# CSV VALIDATOR CLASS
# =============================================================================

class CSVValidator:
    """Validate CSV files before ingestion."""
    
    def __init__(self):
        self.errors = []
        self.warnings = []
    
    def reset(self):
        self.errors = []
        self.warnings = []
    
    def validate_kb_csv(self, df: pd.DataFrame) -> Tuple[bool, List[str], List[str]]:
        """Validate KB articles CSV with flexible column names."""
        self.reset()
        
        id_col = find_column(df, KB_COLUMN_MAPPING['article_id'])
        if not id_col:
            self.errors.append(f"Missing required column: article_id (or: {KB_COLUMN_MAPPING['article_id']})")
        
        title_col = find_column(df, KB_COLUMN_MAPPING['title'])
        if not title_col:
            self.errors.append(f"Missing required column: title (or: {KB_COLUMN_MAPPING['title']})")
        
        role_col = find_column(df, KB_COLUMN_MAPPING['access_role'])
        if not role_col:
            self.warnings.append(f"Missing access_role column, defaulting to 'Support'")
        
        if self.errors:
            return False, self.errors, self.warnings
        
        # Check for duplicates
        duplicates = df[df.duplicated(subset=[id_col], keep=False)]
        if not duplicates.empty:
            dup_ids = duplicates[id_col].unique().tolist()
            self.errors.append(f"Duplicate article_ids found: {', '.join(map(str, dup_ids))}")
        
        is_valid = len(self.errors) == 0
        return is_valid, self.errors, self.warnings
    
    def validate_incident_csv(self, df: pd.DataFrame, valid_categories: List[str] = None) -> Tuple[bool, List[str], List[str]]:
        """Validate Incidents CSV with flexible column names."""
        self.reset()
        
        num_col = find_column(df, INCIDENT_COLUMN_MAPPING['number'])
        if not num_col:
            self.errors.append(f"Missing required column: number (or: {INCIDENT_COLUMN_MAPPING['number']})")
        
        if self.errors:
            return False, self.errors, self.warnings
        
        # Check for duplicates
        duplicates = df[df.duplicated(subset=[num_col], keep=False)]
        if not duplicates.empty:
            dup_ids = duplicates[num_col].unique().tolist()
            self.errors.append(f"Duplicate incident numbers found: {', '.join(map(str, dup_ids))}")
        
        is_valid = len(self.errors) == 0
        return is_valid, self.errors, self.warnings


# =============================================================================
# CSV INGESTION SERVICE CLASS
# =============================================================================

class CSVIngestionService:
    """Service for ingesting KB articles and Incidents from CSV files."""
    
    def __init__(self, fabric_id: str):
        self.fabric_id = fabric_id
        self.fabric = None
        self.validator = CSVValidator()
        self.ci_list = []
        
        self.stats = {
            'total': 0,
            'processed': 0,
            'succeeded': 0,
            'failed': 0,
            'needs_review': 0,
            'errors': []
        }
    
    def _load_fabric(self):
        """Load fabric from database."""
        self.fabric = db.session.get(Fabric, self.fabric_id)
        if not self.fabric:
            raise ValueError(f"Fabric not found: {self.fabric_id}")
    
    def _load_ci_list(self):
        """Load CI list from database."""
        categories = CICategory.query.filter_by(is_active=True).all()
        self.ci_list = [cat.ci_name for cat in categories]
    
    def _get_access_level(self, access_role: str) -> int:
        """Convert access role to numeric level."""
        levels = {'Admin': 3, 'Support': 2, 'BusinessOps': 1}
        return levels.get(access_role, 1)
    
    def _reset_stats(self):
        """Reset ingestion stats."""
        self.stats = {
            'total': 0,
            'processed': 0,
            'succeeded': 0,
            'failed': 0,
            'needs_review': 0,
            'errors': []
        }
    
    # =========================================================================
    # KB ARTICLES INGESTION
    # =========================================================================
    
    def ingest_kb_articles(
        self, 
        file_path: str,
        use_csv_category: bool = True,
        progress_callback: Optional[callable] = None
    ) -> Dict[str, Any]:
        """Ingest KB articles from CSV."""
        self._reset_stats()
        self._load_fabric()
        self._load_ci_list()
        
        # Read CSV
        try:
            df = pd.read_csv(file_path, encoding='utf-8')
        except Exception as e:
            return {'success': False, 'error': f"Failed to read CSV: {str(e)}", 'stats': self.stats}
        
        # Validate
        is_valid, errors, warnings = self.validator.validate_kb_csv(df)
        if not is_valid:
            return {'success': False, 'error': 'Validation failed', 'errors': errors, 'stats': self.stats}
        
        self.stats['total'] = len(df)
        print(f"    Processing {len(df)} KB articles...")
        
        # Process each row
        for idx, row in df.iterrows():
            self.stats['processed'] += 1
            
            try:
                # Extract data using flexible mapping
                article_id = get_value(row, df, 'article_id', KB_COLUMN_MAPPING)
                title = get_value(row, df, 'title', KB_COLUMN_MAPPING)
                short_desc = get_value(row, df, 'short_description', KB_COLUMN_MAPPING, '')
                article_body = get_value(row, df, 'article_body', KB_COLUMN_MAPPING, '')
                access_role = get_value(row, df, 'access_role', KB_COLUMN_MAPPING, 'Support')
                csv_category = get_value(row, df, 'category', KB_COLUMN_MAPPING, '')
                sub_category = get_value(row, df, 'sub_category', KB_COLUMN_MAPPING, '')
                
                if progress_callback:
                    progress_callback(self.stats['processed'], self.stats['total'], f"Processing {article_id}")
                
                # Determine category
                if use_csv_category and csv_category:
                    category = csv_category
                    confidence = 1.0 if category in self.ci_list else 0.5
                    reasoning = 'Category from CSV'
                    needs_review = category not in self.ci_list
                else:
                    category = 'Uncategorized'
                    confidence = 0.0
                    reasoning = 'No category provided'
                    needs_review = True
                
                # Build metadata
                original_metadata = {col: str(row[col]) if not pd.isna(row[col]) else None for col in df.columns}
                original_metadata['sub_category'] = sub_category
                
                # Check if exists (update) or create new
                existing = IngestedContent.query.filter_by(
                    fabric_id=self.fabric_id,
                    source_type='kb',
                    source_id=article_id
                ).first()
                
                if existing:
                    existing.title = title
                    existing.short_description = short_desc
                    existing.content = article_body
                    existing.category_ci = category
                    existing.category_confidence = confidence
                    existing.category_reasoning = reasoning
                    existing.needs_review = needs_review
                    existing.access_role = access_role
                    existing.access_level = self._get_access_level(access_role)
                    existing.original_metadata = original_metadata
                    existing.updated_at = datetime.utcnow()
                else:
                    content_record = IngestedContent(
                        fabric_id=self.fabric_id,
                        source_type='kb',
                        source_id=article_id,
                        title=title,
                        short_description=short_desc,
                        content=article_body,
                        category_ci=category,
                        category_confidence=confidence,
                        category_reasoning=reasoning,
                        needs_review=needs_review,
                        access_role=access_role,
                        access_level=self._get_access_level(access_role),
                        original_metadata=original_metadata
                    )
                    db.session.add(content_record)
                
                # Create graph node - FIXED: no access_level on GraphNode
                self._create_or_update_graph_node(
                    node_id=article_id,
                    node_type='kb_article',
                    label=title[:200] if title else article_id,
                    category_ci=category,
                    sub_category=sub_category,
                    access_level=self._get_access_level(access_role)
                )
                
                self.stats['succeeded'] += 1
                if needs_review:
                    self.stats['needs_review'] += 1
                
            except Exception as e:
                self.stats['failed'] += 1
                self.stats['errors'].append(f"Row {idx + 2}: {str(e)}")
                print(f"    Error on row {idx + 2}: {str(e)}")
        
        db.session.commit()
        self._update_fabric_stats()
        
        print(f"    KB ingestion complete: {self.stats['succeeded']} succeeded, {self.stats['failed']} failed")
        
        return {
            'success': True,
            'stats': self.stats,
            'warnings': warnings
        }
    
    # =========================================================================
    # INCIDENTS INGESTION
    # =========================================================================
    
    def ingest_incidents(
        self, 
        file_path: str,
        use_csv_category: bool = True,
        progress_callback: Optional[callable] = None
    ) -> Dict[str, Any]:
        """Ingest incidents from CSV."""
        self._reset_stats()
        self._load_fabric()
        self._load_ci_list()
        
        # Read CSV
        try:
            df = pd.read_csv(file_path, encoding='utf-8')
        except Exception as e:
            return {'success': False, 'error': f"Failed to read CSV: {str(e)}", 'stats': self.stats}
        
        # Validate
        is_valid, errors, warnings = self.validator.validate_incident_csv(df, self.ci_list)
        if not is_valid:
            return {'success': False, 'error': 'Validation failed', 'errors': errors, 'stats': self.stats}
        
        self.stats['total'] = len(df)
        print(f"    Processing {len(df)} incidents...")
        
        # Process each row
        for idx, row in df.iterrows():
            self.stats['processed'] += 1
            
            try:
                # Extract data
                number = get_value(row, df, 'number', INCIDENT_COLUMN_MAPPING)
                short_desc = get_value(row, df, 'short_description', INCIDENT_COLUMN_MAPPING, '')
                resolution_notes = get_value(row, df, 'resolution_notes', INCIDENT_COLUMN_MAPPING, '')
                work_notes = get_value(row, df, 'work_notes', INCIDENT_COLUMN_MAPPING, '')
                state = get_value(row, df, 'state', INCIDENT_COLUMN_MAPPING, 'Resolved')
                access_role = get_value(row, df, 'access_role', INCIDENT_COLUMN_MAPPING, 'Support')
                csv_category = get_value(row, df, 'category', INCIDENT_COLUMN_MAPPING, '')
                sub_category = get_value(row, df, 'sub_category', INCIDENT_COLUMN_MAPPING, '')
                
                if progress_callback:
                    progress_callback(self.stats['processed'], self.stats['total'], f"Processing {number}")
                
                # Combine content
                content = f"{resolution_notes}\n\n{work_notes}".strip()
                
                # Determine category
                if use_csv_category and csv_category:
                    category = csv_category
                    confidence = 1.0 if category in self.ci_list else 0.5
                    reasoning = 'Category from CSV'
                    needs_review = category not in self.ci_list
                else:
                    category = 'Uncategorized'
                    confidence = 0.0
                    reasoning = 'No category provided'
                    needs_review = True
                
                # Build metadata
                original_metadata = {col: str(row[col]) if not pd.isna(row[col]) else None for col in df.columns}
                
                # Check if exists
                existing = IngestedContent.query.filter_by(
                    fabric_id=self.fabric_id,
                    source_type='incident',
                    source_id=number
                ).first()
                
                if existing:
                    existing.title = f"{number}: {short_desc}"
                    existing.short_description = short_desc
                    existing.content = content
                    existing.category_ci = category
                    existing.category_confidence = confidence
                    existing.category_reasoning = reasoning
                    existing.needs_review = needs_review
                    existing.access_role = access_role
                    existing.access_level = self._get_access_level(access_role)
                    existing.original_metadata = original_metadata
                    existing.updated_at = datetime.utcnow()
                else:
                    content_record = IngestedContent(
                        fabric_id=self.fabric_id,
                        source_type='incident',
                        source_id=number,
                        title=f"{number}: {short_desc}",
                        short_description=short_desc,
                        content=content,
                        category_ci=category,
                        category_confidence=confidence,
                        category_reasoning=reasoning,
                        needs_review=needs_review,
                        access_role=access_role,
                        access_level=self._get_access_level(access_role),
                        original_metadata=original_metadata
                    )
                    db.session.add(content_record)
                
                # Create graph node - FIXED: no access_level on GraphNode
                self._create_or_update_graph_node(
                    node_id=number,
                    node_type='incident',
                    label=f"{number}: {short_desc[:50]}" if short_desc else number,
                    category_ci=category,
                    sub_category=sub_category,
                    access_level=self._get_access_level(access_role)
                )
                
                self.stats['succeeded'] += 1
                if needs_review:
                    self.stats['needs_review'] += 1
                
            except Exception as e:
                self.stats['failed'] += 1
                self.stats['errors'].append(f"Row {idx + 2}: {str(e)}")
                print(f"    Error on row {idx + 2}: {str(e)}")
        
        db.session.commit()
        self._update_fabric_stats()
        
        print(f"    Incident ingestion complete: {self.stats['succeeded']} succeeded, {self.stats['failed']} failed")
        
        return {
            'success': True,
            'stats': self.stats,
            'warnings': warnings
        }
    
    # =========================================================================
    # CI CATEGORIES INGESTION
    # =========================================================================
    
    def ingest_ci_categories(self, file_path: str) -> Dict[str, Any]:
        """Ingest CI categories from CSV."""
        stats = {'loaded': 0, 'skipped': 0, 'errors': []}
        
        try:
            df = pd.read_csv(file_path, encoding='utf-8')
        except Exception as e:
            return {'success': False, 'error': f"Failed to read CSV: {str(e)}", 'stats': stats}
        
        print(f"    Processing {len(df)} CI categories...")
        
        for idx, row in df.iterrows():
            try:
                ci_name = str(row['ci_name']).strip()
                description = str(row.get('description', '')).strip() if not pd.isna(row.get('description')) else ''
                is_active = str(row.get('is_active', 'TRUE')).upper() == 'TRUE'
                
                existing = CICategory.query.filter_by(ci_name=ci_name).first()
                
                if existing:
                    stats['skipped'] += 1
                else:
                    ci = CICategory(
                        ci_name=ci_name,
                        description=description,
                        is_active=is_active
                    )
                    db.session.add(ci)
                    stats['loaded'] += 1
                    
            except Exception as e:
                stats['errors'].append(f"Row {idx + 2}: {str(e)}")
        
        db.session.commit()
        self._load_ci_list()
        
        print(f"    CI categories: {stats['loaded']} loaded, {stats['skipped']} skipped")
        
        return {'success': True, 'stats': stats}
    
    # =========================================================================
    # GRAPH NODES & EDGES - FIXED VERSION
    # =========================================================================
    
    def _create_or_update_graph_node(
        self, 
        node_id: str, 
        node_type: str, 
        label: str,
        category_ci: str,
        sub_category: str = '',
        access_level: int = 1
    ):
        """Create or update a graph node - FIXED for actual GraphNode model."""
        try:
            existing = GraphNode.query.filter_by(
                fabric_id=self.fabric_id,
                node_id=node_id
            ).first()
            
            # Store access_level in properties since GraphNode doesn't have that column
            properties = {
                'category_ci': category_ci,
                'sub_category': sub_category,
                'access_level': access_level
            }
            
            if existing:
                existing.label = label
                existing.node_type = node_type
                existing.properties = properties
                content_node = existing
            else:
                content_node = GraphNode(
                    fabric_id=self.fabric_id,
                    node_id=node_id,
                    node_type=node_type,
                    label=label,
                    properties=properties
                )
                db.session.add(content_node)
                db.session.flush()
            
            # Create CI node and edge
            if category_ci and category_ci != 'Uncategorized':
                self._create_ci_node_and_edge(content_node, category_ci)
                
        except Exception as e:
            print(f"    Error creating graph node {node_id}: {str(e)}")
    
    def _create_ci_node_and_edge(self, content_node: GraphNode, category_ci: str):
        """Create CI node and BELONGS_TO edge."""
        try:
            ci_node = GraphNode.query.filter_by(
                fabric_id=self.fabric_id,
                node_type='ci',
                node_id=category_ci
            ).first()
            
            if not ci_node:
                ci_node = GraphNode(
                    fabric_id=self.fabric_id,
                    node_id=category_ci,
                    node_type='ci',
                    label=category_ci,
                    properties={'category_ci': category_ci}
                )
                db.session.add(ci_node)
                db.session.flush()
            
            # Create edge if not exists
            existing_edge = GraphEdge.query.filter_by(
                fabric_id=self.fabric_id,
                source_node_id=content_node.id,
                target_node_id=ci_node.id,
                relationship_type='BELONGS_TO'
            ).first()
            
            if not existing_edge:
                edge = GraphEdge(
                    fabric_id=self.fabric_id,
                    source_node_id=content_node.id,
                    target_node_id=ci_node.id,
                    relationship_type='BELONGS_TO',
                    properties={'weight': 1.0}
                )
                db.session.add(edge)
                
        except Exception as e:
            print(f"    Error creating CI node/edge for {category_ci}: {str(e)}")
    
    def _update_fabric_stats(self):
        """Update fabric statistics after ingestion."""
        if not self.fabric:
            return
        
        try:
            kb_count = IngestedContent.query.filter_by(
                fabric_id=self.fabric_id, source_type='kb'
            ).count()
            
            incident_count = IngestedContent.query.filter_by(
                fabric_id=self.fabric_id, source_type='incident'
            ).count()
            
            doc_count = IngestedContent.query.filter_by(
                fabric_id=self.fabric_id, source_type='document'
            ).count()
            
            self.fabric.documents_count = kb_count + incident_count + doc_count
            self.fabric.source_breakdown = {
                'kb_articles': kb_count,
                'incidents': incident_count,
                'documents': doc_count
            }
            self.fabric.graph_nodes = GraphNode.query.filter_by(fabric_id=self.fabric_id).count()
            self.fabric.graph_edges = GraphEdge.query.filter_by(fabric_id=self.fabric_id).count()
            self.fabric.last_synced_at = datetime.utcnow()
            self.fabric.status = 'ready'
            
            db.session.commit()
            
            print(f"    Fabric stats updated: {self.fabric.documents_count} docs, {self.fabric.graph_nodes} nodes, {self.fabric.graph_edges} edges")
            
        except Exception as e:
            print(f"    Error updating fabric stats: {str(e)}")
