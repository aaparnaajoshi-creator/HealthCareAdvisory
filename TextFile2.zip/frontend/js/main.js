document.addEventListener('DOMContentLoaded', () => {
    // --- 1. STATE & CONFIG ---
    const API_URL = 'http://localhost:8000';
    const appState = {
        projectId: null,
        pollInterval: null,
        currentView: 'dashboard',
        wizardStep: 1,
        currentExecutionData: null,
        summaryShown: false
    };
    const allPossiblePhases = ["ImpactAnalysis", "Requirements", "Design", "Coding", "Testing", "Deployment"];
    const agentIcons = {
        "ImpactAnalysis": `<svg class="agent-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5A6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5S14 7.01 14 9.5S11.99 14 9.5 14z"></path></svg>`,
        "Requirements": `<svg class="agent-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M14 2H6C4.9 2 4 2.9 4 4V20C4 21.1 4.9 22 6 22H18C19.1 22 20 21.1 20 20V8L14 2ZM10.41 17.41L7.59 14.59L9 13.17L10.41 14.59L14.03 10.97L15.44 12.38L10.41 17.41Z" /><path d="M13 3.5V9H18.5L13 3.5Z" /></svg>`,
        "Design": `<svg class="agent-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L3 8V21H21V8L12 2ZM11 19H7V15H11V19ZM11 13H7V9H11V13ZM17 19H13V15H17V19ZM17 13H13V9H17V13Z" /></svg>`,
        "Coding": `<svg class="agent-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M9.4 16.6L4.8 12L9.4 7.4L8 6L2 12L8 18L9.4 16.6ZM14.6 16.6L19.2 12L14.6 7.4L16 6L22 12L16 18L14.6 16.6Z" /></svg>`,
        "Testing": `<svg class="agent-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L3.5 5.5V11.5C3.5 16.5 7.5 21.5 12 22C16.5 21.5 20.5 16.5 20.5 11.5V5.5L12 2ZM10.5 16L6.5 12L8 10.5L10.5 13L16 7.5L17.5 9L10.5 16Z" /></svg>`,
        "Deployment": `<svg class="agent-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M2 21H22V19H2V21ZM21 16H3C2.45 16 2 15.55 2 15V4C2 3.45 2.45 3 3 3H21C21.55 3 22 3.45 22 4V15C22 15.55 21.55 16 21 16ZM5 14H7V11H5V14ZM9 14H11V11H9V14ZM13 14H15V11H13V14Z" /></svg>`
    };

    // --- 2. SELECTORS ---
    const selectors = {
        projectSummaryCard: document.getElementById('project-summary-card'),
        toastNotification: document.getElementById('toast-notification'),
        dashboardSection: document.getElementById('dashboard-section'),
        executionSection: document.getElementById('execution-section'),
        projectGrid: document.getElementById('project-grid'),
        createProjectBtn: document.getElementById('create-project-btn'),
        backToDashboardBtn: document.getElementById('back-to-dashboard-btn'),
        projectForm: document.getElementById('project-form'),
        projectTitleExecution: document.getElementById('project-title-execution'),
        projectStatus: document.getElementById('project-status'),
        statusIndicator: document.getElementById('status-indicator'),
        timeline: document.getElementById('timeline'),
        downloadOutputsBtn: document.getElementById('download-outputs-btn'),
        humanInterventionBox: document.getElementById('human-intervention-box'),
        humanInterventionPhase: document.getElementById('human-intervention-phase'),
        humanEditArea: document.getElementById('human-edit-area'),
        resumeButton: document.getElementById('resume-button'),
        expandEditorBtn: document.getElementById('expand-editor-btn'),
        editorModal: document.getElementById('editor-modal'),
        closeEditorModalBtn: document.getElementById('close-editor-modal-btn'),
        modalEditorArea: document.getElementById('modal-editor-area'),
        saveEditBtn: document.getElementById('save-edit-btn'),
        cancelEditBtn: document.getElementById('cancel-edit-btn'),
        logModal: document.getElementById('log-modal'),
        logViewer: document.getElementById('log-viewer'),
        closeLogModalBtn: document.getElementById('close-modal-btn'),
        formInputsSource: document.getElementById('form-inputs-source'),
        projectWizardModal: document.getElementById('project-wizard-modal'),
        closeWizardBtn: document.getElementById('close-wizard-btn'),
        summaryModal: document.getElementById('summary-modal'),
        summaryModalBody: document.getElementById('summary-modal-body'),
        closeSummaryBtn: document.getElementById('close-summary-btn'),
    };

    // --- 3. UI RENDERING & UPDATES ---

    function showToast(message, type = 'error') {
        const toast = selectors.toastNotification;
        toast.textContent = message;
        toast.className = `toast show ${type}`;
        setTimeout(() => { toast.classList.remove('show'); }, 4000);
    }

    function showView(viewName) {
        appState.currentView = viewName;
        selectors.dashboardSection.classList.toggle('hidden', viewName !== 'dashboard');
        selectors.executionSection.classList.toggle('hidden', viewName !== 'execution');
        if (viewName === 'dashboard') {
            if (appState.pollInterval) clearInterval(appState.pollInterval);
            appState.projectId = null;
            loadAndRenderProjects();
        }
    }

    async function loadAndRenderProjects() {
        try {
            const response = await fetch(`${API_URL}/projects`);
            if (!response.ok) throw new Error('Failed to fetch projects');
            const projects = await response.json();
            selectors.projectGrid.innerHTML = '';
            if (projects.length === 0) {
                selectors.projectGrid.innerHTML = `<p>No projects yet. Click "Create New Project" to get started!</p>`;
                return;
            }
            projects.forEach(p => {
                const card = document.createElement('div');
                card.className = 'project-card';
                card.dataset.id = p.id;
                const statusClass = p.status.toLowerCase().replace(/ .*/, '');
                card.innerHTML = `
                    <div class="project-card-header">
                        <h3>${p.project_name}</h3>
                        <span class="status-chip ${statusClass}">${p.status}</span>
                    </div>

                    <div class="project-card-body">
                        <p>Type: <strong>${p.project_type === 'new' ? 'New Project' : 'Enhancement'}</strong></p>
                    </div>
                    <div class="project-card-footer">
                        <div class="footer-left-group">
                            <span>ID: ${p.id.substring(0, 8)}...</span>
                            <span>Created On: ${new Date(p.created_at).toLocaleDateString()}</span>
                        </div>
                        <div class="card-menu">
                            <button class="menu-toggle-btn" title="Options" data-id="${p.id}">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 16a2 2 0 1 1 0 4a2 2 0 0 1 0-4m0-6a2 2 0 1 1 0 4a2 2 0 0 1 0-4m0-6a2 2 0 1 1 0 4a2 2 0 0 1 0-4"></path></svg>
                            </button>
                            <div class="dropdown-menu">
                                <button class="delete-project-btn" data-id="${p.id}">Delete</button>
                            </div>
                        </div>
                    </div>
                `;
                selectors.projectGrid.appendChild(card);
            });
        } catch (error) {
            console.error("Could not fetch project history:", error);
            showToast('Could not load project history.');
        }
    }

    function renderProjectSummary(data) {
        if (!data || !selectors.projectSummaryCard) return;
        const hitlSteps = data.human_in_loop_steps;
        const hitlValue = (hitlSteps && hitlSteps.length > 0) ? hitlSteps.join(', ') : 'None';
        selectors.projectSummaryCard.innerHTML = `
            <h3>Project Configuration</h3>
            <div class="summary-item"><span class="label">Project Type:</span><span class="value">${data.project_type || 'N/A'}</span></div>
            <div class="summary-item"><span class="label">Start Phase:</span><span class="value">${data.start_phase || 'N/A'}</span></div>
            <div class="summary-item"><span class="label">End Phase:</span><span class="value">${data.end_phase || 'N/A'}</span></div>
            <div class="summary-item"><span class="label">HITL Checkpoints:</span><span class="value">${hitlValue}</span></div>`;
    }

    function renderTimeline(container, phasesData) {
        container.innerHTML = '';
        if (!phasesData) return;
        phasesData.forEach(phaseInfo => {
            const item = document.createElement('div');
            item.className = 'timeline-item';
            item.id = `timeline-phase-${phaseInfo.phase_name.toLowerCase()}`;
            item.innerHTML = `
                <div class="timeline-item-header">
                    <div class="timeline-item-header-title">${agentIcons[phaseInfo.phase_name] || ''}<h4>${phaseInfo.phase_name} Agent</h4></div>
                    <div class="status-container">
                        <span class="phase-duration"></span><span class="status">Pending</span>
                        <svg class="toggle-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
                    </div>
                </div>
                <div class="timeline-item-body"></div>`;
            container.appendChild(item);
        });
    }

    function updateTimeline(phasesData, overallStatus) {
        let activePhaseName = null;
        let pausedPhaseName = null;
        if (overallStatus?.startsWith('In Progress - ')) {
            activePhaseName = overallStatus.replace('In Progress - ', '').split('(')[0].trim();
        } else if (overallStatus?.includes('Paused - Waiting for Human Input at ')) {
            pausedPhaseName = overallStatus.split(' at ')[1]?.trim();
        }

        phasesData.forEach(phaseInfo => {
            const item = document.getElementById(`timeline-phase-${phaseInfo.phase_name.toLowerCase()}`);
            if (!item) return;

            item.querySelector('.status').textContent = phaseInfo.status;
            item.querySelector('.phase-duration').textContent = phaseInfo.duration ? `(${phaseInfo.duration}s)` : '';

            const body = item.querySelector('.timeline-item-body');
            body.innerHTML = `<div class="timeline-io-section"><h5>Outputs</h5>${renderOutput(phaseInfo)}</div>
                              <div class="item-actions ${phaseInfo.details?.length > 0 || phaseInfo.final_output ? '' : 'hidden'}">
                                <button class="download-phase-btn btn-secondary" data-phase="${phaseInfo.phase_name}" ${phaseInfo.status !== 'Completed' ? 'disabled' : ''}>Download Output</button>
                                <button class="logs-btn btn-secondary" data-phase="${phaseInfo.phase_name}">View Logs</button>
                              </div>`;

            item.classList.remove('active', 'completed', 'paused-for-input');
            if (phaseInfo.status === 'Completed') item.classList.add('completed');
            if (phaseInfo.phase_name === activePhaseName) item.classList.add('active');
            if (phaseInfo.phase_name === pausedPhaseName) item.classList.add('paused-for-input');
        });
    }

    function renderOutput(phaseInfo) {
        if (!phaseInfo.details || phaseInfo.details.length === 0) {
            return '<p class="no-output">No output generated yet.</p>';
        }
        return phaseInfo.details.map((log, index) => {
            const isCritic = log.agent_name === 'Critic';
            const summary = log.details || (isCritic ? log.output : 'No summary provided.');
            const fullOutput = log.output || 'No output available.';
            const uniqueId = `output-${phaseInfo.phase_name}-${log.agent_name}-${index}`.replace(/\s/g, '');

            if (!summary || summary.trim() === fullOutput.trim()) {
                return `<div class="output ${isCritic ? 'critic-feedback' : ''}"><div class="output-header"><span>${log.agent_name} Output</span></div><div class="output-content">${marked.parse(fullOutput)}</div></div>`;
            }
            return `<div class="output ${isCritic ? 'critic-feedback' : ''}"><div class="output-header"><span>${log.agent_name} Summary</span><button class="toggle-output-btn" data-target="${uniqueId}">View Full Output</button></div><div class="output-summary">${marked.parse(summary)}</div><div id="${uniqueId}" class="output-content hidden">${marked.parse(fullOutput)}</div></div>`;
        }).join('');
    }

    function renderExecutionSummary(data) {
        const body = selectors.summaryModalBody;
        if (!body || !data) return;

        const isSuccess = data.overall_status === 'Completed';

        let stepsHtml = `
            <div class="summary-item">
                <span class="summary-icon success">✔</span>
                <span class="summary-text">Loaded Initial Artifacts</span>
                <span class="status-chip completed">Success</span>
            </div>
        `;

        data.phases.forEach(phase => {
            const isPhaseSuccess = phase.status === 'Completed';
            stepsHtml += `
                <div class="summary-item">
                    <span class="summary-icon ${isPhaseSuccess ? 'success' : 'failed'}">${isPhaseSuccess ? '✔' : '✖'}</span>
                    <span class="summary-text">${phase.phase_name} Agent</span>
                    <span class="status-chip ${isPhaseSuccess ? 'completed' : 'failed'}">${phase.status}</span>
                </div>
            `;
        });

        if (isSuccess) {
            if (data.output_destination === 'github' && data.github_repo_url) {
                const repoName = data.github_repo_url.split('/').slice(-2).join('/');
                stepsHtml += `
                    <div class="summary-item">
                        <span class="summary-icon success">✔</span>
                        <span class="summary-text">Pushed Artifacts to <a href="${data.github_repo_url}" target="_blank">${repoName}</a></span>
                        <span class="status-chip completed">Success</span>
                    </div>`;
            } else {
                stepsHtml += `
                    <div class="summary-item">
                        <span class="summary-icon success">✔</span>
                        <span class="summary-text">Saved Artifacts to Local Disk</span>
                        <span class="status-chip completed">Success</span>
                    </div>`;
            }
        }

        body.innerHTML = `
            <div class="summary-header">
                <div class="summary-status-icon ${isSuccess ? 'success' : 'failed'}">
                    ${isSuccess ? '✔' : '✖'}
                </div>
                <h2>Workflow ${data.overall_status}</h2>
                <p>Project: <strong>${data.project_name}</strong></p>
            </div>
            <div class="summary-list">
                ${stepsHtml}
            </div>
        `;

        selectors.summaryModal.classList.remove('hidden');
    }

    // --- 4. WIZARD LOGIC ---

    function openWizard() {
        appState.wizardStep = 1;
        selectors.projectForm.reset();
        const form = selectors.projectForm;
        const source = selectors.formInputsSource;
        form.innerHTML = '';
        form.append(source.querySelector('#wizard-step-1'));
        form.append(source.querySelector('#wizard-step-2'));
        form.append(source.querySelector('#wizard-step-3'));
        form.append(source.querySelector('#wizard-step-4'));
        form.append(source.querySelector('.modal-footer'));

        const projectTypeInput = form.querySelector('#project_type_input');
        const projectTypeSelector = form.querySelector('.project-type-selector');
        if (projectTypeInput && projectTypeSelector) {
            projectTypeInput.value = 'enhancement';
            projectTypeSelector.querySelector('.type-card.selected')?.classList.remove('selected');
            projectTypeSelector.querySelector('.type-card[data-value="enhancement"]').classList.add('selected');
        }
        document.getElementById('github-output-config')?.classList.add('hidden');
        setupPhaseStepper();
        updateWizardView();
        selectors.projectWizardModal.classList.remove('hidden');
    }

    function closeWizard() {
        selectors.projectWizardModal.classList.add('hidden');
        const source = selectors.formInputsSource;
        const form = selectors.projectForm;
        source.append(form.querySelector('#wizard-step-1'));
        source.append(form.querySelector('#wizard-step-2'));
        source.append(form.querySelector('#wizard-step-3'));
        source.append(form.querySelector('#wizard-step-4'));
        source.append(form.querySelector('.modal-footer'));
    }

    function updateWizardView() {
        const wizard = selectors.projectWizardModal;
        wizard.querySelectorAll('.wizard-step').forEach(step => step.classList.add('hidden'));
        wizard.querySelector(`#wizard-step-${appState.wizardStep}`)?.classList.remove('hidden');

        wizard.querySelectorAll('.wizard-stepper .step').forEach(step => {
            step.classList.remove('active');
            if (parseInt(step.dataset.step) <= appState.wizardStep) {
                step.classList.add('active');
            }
        });
        const footer = selectors.projectForm.querySelector('.modal-footer');
        if (footer) {
            footer.querySelector('#wizard-back-btn').classList.toggle('hidden', appState.wizardStep === 1);
            footer.querySelector('#wizard-next-btn').classList.toggle('hidden', appState.wizardStep === 4);
            footer.querySelector('#wizard-submit-btn').classList.toggle('hidden', appState.wizardStep !== 4);
        }
        if (appState.wizardStep === 3) {
            updateFormView();
        }
    }

    function handleWizardNext() {
        if (appState.wizardStep === 2 && !selectors.projectForm.querySelector('#project-name').value.trim()) {
            showToast('Project Name is required.');
            return;
        }
        if (appState.wizardStep < 4) {
            appState.wizardStep++;
            updateWizardView();
        }
    }

    function handleWizardBack() {
        if (appState.wizardStep > 1) {
            appState.wizardStep--;
            updateWizardView();
        }
    }

    function handleProjectTypeSelect(e) {
        const card = e.target.closest('.type-card');
        if (!card) return;
        card.parentElement.querySelector('.type-card.selected')?.classList.remove('selected');
        card.classList.add('selected');
        const hiddenInput = selectors.projectForm.querySelector('#project_type_input');
        if (hiddenInput) hiddenInput.value = card.dataset.value;
    }

    function handleOutputModeSelect(selectedCard) {
        const container = selectedCard.closest('.input-mode-cards');
        const hiddenInput = document.getElementById('output-destination-input');
        const gitHubConfigSection = document.getElementById('github-output-config');
        const pushCheckboxesContainer = document.getElementById('github-push-phases-checkboxes');

        container.querySelector('.mode-card.selected')?.classList.remove('selected');
        selectedCard.classList.add('selected');
        const selectedValue = selectedCard.dataset.value;
        hiddenInput.value = selectedValue;

        if (selectedValue === 'github') {
            pushCheckboxesContainer.innerHTML = '';
            const startPhase = document.getElementById('start-phase-input').value;
            const endPhase = document.getElementById('end-phase-input').value;
            const startIndex = allPossiblePhases.indexOf(startPhase);
            const endIndex = allPossiblePhases.indexOf(endPhase);
            if (startIndex !== -1 && endIndex !== -1) {
                const selectedPhases = allPossiblePhases.slice(startIndex, endIndex + 1);
                selectedPhases.forEach(phase => {
                    const label = document.createElement('label');
                    label.innerHTML = `<input type="checkbox" name="github_push_phases" value="${phase}" checked><span>${phase}</span>`;
                    pushCheckboxesContainer.appendChild(label);
                });
            }
            gitHubConfigSection.classList.remove('hidden');
        } else {
            gitHubConfigSection.classList.add('hidden');
        }
    }

    function setupPhaseStepper() {
        const stepper = document.getElementById('phase-stepper');
        if (!stepper) return;
        stepper.innerHTML = '';
        let selectedStartPhase = null;
        const startPhaseInput = document.getElementById('start-phase-input');
        const endPhaseInput = document.getElementById('end-phase-input');

        allPossiblePhases.forEach(phase => {
            const tile = document.createElement('div');
            tile.className = 'step-tile';
            tile.dataset.phase = phase;
            tile.textContent = phase;
            stepper.appendChild(tile);
            tile.addEventListener('click', () => {
                selectedStartPhase = phase;
                updateSelection(phase);
            });
            tile.addEventListener('mouseover', () => {
                if (selectedStartPhase) updateSelection(phase);
            });
        });

        const updateSelection = (endPhase) => {
            const tiles = stepper.querySelectorAll('.step-tile');
            const startIndex = allPossiblePhases.indexOf(selectedStartPhase);
            const endIndex = allPossiblePhases.indexOf(endPhase);
            if (startIndex === -1 || endIndex === -1) return;
            const finalEndIndex = Math.max(startIndex, endIndex);

            tiles.forEach((tile, i) => {
                tile.classList.remove('is-start', 'is-end', 'in-range');
                if (i >= startIndex && i <= finalEndIndex) tile.classList.add('in-range');
                if (i === startIndex) tile.classList.add('is-start');
                if (i === finalEndIndex) tile.classList.add('is-end');
            });
            startPhaseInput.value = allPossiblePhases[startIndex];
            endPhaseInput.value = allPossiblePhases[finalEndIndex];
            startPhaseInput.dispatchEvent(new Event('change', { bubbles: true }));
        };
        selectedStartPhase = allPossiblePhases[0];
        updateSelection(allPossiblePhases[allPossiblePhases.length - 1]);
    }

    function updateFormView() {
        const form = selectors.projectForm;
        const projectType = form.querySelector('#project_type_input').value;
        const startPhase = form.querySelector('#start-phase-input').value;
        const enhancementInputs = form.querySelector('#enhancement-inputs');
        const newProjectInputs = form.querySelector('#new-project-inputs');

        enhancementInputs.classList.toggle('hidden', projectType !== 'enhancement');
        newProjectInputs.classList.toggle('hidden', projectType !== 'new');
        enhancementInputs.innerHTML = '';
        newProjectInputs.innerHTML = '<p class="input-guidance">Provide initial documents for the selected Start Phase.</p>';

        const requiredInputs = {
            enhancement: [['new_requirement', 'New Requirement Document'], ['existing_artifacts_zip', 'Existing Project Artifacts (.zip)']],
            new: {
                'ImpactAnalysis': [['new_requirement', 'New Requirement Document'], ['existing_artifacts_zip', 'Existing Project Artifacts (.zip)']],
                'Requirements': [['hl_functional_req', 'High-Level Functional Req'], ['hl_technical_req', 'High-Level Technical Req']],
                'Design': [['hl_technical_req', 'High-Level Technical Req'], ['user_stories', 'User Stories (SRS)']],
                'Testing': [['user_stories', 'User Stories (SRS)'], ['design', 'Design Document (HLD)']],
                'Coding': [['design', 'Design Document (HLD)'], ['testing_artifacts', 'Test Cases / Plan']],
                'Deployment': [['design', 'Design Document (HLD)']]
            }
        };
        const inputsToCreate = projectType === 'new' ? (requiredInputs.new[startPhase] || []) : requiredInputs.enhancement;
        const container = projectType === 'new' ? newProjectInputs : enhancementInputs;
        inputsToCreate.forEach(([name, label]) => createDynamicInput(container, name, label));
    }

    function createDynamicInput(container, name, label) {
        const template = selectors.formInputsSource.querySelector('#dynamic-input-template').cloneNode(true);
        template.removeAttribute('id');
        template.querySelector('.dynamic-label').textContent = label;
        template.querySelectorAll('input[type="radio"]').forEach(radio => radio.name = `input_mode_${name}`);
        template.querySelector('.file-input').name = `${name}_file`;
        template.querySelector('.github-input').name = `${name}_github_url`;
        container.appendChild(template);
    }

    // --- 5. EVENT HANDLERS & API CALLS ---

    function setupEventListeners() {
        selectors.createProjectBtn.addEventListener('click', openWizard);

        selectors.projectForm.addEventListener('click', (e) => {
            const target = e.target;
            if (target.closest('.type-card')) handleProjectTypeSelect(e);
            if (target.closest('#wizard-next-btn')) handleWizardNext();
            if (target.closest('#wizard-back-btn')) handleWizardBack();
            const outputCard = target.closest('.mode-card[data-value]');
            if (outputCard && outputCard.closest('#wizard-step-4')) {
                handleOutputModeSelect(outputCard);
            }
        });

        selectors.projectForm.addEventListener('change', (e) => {
            if (e.target.closest('#phase-stepper') || e.target.closest('.project-type-selector')) {
                updateFormView();
            }
            const inputCardRadio = e.target.closest('.input-mode-cards input[type="radio"]');
            if (inputCardRadio) {
                const fieldsContainer = inputCardRadio.closest('.form-group').querySelector('.input-mode-fields');
                if (fieldsContainer) {
                    fieldsContainer.querySelector('.file-drop-area').classList.toggle('hidden', e.target.value !== 'file');
                    fieldsContainer.querySelector('.github-input').classList.toggle('hidden', e.target.value !== 'github');
                }
            }
        });

        selectors.projectForm.addEventListener('submit', handleProjectFormSubmit);
        selectors.backToDashboardBtn.addEventListener('click', () => showView('dashboard'));
        selectors.projectGrid.addEventListener('click', handleProjectCardClick);
        selectors.timeline.addEventListener('click', handleTimelineClick);
        selectors.resumeButton.addEventListener('click', handleResumeWorkflow);
        selectors.expandEditorBtn.addEventListener('click', openEditorModal);
        selectors.saveEditBtn.addEventListener('click', saveAndCloseEditorModal);
        selectors.cancelEditBtn.addEventListener('click', closeEditorModal);
        selectors.downloadOutputsBtn.addEventListener('click', handleDownloadAll);

        setupModalClose(selectors.logModal, selectors.closeLogModalBtn);
        setupModalClose(selectors.editorModal, selectors.closeEditorModalBtn);
        setupModalClose(selectors.projectWizardModal, selectors.closeWizardBtn);
        setupModalClose(selectors.summaryModal, selectors.closeSummaryBtn);
        const summaryCloseBtn = document.getElementById('summary-close-btn');
        if (summaryCloseBtn) {
            summaryCloseBtn.addEventListener('click', () => {
                selectors.summaryModal.classList.add('hidden');
            });
        }
    }

    async function handleProjectFormSubmit(e) {
        e.preventDefault();
        const submitBtn = e.target.querySelector('#wizard-submit-btn');
        const formData = new FormData(selectors.projectForm);

        submitBtn.disabled = true;
        submitBtn.textContent = 'Creating...';

        try {
            const response = await fetch(`${API_URL}/projects`, { method: 'POST', body: formData });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.detail || 'Failed to create project');
            }

            const result = await response.json();
            appState.projectId = result.project_id;
            appState.summaryShown = false;

            closeWizard();
            showToast('Project created successfully!', 'success');

            const projectName = formData.get('project_name');
            selectors.projectTitleExecution.textContent = projectName;

            const startPhase = formData.get('start_phase');
            const endPhase = formData.get('end_phase');
            const phasesToDisplay = allPossiblePhases.slice(allPossiblePhases.indexOf(startPhase), allPossiblePhases.indexOf(endPhase) + 1);

            renderProjectSummary({
                project_name: projectName,
                project_type: formData.get('project_type'),
                start_phase: startPhase,
                end_phase: endPhase,
                human_in_loop_steps: Array.from(formData.getAll('human_steps'))
            });

            showView('execution');
            renderTimeline(selectors.timeline, phasesToDisplay.map(name => ({ phase_name: name, status: 'Pending', details: [] })));
            startExecution();

        } catch (error) {
            console.error('Form submission error:', error);
            showToast(`Error: ${error.message}`);
        } finally {
            submitBtn.disabled = false;
            submitBtn.textContent = 'Create and Start Project';
        }
    }
    async function handleDeleteProject(projectId) {
        if (!confirm('Are you sure you want to delete this project? This action cannot be undone.')) {
            return;
        }

        try {
            const response = await fetch(`${API_URL}/projects/${projectId}`, {
                method: 'DELETE',
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.detail || 'Failed to delete the project.');
            }

            showToast('Project deleted successfully.', 'success');
            loadAndRenderProjects();

        } catch (error) {
            console.error('Error deleting project:', error);
            showToast(error.message);
        }
    }

    async function handleProjectCardClick(e) {
        const menuToggle = e.target.closest('.menu-toggle-btn');
        const deleteBtn = e.target.closest('.delete-project-btn');

        if (menuToggle) {
            e.stopPropagation();
            const parentMenu = menuToggle.parentElement;
            const menu = parentMenu.querySelector('.dropdown-menu');
            if (menu) {
                document.querySelectorAll('.dropdown-menu.visible').forEach(m => {
                    if (m !== menu) m.classList.remove('visible');
                });
                menu.classList.toggle('visible');
            } else {
                console.error('CRITICAL: Could not find the .dropdown-menu element inside the parent!');
            }
            return;
        }

        if (deleteBtn) {
            e.stopPropagation();
            handleDeleteProject(deleteBtn.dataset.id);
            return;
        }

        const card = e.target.closest('.project-card');
        if (card) {
            appState.projectId = card.dataset.id;
            appState.summaryShown = false;
            try {
                const response = await fetch(`${API_URL}/projects/${appState.projectId}/status`);
                if (!response.ok) throw new Error('Could not fetch project status.');
                const data = await response.json();
                appState.currentExecutionData = data;

                selectors.projectTitleExecution.textContent = data.project_name || 'Project Details';

                renderProjectSummary(data);
                renderTimeline(selectors.timeline, data.phases);
                updateStatus(data.overall_status, data.phases, true);

                showView('execution');

                const status = data.overall_status?.toLowerCase() || '';
                if (status.includes('in progress') || status.includes('paused')) {
                    if (appState.pollInterval) clearInterval(appState.pollInterval);
                    appState.pollInterval = setInterval(pollStatus, 2000);
                }
            } catch (error) {
                showToast(error.message);
                console.error(error);
            }
        }
    }

    document.addEventListener('click', (e) => {
        if (!e.target.closest('.card-menu')) {
            document.querySelectorAll('.dropdown-menu.visible').forEach(menu => {
                menu.classList.remove('visible');
            });
        }
    });

    function handleTimelineClick(e) {
        const target = e.target;

        const timelineItemHeader = target.closest('.timeline-item-header');
        if (timelineItemHeader) {
            timelineItemHeader.querySelector('.toggle-icon')?.classList.toggle('expanded');
            timelineItemHeader.nextElementSibling?.classList.toggle('expanded');
            return;
        }

        const toggleOutputBtn = target.closest('.toggle-output-btn');
        if (toggleOutputBtn) {
            const targetElement = document.getElementById(toggleOutputBtn.dataset.target);
            if (targetElement) {
                const isHidden = targetElement.classList.toggle('hidden');
                toggleOutputBtn.textContent = isHidden ? 'View Full Output' : 'Hide Full Output';
            }
            return;
        }

        const logsBtn = target.closest('.logs-btn');
        if (logsBtn) handleViewLogs(logsBtn.dataset.phase);

        const downloadBtn = target.closest('.download-phase-btn');
        if (downloadBtn) handleDownloadPhaseOutput(downloadBtn.dataset.phase);
    }

    async function handleViewLogs(phase) {
        if (!appState.projectId || !phase) return;
        try {
            const response = await fetch(`${API_URL}/projects/${appState.projectId}/technical_logs/${phase}`);
            if (!response.ok) throw new Error('Failed to fetch logs.');
            const logs = await response.json();

            const logContent = logs.map(log => {
                const metadata = JSON.parse(log.metadata);
                const metadataItems = Object.entries(metadata).map(([key, value]) =>
                    `<div class="metadata-item"><span class="metadata-key">${key}:</span><span class="metadata-value">${value}</span></div>`
                ).join('');

                return `<div class="log-entry"><div class="log-entry-header"><span class="log-timestamp">${new Date(log.timestamp).toLocaleString()}</span><strong class="log-event">${log.event_description}</strong></div><div class="metadata-container">${metadataItems}</div></div>`
            }).join('') || '<p>No technical logs for this phase.</p>';

            selectors.logViewer.innerHTML = logContent;
            selectors.logModal.classList.remove('hidden');
        } catch (error) {
            showToast(error.message);
            console.error(error);
        }
    }

    function handleDownloadPhaseOutput(phase) {
        if (!appState.projectId || !phase) return;
        const url = `${API_URL}/projects/${appState.projectId}/download/${phase}`;
        window.open(url, '_blank');
    }

    function handleDownloadAll() {
        if (!appState.projectId) return;
        const url = `${API_URL}/projects/${appState.projectId}/download-all`;
        window.open(url, '_blank');
    }

    async function handleResumeWorkflow() {
        if (!appState.projectId) return;
        const phaseOfEdit = selectors.resumeButton.dataset.phaseOfEdit;
        const editedContent = selectors.humanEditArea.value;
        if (!editedContent.trim()) {
            showToast('The document content cannot be empty.');
            return;
        }
        const formData = new FormData();
        formData.append('edited_content', editedContent);
        formData.append('phase_of_edit', phaseOfEdit);
        try {
            const response = await fetch(`${API_URL}/projects/${appState.projectId}/resume`, { method: 'POST', body: formData });
            if (!response.ok) throw new Error((await response.json()).detail || 'Failed to resume.');
            selectors.humanInterventionBox.classList.add('hidden');
            if (appState.pollInterval) clearInterval(appState.pollInterval);
            appState.pollInterval = setInterval(pollStatus, 2000);
            showToast('Workflow resumed!', 'success');
        } catch (error) {
            showToast(`Error resuming project: ${error.message}`);
        }
    }

    function pollStatus() {
        if (!appState.projectId) {
            clearInterval(appState.pollInterval);
            return;
        };
        fetch(`${API_URL}/projects/${appState.projectId}/status`)
            .then(res => res.ok ? res.json() : Promise.reject('Failed to fetch status'))
            .then(data => {
                const oldData = appState.currentExecutionData;
                appState.currentExecutionData = data;

                let needsFullRender = false;
                if (!oldData || oldData.overall_status !== data.overall_status || oldData.phases.length !== data.phases.length) {
                    needsFullRender = true;
                } else {
                    for (let i = 0; i < data.phases.length; i++) {
                        if (oldData.phases[i].details.length !== data.phases[i].details.length) {
                            needsFullRender = true;
                            break;
                        }
                    }
                }
                updateStatus(data.overall_status, data.phases, needsFullRender);
            })
            .catch(error => {
                console.error("Polling error:", error);
                clearInterval(appState.pollInterval);
                updateStatus('Connection Error');
            });
    }

    function updateStatus(overallStatus, phases = [], isFullRender = false) {
        selectors.projectStatus.textContent = overallStatus;
        let statusClass = (overallStatus?.toLowerCase() || 'pending').split(' ')[0];
        if (statusClass === 'in') statusClass = 'inprogress';
        selectors.statusIndicator.className = `status-indicator ${statusClass}`;

        if (isFullRender) {
            updateTimeline(phases, overallStatus);
        }

        const isPaused = overallStatus?.includes('Paused');
        if (isPaused) {
            clearInterval(appState.pollInterval);
            const pausedPhaseName = overallStatus.split(' at ')[1]?.trim();
            const phaseInfo = phases?.find(p => p.phase_name === pausedPhaseName);

            if (phaseInfo && phaseInfo.final_output) {
                selectors.humanInterventionPhase.textContent = pausedPhaseName;
                selectors.humanEditArea.value = phaseInfo.final_output;
                selectors.resumeButton.dataset.phaseOfEdit = pausedPhaseName;
                selectors.humanInterventionBox.classList.remove('hidden');
            }
        } else {
            selectors.humanInterventionBox.classList.add('hidden');
        }

        const isFinished = overallStatus === 'Completed' || overallStatus === 'Failed';
        if (isFinished) {
            clearInterval(appState.pollInterval);
            if (!appState.summaryShown) {
                renderExecutionSummary(appState.currentExecutionData);
                appState.summaryShown = true;
            }
        }
        selectors.downloadOutputsBtn.disabled = overallStatus !== 'Completed';
    }

    function startExecution() {
        fetch(`${API_URL}/projects/${appState.projectId}/execute`, { method: 'POST' });
        if (appState.pollInterval) clearInterval(appState.pollInterval);
        appState.pollInterval = setInterval(pollStatus, 2000);
    }

    function setupModalClose(modalElement, closeButton) {
        if (!modalElement) return;
        const close = () => {
            if (modalElement.id === 'project-wizard-modal') {
                closeWizard();
            } else {
                modalElement.classList.add('hidden');
            }
        };
        if (closeButton) closeButton.addEventListener('click', close);
        modalElement.addEventListener('click', (e) => {
            if (e.target === modalElement) close();
        });
    }

    function openEditorModal() {
        selectors.modalEditorArea.value = selectors.humanEditArea.value;
        selectors.editorModal.classList.remove('hidden');
    }

    function closeEditorModal() {
        selectors.editorModal.classList.add('hidden');
    }

    function saveAndCloseEditorModal() {
        selectors.humanEditArea.value = selectors.modalEditorArea.value;
        closeEditorModal();
    }

    function initializeApp() {
        setupEventListeners();
        showView('dashboard');
    }

    // --- 6. INITIALIZATION ---
    initializeApp();
});