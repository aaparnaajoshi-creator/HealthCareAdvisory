import requests

url = "https://api.github.com/repos/sagark82/Agentic_SDLC_Test_Enh_01/contents/"
headers = {"Authorization": "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"}

response = requests.get(url, headers=headers)

if response.status_code == 200:
    print(response.json())
else:
    print("Error:", response.status_code, response.text)
