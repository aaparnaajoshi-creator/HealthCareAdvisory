```markdown
### backend/requirements.txt
```
fastapi
uvicorn[standard]
sqlalchemy
psycopg2-binary
pydantic[email]
python-dotenv
slowapi
pytest
httpx
requests
```

### backend/config.py
```python
import os
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://user:password@localhost/pharmacorp_db")
```

### backend/database/schema.sql
```sql
-- This script sets up the necessary tables for the PharmaCorp application.
-- It assumes the 'pharmacorp_db' database has been created.
-- For UUID generation, ensure necessary extensions are enabled in PostgreSQL.
-- Run `CREATE EXTENSION IF NOT EXISTS "pgcrypto";` or use `uuid-ossp` if preferred.
-- `gen_random_uuid()` is part of pgcrypto and is the modern standard.

-- Drop tables if they exist to ensure a clean slate
DROP TABLE IF EXISTS newsletter_subscriptions;
DROP TABLE IF EXISTS contact_submissions;

-- Table to store contact form submissions
CREATE TABLE contact_submissions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    submitted_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Table to store newsletter signups
CREATE TABLE newsletter_subscriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) NOT NULL UNIQUE,
    consent_given BOOLEAN NOT NULL,
    subscribed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Add indexes for faster lookups
CREATE INDEX idx_contact_submissions_email ON contact_submissions(email);
CREATE INDEX idx_contact_submissions_submitted_at ON contact_submissions(submitted_at);

CREATE INDEX idx_newsletter_subscriptions_subscribed_at ON newsletter_subscriptions(subscribed_at);
```

### backend/database/database.py
```python
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from ..config import DATABASE_URL

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Dependency to get DB session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
```

### backend/database/models.py
```python
import uuid
from sqlalchemy import Column, String, Text, DateTime, Boolean
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from .database import Base

class ContactSubmission(Base):
    __tablename__ = "contact_submissions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    email = Column(String(255), nullable=False)
    message = Column(Text, nullable=False)
    submitted_at = Column(DateTime(timezone=True), server_default=func.now())

class NewsletterSubscription(Base):
    __tablename__ = "newsletter_subscriptions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String(255), nullable=False, unique=True)
    consent_given = Column(Boolean, nullable=False)
    subscribed_at = Column(DateTime(timezone=True), server_default=func.now())
```

### backend/schemas/submission.py
```python
from pydantic import BaseModel, EmailStr, Field

class ContactSubmissionSchema(BaseModel):
    name: str = Field(..., min_length=2, max_length=255)
    email: EmailStr
    message: str = Field(..., min_length=10)

class NewsletterSubscriptionSchema(BaseModel):
    email: EmailStr
    consent: bool

    class Config:
        orm_mode = True
```

### backend/routers/submissions.py
```python
from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from ..database import database, models
from ..schemas import submission as schemas
from slowapi import Limiter
from slowapi.util import get_remote_address

limiter = Limiter(key_func=get_remote_address)
router = APIRouter()

@router.post("/contact", status_code=201)
@limiter.limit("5/minute")
async def submit_contact_form(
    submission: schemas.ContactSubmissionSchema,
    request: Request,
    db: Session = Depends(database.get_db)
):
    """
    Submits a new inquiry from the contact form.
    """
    db_submission = models.ContactSubmission(
        name=submission.name,
        email=submission.email,
        message=submission.message
    )
    db.add(db_submission)
    db.commit()
    db.refresh(db_submission)
    return {"status": "success", "message": "Your message has been received."}

@router.post("/newsletter", status_code=201)
@limiter.limit("10/minute")
async def submit_newsletter_signup(
    subscription: schemas.NewsletterSubscriptionSchema,
    request: Request,
    db: Session = Depends(database.get_db)
):
    """
    Subscribes a new email address to the newsletter.
    """
    if not subscription.consent:
        raise HTTPException(
            status_code=400,
            detail="Consent must be given to subscribe."
        )

    db_subscription = models.NewsletterSubscription(
        email=subscription.email,
        consent_given=subscription.consent
    )
    try:
        db.add(db_subscription)
        db.commit()
        db.refresh(db_subscription)
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=409,
            detail="This email address is already subscribed."
        )
    return {"status": "success", "message": "Thank you for subscribing!"}
```

### backend/main.py
```python
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address

from .routers import submissions

# Initialize Rate Limiter
limiter = Limiter(key_func=get_remote_address, default_limits=["200 per minute"])

app = FastAPI(
    title="PharmaCorp API",
    description="Backend API for the PharmaCorp commercial website.",
    version="1.0.0"
)

# Add state to app for the limiter
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# CORS Middleware
origins = [
    "http://localhost:3000",  # Allow frontend dev server
    "https://www.your-production-domain.com" # Add your production domain
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(submissions.router, prefix="/api/v1", tags=["Submissions"])

@app.get("/health", tags=["Health Check"])
def health_check():
    return {"status": "ok"}
```

### backend/tests/test_submissions.py
```python
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from ..main import app
from ..database.database import Base, get_db

# Use an in-memory SQLite database for testing
SQLALCHEMY_DATABASE_URL = "sqlite:///./test.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Override the get_db dependency to use the test database
def override_get_db():
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db

client = TestClient(app)

@pytest.fixture(scope="function", autouse=True)
def setup_and_teardown_db():
    # Create tables before each test
    Base.metadata.create_all(bind=engine)
    yield
    # Drop tables after each test
    Base.metadata.drop_all(bind=engine)


def test_health_check():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}

# --- Contact Form Tests ---

def test_submit_contact_form_success():
    response = client.post(
        "/api/v1/contact",
        json={"name": "John Doe", "email": "john.doe@example.com", "message": "This is a test message."}
    )
    assert response.status_code == 201
    assert response.json() == {"status": "success", "message": "Your message has been received."}

def test_submit_contact_form_invalid_email():
    response = client.post(
        "/api/v1/contact",
        json={"name": "Jane Doe", "email": "invalid-email", "message": "Another test message."}
    )
    assert response.status_code == 422
    assert "value is not a valid email address" in response.text

def test_submit_contact_form_short_message():
    response = client.post(
        "/api/v1/contact",
        json={"name": "Jane Doe", "email": "jane.doe@example.com", "message": "short"}
    )
    assert response.status_code == 422
    assert "ensure this value has at least 10 characters" in response.text

# --- Newsletter Signup Tests ---

def test_submit_newsletter_signup_success():
    response = client.post(
        "/api/v1/newsletter",
        json={"email": "test@example.com", "consent": True}
    )
    assert response.status_code == 201
    assert response.json() == {"status": "success", "message": "Thank you for subscribing!"}

def test_submit_newsletter_signup_no_consent():
    response = client.post(
        "/api/v1/newsletter",
        json={"email": "noconsent@example.com", "consent": False}
    )
    assert response.status_code == 400
    assert response.json()["detail"] == "Consent must be given to subscribe."

def test_submit_newsletter_signup_duplicate_email():
    # First submission should succeed
    client.post("/api/v1/newsletter", json={"email": "duplicate@example.com", "consent": True})
    
    # Second submission with the same email should fail
    response = client.post(
        "/api/v1/newsletter",
        json={"email": "duplicate@example.com", "consent": True}
    )
    assert response.status_code == 409
    assert response.json()["detail"] == "This email address is already subscribed."

def test_submit_newsletter_invalid_email():
    response = client.post(
        "/api/v1/newsletter",
        json={"email": "not-an-email", "consent": True}
    )
    assert response.status_code == 422
```

### frontend/package.json
```json
{
  "name": "pharmacorp-frontend",
  "version": "0.1.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint",
    "test": "jest --watch"
  },
  "dependencies": {
    "next": "13.4.19",
    "react": "18.2.0",
    "react-dom": "18.2.0"
  },
  "devDependencies": {
    "@testing-library/jest-dom": "^6.1.3",
    "@testing-library/react": "^14.0.0",
    "eslint": "8.49.0",
    "eslint-config-next": "13.4.19",
    "jest": "^29.7.0",
    "jest-environment-jsdom": "^29.7.0"
  }
}
```

### frontend/next.config.js
```javascript
/** @type {import('next').NextConfig} */

const ContentSecurityPolicy = `
  default-src 'self';
  script-src 'self' 'unsafe-eval' 'unsafe-inline';
  style-src 'self' 'unsafe-inline';
  img-src 'self' data:;
  font-src 'self';
  connect-src 'self' http://localhost:8000;
  object-src 'none';
  base-uri 'self';
  form-action 'self';
  frame-ancestors 'none';
`;

const securityHeaders = [
  {
    key: 'Content-Security-Policy',
    value: ContentSecurityPolicy.replace(/\s{2,}/g, ' ').trim(),
  },
  {
    key: 'X-Content-Type-Options',
    value: 'nosniff',
  },
  {
    key: 'X-Frame-Options',
    value: 'DENY',
  },
  {
    key: 'X-XSS-Protection',
    value: '1; mode=block',
  },
];

const nextConfig = {
  reactStrictMode: true,
  async headers() {
    return [
      {
        // Apply these headers to all routes in your application.
        source: '/:path*',
        headers: securityHeaders,
      },
    ];
  },
};

module.exports = nextConfig;
```

### frontend/jest.config.js
```javascript
const nextJest = require('next/jest')

const createJestConfig = nextJest({
  dir: './',
})

const customJestConfig = {
  setupFilesAfterEnv: ['<rootDir>/jest.setup.js'],
  testEnvironment: 'jest-environment-jsdom',
}

module.exports = createJestConfig(customJestConfig)
```

### frontend/jest.setup.js
```javascript
import '@testing-library/jest-dom'
```

### frontend/styles/globals.css
```css
:root {
  --primary-color: #00529b;
  --secondary-color: #00a9e0;
  --accent-color: #f5a623;
  --text-color: #333;
  --bg-color: #ffffff;
  --light-gray: #f4f4f4;
  --border-color: #ddd;
}

html,
body {
  padding: 0;
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Oxygen,
    Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue, sans-serif;
  color: var(--text-color);
  background-color: var(--bg-color);
}

a {
  color: var(--primary-color);
  text-decoration: none;
}

* {
  box-sizing: border-box;
}

main {
  min-height: 80vh;
  padding: 2rem 1rem;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 1rem;
}

h1, h2, h3 {
  color: var(--primary-color);
}

button, input[type="submit"] {
  background-color: var(--primary-color);
  color: white;
  border: none;
  padding: 12px 24px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 1rem;
  transition: background-color 0.2s;
}

button:hover, input[type="submit"]:hover {
  background-color: #003d73;
}

button:disabled {
  background-color: #ccc;
  cursor: not-allowed;
}

input[type="text"], input[type="email"], textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid var(--border-color);
    border-radius: 4px;
    margin-bottom: 1rem;
    font-size: 1rem;
}
```

### frontend/lib/api.js
```javascript
// This file mocks a headless CMS API

const products = [
  {
    id: 1,
    name: 'ProductA',
    slug: 'producta',
    tagline: 'A revolutionary new treatment.',
    thumbnail: '/images/product_thumb.png',
    description: '<p>ProductA is indicated for the treatment of specific conditions. Consult your doctor for more information.</p>',
    indication: 'For specific conditions.',
    dosing: 'As prescribed by a healthcare professional.',
    isi: 'Important Safety Information for ProductA: This product may cause side effects. Please discuss with your doctor. Not for use in patients with known hypersensitivity...',
    pi_pdf: '/pdfs/placeholder_pi.pdf',
  },
  {
    id: 2,
    name: 'ProductB',
    slug: 'productb',
    tagline: 'The trusted choice for professionals.',
    thumbnail: '/images/product_thumb.png',
    description: '<p>ProductB offers a new approach to patient care. It has been clinically tested for safety and efficacy.</p>',
    indication: 'For advanced patient care.',
    dosing: 'Varies based on patient needs.',
    isi: 'Important Safety Information for ProductB: Side effects may include dizziness or nausea. Do not operate heavy machinery until you know how this drug affects you.',
    pi_pdf: '/pdfs/placeholder_pi.pdf',
  },
];

const pages = {
  'about-us': {
    title: 'About Us',
    content: '<h1>Our Mission</h1><p>PharmaCorp is dedicated to improving lives through innovative science and medicine. Our history is rich with breakthroughs, and our values guide everything we do.</p>',
  },
  'privacy-policy': {
    title: 'Privacy Policy',
    content: '<h1>Privacy Policy</h1><p>This page details how PharmaCorp handles your data. We are committed to protecting your privacy...</p>',
  },
  'terms-of-use': {
    title: 'Terms of Use',
    content: '<h1>Terms of Use</h1><p>By using this website, you agree to the following terms and conditions...</p>',
  },
};


export function getAllProducts() {
  return products;
}

export function getProductBySlug(slug) {
  return products.find((p) => p.slug === slug);
}

export function getPageContent(slug) {
  return pages[slug];
}
```

### frontend/components/Header.js
```javascript
import Link from 'next/link';
import { useState } from 'react';
import styles from './Header.module.css';

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className={styles.header}>
      <div className={styles.container}>
        <Link href="/" className={styles.logo}>PharmaCorp</Link>
        <button 
          className={styles.hamburger} 
          onClick={() => setMenuOpen(!menuOpen)}
          aria-expanded={menuOpen}
          aria-controls="main-nav"
        >
          ☰
        </button>
        <nav id="main-nav" className={`${styles.nav} ${menuOpen ? styles.open : ''}`}>
          <ul>
            <li><Link href="/">Home</Link></li>
            <li><Link href="/about-us">About Us</Link></li>
            <li><Link href="/products">Products</Link></li>
            <li><Link href="/contact-us">Contact Us</Link></li>
          </ul>
        </nav>
      </div>
    </header>
  );
}
```

### frontend/components/Header.module.css
```css
.header {
  background-color: var(--bg-color);
  border-bottom: 1px solid var(--border-color);
  padding: 1rem 0;
  position: sticky;
  top: 0;
  z-index: 1000;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 1rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.logo {
  font-weight: bold;
  font-size: 1.5rem;
  color: var(--primary-color);
}

.nav ul {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  gap: 1.5rem;
}

.nav a {
  color: var(--text-color);
  font-weight: 500;
  transition: color 0.2s;
}

.nav a:hover {
  color: var(--primary-color);
}

.hamburger {
  display: none;
  background: none;
  border: none;
  font-size: 2rem;
  color: var(--primary-color);
  cursor: pointer;
}

@media (max-width: 768px) {
  .hamburger {
    display: block;
  }
  .nav {
    display: none;
    position: absolute;
    top: 100%;
    left: 0;
    width: 100%;
    background-color: var(--bg-color);
    border-top: 1px solid var(--border-color);
  }
  .nav.open {
    display: block;
  }
  .nav ul {
    flex-direction: column;
    padding: 1rem;
    gap: 1rem;
    align-items: center;
  }
}
```

### frontend/components/Footer.js
```javascript
import Link from 'next/link';
import NewsletterForm from './NewsletterForm';
import styles from './Footer.module.css';

export default function Footer() {
  return (
    <footer className={styles.footer}>
      <div className={styles.container}>
        <div className={styles.links}>
          <h4>PharmaCorp</h4>
          <Link href="/privacy-policy">Privacy Policy</Link>
          <Link href="/terms-of-use">Terms of Use</Link>
          <Link href="/contact-us">Contact Us</Link>
        </div>
        <div className={styles.newsletter}>
          <h4>Stay Informed</h4>
          <p>Sign up for our newsletter to receive updates.</p>
          <NewsletterForm />
        </div>
      </div>
      <div className={styles.copyright}>
        © {new Date().getFullYear()} PharmaCorp. All rights reserved.
      </div>
    </footer>
  );
}
```

### frontend/components/Footer.module.css
```css
.footer {
  background-color: var(--light-gray);
  padding: 2rem 0 0;
  border-top: 1px solid var(--border-color);
  color: #555;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 1rem;
  display: flex;
  justify-content: space-between;
  gap: 2rem;
  flex-wrap: wrap;
}

.links, .newsletter {
  flex: 1;
  min-width: 250px;
}

.links a {
  display: block;
  margin-bottom: 0.5rem;
  color: #555;
}

.links a:hover {
  color: var(--primary-color);
}

.copyright {
  text-align: center;
  padding: 1rem;
  margin-top: 2rem;
  border-top: 1px solid var(--border-color);
  font-size: 0.9rem;
}
```

### frontend/components/Layout.js
```javascript
import Header from './Header';
import Footer from './Footer';
import CookieBanner from './CookieBanner';

export default function Layout({ children }) {
  return (
    <>
      <Header />
      <main>
        <div className="container">{children}</div>
      </main>
      <Footer />
      <CookieBanner />
    </>
  );
}
```

### frontend/components/NewsletterForm.js
```javascript
import { useState } from 'react';
import styles from './Form.module.css';

export default function NewsletterForm() {
  const [email, setEmail] = useState('');
  const [consent, setConsent] = useState(false);
  const [status, setStatus] = useState('idle'); // idle, loading, success, error
  const [message, setMessage] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus('loading');
    setMessage('');

    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/newsletter`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, consent }),
      });

      const result = await response.json();

      if (!response.ok) {
        // Handle FastAPI validation errors and other API errors
        if (result.detail && Array.isArray(result.detail)) {
          // This is a validation error from FastAPI
          const errorMsg = result.detail.map(err => `${err.loc[1]}: ${err.msg}`).join(', ');
          throw new Error(errorMsg);
        } else if (result.detail) {
          // This is a standard HTTP exception message
          throw new Error(result.detail);
        }
        throw new Error('An unexpected error occurred.');
      }

      setStatus('success');
      setMessage(result.message);
      setEmail('');
      setConsent(false);
    } catch (error) {
      setStatus('error');
      setMessage(error.message || 'Failed to subscribe. Please try again.');
    }
  };

  return (
    <form onSubmit={handleSubmit} className={styles.form}>
      {status === 'success' && <p className={styles.successMessage}>{message}</p>}
      {status === 'error' && <p className={styles.errorMessage}>{message}</p>}
      
      {status !== 'success' && (
        <>
          <div className={styles.inputGroup}>
            <input
              type="email"
              id="newsletter-email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="your.email@example.com"
              required
              disabled={status === 'loading'}
            />
            <button type="submit" disabled={status === 'loading' || !consent}>
              {status === 'loading' ? 'Signing Up...' : 'Sign Up'}
            </button>
          </div>
          <div className={styles.consent}>
            <input
              type="checkbox"
              id="consent"
              checked={consent}
              onChange={(e) => setConsent(e.target.checked)}
              required
            />
            <label htmlFor="consent">
              I agree to the Privacy Policy and consent to receive emails.
            </label>
          </div>
        </>
      )}
    </form>
  );
}
```

### frontend/components/ContactForm.js
```javascript
import { useState } from 'react';
import styles from './Form.module.css';

export default function ContactForm() {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [status, setStatus] = useState('idle'); // idle, loading, success, error
  const [responseMessage, setResponseMessage] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus('loading');
    setResponseMessage('');

    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/contact`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const result = await response.json();

      if (!response.ok) {
        if (result.detail && Array.isArray(result.detail)) {
          const errorMsg = result.detail.map(err => `${err.loc[1]}: ${err.msg}`).join(', ');
          throw new Error(errorMsg);
        } else if (result.detail) {
          throw new Error(result.detail);
        }
        throw new Error('An unexpected error occurred.');
      }
      
      setStatus('success');
      setResponseMessage(result.message);
      setFormData({ name: '', email: '', message: '' });
    } catch (error) {
      setStatus('error');
      setResponseMessage(error.message || 'Failed to send message. Please try again.');
    }
  };

  if (status === 'success') {
    return <p className={styles.successMessage}>{responseMessage}</p>;
  }

  return (
    <form onSubmit={handleSubmit} className={styles.form}>
      {status === 'error' && <p className={styles.errorMessage}>{responseMessage}</p>}
      
      <label htmlFor="name">Name</label>
      <input
        type="text"
        id="name"
        name="name"
        value={formData.name}
        onChange={handleChange}
        required
        minLength="2"
        disabled={status === 'loading'}
      />

      <label htmlFor="email">Email</label>
      <input
        type="email"
        id="email"
        name="email"
        value={formData.email}
        onChange={handleChange}
        required
        disabled={status === 'loading'}
      />

      <label htmlFor="message">Message</label>
      <textarea
        id="message"
        name="message"
        value={formData.message}
        onChange={handleChange}
        required
        minLength="10"
        rows="5"
        disabled={status === 'loading'}
      ></textarea>

      <button type="submit" disabled={status === 'loading'}>
        {status === 'loading' ? 'Sending...' : 'Submit'}
      </button>
    </form>
  );
}
```

### frontend/components/Form.module.css
```css
.form {
  width: 100%;
  max-width: 600px;
}

.inputGroup {
  display: flex;
}

.inputGroup input {
  flex-grow: 1;
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
  margin-bottom: 0;
}

.inputGroup button {
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
}

.consent {
  margin-top: 0.5rem;
  font-size: 0.8rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.errorMessage {
  color: #d8000c;
  background-color: #ffbaba;
  padding: 10px;
  border-radius: 4px;
  margin-bottom: 1rem;
}

.successMessage {
  color: #4f8a10;
  background-color: #dff2bf;
  padding: 10px;
  border-radius: 4px;
  margin-bottom: 1rem;
}
```

### frontend/components/StickyISI.js
```javascript
import { useState } from 'react';
import styles from './StickyISI.module.css';

export default function StickyISI({ content }) {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <aside className={`${styles.isiContainer} ${isExpanded ? styles.expanded : ''}`}>
      <div className={styles.isiHeader}>
        <h3>Important Safety Information</h3>
        <button onClick={() => setIsExpanded(!isExpanded)} aria-expanded={isExpanded}>
          {isExpanded ? 'Collapse' : 'Expand'}
        </button>
      </div>
      <div className={styles.isiContent} dangerouslySetInnerHTML={{ __html: content }} />
    </aside>
  );
}
```

### frontend/components/StickyISI.module.css
```css
.isiContainer {
  position: sticky;
  bottom: 0;
  background-color: var(--light-gray);
  border-top: 2px solid var(--accent-color);
  max-height: 150px;
  overflow: hidden;
  transition: max-height 0.3s ease-in-out;
  z-index: 900;
}

.isiContainer.expanded {
  max-height: 400px;
}

.isiHeader {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.5rem 1rem;
  background-color: #e0e0e0;
}

.isiHeader h3 {
  margin: 0;
  font-size: 1rem;
}

.isiHeader button {
  padding: 5px 10px;
  font-size: 0.9rem;
  background-color: var(--secondary-color);
}

.isiContent {
  padding: 1rem;
  height: 100%;
  overflow-y: auto;
}
```

### frontend/components/CookieBanner.js
```javascript
import { useState, useEffect } from 'react';
import Link from 'next/link';
import styles from './CookieBanner.module.css';

const COOKIE_CONSENT_KEY = 'pharma_cookie_consent';

export default function CookieBanner() {
  const [showBanner, setShowBanner] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(COOKIE_CONSENT_KEY);
    if (!consent) {
      setShowBanner(true);
    }
  }, []);

  const handleConsent = (consentValue) => {
    localStorage.setItem(COOKIE_CONSENT_KEY, consentValue);
    setShowBanner(false);
    // Here you would typically initialize analytics if consentValue is 'accepted'
    console.log(`Cookie consent: ${consentValue}`);
  };

  if (!showBanner) {
    return null;
  }

  return (
    <div className={styles.banner}>
      <p>
        We use cookies to improve your experience. By using our site, you agree to our use of cookies.
        Please see our <Link href="/privacy-policy">Privacy Policy</Link> for more details.
      </p>
      <div className={styles.actions}>
        <button onClick={() => handleConsent('declined')}>Decline</button>
        <button className={styles.acceptButton} onClick={() => handleConsent('accepted')}>Accept</button>
      </div>
    </div>
  );
}
```

### frontend/components/CookieBanner.module.css
```css
.banner {
  position: fixed;
  bottom: 0;
  left: 0;
  width: 100%;
  background-color: rgba(0, 0, 0, 0.85);
  color: white;
  padding: 1rem 2rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  z-index: 2000;
  flex-wrap: wrap;
  gap: 1rem;
}

.banner p {
  margin: 0;
  flex-grow: 1;
}

.banner a {
  color: var(--secondary-color);
  text-decoration: underline;
}

.actions {
  display: flex;
  gap: 1rem;
}

.acceptButton {
  background-color: var(--secondary-color);
}
```

### frontend/pages/_app.js
```javascript
import Layout from '../components/Layout';
import '../styles/globals.css';

function MyApp({ Component, pageProps }) {
  return (
    <Layout>
      <Component {...pageProps} />
    </Layout>
  );
}

export default MyApp;
```

### frontend/pages/index.js
```javascript
import Head from 'next/head';
import Link from 'next/link';
import { getAllProducts } from '../lib/api';
import styles from '../styles/Home.module.css';

export default function Home({ featuredProducts }) {
  return (
    <>
      <Head>
        <title>PharmaCorp - Innovative Healthcare Solutions</title>
        <meta name="description" content="Welcome to PharmaCorp, a leader in pharmaceutical research and development." />
      </Head>

      <section className={styles.hero}>
        <h1>Advancing Health Through Science</h1>
        <p>Discover our commitment to creating a healthier future for everyone.</p>
      </section>

      <section className={styles.about}>
        <h2>About PharmaCorp</h2>
        <p>We are a global biopharmaceutical company dedicated to discovering, developing, and delivering innovative medicines that help patients prevail over serious diseases.</p>
        <Link href="/about-us" className={styles.ctaButton}>Learn More</Link>
      </section>

      <section className={styles.featuredProducts}>
        <h2>Featured Products</h2>
        <div className={styles.productGrid}>
          {featuredProducts.map(product => (
            <Link key={product.id} href={`/products/${product.slug}`} className={styles.productCard}>
              <img src={product.thumbnail} alt={`${product.name} thumbnail`} />
              <h3>{product.name}</h3>
              <p>{product.tagline}</p>
            </Link>
          ))}
        </div>
        <Link href="/products" className={styles.ctaButton}>View All Products</Link>
      </section>
    </>
  );
}

export async function getStaticProps() {
  const allProducts = getAllProducts();
  return {
    props: {
      featuredProducts: allProducts.slice(0, 2), // Feature the first two products
    },
  };
}
```

### frontend/styles/Home.module.css
```css
.hero {
  text-align: center;
  padding: 4rem 1rem;
  background-color: var(--primary-color);
  color: white;
  border-radius: 8px;
}

.about, .featuredProducts {
  padding: 3rem 0;
  text-align: center;
}

.ctaButton {
  display: inline-block;
  margin-top: 1rem;
  background-color: var(--accent-color);
  color: white;
  padding: 12px 24px;
  border-radius: 4px;
  font-weight: bold;
}
.ctaButton:hover {
  opacity: 0.9;
}

.productGrid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 2rem;
  margin-top: 2rem;
  margin-bottom: 2rem;
}

.productCard {
  border: 1px solid var(--border-color);
  border-radius: 8px;
  padding: 1rem;
  text-align: center;
  transition: box-shadow 0.2s;
  color: var(--text-color);
}

.productCard:hover {
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.productCard img {
  max-width: 100px;
  height: auto;
  margin-bottom: 1rem;
}
```

### frontend/pages/about-us.js
```javascript
import Head from 'next/head';
import { getPageContent } from '../lib/api';

export default function AboutUs({ page }) {
  return (
    <>
      <Head>
        <title>{page.title} | PharmaCorp</title>
        <meta name="description" content="Learn about PharmaCorp's mission, history, and values." />
      </Head>
      <div dangerouslySetInnerHTML={{ __html: page.content }} />
    </>
  );
}

export async function getStaticProps() {
  const page = getPageContent('about-us');
  return {
    props: { page },
  };
}
```

### frontend/pages/contact-us.js
```javascript
import Head from 'next/head';
import ContactForm from '../components/ContactForm';
import styles from '../styles/Contact.module.css';

export default function ContactUs() {
  return (
    <>
      <Head>
        <title>Contact Us | PharmaCorp</title>
        <meta name="description" content="Get in touch with PharmaCorp for inquiries." />
      </Head>
      <h1>Contact Us</h1>
      <div className={styles.contactContainer}>
        <div className={styles.info}>
          <h2>Corporate Headquarters</h2>
          <p>123 Pharma Lane<br />Innovation City, HC 54321</p>
          <h2>General Inquiries</h2>
          <p>Phone: 1-800-555-1234</p>
        </div>
        <div className={styles.formWrapper}>
          <h2>Send us a message</h2>
          <ContactForm />
        </div>
      </div>
    </>
  );
}
```

### frontend/styles/Contact.module.css
```css
.contactContainer {
  display: flex;
  gap: 3rem;
  flex-wrap: wrap;
}

.info, .formWrapper {
  flex: 1;
  min-width: 300px;
}
```

### frontend/pages/privacy-policy.js
```javascript
import Head from 'next/head';
import { getPageContent } from '../lib/api';

export default function PrivacyPolicy({ page }) {
  return (
    <>
      <Head>
        <title>{page.title} | PharmaCorp</title>
      </Head>
      <div dangerouslySetInnerHTML={{ __html: page.content }} />
    </>
  );
}

export async function getStaticProps() {
  const page = getPageContent('privacy-policy');
  return {
    props: { page },
  };
}
```

### frontend/pages/terms-of-use.js
```javascript
import Head from 'next/head';
import { getPageContent } from '../lib/api';

export default function TermsOfUse({ page }) {
  return (
    <>
      <Head>
        <title>{page.title} | PharmaCorp</title>
      </Head>
      <div dangerouslySetInnerHTML={{ __html: page.content }} />
    </>
  );
}

export async function getStaticProps() {
  const page = getPageContent('terms-of-use');
  return {
    props: { page },
  };
}
```

### frontend/pages/products/index.js
```javascript
import Head from 'next/head';
import Link from 'next/link';
import { getAllProducts } from '../../lib/api';
import styles from '../../styles/Products.module.css';

export default function ProductListing({ allProducts }) {
  return (
    <>
      <Head>
        <title>Our Products | PharmaCorp</title>
        <meta name="description" content="Browse the full portfolio of PharmaCorp products." />
      </Head>
      <h1>Our Products</h1>
      <div className={styles.productGrid}>
        {allProducts.map(product => (
          <Link key={product.id} href={`/products/${product.slug}`} className={styles.productCard}>
            <img src={product.thumbnail} alt={`${product.name} thumbnail`} />
            <h3>{product.name}</h3>
            <p>{product.tagline}</p>
          </Link>
        ))}
      </div>
    </>
  );
}

export async function getStaticProps() {
  const allProducts = getAllProducts();
  return {
    props: { allProducts },
  };
}
```

### frontend/styles/Products.module.css
```css
.productGrid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 2rem;
}

.productCard {
  border: 1px solid var(--border-color);
  border-radius: 8px;
  padding: 1.5rem;
  transition: box-shadow 0.2s;
  color: var(--text-color);
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
}

.productCard:hover {
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.productCard img {
  max-width: 120px;
  height: auto;
  margin-bottom: 1rem;
}
```

### frontend/pages/products/[slug].js
```javascript
import Head from 'next/head';
import Link from 'next/link';
import { getAllProducts, getProductBySlug } from '../../lib/api';
import StickyISI from '../../components/StickyISI';
import styles from '../../styles/ProductDetail.module.css';

export default function ProductDetail({ product }) {
  if (!product) {
    return <div>Loading...</div>; // Or a 404 component
  }

  return (
    <>
      <Head>
        <title>{product.name} | PharmaCorp</title>
        <meta name="description" content={product.tagline} />
      </Head>
      <div className={styles.productDetailContainer}>
        <article>
          <h1>{product.name}</h1>
          <div dangerouslySetInnerHTML={{ __html: product.description }} />
          
          <h2>Indication</h2>
          <p>{product.indication}</p>

          <h2>Dosing</h2>
          <p>{product.dosing}</p>
          
          <Link href={product.pi_pdf} target="_blank" rel="noopener noreferrer" className={styles.piButton}>
            Download Prescribing Information (PDF)
          </Link>
        </article>
      </div>
      <StickyISI content={product.isi} />
    </>
  );
}

export async function getStaticPaths() {
  const products = getAllProducts();
  const paths = products.map((product) => ({
    params: { slug: product.slug },
  }));
  return { paths, fallback: false };
}

export async function getStaticProps({ params }) {
  const product = getProductBySlug(params.slug);
  return {
    props: { product },
  };
}
```

### frontend/styles/ProductDetail.module.css
```css
.productDetailContainer {
  padding-bottom: 2rem; /* Space for sticky ISI */
}

.piButton {
  display: inline-block;
  margin: 2rem 0;
  background-color: var(--primary-color);
  color: white;
  padding: 12px 24px;
  border-radius: 4px;
  font-weight: bold;
}

.piButton:hover {
  background-color: #003d73;
}
```

### frontend/tests/pages/index.test.js
```javascript
import { render, screen } from '@testing-library/react';
import Home from '../../pages/index';

// Mock the API data
const mockProducts = [
  { id: 1, name: 'ProductA', slug: 'producta', tagline: 'Tagline A', thumbnail: '/path/a' },
  { id: 2, name: 'ProductB', slug: 'productb', tagline: 'Tagline B', thumbnail: '/path/b' },
];

describe('Home Page', () => {
  it('renders the main heading', () => {
    render(<Home featuredProducts={mockProducts} />);
    const heading = screen.getByRole('heading', {
      name: /Advancing Health Through Science/i,
    });
    expect(heading).toBeInTheDocument();
  });

  it('renders the "About Us" section with a link', () => {
    render(<Home featuredProducts={mockProducts} />);
    expect(screen.getByRole('heading', { name: /About PharmaCorp/i })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /Learn More/i })).toHaveAttribute('href', '/about-us');
  });

  it('renders featured products correctly', () => {
    render(<Home featuredProducts={mockProducts} />);
    expect(screen.getByRole('heading', { name: /Featured Products/i })).toBeInTheDocument();
    
    const productA = screen.getByRole('heading', { name: /ProductA/i });
    const productB = screen.getByRole('heading', { name: /ProductB/i });

    expect(productA).toBeInTheDocument();
    expect(productB).toBeInTheDocument();
    expect(screen.getByText('Tagline A')).toBeInTheDocument();
    expect(screen.getByText('Tagline B')).toBeInTheDocument();
  });
});
```

### frontend/tests/components/ContactForm.test.js
```javascript
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import ContactForm from '../../components/ContactForm';

// Mock the global fetch function
global.fetch = jest.fn();

describe('ContactForm', () => {
  beforeEach(() => {
    fetch.mockClear();
  });

  it('renders the form with all fields', () => {
    render(<ContactForm />);
    expect(screen.getByLabelText(/Name/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Email/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Message/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Submit/i })).toBeInTheDocument();
  });

  it('shows a success message after a successful submission', async () => {
    fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => ({ status: 'success', message: 'Your message has been received.' }),
    });

    render(<ContactForm />);

    fireEvent.change(screen.getByLabelText(/Name/i), { target: { value: 'Test User' } });
    fireEvent.change(screen.getByLabelText(/Email/i), { target: { value: 'test@example.com' } });
    fireEvent.change(screen.getByLabelText(/Message/i), { target: { value: 'This is a test message.' } });
    fireEvent.click(screen.getByRole('button', { name: /Submit/i }));

    expect(screen.getByRole('button', { name: /Sending.../i })).toBeDisabled();

    await waitFor(() => {
      expect(screen.getByText('Your message has been received.')).toBeInTheDocument();
    });

    // The form should be cleared/hidden
    expect(screen.queryByLabelText(/Name/i)).not.toBeInTheDocument();
  });

  it('shows an error message if the submission fails', async () => {
    fetch.mockResolvedValueOnce({
      ok: false,
      json: async () => ({ detail: 'Something went wrong.' }),
    });

    render(<ContactForm />);

    fireEvent.change(screen.getByLabelText(/Name/i), { target: { value: 'Test User' } });
    fireEvent.change(screen.getByLabelText(/Email/i), { target: { value: 'test@example.com' } });
    fireEvent.change(screen.getByLabelText(/Message/i), { target: { value: 'This is a test message.' } });
    fireEvent.click(screen.getByRole('button', { name: /Submit/i }));

    await waitFor(() => {
      expect(screen.getByText('Something went wrong.')).toBeInTheDocument();
    });

    // The form fields should not be cleared
    expect(screen.getByLabelText(/Name/i)).toHaveValue('Test User');
  });

  it('parses and displays FastAPI validation errors correctly', async () => {
    const validationError = {
      detail: [{ loc: ['body', 'email'], msg: 'value is not a valid email address', type: 'value_error.email' }]
    };
    
    fetch.mockResolvedValueOnce({
      ok: false,
      status: 422,
      json: async () => validationError,
    });

    render(<ContactForm />);
    fireEvent.click(screen.getByRole('button', { name: /Submit/i }));

    await waitFor(() => {
      expect(screen.getByText('email: value is not a valid email address')).toBeInTheDocument();
    });
  });
});
```