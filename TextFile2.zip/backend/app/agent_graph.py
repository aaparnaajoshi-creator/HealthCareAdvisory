from langgraph.graph import StateGraph, END
from typing import TypedDict, List, Optional
import os
import time
import re
import json
from tools import push_artifact_to_github

from agents import impact_analysis_agent, requirements_agent, design_agent, coding_agent, testing_agent, deployment_agent, critic_agent
from database import log_agent_activity, update_project_status, log_technical_event

class HumanInputRequired(Exception):
    pass

class AgentState(TypedDict):
    project_id: str
    project_name: str
    project_type: str
    start_phase: str
    end_phase: str
    current_phase: str
    artifacts: dict
    logs: List[str]
    last_output: str
    human_input: Optional[str]
    review_cycles: int
    human_in_loop_steps: List[str] 
    github_repo_url: Optional[str] 

AGENT_MAP = {
    "ImpactAnalysis": impact_analysis_agent,
    "Requirements": requirements_agent,
    "Design": design_agent,
    "Coding": coding_agent,
    "Testing": testing_agent,
    "Deployment": deployment_agent,
}
PHASES = list(AGENT_MAP.keys())

def get_agent_graph(human_in_loop_steps: List[str]):
    workflow = StateGraph(AgentState)

    async def run_agent(state: AgentState):
        phase = state["current_phase"]
        agent_func = AGENT_MAP[phase]
        
        start_time = time.time()
        update_project_status(state['project_id'], f"In Progress - {phase} (Generating)")
        log_technical_event(state['project_id'], phase, f"Invoking {phase} Agent", {"review_cycle": state['review_cycles'], "project_type": state['project_type']})
        
        combined_output = await agent_func(state)
        
        duration = time.time() - start_time
        log_technical_event(state['project_id'], phase, f"{phase} Agent Finished", {"duration_seconds": round(duration, 2)})

        main_content = combined_output
        summary = f"Completed {phase} phase."

        if "---SUMMARY---" in combined_output:
            parts = combined_output.split("---SUMMARY---", 1)
            main_content = parts[0].strip()
            summary = parts[1].strip()

        state["last_output"] = main_content
        state["artifacts"][phase] = main_content
        
        log_agent_activity(state['project_id'], phase, "Generated Output", main_content, details=summary, phase=phase)
        return state

    async def run_critic(state: AgentState):
        phase = state["current_phase"]
        start_time = time.time()
        
        update_project_status(state['project_id'], f"In Progress - {phase} (Reviewing)")
        log_technical_event(state['project_id'], phase, "Invoking Critic Agent", {"review_cycle": state['review_cycles']})
        
        feedback = await critic_agent(state)
        
        duration = time.time() - start_time
        log_technical_event(state['project_id'], phase, "Critic Agent Finished", {"duration_seconds": round(duration, 2)})

        state["last_output"] = feedback
        state["review_cycles"] = state.get("review_cycles", 0) + 1
        
        log_agent_activity(
            project_id=state['project_id'], 
            agent_name="Critic", 
            status="Feedback Provided", 
            output=feedback,
            details=feedback,
            phase=phase
        )
        return state

    def should_continue_after_critic(state: AgentState):
        if "APPROVE" not in state["last_output"].upper() and state["review_cycles"] < 2:
            update_project_status(state['project_id'], f"In Progress - {state['current_phase']} (Revising)")
            log_agent_activity(
                project_id=state['project_id'],
                agent_name=state['current_phase'],
                status="Revising",
                details="Revising artifact based on critic feedback.",
                phase=state['current_phase']
            )
            return "run_agent"
        
        current_phase = state["current_phase"]
        project_id = state["project_id"]
        final_artifact = state['artifacts'].get(current_phase, "No artifact found")
        
        github_repo_url = state.get("github_repo_url") 
 
        if github_repo_url:
            output_path_in_repo = f"output/{current_phase.lower()}_artifact.md"
            commit_msg = f"feat: Add artifact for {current_phase} phase"
            
            if current_phase == "Coding":
                pass # Placeholder for multi-file push logic
            else:
                result = push_artifact_to_github(github_repo_url, output_path_in_repo, final_artifact, commit_msg)
                if "error" in result:
                    print(f"Failed to push to GitHub: {result['error']}")
        else:
            output_dir = os.path.join("uploads", project_id, "output")
            os.makedirs(output_dir, exist_ok=True)

            try:
                if current_phase == "Coding":
                    save_coding_artifact(output_dir, final_artifact)
                else:
                    file_extension = ".md"
                    file_path = os.path.join(output_dir, f"{current_phase.lower()}_artifact{file_extension}")
                    with open(file_path, "w", encoding="utf-8") as f:
                        f.write(final_artifact)
            except Exception as e:
                print(f"Error saving artifact for {current_phase}: {e}")

        log_agent_activity(project_id, current_phase, "Completed", final_artifact, details=f"Phase completed and approved after {state['review_cycles']} review cycle(s).", phase=current_phase)
        
        if current_phase == state["end_phase"]:
            return END
        
        if current_phase in state["human_in_loop_steps"]:
            raise HumanInputRequired(f"Paused for human input at {current_phase}")
        
        return "next_phase"

    async def move_to_next_phase(state: AgentState):
        current_idx = PHASES.index(state["current_phase"])
        next_idx = current_idx + 1
        if next_idx < len(PHASES):
            state["current_phase"] = PHASES[next_idx]
            state["review_cycles"] = 0
        return state

    workflow.add_node("run_agent", run_agent)
    workflow.add_node("run_critic", run_critic)
    workflow.add_node("next_phase", move_to_next_phase)

    workflow.set_entry_point("run_agent")
    workflow.add_edge("run_agent", "run_critic")
    
    workflow.add_conditional_edges(
        "run_critic",
        should_continue_after_critic,
        {
            "run_agent": "run_agent",
            "next_phase": "next_phase",
            END: END,
        },
    )
    
    workflow.add_edge("next_phase", "run_agent")

    return workflow.compile()

def save_coding_artifact(output_dir: str, artifact_content: str):
    """
    Parses the markdown output from the coding agent to extract and save
    individual code files.
    """
    print("Parsing markdown and saving coding artifact...")
    try:
        pattern = re.compile(r"```[\w\s]*\n([\w\./\-_]+)\n```\s*```[\w\s]*\n(.*?)\n```", re.DOTALL)
        matches = pattern.findall(artifact_content)

        if not matches:
            print("No file paths and code blocks found. Saving as a single markdown file.")
            fallback_path = os.path.join(output_dir, "coding_artifact.md")
            with open(fallback_path, "w", encoding="utf-8") as f:
                f.write(artifact_content)
            return

        for file_path_str, file_content in matches:
            if not file_path_str or not file_content:
                continue
            
            sanitized_path = file_path_str.strip().replace("..", "")
            full_path = os.path.join(output_dir, sanitized_path)
            
            print(f"Creating file: {full_path}")
            os.makedirs(os.path.dirname(full_path), exist_ok=True)
            
            with open(full_path, "w", encoding="utf-8") as f:
                f.write(file_content.strip())

    except Exception as e:
        print(f"An unexpected error occurred: {e}. Saving content as a fallback markdown file.")
        fallback_path = os.path.join(output_dir, "coding_artifact_fallback.md")
        with open(fallback_path, "w", encoding="utf-8") as f:
            f.write(artifact_content)