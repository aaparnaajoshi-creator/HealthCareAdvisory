from pydantic import BaseModel
from typing import List, Optional, Dict

class ProjectConfig(BaseModel):
    project_name: str
    project_type: str = "enhancement" # New field
    start_phase: str
    end_phase: str
    human_in_loop_steps: List[str] = []
    output_destination: str = "disk"
    github_repo_url: Optional[str] = None
    github_push_phases: List[str] = []
    

class ProjectCreateResponse(BaseModel):
    project_id: str
    message: str

class AgentOutput(BaseModel):
    agent_name: str
    output: str

class LogEntry(BaseModel):
    agent_name: str
    status: str
    output: Optional[str]
    details: Optional[str]
    timestamp: str

class ProjectStatusResponse(BaseModel):
    status: str
    logs: List[Dict]
    durations: Dict[str, float]