import asyncio
import os
import pandas as pd
import csv
from datetime import datetime
from dotenv import load_dotenv
from langchain_google_genai import ChatGoogleGenerativeAI
from database import log_technical_event

load_dotenv()
GEMINI_API_KEY = os.getenv("GOOGLE_API_KEY")

# --- Debug Logging Setup ---
DEBUG_LOG_FILE = 'debug_log.csv'
log_lock = asyncio.Lock()

async def log_to_csv(project_id: str, phase: str, agent_name: str, prompt: str, response: str, status: str):
    """
    Logs the input prompt and output response for each LLM call to a CSV file.
    This is more robust for concurrent appends than Excel.
    """
    async with log_lock:
        try:
            file_exists = os.path.isfile(DEBUG_LOG_FILE)
            with open(DEBUG_LOG_FILE, mode='a', newline='', encoding='utf-8') as csvfile:
                fieldnames = ["Timestamp", "ProjectID", "Phase", "AgentName", "Status", "InputPrompt", "OutputResponse"]
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

                if not file_exists:
                    writer.writeheader()
                
                writer.writerow({
                    "Timestamp": datetime.now().isoformat(),
                    "ProjectID": project_id,
                    "Phase": phase,
                    "AgentName": agent_name,
                    "Status": status,
                    "InputPrompt": prompt,
                    "OutputResponse": response
                })
        except Exception as e:
            print(f"!!! Critical: Failed to write to debug log file '{DEBUG_LOG_FILE}'. Error: {e}")


try:
    llm = ChatGoogleGenerativeAI(model="gemini-2.5-pro", google_api_key=GEMINI_API_KEY)
except Exception as e:
    print(f"Error initializing Gemini LLM: {e}")
    llm = None

async def invoke_llm(prompt: str, project_id: str, agent_name: str, phase: str) -> str:
    """
    Invokes the Gemini model using LangChain, including technical and debug logging.
    """
    retries = 3
    delay = 2
    log_technical_event(project_id, phase, f"LLM Invocation for {agent_name}", {"status": "started"})
    
    # --- Debug Logging ---
    print(f"--- DEBUG: Preparing to call LLM for {agent_name} in phase {phase} ---")
    print(f"--- DEBUG: Input Prompt:\n{prompt[:500]}...\n--------------------")
    # --- End Debug Logging ---

    for i in range(retries):
        try:
            response = await asyncio.to_thread(llm.invoke, prompt)
            
            usage_metadata = response.usage_metadata or {}
            response_content = response.content if hasattr(response, 'content') else str(response)

            log_technical_event(project_id, phase, f"LLM Invocation for {agent_name}", {
                "model_used": llm.model,
                "response_status": "Success",
                "failure_description": "N/A",
                "input_tokens": usage_metadata.get("input_tokens", 0),
                "output_tokens": usage_metadata.get("output_tokens", 0),
                "total_tokens": usage_metadata.get("total_tokens", 0)
            })
            
            await log_to_csv(project_id, phase, agent_name, prompt, response_content, "Success")
            # --- End Debug Logging ---

            return response_content
        except Exception as e:
            error_message = str(e)
            log_technical_event(project_id, phase, f"LLM Invocation for {agent_name}", {
                "model_used": llm.model,
                "response_status": "Failure",
                "failure_description": error_message,
                "retry_count": i + 1
            })

            # --- Debug Logging ---
            print(f"--- DEBUG: LLM call FAILED for {agent_name}. Error: {error_message} ---")
            await log_to_csv(project_id, phase, agent_name, prompt, f"Error: {error_message}", f"Failure (Retry {i+1})")
            # --- End Debug Logging ---

            print(f"LLM call failed with error: {e}. Retrying in {delay} seconds...")
            await asyncio.sleep(delay)
            delay *= 2
            
    final_error_message = "Error: The LLM call failed after multiple retries."
    await log_to_csv(project_id, phase, agent_name, prompt, final_error_message, "Terminal Failure")
    return final_error_message

# --- Specialized Agent Functions ---

async def impact_analysis_agent(state: dict) -> str:
    """
    New agent to generate an Impact Assessment document for enhancement projects.
    """
    prompt = f"""
    You are an expert Senior Business Analyst and Solution Architect. Your task is to create a detailed Impact Assessment document for a new software enhancement.

    Carefully analyze the new enhancement request against all provided existing project artifacts. Pay special attention to how the new request relates to past incidents, existing user stories, and functional screen flows to identify all potential impacts.

    **Primary Input: New Enhancement Request:**
    ---
    {state['artifacts'].get('new_requirement', 'No new requirement document provided. This is a critical input.')}
    ---

    **Supporting Artifacts for Analysis:**
    ---
    **Existing User Stories (SRS):**
    {state['artifacts'].get('Requirements', 'No existing requirements document provided.')}
    
    **Existing High-Level Design (HLD):**
    {state['artifacts'].get('Design', 'No existing design document provided.')}

    **Existing Codebase Snippets:**
    {state['artifacts'].get('Coding', 'No existing code provided.')}
    
    **Related Incidents / Bug Reports:**
    {state['artifacts'].get('Incidents', 'No incident reports provided.')}

    **Functional Screen Flow Diagrams/Descriptions:**
    {state['artifacts'].get('ScreenFlow', 'No screen flow documents provided.')}
    ---

    **Feedback from previous review to address (if any):**
    ---
    {state.get('last_output', '') if state.get('review_cycles', 0) > 0 else 'N/A'}
    ---

    **CRITICAL INSTRUCTIONS:**
    Generate a comprehensive Impact Assessment document in Markdown format. The document MUST include the following sections:

    1.  **Executive Summary:** A brief overview of the enhancement and its overall impact, referencing any related incidents if applicable.

    2.  **Detailed Impact Assessment:**
        *   **Functional Impact:**
            -   Describe changes to existing functionalities.
            -   List new functionalities being introduced.
            -   Analyze the impact on user workflows and screen flows.
            -   Identify which existing user stories are affected or need modification.
        *   **Design & Architectural Impact:**
            -   List all software modules, microservices, or components that will require modification.
            -   Describe any impact on UI/UX components and layouts.
            -   Detail required changes to backend services and APIs (new endpoints, modified request/response signatures, logic changes).
        *   **Data Flow Impact:**
            -   Analyze how data will flow through the system to support the new enhancement.
            -   Describe changes to data processing, validation, and transformations.
            -   Identify impacts on integrations with third-party services or other internal systems.
        *   **Database Impact:**
            -   Specify all required changes to the database schema (new tables, new columns, modified columns, indexes, constraints).
            -   Outline any necessary data migration or back-filling strategies.

    3.  **Risks and Dependencies:**
        *   **Technical Risks:** Identify potential risks (e.g., performance degradation, security vulnerabilities, backward compatibility issues) and suggest mitigation strategies.
        *   **Dependencies:** List any dependencies on other teams, services, or upcoming features.

    4.  **Estimated Effort:** Provide a T-shirt size estimate (S, M, L, XL) for the development effort with a brief justification.

    **Return ONLY the complete Impact Assessment document.**
    **At the very end of your response, on a new line, add a separator `---SUMMARY---` followed by a brief, concise summary of the key impacts identified (e.g., 'Impacts 3 functional areas, requires 2 new API endpoints and schema changes to 1 database table. Effort: M.').**
    """
    return await invoke_llm(prompt, state['project_id'], "Impact Analysis Agent", "ImpactAnalysis")

# --- Requirements Agents ---
async def enhancement_requirements_agent(state: dict) -> str:
     
    prompt = f"""
    You are an expert Agile product owner. Your task is to act as a product owner and **update** existing user stories based on a new enhancement request.
    Your output must be the complete, updated document. You must clearly mark your changes using `++[ADDED CONTENT]++` for additions and `--[REMOVED CONTENT]--` for deletions.

    **New Enhancement Request:**
    ---
    {state['artifacts'].get('new_requirement', 'No new requirement provided.')}
    ---
    **Impact Analysis (for context):**
    ---
    {state['artifacts'].get('ImpactAnalysis', 'No impact analysis provided.')}
    ---
    **Existing SRS to be updated:**
    ---
    {state['artifacts'].get('Requirements', 'No existing requirements document provided.')}
    ---
    **Feedback from previous review to address:**
    ---
    {state.get('last_output', '') if state.get('review_cycles', 0) > 0 else 'N/A'}
    ---
    **Return ONLY the complete, updated SRS document in Markdown format with changes clearly marked.**
    **Only add/modify existing stories per the new requirements**
    **At the very end of your response, on a new line, add a separator `---SUMMARY---` followed by a brief, concise summary in bullet points for the changes made. Count the number of additions, updates, or deletions (e.g., 'Updated 2 user stories, removed 1 acceptance criterion').**
    """
     
    return await invoke_llm(prompt, state['project_id'], "Requirements Agent", "Requirements")

async def new_requirements_agent(state: dict) -> str:
    prompt = f"""
    You are an expert Agile product owner creating user stories from scratch.
    Your task is to generate detailed user stories with acceptance criteria based on the provided high-level requirements.

    **High-Level Functional Requirements:**
    ---
    {state['artifacts'].get('hl_functional_req', 'No high-level functional requirements provided.')}
    ---
    **High-Level Technical Requirements / Constraints:**
    ---
    {state['artifacts'].get('hl_technical_req', 'No high-level technical requirements provided.')}
    ---
    **Feedback from previous review to address (if any):**
    ---
    {state.get('last_output', '') if state.get('review_cycles', 0) > 0 else 'N/A'}
    ---
    **Return ONLY the complete user story document the user stories in Markdown format.**
    **At the very end of your response, on a new line, add a separator `---SUMMARY---` followed by a brief, concise summary in bullet points for the changes made. Count the number of additions, updates, or deletions (e.g., 'Created 5 new user stories with acceptance criteria').**
    """
    return await invoke_llm(prompt, state['project_id'], "Requirements Agent", "Requirements")

# --- Design Agents ---
async def enhancement_design_agent(state: dict) -> str:
    prompt = f"""
    You are an expert Solutions Architect. Your task is to **update** an existing High-Level Design (HLD) to reflect changes in the requirements.
    Focus only on the necessary modifications. Clearly mark your changes using `++[ADDED CONTENT]++` for additions and `--[REMOVED CONTENT]--` for deletions.

    **Updated SRS:**
    ---
    {state['artifacts'].get('Requirements', 'No requirements provided.')}
    ---
    **Existing HLD to be updated:**
    ---
    {state['artifacts'].get('Design', 'No existing design document provided.')}
    ---
    **Feedback from previous review to address:**
    ---
    {state.get('last_output', '') if state.get('review_cycles', 0) > 0 else 'N/A'}
    ---
    **Return ONLY the complete, updated HLD document in Markdown format with changes clearly marked.**
    **Only update as per the new requirement, no need to improve or enhance existing design elements not related  to new requirement**
    **At the very end of your response, on a new line, add a separator `---SUMMARY---` followed by a brief, concise summary in bullet points for the changes made. Count the number of additions, updates, or deletions (e.g., 'Updated the authentication service endpoint, added a caching layer diagram').**
    """
    return await invoke_llm(prompt, state['project_id'], "Design Agent", "Design")

async def new_design_agent(state: dict) -> str:
    prompt = f"""
    You are an expert Solutions Architect creating a High-Level Design (HLD) from scratch.
    Your task is to design a system architecture based on the provided user stories and technical constraints.

    **User Stories (SRS):**
    ---
    {state['artifacts'].get('Requirements', 'No user stories provided.')}
    ---
    **High-Level Technical Requirements / Constraints:**
    ---
    {state['artifacts'].get('hl_technical_req', 'No high-level technical requirements provided.')}
    ---
    **Feedback from previous review to address (if any):**
    ---
    {state.get('last_output', '') if state.get('review_cycles', 0) > 0 else 'N/A'}
    ---
    **CRITICAL Instructions:**
    1.  **Strictly adhere to the specified tech stack.** You MUST use the technologies mentioned in the technical requirements and nothing else. For example, if the requirement is for "HTML5 + JavaScript," you must not use a framework like React or Vue.
    2.  Define the overall architecture (e.g., microservices).
    3.  Specify data models and database schema.
    4.  Define API endpoints with request/response formats.
    5.  Create diagrams (using Mermaid syntax) for architecture and data flow.
    6.  Before finalizing, double-check that your design exclusively uses the technologies from the technical requirements.
    
    **Return ONLY the complete HLD document in Markdown format.**
    **At the very end of your response, on a new line, add a separator `---SUMMARY---` followed by a brief, concise summary in bullet points for  changes made. Count the number of additions, updates, or deletions (e.g., 'Designed 3 new API endpoints, created a database schema with 5 tables').**
    """
    return await invoke_llm(prompt, state['project_id'], "Design Agent", "Design")

# --- Coding Agents ---
async def enhancement_coding_agent(state: dict) -> str:
    prompt = f"""
    You are a Senior Software Engineer. Your task is to **modify** an existing codebase to implement a new enhancement.
    Use the same programming language, frameworks, and style as the existing code. Clearly mark your changes using code comments: `++ ADDED START ++`, `++ ADDED END ++`, `-- REMOVED START --`, `-- REMOVED END --`.

    **Enhancement Details from Requirements:**
    ---
    {state['artifacts'].get('Requirements', 'No requirements provided.')}
    ---
    **Guidance from Design Document:**
    ---
    {state['artifacts'].get('Design', 'No design provided.')}
    ---
    **Existing Codebase to Modify:**
    ---
    {state['artifacts'].get('Coding', 'No existing code provided.')}
    ---
    **Feedback from previous review to address:**
    ---
    {state.get('last_output', '') if state.get('review_cycles', 0) > 0 else 'N/A'}
    ---
    **Return ONLY the complete, updated code in a single Markdown code block, with changes clearly marked.**
    **At the very end of your response, on a new line, add a separator `---SUMMARY---` followed by a brief, concise summary in bullet points for the changes made. Count the number of additions, updates, or deletions (e.g., 'Refactored the payment module, added 2 new functions to the user service').**
    **Instructions:**
    1. Refer to the updated design document to understand what changes are required in the existing code  
    2. Structure the output with clear file names for each part of the codebase.
    3. Do not include any other text, prefix, code blocks 
    
    **At the very end of your response, on a new line, add a separator `---SUMMARY---` followed by a brief, concise summary in bullet points for the changes made. Count the number of additions, updates, or deletions (e.g., 'added or Updated 2 user stories, added 1 new endpoint').**
    
    """
    return await invoke_llm(prompt, state['project_id'], "Coding Agent", "Coding")

async def new_coding_agent(state: dict) -> str:
    prompt = f"""
    You are a Senior Software Engineer writing a new application from scratch.
    Your task is to generate a **complete and runnable** application codebase based on the user stories and design document.

    **User Stories (SRS):**
    ---
    {state['artifacts'].get('Requirements', 'No user stories provided.')}
    ---
    **High-Level Design (HLD):**
    ---
    {state['artifacts'].get('Design', 'No design document provided.')}
    ---
    **Feedback from previous review to address (if any):**
    ---
    {state.get('last_output', '') if state.get('review_cycles', 0) > 0 else 'N/A'}
    ---
    **CRITICAL Instructions:**
    1.  **Generate a complete application.** This includes the front end, back end, database schema, and any other layers specified in the HLD. For example, if the HLD specifies a React front end and a Python back end, you must generate the code for **BOTH**.
    2.  **Strictly adhere to the tech stack**, language, and frameworks specified in the HLD. 
    3.  Implement the full application logic and write comprehensive unit tests.
    4.  Structure the output with clear file paths and file names for each part of the codebase, formatted as markdown. For example: `path/to/your/file.py`.
    5.  Before finalizing, double-check that your code exclusively uses the technologies specified in the HLD.
    6.  Do not include any other text, prefixes, or explanations outside of the code blocks.
    
    **At the very end of your response, on a new line, add a separator `---SUMMARY---` followed by a brief, concise summary in bullet points for the code generated. Count the number of additions, updates, or deletions (e.g., 'Generated 5 backend files for the API, created 3 new React components for the UI').**
    """
    return await invoke_llm(prompt, state['project_id'], "Coding Agent", "Coding")

# --- Testing Agents ---
async def enhancement_testing_agent(state: dict) -> str:
    prompt = f"""
    You are a QA Automation Engineer. Your task is to **update** a test plan and associated scripts based on new requirements.
    Mark your changes using `++[ADDED CONTENT]++` for additions and `--[REMOVED CONTENT]--` for deletions.

    **Updated Requirements (SRS):**
    ---
    {state['artifacts'].get('Requirements', 'No requirements provided.')}
    ---
    **Existing Testing Artifacts:**
    ---
    {state['artifacts'].get('Testing', 'No existing test plan provided.')}
    ---
    **Feedback from previous review to address:**
    ---
    {state.get('last_output', '') if state.get('review_cycles', 0) > 0 else 'N/A'}
    ---
    **Return ONLY the complete, updated testing document in Markdown format.**
    **At the very end of your response, on a new line, add a separator `---SUMMARY---` followed by a brief, concise summary in bullet points for the changes made. Count the number of additions, updates, or deletions (e.g., 'Added 3 test cases for the new feature, updated 1 existing test script').**
    """
    return await invoke_llm(prompt, state['project_id'], "Testing Agent", "Testing")

async def new_testing_agent(state: dict) -> str:
    prompt = f"""
    You are a QA Automation Engineer creating a test strategy, test plan, automation test scripts for a new project.
    Your task is to generate a comprehensive testing document from scratch.

    **Project Requirements (SRS):**
    ---
    {state['artifacts'].get('Requirements', 'No user stories provided.')}
    ---
    **Project Design (HLD):**
    ---
    {state['artifacts'].get('Design', 'No design document provided.')}
    ---
    **Feedback from previous review to address (if any):**
    ---
    {state.get('last_output', '') if state.get('review_cycles', 0) > 0 else 'N/A'}
    ---
    **Instructions:**
    1. Create a test strategy (scope, objectives, types of testing).
    2. Generate a BDD feature file in Gherkin format based on all user stories to cover all the scenariosx. Feature file should follow Gherkin syntax and include two structure tables: Example table and Data Table
    Example:
    Feature: <feature name>
    Scenario: <Scenario description>
    Given ......
    When.....
    Then...

    3. Never add backticks like ```Gherkin and any other comments in feature file

    **Return ONLY the complete testing document in Markdown format.**
    **At the very end of your response, on a new line, add a separator `---SUMMARY---` followed by a brief, concise summary in bullet points for the changes made. Count the number of additions, updates, or deletions (e.g., 'Created a test plan with 10 test cases, wrote 2 automation scripts').**
    """
    return await invoke_llm(prompt, state['project_id'], "Testing Agent", "Testing")

# --- Deployment Agents ---
async def enhancement_deployment_agent(state: dict) -> str:
    prompt = f"""
    You are a DevOps Engineer. Your task is to **update** deployment artifacts based on design changes.
    Mark changes using `++[ADDED CONTENT]++` and `--[REMOVED CONTENT]--`.

    **Updated Design Document (HLD):**
    ---
    {state['artifacts'].get('Design', 'No design provided.')}
    ---
    **Existing Deployment Scripts/README:**
    ---
    {state['artifacts'].get('Deployment', 'No existing deployment scripts provided.')}
    ---
    **Feedback from previous review to address:**
    ---
    {state.get('last_output', '') if state.get('review_cycles', 0) > 0 else 'N/A'}
    ---
    **Return ONLY the complete, updated deployment artifacts in Markdown format.**
    **At the very end of your response, on a new line, add a separator `---SUMMARY---` followed by a brief, concise summary in bullet points for the changes made. Count the number of additions, updates, or deletions (e.g., 'Updated the Dockerfile to include a new dependency, modified the Nginx configuration').**
    """
    return await invoke_llm(prompt, state['project_id'], "Deployment Agent", "Deployment")

async def new_deployment_agent(state: dict) -> str:
    prompt = f"""
    You are a DevOps Engineer creating deployment artifacts for a new application.

    **Project Design (HLD):**
    ---
    {state['artifacts'].get('Design', 'No design document provided.')}
    ---
    **Application Codebase:**
    ---
    {state['artifacts'].get('Coding', 'No code has been provided.')}
    ---
    **Feedback from previous review to address (if any):**
    ---
    {state.get('last_output', '') if state.get('review_cycles', 0) > 0 else 'N/A'}
    ---
    **Instructions:**
    1. Create a `Dockerfile` to containerize the application.
    2. Create a `docker-compose.yml` file to manage the application services.
    3. Write a `README.md` with clear build, configuration, and deployment instructions.

    **Return ONLY the complete set of deployment artifacts in Markdown format.**
    **At the very end of your response, on a new line, add a separator `---SUMMARY---` followed by a brief, concise summary in bullet points for the changes made. Count the number of additions, updates, or deletions (e.g., 'Created a Dockerfile and a docker-compose.yml with 3 services').**
    """
    return await invoke_llm(prompt, state['project_id'], "Deployment Agent", "Deployment")


# --- Agent Dispatchers ---

async def requirements_agent(state: dict) -> str:
    if state.get('project_type') == 'new':
        return await new_requirements_agent(state)
    else:
        return await enhancement_requirements_agent(state)

async def design_agent(state: dict) -> str:
    if state.get('project_type') == 'new':
        return await new_design_agent(state)
    else:
        return await enhancement_design_agent(state)

async def coding_agent(state: dict) -> str:
    if state.get('project_type') == 'new':
        return await new_coding_agent(state)
    else:
        return await enhancement_coding_agent(state)

async def testing_agent(state: dict) -> str:
    if state.get('project_type') == 'new':
        return await new_testing_agent(state)
    else:
        return await enhancement_testing_agent(state)

async def deployment_agent(state: dict) -> str:
    if state.get('project_type') == 'new':
        return await new_deployment_agent(state)
    else:
        return await enhancement_deployment_agent(state)


# --- Critic Agent (Updated Logic) ---
async def critic_agent(state: dict) -> str:
    """
    A context-aware critic that reviews agent output against the correct
    sources of truth based on project type and phase.
    """
    project_id = state['project_id']
    last_output = state.get('last_output', 'No output to review.')
    current_phase = state.get('current_phase', 'Unknown phase')
    project_type = state.get('project_type', 'enhancement')
    artifacts = state.get('artifacts', {})

    primary_source_text = ""
    secondary_source_text = ""
    primary_instruction = ""
    secondary_instruction = ""

    # 1. Determine the Primary Source of Truth and Instruction
    if project_type == 'new':
        primary_source_text = f"""
### High-Level Functional Requirement
{artifacts.get('hl_functional_req', 'Not provided.')}

### High-Level Technical Requirement
{artifacts.get('hl_technical_req', 'Not provided.')}
"""
        primary_instruction = "First, does the artifact align with the initial high-level project requirements provided above?"
    else: # enhancement
        primary_source_text = artifacts.get('new_requirement', 'No new enhancement request provided.')
        primary_instruction = "First, does the artifact correctly and completely implement the specific enhancement request provided above?"

    # 2. Determine the Secondary Source of Truth and Instruction (Phase-specific)
    if current_phase == "ImpactAnalysis":
        secondary_source_text = f"""
### New Enhancement Request
{artifacts.get('new_requirement', 'Not provided.')}
### Existing Design
{artifacts.get('Design', 'Not provided.')}
### Existing Code
{artifacts.get('Coding', 'Not provided.')}
"""
        secondary_instruction = "Second, does the Impact Assessment document thoroughly analyze the new enhancement against all provided existing artifacts? Does it include all required sections (Affected Modules, DB Changes, Risks, etc.) and is the analysis logical and complete?"
    elif current_phase == "Design":
        secondary_source_text = f"### Requirements/User Stories\n{artifacts.get('Requirements', 'Not provided.')}"
        secondary_instruction = "Second, does the Design artifact accurately reflect all user stories and requirements from the preceding phase? **Crucially, verify that the chosen technology stack in the design matches the one specified in the technical requirements.**"
    elif current_phase == "Coding":
        secondary_source_text = f"### Design Document\n{artifacts.get('Design', 'Not provided.')}"
        secondary_instruction = "Second, does the Code correctly implement all specifications from the Design document? **Crucially, verify that the generated code includes all specified components (e.g., UI, API, database scripts) and that the technology used (e.g., React vs. plain HTML/JS) matches the design. If any part is missing or uses the wrong technology, you must reject it.**"
    elif current_phase == "Testing":
        secondary_source_text = f"""
### Requirements/User Stories
{artifacts.get('Requirements', 'Not provided.')}

### Design Document
{artifacts.get('Design', 'Not provided.')}
"""
        secondary_instruction = "Second, does the Test Plan provide adequate coverage for all user stories and design components?"
    elif current_phase == "Deployment":
        secondary_source_text = f"### Design Document\n{artifacts.get('Design', 'Not provided.')}"
        secondary_instruction = "Second, are the deployment scripts consistent with the architecture specified in the Design document?"
    
    # 3. Assemble the final prompt
    prompt = f"""
You are a meticulous Critic AI. Your job is to perform a two-step review on the artifact for the **{current_phase}** phase of this **{project_type}** project.

**STEP 1: Review against Primary Project Goal**

**Primary Goal / Request:**
---
{primary_source_text}
---
**Review Question 1:** {primary_instruction}

**STEP 2: Review against Preceding Artifact**

**Preceding Artifact(s):**
---
{secondary_source_text if secondary_source_text else "N/A for this phase."}
---
**Review Question 2:** {secondary_instruction if secondary_instruction else "N/A for this phase."}


**ARTIFACT TO REVIEW:**
---
{last_output}
---

**DECISION:**
Based on your two-step review, analyze the artifact for correctness, completeness, logical errors, and alignment with all provided sources of truth.
- If the artifact is of high quality and satisfies BOTH review steps, respond with the single word: **APPROVE**.
- If the artifact fails either review step, provide a brief, bulleted list of the specific, actionable changes required. Be concise and clear.

**Return ONLY "APPROVE" or the bulleted list of feedback.**
"""

    return await invoke_llm(prompt, project_id, "Critic Agent", current_phase)