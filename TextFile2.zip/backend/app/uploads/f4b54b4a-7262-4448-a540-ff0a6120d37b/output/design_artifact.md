# PharmaCorp Website - High-Level Design

## 1. Introduction

This document outlines the high-level design for the PharmaCorp website, addressing the user stories and technical requirements.  The architecture utilizes a microservices approach with a focus on scalability, maintainability, and accessibility.

## 2. Architecture

The system will be composed of the following components:

* **Frontend:** A single-page application (SPA) built using React, leveraging a component library for accessibility and responsiveness.
* **Backend APIs:**  A set of RESTful APIs built using FastAPI (Python) providing data and functionality to the frontend.
* **Database:** PostgreSQL database to store website content, user submissions, and newsletter subscriptions.
* **Search:** Elasticsearch cluster for efficient and relevant search results.
* **Object Storage:** AWS S3 (or similar) for storing product PDFs (Prescribing Information).
* **Email Service:** AWS SES (or similar) for sending newsletter confirmations and other emails.
* **CI/CD:** GitHub Actions (or similar) for automated build, testing, and deployment to AWS (or similar cloud provider).


```mermaid
graph LR
    subgraph Frontend
        A[React SPA]
    end
    subgraph Backend
        B(FastAPI APIs)
        C(Search API)
    end
    subgraph Data
        D[PostgreSQL]
        E[AWS S3 (Object Storage)]
    end
    subgraph Services
        F[AWS SES (Email)]
    end
    A --> B
    B --> D
    B --> E
    C --> B
    B --> F
    A --> C

```

## 3. Data Model

**PostgreSQL Schema:**

* **users:** (id, email, name, subscribed) - Stores newsletter subscribers.
* **pages:** (id, title, content, url) - Stores website content (About Us, Privacy Policy, etc.).
* **products:** (id, name, description, image_url, pi_url) - Stores product information.  `pi_url` points to the PDF in S3.
* **contact_forms:** (id, name, email, message, timestamp) - Stores contact form submissions.

## 4. API Endpoints

**Product API:**

* `/products`: (GET) Returns a list of products.
    * Response: `[{id, name, description, image_url}]`
* `/products/{id}`: (GET) Returns details for a specific product.
    * Response: `{id, name, description, image_url, pi_url}`

**Search API:**

* `/search`: (GET)  Performs a search using Elasticsearch.  Uses query parameters to define search terms.
    * Response: `[{id, type, title, snippet}]` (type: product, page)

**Contact Form API:**

* `/contact`: (POST) Submits a contact form.
    * Request: `{name, email, message}`
    * Response: `{status: "success", message: "Thank you for your message!"}` or `{status: "error", message: "Error submitting form."}`

**Newsletter API:**

* `/newsletter/subscribe`: (POST) Subscribes a user to the newsletter.
    * Request: `{email}`
    * Response: `{status: "success", message: "Confirmation email sent."}`
* `/newsletter/unsubscribe`: (POST) Unsubscribes a user from the newsletter.
    * Request: `{email}`
    * Response: `{status: "success", message: "Unsubscribed successfully."}`

**Page API:**

* `/pages/{url}`: (GET) Retrieves a specific page by URL.  Handles routing to static content.
    * Response: `{content}`


## 5.  Accessibility and Security

* **WCAG 2.2 AA Compliance:**  Achieved through using a React component library with built-in accessibility features, automated testing with tools like axe-core, and manual review by accessibility experts.  Specific accessibility considerations will be documented for each component (e.g., proper ARIA attributes, color contrast ratios, keyboard navigation).
* **Security:** HTTPS, Content Security Policy (CSP), rate limiting, input validation (using FastAPI's built-in features), and secure handling of user data will be implemented.

## 6. Sticky ISI Implementation (User Story 2)

The sticky ISI section will be implemented using a React component positioned with CSS `position: sticky`.  This will ensure it remains visible while scrolling, regardless of the device.  Clear visual distinction will be achieved through contrasting colors and clear labeling.


## 7. HCP Restriction (User Story 2) - Future Considerations

Future implementation of HCP restrictions will involve adding authentication and authorization mechanisms.  This might involve integrating with a third-party HCP verification service or developing a custom authentication system.  Roles and permissions will be managed within the database.

## 8. Cookie Consent Banner (User Story 8)

The cookie consent banner will be implemented using a dedicated JavaScript library (e.g., `cookieconsent`).  It will allow users to manage cookie preferences in accordance with GDPR and CCPA regulations.

## 9. CI/CD Pipeline

The CI/CD pipeline will utilize GitHub Actions to automate the build, testing, and deployment process.  Automated tests will include unit tests, integration tests, and end-to-end tests.  Deployment will be to AWS or a similar cloud provider, using infrastructure as code (e.g., Terraform).