```markdown
## Dockerfile

```dockerfile
FROM mulesoft/mule-runtime:4.4

# Set the working directory
WORKDIR /opt/mule

# Copy the Mule application
COPY mule-hubspot-sync.jar apps/

# Copy the truststore (optional, if not using mounted volume)
# COPY truststore.jks conf/

# Expose the HTTP port
EXPOSE 8081

# Set environment variables (can be overridden by docker-compose)
ENV MULE_HOME=/opt/mule
```

## docker-compose.yml

```yaml
version: "3.8"

services:
  mule:
    build: .
    ports:
      - "8081:8081"
    environment:
      - mule_env=prod
      - db.host=jdbc:postgresql://db:5432/customerdb
      - db.user=dbuser
      - db.password=/run/secrets/db_password
      - http.port=8081
      - tls.truststore.path=/opt/mule/conf/truststore.jks
      - tls.truststore.password=password
      - hubspot.client.secret=/run/secrets/hubspot_client_secret
      - mail.host=smtp.gmail.com
      - mail.port=587
      - mail.user=your_email@gmail.com
      - mail.password=/run/secrets/mail_password
      - mail.to=recipient_email@example.com
      - mail.from=your_email@gmail.com
    secrets:
      - db_password
      - hubspot_client_secret
      - mail_password
    depends_on:
      - db
    volumes:
      - ./truststore.jks:/opt/mule/conf/truststore.jks

  db:
    image: postgres:13
    environment:
      POSTGRES_USER: dbuser
      POSTGRES_PASSWORD: dbpassword
      POSTGRES_DB: customerdb
    ports:
      - "5432:5432"
    volumes:
      - db_data:/var/lib/postgresql/data

secrets:
  db_password:
    file: ./db_password.txt
  hubspot_client_secret:
    file: ./hubspot_client_secret.txt
  mail_password:
    file: ./mail_password.txt

volumes:
  db_data:
```

## README.md

```markdown
# MuleSoft HubSpot Company to Customer DB Sync - Deployment Instructions

This document provides instructions for building, configuring, and deploying the MuleSoft application that synchronizes HubSpot Company records to a PostgreSQL database.

## Prerequisites

*   Docker and Docker Compose installed
*   A HubSpot account with webhook access
*   A PostgreSQL database instance
*   Maven installed (optional, for building the Mule application)

## Building the Mule Application (Optional)

If you haven't already, you can build the Mule application using Maven:

```bash
cd mule-hubspot-sync
mvn clean package -DskipTests
```

This will create a `mule-hubspot-sync.jar` file in the `target` directory.

## Configuration

The application uses configuration files (`config-dev.yaml` and `config-prod.yaml`) for environment-specific settings. The `docker-compose.yml` file uses environment variables and Docker secrets to override these settings.

### Docker Secrets

Sensitive information such as database passwords, HubSpot client secret, and mail server passwords should be managed using Docker secrets.

1.  **Create secret files:** Create three files: `db_password.txt`, `hubspot_client_secret.txt`, and `mail_password.txt`. Each file should contain the respective password.

    ```bash
    echo "your_db_password" > db_password.txt
    echo "YOUR_HUBSPOT_CLIENT_SECRET" > hubspot_client_secret.txt
    echo "your_mail_password" > mail_password.txt
    ```

2.  **Reference secrets in `docker-compose.yml`:** The `docker-compose.yml` file references these files as Docker secrets.

### Truststore Configuration

The application uses a truststore to establish a secure connection to the database and mail server.

1.  **Create or obtain a truststore:** If you don't have one already, you can create a Java KeyStore (JKS) truststore. You can generate a new truststore or import certificates to an existing one:

    ```bash
    keytool -genkey -alias mule -keyalg RSA -keystore truststore.jks -storepass password
    ```

    Or, to import certificates:

    ```bash
    keytool -import -trustcacerts -alias <alias_name> -file <certificate_file> -keystore truststore.jks -storepass password
    ```

    Replace `<alias_name>` with a unique alias for the certificate and `<certificate_file>` with the path to the certificate file.  Repeat for each certificate needed.

2.  **Place the truststore in the project directory:**  Ensure the `truststore.jks` file is in the same directory as your `docker-compose.yml` file.

3.  **Mount the truststore:** The `docker-compose.yml` file mounts the local `truststore.jks` file to `/opt/mule/conf/truststore.jks` inside the container.

### Database Configuration

The `docker-compose.yml` file also defines a PostgreSQL service.  You can customize the database settings by modifying the environment variables for the `db` service.

## Deployment

1.  **Build the Docker image:**

    ```bash
    docker-compose build
    ```

2.  **Start the services:**

    ```bash
    docker-compose up -d
    ```

    This will start the Mule application and the PostgreSQL database in detached mode.

3.  **Verify the deployment:**

    Check the logs of the Mule container to ensure the application has started successfully:

    ```bash
    docker logs <mule_container_id>
    ```

    Replace `<mule_container_id>` with the actual container ID.

## HubSpot Configuration

To configure HubSpot to send webhooks to the MuleSoft API:

1.  **Create a webhook subscription in HubSpot:** Log in to your HubSpot account and navigate to **Settings > Integrations > Webhooks**.
2.  **Configure the webhook:**
    *   **Event type:** Choose "company.creation".
    *   **Target URL:** Enter the URL of your MuleSoft API endpoint: `http://<your_docker_host>:8081/api/v1/hubspot/company`.  Replace `<your_docker_host>` with the IP address or hostname where your Docker container is running. If running locally, this is likely `localhost`.
    *   **Subscribe to:** Select "All properties".
3.  **Client Secret:** Ensure the client secret configured in HubSpot matches the one provided as a Docker secret to the Mule application.

## Accessing the Application

The MuleSoft API will be accessible at `http://<your_docker_host>:8081/api/v1/hubspot/company`.

## Troubleshooting

*   **Database connection errors:** Ensure the database service is running and the database credentials are correct.
*   **HubSpot signature validation errors:** Verify the HubSpot client secret is configured correctly in both HubSpot and the Mule application.
*   **Application startup errors:** Check the Mule application logs for any exceptions or errors.

```