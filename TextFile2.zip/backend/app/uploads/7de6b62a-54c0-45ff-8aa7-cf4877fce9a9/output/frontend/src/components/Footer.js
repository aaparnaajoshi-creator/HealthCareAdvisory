import React from 'react';
import { Box, Typography, Container, Link } from '@mui/material';

const Footer = ({ children }) => {
    return (
        <Box component="footer" sx={{ bgcolor: 'grey.200', py: 3 }}>
            <Container maxWidth="lg">
                {children}
                <Typography variant="body2" color="text.secondary" align="center">
                    {'Copyright © '}
                    <Link color="inherit" href="https://pharmacon.com/">
                        PharmaCorp
                    </Link>{' '}
                    {new Date().getFullYear()}
                    {'.'}
                </Typography>
            </Container>
        </Box>
    );
};

export default Footer;