import React, { useState } from 'react';
import { FormControlLabel, Switch, Typography, Slider, Box } from '@mui/material';

const AccessibilitySettings = ({ applySettings }) => {
    const [fontSize, setFontSize] = useState(16);
    const [highContrast, setHighContrast] = useState(false);

    const handleFontSizeChange = (event, newValue) => {
        setFontSize(newValue);
        applySettings(`${newValue}px`, highContrast);
    };

    const handleContrastChange = (event) => {
        setHighContrast(event.target.checked);
        applySettings(`${fontSize}px`, event.target.checked);
    };

    return (
        <Box sx={{ margin: 2, padding: 2, border: '1px solid #ccc', borderRadius: '5px' }}>
            <Typography variant="h6">Accessibility Settings</Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', marginTop: 1 }}>
                <Typography id="font-size-slider" gutterBottom>
                    Font Size:
                </Typography>
                <Slider
                    value={fontSize}
                    onChange={handleFontSizeChange}
                    min={12}
                    max={24}
                    aria-labelledby="font-size-slider"
                    sx={{ ml: 2, width: '200px' }}
                />
            </Box>
            <FormControlLabel
                control={<Switch checked={highContrast} onChange={handleContrastChange} name="highContrast" />}
                label="High Contrast"
            />
        </Box>
    );
};

export default AccessibilitySettings;