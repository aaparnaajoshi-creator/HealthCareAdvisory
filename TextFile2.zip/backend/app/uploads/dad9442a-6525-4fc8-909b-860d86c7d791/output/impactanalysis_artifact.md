# Impact Assessment: "Soft-Delete" for Shopping Cart Items

| **Document Version** | **Date**       | **Author**                | **Status** |
| -------------------- | -------------- | ------------------------- | ---------- |
| 1.0                  | October 26, 2023 | Senior Business Analyst | For Review |

---

### 1. Executive Summary

This document outlines the impact of implementing the "Soft-Delete for Shopping Cart Items" enhancement. The goal is to change the item removal behavior in the shopping cart from a permanent deletion to a reversible "soft-delete." When a user removes an item, it will be marked as 'inactive,' visually grayed out, and excluded from the cart total. A new option will allow the user to restore the item to their active cart.

This enhancement directly addresses user feedback and recent incidents (**INC-9876**, **FEEDBACK-451**), where users expressed frustration over accidentally or prematurely removing items. By making removals reversible, we aim to improve the user experience, reduce friction, and potentially increase the average order value.

The implementation will have a medium impact, primarily affecting the **`Cart-Service`** and the **Frontend UI**. It requires changes to the backend API, business logic, and the database schema of the `cart_items` table. The impact on downstream services, such as the `Checkout-Service`, is expected to be minimal as the responsibility for filtering inactive items will lie with the client application before initiating checkout.

---

### 2. Detailed Impact Assessment

#### **Functional Impact**

*   **Changes to Existing Functionalities:**
    *   **Item Removal (`US-103`):** The "Remove" action on the cart screen will no longer permanently delete an item from the database. It will now change the item's state to 'inactive'. The existing confirmation modal may be removed or reworded to reflect this new behavior.
    *   **Cart Summary Calculation (`US-105`):** The logic for calculating the cart subtotal, taxes, and total will be modified to sum only items with an 'active' status.

*   **New Functionalities:**
    *   **Inactive Item State:** A new 'inactive' state for cart items will be introduced. Inactive items will remain associated with the user's cart but will be visually distinct (e.g., grayed out).
    *   **Restore Item:** A new "Move to Cart" (or similar) button will be added for each inactive item, allowing the user to change its status back to 'active'.

*   **Impact on User Workflows and Screen Flows:**
    *   **View Cart Screen Flow:** This flow will be updated to display two types of items: active and inactive. The summary section will only reflect active items.
    *   **Remove Item Flow:** This flow is fundamentally changed. Instead of triggering a permanent deletion, it now triggers a state change.
        1.  User clicks the "Remove" button.
        2.  The item's appearance changes to the 'inactive' state.
        3.  The "Remove" button is replaced by a "Move to Cart" button.
        4.  The cart summary is immediately recalculated to exclude the item's price.
    *   **New "Restore Item" Flow:**
        1.  User clicks the "Move to Cart" button on an inactive item.
        2.  The item's appearance reverts to the 'active' state.
        3.  The "Move to Cart" button is replaced by the original "Remove" button.
        4.  The cart summary is immediately recalculated to include the item's price.

*   **Affected Existing User Stories:**
    *   **`US-103: As a shopper, I want to remove an item from my shopping cart so that I don't purchase it.`**
        *   **Impact:** **High.** The acceptance criteria must be rewritten to reflect the change from permanent deletion to a soft-delete (inactive) state.
    *   **`US-105: As a shopper, I want to see the subtotal, taxes, and total cost of all items in my cart.`**
        *   **Impact:** **Medium.** The acceptance criteria must be updated to specify that calculations are based only on 'active' items.

#### **Design & Architectural Impact**

*   **Affected Software Modules/Services (as per HLD):**
    *   **`Cart-Service`:** High impact. Requires changes to business logic, API contracts, and data access layer.
    *   **Frontend Application (Web/Mobile):** High impact. Requires significant UI/UX changes to handle the new item state and user actions.
    *   **`Checkout-Service`:** No impact (see Data Flow section for validation).

*   **UI/UX Impact:**
    *   The cart item component requires a new visual design for the 'inactive' state.
    *   A new "Move to Cart" button/control needs to be designed and implemented for inactive items.
    *   The cart summary section must update dynamically as items are moved between active and inactive states.

*   **Backend Services and APIs (as per HLD & Codebase Snippets):**
    *   **`Cart-Service`:**
        *   **`DELETE /api/v1/cart/items/:itemId`:** The behavior of this endpoint must change.
            *   **Current:** As seen in `CartController.java` and `CartService.java`, it triggers a permanent `cartItemRepository.deleteById(itemId)`.
            *   **Proposed:** This endpoint will now trigger an `UPDATE` statement on the `cart_items` table, setting a new `is_active` column to `false`. The HTTP method `DELETE` remains semantically appropriate as it removes the item from the *active* cart.
        *   **`GET /api/v1/cart/:cartId`:** The response payload for each item must be modified to include its status.
            *   **Proposed Change:** Add a boolean field, e.g., `"isActive": true/false`, to each item object in the JSON response array. This allows the UI to render items correctly.
        *   **New Endpoint `PUT /api/v1/cart/items/:itemId/restore`:** A new endpoint is required to handle restoring an item. This endpoint will execute an `UPDATE` statement, setting `is_active` to `true`.

#### **Data Flow Impact**

*   **Data Flow Analysis:**
    1.  The UI fetches the cart via `GET /api/v1/cart/:cartId`. The response now includes the `isActive` flag for each item.
    2.  The UI renders items based on the `isActive` flag.
    3.  When a user clicks "Remove," the UI calls `DELETE /api/v1/cart/items/:itemId`. `Cart-Service` updates the item's `is_active` flag to `false`.
    4.  When a user clicks "Move to Cart," the UI calls the new `PUT /api/v1/cart/items/:itemId/restore` endpoint. `Cart-Service` updates the item's `is_active` flag to `true`.
    5.  When the user proceeds to checkout, the UI is responsible for filtering the cart items and sending **only the active items** to the `Checkout-Service`.

*   **Integrations Impact:**
    *   **`Checkout-Service`:** **No changes are anticipated.**
        *   **Validation:** As per the **HLD**, the `Checkout-Service` contract (`POST /api/v1/checkout/initiate`) expects a payload of `{"items": [...]}`. The service is agnostic to how this list was created. The responsibility lies with the client (Frontend Application) to construct this list using only the active cart items. As long as the client sends a valid list of active items in the specified format, the `Checkout-Service` will function correctly without modification.

#### **Database Impact**

*   **Schema Changes (as per HLD `cart_items` table schema):**
    *   **Table:** `cart_items`
    *   **Modification:** A new column is required to track the item's state.
        ```sql
        ALTER TABLE cart_items ADD COLUMN is_active BOOLEAN NOT NULL DEFAULT TRUE;
        ```
    *   **New Index:** To maintain query performance when fetching only active items, a new index is recommended.
        ```sql
        CREATE INDEX idx_cart_items_is_active ON cart_items (is_active);
        ```

*   **Data Migration Strategy:**
    *   A one-time data migration script is required to back-fill the `is_active` status for all existing records in the `cart_items` table. This ensures that all items currently in users' carts are considered 'active' after the deployment.
    *   **Script:**
        ```sql
        UPDATE cart_items SET is_active = TRUE WHERE is_active IS NULL;
        ```

---

### 3. Risks and Dependencies

*   **Technical Risks:**
    *   **API Backward Compatibility:** Modifying the response of `GET /api/v1/cart/:cartId` is a breaking change. If older clients (e.g., a mobile app) are not updated simultaneously, they may fail to parse the new response.
        *   **Mitigation:** Coordinate a simultaneous release of the backend and all frontend clients. Alternatively, introduce a new versioned API endpoint (e.g., `/v2/cart/:cartId`) and maintain the old one for a deprecation period.
    *   **Data Integrity:** There is a risk that an inactive item could be sent to the checkout service if the client-side filtering logic fails.
        *   **Mitigation:** Implement robust unit and integration tests for the client-side filtering logic. As a secondary safeguard, the `Cart-Service` could expose a dedicated endpoint for fetching only active items for checkout.
    *   **Performance:** Queries fetching cart contents will now require an additional `WHERE` clause (`WHERE is_active = TRUE`).
        *   **Mitigation:** The recommended database index on the `is_active` column should prevent any significant performance degradation.

*   **Dependencies:**
    *   **Frontend Team:** This feature cannot be released without the corresponding UI/UX changes. Close collaboration between backend and frontend teams is critical.
    *   **QA Team:** New test plans and cases are required to cover the soft-delete, restore, and checkout flows with both active and inactive items.
    *   **DevOps / DBA Team:** Required to schedule and execute the database migration script during deployment.

---

### 4. Estimated Effort

**T-Shirt Size: M (Medium)**

**Justification:** The effort is medium because the change impacts the full stack:
*   **Database:** Schema migration and back-filling.
*   **Backend:** Changes to existing business logic, modification of one endpoint, and creation of a new endpoint.
*   **Frontend:** Significant UI/UX changes to a core feature.
*   **Testing:** Requires comprehensive testing of new functionality and regression testing of the entire cart and checkout flow.

The scope is well-defined but involves modifying a critical user workflow, which elevates it beyond a 'Small' task.