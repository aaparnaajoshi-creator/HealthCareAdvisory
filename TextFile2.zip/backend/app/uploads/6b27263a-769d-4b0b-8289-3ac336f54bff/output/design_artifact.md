```markdown
# High-Level Design: PharmaCorp Commercial Website

## 1. Introduction

This document outlines the high-level design (HLD) for the PharmaCorp commercial website. It details the architecture, technologies, data models, APIs, and deployment strategy. This design is based on the provided user stories and technical constraints.

## 2. Architecture

The website will adopt a modular architecture, separating the frontend and backend components. The backend will expose RESTful APIs that the frontend consumes.

```mermaid
graph LR
    A[User] --> B{Load Balancer}
    B --> C[Frontend (HTML/JS)]
    C --> D[API Gateway]
    D --> E[Backend (Python - FastAPI/Flask)]
    E --> F[PostgreSQL Database]
    E --> G[Object Storage (AWS S3)]

    style A fill:#f9f,stroke:#333,stroke-width:2px
    style B fill:#ccf,stroke:#333,stroke-width:2px
    style C fill:#ccf,stroke:#333,stroke-width:2px
    style D fill:#ccf,stroke:#333,stroke-width:2px
    style E fill:#ccf,stroke:#333,stroke-width:2px
    style F fill:#ccf,stroke:#333,stroke-width:2px
    style G fill:#ccf,stroke:#333,stroke-width:2px
```

**Components:**

*   **Frontend (HTML/JavaScript):**  Provides the user interface, handles user interactions, and displays content. Uses HTML5, JavaScript, and potentially a CSS framework like Bootstrap for responsive design.
*   **API Gateway:**  A single entry point for all API requests. Handles authentication, authorization, rate limiting, and request routing.
*   **Backend (Python - FastAPI/Flask):** Implements the business logic, interacts with the database and object storage, and exposes RESTful APIs.
*   **PostgreSQL Database:** Stores website content, user data, form submissions, and newsletter subscriptions.
*   **Object Storage (AWS S3):** Stores PI/MedGuide PDF files.
*   **Load Balancer:** Distributes incoming traffic across multiple instances of the frontend application to ensure high availability and scalability.

## 3. Technology Stack

*   **Frontend:** HTML5, JavaScript, Bootstrap (for responsive design)
*   **Backend:** Python (FastAPI or Flask)
*   **Database:** PostgreSQL
*   **Object Storage:** AWS S3 (or similar)
*   **API Gateway:**  Nginx or similar
*   **CI/CD:** Jenkins, GitLab CI, or GitHub Actions
*   **Operating System:** Linux (e.g., Ubuntu)
*   **Web Server:**  Gunicorn or uWSGI

## 4. Data Models and Database Schema

### 4.1. Users Table

```sql
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    first_name VARCHAR(255) NOT NULL,
    last_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    password_salt VARCHAR(255) NOT NULL,
    role VARCHAR(255) NOT NULL,
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT (NOW() AT TIME ZONE 'utc')
);
```

### 4.2. Products Table

```sql
CREATE TABLE products (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    indications TEXT,
    dosage TEXT,
    safety_information TEXT,
    image_url VARCHAR(255),
    pi_pdf_url VARCHAR(255),
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT (NOW() AT TIME ZONE 'utc')
);
```

### 4.3. Pages Table

```sql
CREATE TABLE pages (
    id SERIAL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    content TEXT,
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT (NOW() AT TIME ZONE 'utc')
);
```

### 4.4. Contact Form Submissions Table

```sql
CREATE TABLE contact_form_submissions (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT (NOW() AT TIME ZONE 'utc')
);
```

### 4.5. Newsletter Subscriptions Table

```sql
CREATE TABLE newsletter_subscriptions (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    subscribed_at TIMESTAMP WITHOUT TIME ZONE DEFAULT (NOW() AT TIME ZONE 'utc'),
    is_active BOOLEAN DEFAULT FALSE,
    verification_token VARCHAR(255)
);
```

## 5. API Endpoints

This section defines the API endpoints for core website functionalities.

### 5.1. User Authentication and Authorization

*   **POST /auth/register:** Registers a new user.
    *   Request:
        ```json
        {
            "first_name": "John",
            "last_name": "Doe",
            "email": "john.doe@example.com",
            "password": "password123"
        }
        ```
    *   Response (201 Created):
        ```json
        {
            "message": "User registered successfully"
        }
        ```
    *   Response (400 Bad Request):
        ```json
        {
            "detail": "Email already registered"
        }
        ```

*   **POST /auth/login:** Logs in an existing user.
    *   Request:
        ```json
        {
            "email": "john.doe@example.com",
            "password": "password123"
        }
        ```
    *   Response (200 OK):
        ```json
        {
            "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
            "token_type": "bearer"
        }
        ```
    *   Response (401 Unauthorized):
        ```json
        {
            "detail": "Incorrect username or password"
        }
        ```

*   **GET /users/me:** Gets the current user's information (requires authentication).
    *   Response (200 OK):
        ```json
        {
            "id": 1,
            "first_name": "John",
            "last_name": "Doe",
            "email": "john.doe@example.com",
            "role": "administrator"
        }
        ```
    *   Response (401 Unauthorized):
        ```json
        {
            "detail": "Not authenticated"
        }
        ```
    *   Response (403 Forbidden):
         ```json
        {
            "detail": "Insufficient privileges"
        }
        ```

### 5.2. Content Management

*   **GET /pages/{slug}:** Retrieves a page by its slug.
    *   Response (200 OK):
        ```json
        {
            "id": 1,
            "title": "About Us",
            "slug": "about-us",
            "content": "<p>This is the about us page.</p>"
        }
        ```
    *   Response (404 Not Found):
        ```json
        {
            "detail": "Page not found"
        }
        ```
*   **POST /pages:** Creates a new page (requires authentication and authorization).
     *   Request:
        ```json
        {
            "title": "New Page",
            "slug": "new-page",
            "content": "<p>This is a new page.</p>"
        }
        ```
    *   Response (201 Created):
        ```json
        {
            "id": 2,
            "title": "New Page",
            "slug": "new-page",
            "content": "<p>This is a new page.</p>"
        }
        ```
    *   Response (401 Unauthorized):
        ```json
        {
            "detail": "Not authenticated"
        }
        ```
    *   Response (403 Forbidden):
         ```json
        {
            "detail": "Insufficient privileges"
        }
        ```
*   **PUT /pages/{id}:** Updates an existing page (requires authentication and authorization).
*   **DELETE /pages/{id}:** Deletes a page (requires authentication and authorization).

### 5.3. Product Management

*   **GET /products:** Retrieves a list of all products.
    *   Response (200 OK):
        ```json
        [
            {
                "id": 1,
                "name": "Product A",
                "description": "A description of Product A.",
                "indications": "Indications for Product A.",
                "dosage": "Dosage for Product A.",
                "safety_information": "Safety information for Product A.",
                "image_url": "/images/product-a.jpg",
                "pi_pdf_url": "/pdfs/product-a.pdf"
            },
            {
                "id": 2,
                "name": "Product B",
                "description": "A description of Product B.",
                "indications": "Indications for Product B.",
                "dosage": "Dosage for Product B.",
                "safety_information": "Safety information for Product B.",
                "image_url": "/images/product-b.jpg",
                "pi_pdf_url": "/pdfs/product-b.pdf"
            }
        ]
        ```
*   **GET /products/{id}:** Retrieves a product by its ID.
*   **POST /products:** Creates a new product (requires authentication and authorization).
*   **PUT /products/{id}:** Updates an existing product (requires authentication and authorization).
*   **DELETE /products/{id}:** Deletes a product (requires authentication and authorization).

### 5.4. Contact Form Submissions

*   **POST /contact-form-submissions:** Creates a new contact form submission.
    *   Request:
        ```json
        {
            "name": "John Doe",
            "email": "john.doe@example.com",
            "subject": "Inquiry",
            "message": "I have a question about your product."
        }
        ```
    *   Response (201 Created):
        ```json
        {
            "message": "Form submitted successfully"
        }
        ```
    *   Response (400 Bad Request):
        ```json
        {
            "detail": "Invalid email format"
        }
        ```
*   **GET /contact-form-submissions:** Retrieves a list of all contact form submissions (requires authentication and authorization).

### 5.5. Newsletter Subscriptions

*   **POST /newsletter-subscriptions:** Subscribes a new email to the newsletter.
    *   Request:
        ```json
        {
            "email": "john.doe@example.com"
        }
        ```
     *   Response (201 Created):
        ```json
        {
            "message": "Subscription created. Please verify your email."
        }
        ```
    *   Response (400 Bad Request):
        ```json
        {
            "detail": "Invalid email format or email already subscribed."
        }
        ```
*   **GET /newsletter-subscriptions/verify/{token}:** Verifies a newsletter subscription.
    *   Response (200 OK):
        ```json
        {
            "message": "Email verified successfully."
        }
        ```
    *   Response (400 Bad Request):
        ```json
        {
            "detail": "Invalid or expired token."
        }
        ```
*   **POST /newsletter-subscriptions/unsubscribe:** Unsubscribes an email from the newsletter.
    *   Request:
        ```json
        {
            "email": "john.doe@example.com"
        }
        ```
    *   Response (200 OK):
        ```json
        {
            "message": "Email unsubscribed successfully."
        }
        ```
    *   Response (404 Not Found):
        ```json
        {
            "detail": "Email not found."
        }
        ```

### 5.6. File Management

*   **POST /files/upload:** Uploads a new file (requires authentication and authorization).
*   **GET /files/{filename}:** Retrieves a file by its filename.
*   **DELETE /files/{filename}:** Deletes a file (requires authentication and authorization).

## 6. Security

*   **HTTPS:** All communication will be encrypted using HTTPS.
*   **Authentication:** User authentication will be implemented using JWT (JSON Web Tokens).
*   **Authorization:** Role-based access control will be used to restrict access to administrative functions.
*   **Rate Limiting:** Rate limiting will be implemented to prevent abuse and denial-of-service attacks.
*   **Input Validation:** All user input will be validated to prevent injection attacks.
*   **Content Security Policy (CSP):** CSP will be implemented to prevent cross-site scripting (XSS) attacks.
    *   Example CSP directives:
        *   `default-src 'self';`
        *   `script-src 'self' 'unsafe-inline' https://trusted-cdn.com;`
        *   `style-src 'self' 'unsafe-inline' https://trusted-cdn.com;`
        *   `img-src 'self' data:;`
        *   `font-src 'self';`
        *   `object-src 'none';`
*   **Password Hashing:** Passwords will be hashed using a strong hashing algorithm (e.g., bcrypt) with a unique salt for each user.

## 7. Newsletter Subscription Verification Process

1.  User submits their email address via the newsletter signup form.
2.  The backend generates a unique, random verification token (e.g., a UUID).
3.  The token is stored in the `newsletter_subscriptions` table alongside the user's email address.  The `is_active` flag is set to `FALSE`.
4.  The backend sends an email to the user containing a verification link. The link includes the verification token (e.g., `https://www.pharmaco.com/newsletter-subscriptions/verify/{token}`).
5.  When the user clicks the verification link, the frontend sends a request to the `GET /newsletter-subscriptions/verify/{token}` endpoint.
6.  The backend retrieves the user's record from the `newsletter_subscriptions` table using the provided token.
7.  If the token is valid and the `is_active` flag is `FALSE`, the backend sets the `is_active` flag to `TRUE` and returns a success message.
8.  If the token is invalid or expired, the backend returns an error message.

## 8. Deployment

*   **Environments:** Dev, Staging, and Prod environments will be set up.
*   **CI/CD Pipeline:** A CI/CD pipeline will be set up using Jenkins, GitLab CI, or GitHub Actions to automate the build, test, and deployment process.
*   **Containerization:** The backend application will be containerized using Docker.
*   **Orchestration:** Docker Compose or Kubernetes will be used to orchestrate the containers.
*   **Infrastructure as Code (IaC):** Terraform or CloudFormation will be used to manage the infrastructure.

## 9. Frontend Implementation

The frontend will be developed using HTML5, JavaScript, and potentially Bootstrap for responsive design. Vanilla JavaScript will be used for core functionality. Bootstrap will be used for layout, styling, and responsive behavior.

## 10. Performance Optimization

*   **Image Optimization:** Images will be optimized for web use.
*   **Browser Caching:** Browser caching will be enabled.
*   **Content Delivery Network (CDN):** A CDN will be used to serve static assets.
*   **Lazy Loading:** Images will be lazy-loaded.
*   **Minification:** HTML, CSS, and JavaScript files will be minified.

## 11. WCAG 2.2 AA Compliance

The website will be designed and developed to comply with WCAG 2.2 AA accessibility guidelines. This includes:

*   Using semantic HTML.
*   Providing alternative text for images.
*   Using sufficient color contrast.
*   Ensuring keyboard accessibility.
*   Testing with assistive technologies (e.g., screen readers).