class UserBase(BaseModel):
    first_name: str
    last_name: str
    email: str
    role: str

class UserCreate(BaseModel):
    first_name: str
    last_name: str
    email: str
    password: str

class User(UserBase):
    id: int
    created_at: datetime

    class Config:
        orm_mode = True


class ProductBase(BaseModel):
    name: str
    description: str | None = None
    indications: str | None = None
    dosage: str | None = None
    safety_information: str | None = None
    image_url: str | None = None
    pi_pdf_url: str | None = None


class ProductCreate(ProductBase):
    pass


class Product(ProductBase):
    id: int
    created_at: datetime

    class Config:
        orm_mode = True


class PageBase(BaseModel):
    title: str
    slug: str
    content: str | None = None


class PageCreate(PageBase):
    pass


class Page(PageBase):
    id: int
    created_at: datetime

    class Config:
        orm_mode = True


class ContactFormSubmissionBase(BaseModel):
    name: str
    email: str
    subject: str
    message: str


class ContactFormSubmissionCreate(ContactFormSubmissionBase):
    pass


class ContactFormSubmission(ContactFormSubmissionBase):
    id: int
    created_at: datetime

    class Config:
        orm_mode = True


class NewsletterSubscriptionBase(BaseModel):
    email: str


class NewsletterSubscriptionCreate(NewsletterSubscriptionBase):
    pass


class NewsletterSubscription(NewsletterSubscriptionBase):
    id: int
    subscribed_at: datetime
    is_active: bool
    verification_token: str | None = None

    class Config:
        orm_mode = True

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    email: str | None = None