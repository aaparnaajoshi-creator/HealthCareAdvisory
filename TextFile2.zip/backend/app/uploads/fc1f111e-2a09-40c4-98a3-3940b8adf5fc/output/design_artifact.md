# High-Level Design (HLD) Document: PharmaCorp Commercial Website

## 1. Introduction

This High-Level Design (HLD) document outlines the architectural blueprint for the PharmaCorp Commercial Website. It addresses the user stories and technical constraints provided, detailing the system's components, data models, API endpoints, and key architectural considerations. The goal is to create a secure, performant, accessible, and compliant web presence for PharmaCorp.

## 2. Overall Architecture

The PharmaCorp Commercial Website will be built using a **3-Tier Architecture** with a clear separation of concerns, facilitating scalability, maintainability, and independent development.

*   **Presentation Tier (Frontend):**
    *   Comprises static HTML, CSS, and JavaScript files.
    *   Responsible for rendering the user interface, handling user interactions, and making API calls to the backend.
    *   Served by a Content Delivery Network (CDN) for performance and global reach.
*   **Application Tier (Backend):**
    *   Developed using Python with FastAPI (chosen for its performance, async capabilities, and robust API definition features).
    *   Exposes RESTful APIs for data retrieval (products, content) and data submission (contact forms, newsletter signups).
    *   Implements business logic, data validation, security measures (rate limiting, input sanitization), and interacts with the Data Tier.
*   **Data Tier:**
    *   **PostgreSQL Database:** Primary data store for structured data such as product information, user submissions, and dynamic page content.
    *   **Object Storage:** Used for storing and serving large binary assets like Product Information (PI) PDFs and other media files.

**Key Architectural Principles:**

*   **Decoupling:** Frontend and Backend are separate services, communicating via RESTful APIs.
*   **Scalability:** Components can be scaled independently (e.g., adding more backend instances, leveraging CDN).
*   **Security:** HTTPS, input validation, rate limiting, and secure data storage are integral.
*   **Compliance:** Designed with GDPR/CCPA and WCAG 2.2 AA accessibility in mind.
*   **Automation:** CI/CD pipeline for efficient and reliable deployments.

## 3. Data Models and Database Schema

The primary database for the PharmaCorp website is **PostgreSQL**. The schema is designed to support the various content types and functionalities outlined in the user stories.

### 3.1. `products` Table

Stores information about PharmaCorp's products.

| Field Name           | Data Type         | Constraints                                   | Description                                                 |
| :------------------- | :---------------- | :-------------------------------------------- | :---------------------------------------------------------- |
| `id`                 | UUID / SERIAL     | PRIMARY KEY, NOT NULL                         | Unique identifier for the product.                          |
| `name`               | VARCHAR(255)      | NOT NULL, UNIQUE                              | Full product name.                                          |
| `summary`            | TEXT              | NOT NULL                                      | Brief descriptive summary for product list.                 |
| `description`        | TEXT              | NOT NULL                                      | Comprehensive description for product detail page.          |
| `image_url`          | VARCHAR(512)      | NULLABLE                                      | URL to product image (e.g., from object storage).           |
| `pi_pdf_object_key`  | VARCHAR(512)      | NOT NULL                                      | Key/path to the Product Information PDF in object storage.  |
| `isi_content_id`     | UUID / INTEGER    | NOT NULL, FOREIGN KEY REFERENCES `page_content(id)` | Link to the Important Safety Information content.           |
| `indications`        | TEXT              | NULLABLE                                      | Medical indications for the product.                        |
| `dosage`             | TEXT              | NULLABLE                                      | Recommended dosage information.                             |
| `is_active`          | BOOLEAN           | NOT NULL, DEFAULT TRUE                        | Flag to indicate if the product is currently active/visible. |
| `created_at`         | TIMESTAMP WITH TZ | NOT NULL, DEFAULT NOW()                       | Timestamp of product creation.                              |
| `updated_at`         | TIMESTAMP WITH TZ | NOT NULL, DEFAULT NOW()                       | Timestamp of last update.                                   |

### 3.2. `contact_submissions` Table

Stores inquiries submitted through the contact form.

| Field Name     | Data Type         | Constraints             | Description                                |
| :------------- | :---------------- | :---------------------- | :----------------------------------------- |
| `id`           | UUID / SERIAL     | PRIMARY KEY, NOT NULL   | Unique identifier for the submission.      |
| `name`         | VARCHAR(255)      | NOT NULL                | Name of the submitter.                     |
| `email`        | VARCHAR(255)      | NOT NULL                | Email address of the submitter.            |
| `subject`      | VARCHAR(255)      | NOT NULL                | Subject of the inquiry.                    |
| `message`      | TEXT              | NOT NULL                | Full message content.                      |
| `submitted_at` | TIMESTAMP WITH TZ | NOT NULL, DEFAULT NOW() | Timestamp of when the form was submitted.  |
| `ip_address`   | INET              | NULLABLE                | IP address of the submitter (for rate limiting/auditing) |

### 3.3. `newsletter_subscribers` Table

Stores email addresses for newsletter sign-ups.

| Field Name       | Data Type         | Constraints                               | Description                                     |
| :--------------- | :---------------- | :---------------------------------------- | :---------------------------------------------- |
| `id`             | UUID / SERIAL     | PRIMARY KEY, NOT NULL                     | Unique identifier for the subscriber.           |
| `email`          | VARCHAR(255)      | NOT NULL, UNIQUE                          | Subscriber's email address.                     |
| `opt_in_token`   | VARCHAR(64)       | NULLABLE                                  | Token for double opt-in confirmation.           |
| `is_confirmed`   | BOOLEAN           | NOT NULL, DEFAULT FALSE                   | True if email confirmed (double opt-in).        |
| `subscribed_at`  | TIMESTAMP WITH TZ | NOT NULL, DEFAULT NOW()                   | Timestamp of initial signup.                    |
| `confirmed_at`   | TIMESTAMP WITH TZ | NULLABLE                                  | Timestamp of email confirmation.                |

### 3.4. `page_content` Table

Stores dynamic content for various pages and sections, including ISI, which can be updated by content administrators. This addresses the feedback for US6.

| Field Name       | Data Type         | Constraints                               | Description                                   |
| :--------------- | :---------------- | :---------------------------------------- | :-------------------------------------------- |
| `id`             | UUID / SERIAL     | PRIMARY KEY, NOT NULL                     | Unique identifier for the content block.      |
| `key`            | VARCHAR(255)      | NOT NULL, UNIQUE                          | Unique identifier for content lookup (e.g., 'isi_product_x', 'privacy_policy_main'). |
| `title`          | VARCHAR(255)      | NOT NULL                                  | Title of the content block.                   |
| `content_html`   | TEXT              | NOT NULL                                  | HTML content of the block.                    |
| `last_updated_by`| VARCHAR(255)      | NULLABLE                                  | User or system that last updated the content. |
| `updated_at`     | TIMESTAMP WITH TZ | NOT NULL, DEFAULT NOW()                   | Timestamp of last update.                     |

## 4. API Endpoints

The Python (FastAPI) backend will expose the following RESTful API endpoints:

### 4.1. Product Endpoints

*   **`GET /api/products`**
    *   **Description:** Retrieves a list of all active PharmaCorp products.
    *   **Request:** None
    *   **Response:** `200 OK`
        ```json
        [
            {
                "id": "uuid-1",
                "name": "Product A",
                "summary": "Brief description of Product A.",
                "image_url": "https://cdn.example.com/productA.jpg",
                "link": "/products/uuid-1"
            },
            // ... more products
        ]
        ```
*   **`GET /api/products/{product_id}`**
    *   **Description:** Retrieves detailed information for a specific product.
    *   **Request:**
        *   `product_id`: UUID (Path Parameter)
    *   **Response:** `200 OK`
        ```json
        {
            "id": "uuid-1",
            "name": "Product A",
            "description": "Comprehensive description of Product A...",
            "image_url": "https://cdn.example.com/productA.jpg",
            "pi_pdf_download_url": "https://object-storage.example.com/productA_PI.pdf",
            "isi_content_html": "<p>Important Safety Information for Product A...</p>",
            "indications": "Used for...",
            "dosage": "Take X daily."
        }
        ```
    *   **Error Responses:** `404 Not Found` if product_id does not exist.

### 4.2. Content Endpoints

*   **`GET /api/content/{content_key}`**
    *   **Description:** Retrieves specific dynamic content blocks (e.g., ISI content).
    *   **Request:**
        *   `content_key`: String (Path Parameter, e.g., `isi_product_uuid-1`, `privacy_policy_main`)
    *   **Response:** `200 OK`
        ```json
        {
            "id": "uuid-content-1",
            "key": "isi_product_uuid-1",
            "title": "Important Safety Information for Product A",
            "content_html": "<p>This is the <b>Important Safety Information</b> for Product A.</p>"
        }
        ```
    *   **Error Responses:** `404 Not Found` if content_key does not exist.

### 4.3. Contact Form Endpoints

*   **`POST /api/contact`**
    *   **Description:** Submits a contact form inquiry.
    *   **Request:** `200 OK`
        ```json
        {
            "name": "John Doe",
            "email": "john.doe@example.com",
            "subject": "General Inquiry",
            "message": "I have a question about..."
        }
        ```
    *   **Response:** `201 Created`
        ```json
        {
            "message": "Your inquiry has been submitted successfully."
        }
        ```
    *   **Error Responses:**
        *   `400 Bad Request`: Invalid input (e.g., email format, missing fields).
        *   `429 Too Many Requests`: Rate limit exceeded.

### 4.4. Newsletter Endpoints

*   **`POST /api/newsletter/signup`**
    *   **Description:** Signs up a user for the newsletter. Implements double opt-in.
    *   **Request:**
        ```json
        {
            "email": "user@example.com"
        }
        ```
    *   **Response:** `202 Accepted` (indicating processing, not immediate confirmation)
        ```json
        {
            "message": "Please check your email to confirm your subscription."
        }
        ```
    *   **Error Responses:**
        *   `400 Bad Request`: Invalid email format.
        *   `409 Conflict`: Email already subscribed.
*   **`GET /api/newsletter/confirm/{token}`**
    *   **Description:** Confirms newsletter subscription via double opt-in token.
    *   **Request:**
        *   `token`: String (Path Parameter)
    *   **Response:** `200 OK`
        ```json
        {
            "message": "Your subscription has been confirmed."
        }
        ```
    *   **Error Responses:** `400 Bad Request` or `404 Not Found`: Invalid or expired token.

### 4.5. Search Endpoints

*   **`GET /api/search`**
    *   **Description:** Performs a site-wide search for content.
    *   **Request:**
        *   `q`: String (Query Parameter, search query)
    *   **Response:** `200 OK`
        ```json
        [
            {
                "title": "Product X Details",
                "summary": "Find detailed information about Product X.",
                "url": "/products/uuid-x"
            },
            {
                "title": "About Us Page",
                "summary": "Learn about PharmaCorp's mission and history.",
                "url": "/about-us"
            }
        ]
        ```
    *   **Error Responses:** `400 Bad Request` for empty query.

## 5. Diagrams

### 5.1. Overall System Architecture Diagram

```mermaid
graph TD
    subgraph "External Users"
        A[Website Visitor]
    end

    subgraph "Presentation Tier"
        B[Web Browser]
        C(CDN / Web Server)
    end

    subgraph "Application Tier"
        D[Load Balancer]
        E[FastAPI Backend APIs]
    end

    subgraph "Data Tier"
        F[PostgreSQL Database]
        G[Object Storage]
    end

    subgraph "DevOps & Management"
        H[Git Repository]
        I[CI/CD Pipeline]
        J[Monitoring & Logging]
    end

    A -- HTTP/S --> C
    C -- Serves Static Content (HTML, CSS, JS) --> B
    B -- API Requests (HTTP/S) --> D
    D -- Routes Traffic --> E
    E -- Database Queries --> F
    E -- Object Storage Access --> G
    H -- Code Push --> I
    I -- Deploys to --> E
    E -- Emits Logs/Metrics --> J
    F -- Emits Logs/Metrics --> J
    G -- Emits Logs/Metrics --> J
```

**Explanation:**

*   **Website Visitor:** Users accessing the website.
*   **Web Browser:** Client-side application rendering the website.
*   **CDN / Web Server:** Serves static frontend assets (HTML, CSS, JS) and acts as the initial entry point, potentially handling HTTPS termination.
*   **Load Balancer:** Distributes incoming API requests across multiple instances of the FastAPI Backend for scalability and reliability.
*   **FastAPI Backend APIs:** The core application logic, handling all API requests, business logic, and interactions with the data tier.
*   **PostgreSQL Database:** Stores all structured data (products, submissions, content).
*   **Object Storage:** Stores binary assets like PDFs.
*   **Git Repository:** Source code management.
*   **CI/CD Pipeline:** Automates building, testing, and deploying the application to various environments (Dev, Staging, Prod).
*   **Monitoring & Logging:** Collects system performance metrics and application logs for operational insights.

### 5.2. Contact Form Data Flow Diagram

```mermaid
graph TD
    subgraph "Website Visitor"
        A[User Fills Contact Form]
    end

    subgraph "Presentation Tier"
        B[Frontend JavaScript]
    end

    subgraph "Application Tier"
        C[FastAPI Backend - /api/contact Endpoint]
        D{Input Validation & Sanitization}
        E{Rate Limiting Check}
    end

    subgraph "Data Tier"
        F[PostgreSQL Database]
    end

    A -- Submits Form Data --> B
    B -- (AJAX POST) --> C
    C -- Applies --> E
    E -- If not rate limited --> D
    D -- If Valid --> F[Insert into contact_submissions table]
    F -- Success/Failure --> C
    C -- Returns Confirmation --> B
    B -- Displays --> G[On-screen Confirmation Message]

    E -- If rate limited --> C[Return 429 Too Many Requests]
    D -- If Invalid --> C[Return 400 Bad Request]
```

**Explanation:**

1.  **User Fills Contact Form:** The website visitor enters their information and message into the "Contact Us" form.
2.  **Frontend JavaScript:** Captures the form data and sends an AJAX POST request to the backend.
3.  **FastAPI Backend - `/api/contact` Endpoint:** Receives the request.
4.  **Rate Limiting Check:** The backend first checks if the incoming request is within the allowed rate limits (e.g., by IP address or session).
5.  **Input Validation & Sanitization:** If not rate-limited, the backend rigorously validates and sanitizes all input fields (e.g., email format, minimum message length, preventing injection attacks).
6.  **Insert into `contact_submissions` table:** If validation passes, the data is securely stored in the PostgreSQL database.
7.  **Return Confirmation:** The backend sends a success response to the frontend.
8.  **On-screen Confirmation Message:** The frontend displays a confirmation message to the user.
9.  **Error Handling:** Appropriate error responses (e.g., 429 for rate limiting, 400 for invalid input) are returned if checks fail.