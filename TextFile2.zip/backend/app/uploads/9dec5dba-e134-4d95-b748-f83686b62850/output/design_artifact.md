# High-Level Design (HLD): PharmaCorp Commercial Website

## 1. Introduction

This High-Level Design (HLD) document outlines the architectural blueprint for the PharmaCorp commercial website, addressing the provided user stories and adhering to specified technical constraints. The system is designed to be a robust, secure, and user-friendly platform for patients and Healthcare Professionals (HCPs) to access company information, product details, and engage with PharmaCorp.

## 2. Overall Architecture

The PharmaCorp commercial website will adopt a layered architecture, comprising a Frontend, a Backend API, a Database, and Object Storage, all secured by a Content Delivery Network (CDN) and Web Application Firewall (WAF) for enhanced performance and protection. This design promotes separation of concerns, scalability, and maintainability.

### 2.1 Architectural Diagram

```mermaid
graph TD
    A[User/Browser] --> B(CDN / WAF);
    B --> C[Static Web Hosting / Frontend];
    C --> D[Backend API (Python: FastAPI/Flask)];
    D --> E[PostgreSQL Database];
    D --> F[Object Storage (e.g., S3-compatible)];

    subgraph CI/CD Pipeline
        G[Code Repository] --> H[Build & Test];
        H --> I[Container Registry];
        I --> J[Deployment Orchestrator];
    end

    J --> C;
    J --> D;
    J --> E;
    J --> F;

    style C fill:#f9f,stroke:#333,stroke-width:2px
    style D fill:#bbf,stroke:#333,stroke-width:2px
    style E fill:#bfb,stroke:#333,stroke-width:2px
    style F fill:#ffb,stroke:#333,stroke-width:2px
```

### 2.2 Component Descriptions

*   **User/Browser:** End-users accessing the website via various devices (desktop, tablet, mobile).
*   **CDN / WAF:**
    *   **Content Delivery Network (CDN):** Caches static assets (HTML, CSS, JS, images) closer to users, improving load times (LCP < 2.5s) and reducing origin server load.
    *   **Web Application Firewall (WAF):** Provides protection against common web vulnerabilities (e.g., SQL injection, XSS) and helps enforce rate limiting at the edge.
    *   **HTTPS:** All communication secured via SSL/TLS certificates managed at the CDN/WAF layer.
*   **Static Web Hosting / Frontend:**
    *   Serves the static HTML5, CSS, and JavaScript files.
    *   Implements responsive design for various screen sizes.
    *   Handles client-side routing, form validation, and API calls to the Backend API.
    *   Manages cookie consent banner and preferences.
    *   Ensures WCAG 2.2 AA accessibility standards (keyboard navigation, semantic HTML, ARIA attributes).
    *   Implements Content Security Policy (CSP) headers for enhanced security.
*   **Backend API (Python: FastAPI/Flask):**
    *   Developed using Python with either FastAPI or Flask framework.
    *   Exposes RESTful API endpoints for content, products, form submissions, and search.
    *   Performs robust input validation for all incoming requests.
    *   Implements server-side rate limiting to prevent abuse on form submission and newsletter signup endpoints.
    *   Interacts with PostgreSQL for data persistence and Object Storage for binary assets (PDFs).
*   **PostgreSQL Database:**
    *   Relational database for storing structured data such as product information, contact form submissions, newsletter subscriber emails, and static page content.
    *   Designed with GDPR/CCPA compliance in mind, especially concerning personal data handling.
*   **Object Storage (e.g., S3-compatible):**
    *   Stores large binary files like Prescribing Information (PI) PDFs and Medication Guide (MedGuide) PDFs.
    *   Provides high availability and durability for document downloads.
*   **CI/CD Pipeline:**
    *   Automates the build, test, and deployment processes across Dev, Staging, and Production environments.
    *   Ensures consistent and reliable deployments.
    *   Utilizes a Code Repository (e.g., Git), Build & Test tools, Container Registry (e.g., Docker Hub, ECR), and a Deployment Orchestrator (e.g., Kubernetes, AWS ECS, Azure App Service).

## 3. Data Models and Database Schema

The database schema is designed to support the user stories, focusing on data minimization and secure handling of personal information in compliance with GDPR/CCPA.

### 3.1 Table: `products`

Stores information about PharmaCorp's products.

| Column Name            | Data Type          | Constraints            | Description                                   |
| :--------------------- | :----------------- | :--------------------- | :-------------------------------------------- |
| `id`                   | `UUID` / `SERIAL`  | `PRIMARY KEY`          | Unique identifier for the product             |
| `name`                 | `VARCHAR(255)`     | `NOT NULL`, `UNIQUE`   | Product name                                  |
| `slug`                 | `VARCHAR(255)`     | `NOT NULL`, `UNIQUE`   | URL-friendly slug for product detail pages    |
| `brief_description`    | `TEXT`             | `NOT NULL`             | Short summary for product list page           |
| `detailed_description` | `TEXT`             | `NOT NULL`             | Comprehensive description                     |
| `indications`          | `TEXT`             | `NOT NULL`             | Medical indications for the product           |
| `safety_information`   | `TEXT`             | `NOT NULL`             | Important safety information (ISI)            |
| `pi_pdf_url`           | `VARCHAR(2048)`    | `NULLABLE`             | URL to Prescribing Information PDF in object storage |
| `medguide_pdf_url`     | `VARCHAR(2048)`    | `NULLABLE`             | URL to Medication Guide PDF in object storage |
| `is_active`            | `BOOLEAN`          | `DEFAULT TRUE`         | Flag to enable/disable product visibility     |
| `created_at`           | `TIMESTAMP`        | `DEFAULT NOW()`        | Timestamp of record creation                  |
| `updated_at`           | `TIMESTAMP`        | `DEFAULT NOW()`        | Last update timestamp                         |

### 3.2 Table: `contact_submissions`

Stores data from the contact us form. **IP address is not stored directly in this table.**

| Column Name      | Data Type         | Constraints         | Description                                   |
| :--------------- | :---------------- | :------------------ | :-------------------------------------------- |
| `id`             | `UUID` / `SERIAL` | `PRIMARY KEY`       | Unique identifier for the submission          |
| `name`           | `VARCHAR(255)`    | `NOT NULL`          | Name of the submitter                         |
| `email`          | `VARCHAR(255)`    | `NOT NULL`          | Email address of the submitter                |
| `subject`        | `VARCHAR(255)`    | `NOT NULL`          | Subject of the message                        |
| `message`        | `TEXT`            | `NOT NULL`          | The message content                           |
| `created_at`     | `TIMESTAMP`       | `DEFAULT NOW()`     | Timestamp of submission                       |
| `processed`      | `BOOLEAN`         | `DEFAULT FALSE`     | Flag indicating if the submission has been processed |

### 3.3 Table: `newsletter_subscribers`

Stores email addresses for newsletter subscriptions. **IP address is not stored directly in this table.**

| Column Name  | Data Type         | Constraints                 | Description                                   |
| :----------- | :---------------- | :-------------------------- | :-------------------------------------------- |
| `id`         | `UUID` / `SERIAL` | `PRIMARY KEY`               | Unique identifier for the subscriber          |
| `email`      | `VARCHAR(255)`    | `NOT NULL`, `UNIQUE`        | Subscriber's email address                    |
| `consent_at` | `TIMESTAMP`       | `DEFAULT NOW()`             | Timestamp when consent was given              |
| `is_active`  | `BOOLEAN`         | `NOT NULL`, `DEFAULT TRUE`  | Flag for active subscription (for opt-out)    |

### 3.4 Table: `site_content`

Stores dynamic content for static pages like About Us, Privacy Policy, Terms of Use. This allows content updates without code deployments.

| Column Name  | Data Type         | Constraints            | Description                                   |
| :----------- | :---------------- | :--------------------- | :-------------------------------------------- |
| `id`         | `UUID` / `SERIAL` | `PRIMARY KEY`          | Unique identifier                           |
| `slug`       | `VARCHAR(255)`    | `NOT NULL`, `UNIQUE`   | Unique slug for content (e.g., 'about-us', 'privacy-policy') |
| `title`      | `VARCHAR(255)`    | `NOT NULL`             | Page title                                    |
| `content`    | `TEXT`            | `NOT NULL`             | Full HTML or Markdown content of the page     |
| `created_at` | `TIMESTAMP`       | `DEFAULT NOW()`        | Timestamp of record creation                  |
| `updated_at` | `TIMESTAMP`       | `DEFAULT NOW()`        | Last update timestamp                         |

### 3.5 Table: `api_request_logs` (Addressing IP Address Handling Feedback)

This table is specifically for rate limiting and security auditing. It stores *anonymized* or *temporarily retained* IP addresses.

| Column Name    | Data Type         | Constraints         | Description                                   |
| :------------- | :---------------- | :------------------ | :-------------------------------------------- |
| `id`           | `UUID` / `SERIAL` | `PRIMARY KEY`       | Unique identifier for the log entry           |
| `hashed_ip`    | `VARCHAR(64)`     | `NOT NULL`          | SHA256 hash of the client's IP address. Used for rate limiting. (Alternatively, raw IP could be stored temporarily for very short periods, e.g., 24 hours, and then purged, for real-time abuse detection, but hashing is preferred for GDPR compliance). |
| `endpoint`     | `VARCHAR(255)`    | `NOT NULL`          | The API endpoint accessed (e.g., `/api/contact`) |
| `request_time` | `TIMESTAMP`       | `DEFAULT NOW()`     | Timestamp of the API request                  |
| `status_code`  | `INTEGER`         | `NOT NULL`          | HTTP status code of the response              |

**GDPR/CCPA Compliance for IP Addresses:**
*   IP addresses are **not** directly stored in `contact_submissions` or `newsletter_subscribers` tables, ensuring data minimization for personal data.
*   For rate limiting and auditing, IP addresses are either:
    1.  **Hashed (SHA256)** immediately upon receipt and stored in `api_request_logs`. Hashed IPs cannot be reverse-engineered to identify individuals but are sufficient for detecting repeated requests from the same source for rate limiting.
    2.  **(Alternative, less preferred for strict GDPR):** Stored raw in `api_request_logs` for a very short, defined retention period (e.g., 24-48 hours) for real-time abuse detection, then automatically purged. This purpose and retention period must be clearly stated in the privacy policy.
*   The chosen method (preferably hashing) ensures that the collection of IP addresses is for a legitimate security purpose (rate limiting, abuse prevention) and minimizes the risk of re-identification, aligning with GDPR/CCPA principles.

## 4. API Endpoints

The Backend API will expose the following RESTful endpoints. All responses will be in JSON format. Input validation and error handling will be implemented for all endpoints. Rate limiting will be applied to POST endpoints to prevent abuse.

### 4.1 Products Endpoints

*   **GET `/api/products`**
    *   **Description:** Retrieves a paginated list of all active PharmaCorp products.
    *   **Query Parameters:**
        *   `page` (integer, default: 1): Page number.
        *   `limit` (integer, default: 10, max: 100): Number of products per page.
    *   **Response (200 OK):**
        ```json
        {
          "products": [
            {
              "id": "uuid-1",
              "name": "Product A",
              "slug": "product-a",
              "brief_description": "A short description of Product A."
            },
            // ... more products
          ],
          "total_products": 100,
          "total_pages": 10,
          "current_page": 1
        }
        ```
*   **GET `/api/products/{slug}`**
    *   **Description:** Retrieves detailed information for a specific product using its slug.
    *   **Path Parameters:**
        *   `slug` (string): The URL-friendly slug of the product.
    *   **Response (200 OK):**
        ```json
        {
          "id": "uuid-1",
          "name": "Product A",
          "slug": "product-a",
          "detailed_description": "Comprehensive details about Product A...",
          "indications": "Indications for Product A...",
          "safety_information": "Important Safety Information for Product A...",
          "pi_pdf_url": "https://object-storage.com/product-a-pi.pdf",
          "medguide_pdf_url": "https://object-storage.com/product-a-medguide.pdf"
        }
        ```
    *   **Response (404 Not Found):**
        ```json
        {
          "detail": "Product not found."
        }
        ```

### 4.2 Contact Us Endpoint

*   **POST `/api/contact`**
    *   **Description:** Submits a contact form message.
    *   **Request Body:**
        ```json
        {
          "name": "John Doe",
          "email": "john.doe@example.com",
          "subject": "General Inquiry",
          "message": "I have a question about your services."
        }
        ```
    *   **Response (200 OK):**
        ```json
        {
          "message": "Your message has been sent successfully!"
        }
        ```
    *   **Response (400 Bad Request):** (Due to validation errors)
        ```json
        {
          "detail": [
            {"loc": ["body", "email"], "msg": "Invalid email format."},
            {"loc": ["body", "message"], "msg": "Message cannot be empty."}
          ]
        }
        ```
    *   **Response (429 Too Many Requests):** (Due to rate limiting)
        ```json
        {
          "detail": "Rate limit exceeded. Please try again later."
        }
        ```

### 4.3 Newsletter Signup Endpoint

*   **POST `/api/newsletter`**
    *   **Description:** Subscribes an email to the newsletter.
    *   **Request Body:**
        ```json
        {
          "email": "subscriber@example.com"
        }
        ```
    *   **Response (200 OK):**
        ```json
        {
          "message": "You have successfully subscribed to our newsletter!"
        }
        ```
    *   **Response (400 Bad Request):** (Due to validation errors or email already subscribed)
        ```json
        {
          "detail": "Invalid email format."
        }
        ```
        OR
        ```json
        {
          "detail": "This email is already subscribed."
        }
        ```
    *   **Response (429 Too Many Requests):** (Due to rate limiting)
        ```json
        {
          "detail": "Rate limit exceeded. Please try again later."
        }
        ```

### 4.4 Site Content Endpoint

*   **GET `/api/content/{slug}`**
    *   **Description:** Retrieves content for generic pages like "About Us", "Privacy Policy", "Terms of Use".
    *   **Path Parameters:**
        *   `slug` (string): The slug of the content (e.g., `about-us`, `privacy-policy`, `terms-of-use`).
    *   **Response (200 OK):**
        ```json
        {
          "slug": "about-us",
          "title": "About PharmaCorp",
          "content": "<p>PharmaCorp's mission is...</p>" // HTML content
        }
        ```
    *   **Response (404 Not Found):**
        ```json
        {
          "detail": "Content not found."
        }
        ```

### 4.5 Search Endpoint

*   **GET `/api/search`**
    *   **Description:** Searches across website content and products.
    *   **Query Parameters:**
        *   `query` (string, required): The search query.
    *   **Response (200 OK):**
        ```json
        {
          "results": [
            {
              "type": "product",
              "id": "uuid-product-1",
              "title": "Product X",
              "description": "Brief description of Product X matching the query...",
              "url": "/products/product-x"
            },
            {
              "type": "page",
              "id": "uuid-content-1",
              "title": "About Us",
              "description": "Information about PharmaCorp's mission...",
              "url": "/about-us"
            }
          ],
          "total_results": 2
        }
        ```
    *   **Response (200 OK - No Results):**
        ```json
        {
          "results": [],
          "total_results": 0
        }
        ```

## 5. Data Flow Diagram

This diagram illustrates the flow of data for key user interactions, from the user's browser to the backend systems.

```mermaid
graph TD
    A[User Browser] -- 1. Request Homepage --> B(CDN/WAF);
    B -- 2. Serve Static Assets (HTML, CSS, JS) --> A;
    A -- 3. Request Product List/Detail (API Call) --> B;
    B -- 4. Forward API Request --> C[Backend API];
    C -- 5. Query Products/Content --> D[PostgreSQL DB];
    D -- 6. Return Data --> C;
    C -- 7. Return Product/Content Data --> B;
    B -- 8. Return Data to Browser --> A;

    A -- 9. Click Download PDF --> F[Object Storage];
    F -- 10. Serve PDF Directly --> A;

    A -- 11. Submit Contact/Newsletter Form --> B;
    B -- 12. Forward Form Data (with Rate Limiting) --> C;
    C -- 13. Validate & Store Data --> D;
    D -- 14. Confirm Storage --> C;
    C -- 15. Return Success/Error --> B;
    B -- 16. Return Success/Error to Browser --> A;

    C -- 17. Log Request (Hashed IP) --> E[PostgreSQL DB (api_request_logs)];
```

## 6. Security Considerations

*   **HTTPS Everywhere:** All communications between the user, CDN, frontend, and backend will be encrypted using HTTPS/TLS.
*   **Content Security Policy (CSP):** The frontend will implement a strict CSP to mitigate XSS attacks and control which resources the browser is allowed to load.
*   **Input Validation:** The Backend API will perform robust server-side input validation on all incoming data (e.g., contact forms, newsletter signups, search queries) to prevent injection attacks and ensure data integrity.
*   **Rate Limiting:** Key API endpoints (e.g., `/api/contact`, `/api/newsletter`, `/api/search`) will have rate limiting applied to prevent abuse, brute-force attacks, and denial-of-service attempts. This is supported by the `api_request_logs` table.
*   **GDPR/CCPA Compliance:**
    *   **Data Minimization:** Only necessary personal data is collected (e.g., email for newsletter, name/email/message for contact form).
    *   **Secure Storage:** Personal data in PostgreSQL will be encrypted at rest.
    *   **IP Address Handling:** As detailed in Section 3.5, IP addresses are either hashed or stored ephemerally for security/rate limiting purposes only, not linked to personal data.
    *   **Consent Management:** A prominent cookie consent banner will manage user preferences for non-essential cookies, adhering to "Accept All", "Decline All", and "Customize Preferences" options.
    *   **Privacy Policy & Terms of Use:** Comprehensive, legally compliant policies will be easily accessible.
*   **Access Control:** Backend infrastructure and database access will be restricted to authorized personnel and services using IAM roles and security groups.
*   **Regular Security Audits:** Periodic security audits, vulnerability scanning, and penetration testing will be conducted.

## 7. Deployment Strategy

The system will leverage a CI/CD pipeline for automated deployments across three environments:

*   **Development (Dev):** For developers to test features in isolation.
*   **Staging:** A pre-production environment mirroring Production, used for UAT, performance testing, and final QA.
*   **Production (Prod):** The live environment accessible to end-users.

Deployment will involve containerization (Docker) for both frontend and backend applications, allowing for consistent environments. Orchestration (e.g., Kubernetes, AWS ECS, Azure App Service) will manage scaling, load balancing, and high availability. Static frontend assets will be deployed to a CDN-backed static hosting service.