# CTMS Subject Enrollment to CDW Sync Service - Comprehensive Testing Document

## 1. Test Strategy

### 1.1. Introduction

This document outlines the test strategy for the "CTMS Subject Enrollment to CDW Sync Service," a MuleSoft-based integration designed to synchronize subject enrollment data from the CTMS to the CDW in near real-time. The strategy encompasses various testing types to ensure the service meets all functional, security, performance, and reliability requirements as specified in the User Stories and High-Level Design (HLD).

### 1.2. Scope

**In-Scope:**
*   Verification of the MuleSoft application's HTTP webhook endpoint (`/subject-enrollment`).
*   Validation of API key authentication for incoming requests.
*   Accuracy of data mapping and transformation from CTMS payload to CDW schema.
*   Successful insertion of new subject records into the CDW's `Subjects` table.
*   Robustness of error handling mechanisms, including specific database failure handling and global error handling.
*   Correctness of logging to Anypoint Monitoring.
*   Timeliness and content of email notifications for critical failures.
*   Effectiveness of PHI masking in logs.
*   Adherence to HTTP status codes for various scenarios (success, authentication failure, bad request, internal server error).

**Out-of-Scope:**
*   Internal functionality or business logic of the CTMS.
*   Internal functionality or business logic of the CDW (beyond verifying record insertion).
*   Performance testing under extreme load (basic performance checks will be part of functional tests).
*   Non-functional requirements not explicitly mentioned in the SRS or HLD (e.g., detailed security penetration testing, accessibility testing).
*   User Interface (UI) testing (as this is an API service).

### 1.3. Objectives

The primary objectives of testing are to:
*   **Validate Functional Correctness:** Ensure the synchronization service accurately receives, processes, transforms, and stores CTMS subject enrollment data in the CDW according to all acceptance criteria.
*   **Ensure Data Integrity:** Verify that data is correctly mapped, transformed, and inserted into the CDW without loss or corruption.
*   **Verify Security:** Confirm that only authorized CTMS systems can access the webhook endpoint using the API key mechanism and that PHI is properly masked in logs.
*   **Test Robustness and Error Handling:** Validate that the service gracefully handles expected and unexpected errors, logs appropriate information, and sends timely notifications to support teams.
*   **Confirm Observability:** Ensure all critical events, transactions, and errors are consistently logged to Anypoint Monitoring for auditing and debugging.
*   **Achieve Compliance:** Verify that PHI masking in logs adheres to privacy regulations.

### 1.4. Types of Testing

1.  **Unit Testing:**
    *   **Purpose:** To test individual components (e.g., DataWeave transformations, custom Java components if any, security logic) in isolation.
    *   **Methodology:** Developers will write unit tests using MUnit for Mule flows and components.
    *   **Focus:** Core logic, data transformations, small functional blocks.

2.  **Integration Testing:**
    *   **Purpose:** To verify the interactions and data flow between different components of the service and external systems.
    *   **Methodology:** Automated tests simulating CTMS requests, verifying CDW insertions, and email notifications. Mocking external systems (CDW, Email Service) may be used for isolated integration tests.
    *   **Focus:** CTMS webhook -> Mule App, Mule App -> CDW, Mule App -> Email Service, Mule App -> Anypoint Monitoring.

3.  **Functional Testing:**
    *   **Purpose:** To validate that the service meets all functional requirements and acceptance criteria specified in the user stories.
    *   **Methodology:** Manual and automated test cases covering positive and negative scenarios for each user story.
    *   **Focus:** All acceptance criteria, data mapping, error responses, logging, notifications.

4.  **Security Testing:**
    *   **Purpose:** To ensure the service is protected against unauthorized access and sensitive data is handled securely.
    *   **Methodology:** Test cases specifically designed to bypass or misuse the API key, and verification of PHI masking in logs.
    *   **Focus:** API key validation, PHI masking, secure properties usage.

5.  **Error Handling & Resilience Testing:**
    *   **Purpose:** To verify the service's ability to recover from errors, log failures, and notify stakeholders.
    *   **Methodology:** Simulate various failure conditions (e.g., invalid payload, missing API key, database unavailability/errors, network issues) and observe system behavior, logs, and notifications.
    *   **Focus:** Specific database failure handling, global error handling, email notifications, appropriate HTTP error codes.

6.  **Logging & Monitoring Testing:**
    *   **Purpose:** To ensure all required information is logged accurately and consistently to Anypoint Monitoring.
    *   **Methodology:** After executing various test scenarios, inspect Anypoint Monitoring logs for transaction IDs, success/failure messages, error details, and masked PHI.
    *   **Focus:** Transaction start/end, success/failure logs, error stack traces, masked PHI.

### 1.5. Test Environment

*   **Development Environment:** Local developer machines for unit testing.
*   **Integration Test Environment (ITE):** A dedicated CloudHub environment (similar to production) with mock/test instances of CTMS, CDW (PostgreSQL), and Email Service. This environment will be used for automated integration and functional tests.
*   **Staging Environment:** A pre-production environment for final validation, performance baselining, and user acceptance testing (UAT).

### 1.6. Roles & Responsibilities

*   **QA Automation Engineer:** Develops test strategy, creates test plans and cases, designs and implements automation scripts, executes tests, reports defects, and monitors test progress.
*   **Developers:** Write unit tests, assist QA in understanding functionality, fix defects.
*   **DevOps Engineer:** Sets up and maintains test environments, CI/CD pipelines.
*   **Project Manager:** Oversees project, ensures resources, approves test strategy.
*   **Clinical IT Support Team:** Participates in UAT, validates notification content.

### 1.7. Tools

*   **Test Management:** Jira (or similar tool) for test case management, defect tracking, and reporting.
*   **API Testing (Manual):** Postman, Insomnia.
*   **API Testing (Automation):** Python with `requests` library, `pytest` framework.
*   **MuleSoft Specific:** Anypoint Monitoring for log inspection, MUnit for unit testing.
*   **Database Client:** pgAdmin, DBeaver for CDW data verification.
*   **Email Client:** Access to test email inbox for notification verification.

### 1.8. Exit Criteria

*   All critical (P1) and high (P2) defects are resolved and retested.
*   All functional test cases (manual and automated) pass with a minimum 95% pass rate.
*   All security-related test cases pass.
*   PHI masking is verified in logs.
*   Performance baselines are met (if applicable).
*   Test coverage metrics (if tracked) meet defined targets.
*   UAT is successfully completed.
*   All stakeholders approve the release.

---

## 2. Test Plan & Manual Test Cases

This section details the manual test cases derived from the User Stories and HLD. Each test case includes a unique ID, description, preconditions, test steps, and expected results.

**Test Data (Example):**

*   **Valid API Key:** `CTMS_SECRET_API_KEY_123` (stored in secure properties)
*   **Clinical IT Support Email:** `it.support@example.com`
*   **CTMS Subject Enrollment Payload (Valid):**
    ```json
    {
      "subjectIdentifier": "SUB-TEST-001",
      "protocolId": "PROT-TEST-001",
      "siteId": "SITE-TEST-01",
      "enrollmentDate": "2024-01-15T10:00:00Z",
      "dateOfBirth": "1995-03-20",
      "sex": "Male",
      "additionalData": {}
    }
    ```
*   **CDW `Subjects` Table (Pre-existing for negative tests):**
    ```sql
    INSERT INTO Subjects (subject_id, protocol_identifier, clinical_site_id, date_of_enrollment, subject_dob, gender)
    VALUES ('SUB-DUPLICATE-001', 'PROT-DUP-001', 'SITE-DUP-01', '2023-01-01T08:00:00Z', '1990-01-01', 'Female');
    ```

---

### 2.1. User Story 1: CTMS Subject Enrollment Event Reception

| Test Case ID | Description                                                              | Preconditions                                                                                                                                                                                                |
| :----------- | :----------------------------------------------------------------------- | :----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| TC-US1-001   | Verify successful reception and acknowledgment of a valid enrollment event. | 1. MuleSoft service is deployed and running. <br/> 2. CTMS (or Postman) is configured to send requests to `/subject-enrollment`. <br/> 3. Anypoint Monitoring is accessible.                                   |

**Steps:**
1.  Construct a valid CTMS subject enrollment JSON payload (e.g., `SUB-TEST-001`).
2.  Send an HTTP POST request to `http://<service-base-url>/subject-enrollment` with `Content-Type: application/json` and `X-API-KEY: CTMS_SECRET_API_KEY_123`.
3.  Observe the HTTP response.
4.  Check Anypoint Monitoring logs for the transaction.

**Expected Results:**
*   **Step 3:** HTTP status code `202 Accepted` is returned. Response body contains:
    ```json
    {
      "message": "Subject enrollment data received for processing",
      "transactionId": "..."
    }
    ```
*   **Step 4:** A log entry indicating "Transaction Start" with a unique `transactionId` is present in Anypoint Monitoring.

---

### 2.2. User Story 2: Secure CTMS Webhook Endpoint

| Test Case ID | Description                                                              | Preconditions                                                                                                                                                                                                |
| :----------- | :----------------------------------------------------------------------- | :----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| TC-US2-001   | Verify successful authentication with a correct API key.                 | 1. MuleSoft service is deployed and running. <br/> 2. Secure properties are configured with `CTMS_SECRET_API_KEY_123`. <br/> 3. Anypoint Monitoring is accessible.                                            |
| TC-US2-002   | Verify rejection of requests with a missing API key.                     | 1. MuleSoft service is deployed and running. <br/> 2. Secure properties are configured with `CTMS_SECRET_API_KEY_123`. <br/> 3. Anypoint Monitoring is accessible.                                            |
| TC-US2-003   | Verify rejection of requests with an incorrect/invalid API key.          | 1. MuleSoft service is deployed and running. <br/> 2. Secure properties are configured with `CTMS_SECRET_API_KEY_123`. <br/> 3. Anypoint Monitoring is accessible.                                            |

**TC-US2-001 Steps (Positive):**
1.  Construct a valid CTMS subject enrollment JSON payload.
2.  Send an HTTP POST request to `http://<service-base-url>/subject-enrollment` with `Content-Type: application/json` and `X-API-KEY: CTMS_SECRET_API_KEY_123`.
3.  Observe the HTTP response.

**TC-US2-001 Expected Results:**
*   HTTP status code `202 Accepted` is returned. The request proceeds for further processing (as per TC-US1-001).

**TC-US2-002 Steps (Negative - Missing Key):**
1.  Construct a valid CTMS subject enrollment JSON payload.
2.  Send an HTTP POST request to `http://<service-base-url>/subject-enrollment` with `Content-Type: application/json` but **without** the `X-API-KEY` header.
3.  Observe the HTTP response.
4.  Check Anypoint Monitoring logs.

**TC-US2-002 Expected Results:**
*   HTTP status code `401 Unauthorized` is returned. Response body contains:
    ```json
    {
      "message": "Unauthorized: Invalid or missing API Key"
    }
    ```
*   A log entry indicating "Failed authentication attempt" and the originating IP address is present in Anypoint Monitoring.

**TC-US2-003 Steps (Negative - Incorrect Key):**
1.  Construct a valid CTMS subject enrollment JSON payload.
2.  Send an HTTP POST request to `http://<service-base-url>/subject-enrollment` with `Content-Type: application/json` and `X-API-KEY: INVALID_KEY_XYZ`.
3.  Observe the HTTP response.
4.  Check Anypoint Monitoring logs.

**TC-US2-003 Expected Results:**
*   HTTP status code `401 Unauthorized` is returned. Response body contains:
    ```json
    {
      "message": "Unauthorized: Invalid or missing API Key"
    }
    ```
*   A log entry indicating "Failed authentication attempt" and the originating IP address is present in Anypoint Monitoring.

---

### 2.3. User Story 3: CTMS Subject Data Mapping and Transformation

| Test Case ID | Description                                                              | Preconditions                                                                                                                                                                                                |
| :----------- | :----------------------------------------------------------------------- | :----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| TC-US3-001   | Verify accurate data mapping and transformation for a valid payload.     | 1. MuleSoft service is deployed and running. <br/> 2. Secure properties are configured. <br/> 3. CDW `Subjects` table is accessible and empty or does not contain `SUB-TEST-001`. <br/> 4. Anypoint Monitoring is accessible. |
| TC-US3-002   | Verify transformation with date format conversion.                       | Same as TC-US3-001.                                                                                                                                                                                          |
| TC-US3-003   | Verify error handling for invalid date format in payload.                | Same as TC-US3-001.                                                                                                                                                                                          |

**TC-US3-001 Steps (Positive - Mapping):**
1.  Construct a valid CTMS subject enrollment JSON payload (e.g., `SUB-TEST-001`).
2.  Send the request as in TC-US1-001.
3.  Observe the HTTP response.
4.  Query the CDW `Subjects` table for the newly inserted record (`subject_id = 'SUB-TEST-001'`).
5.  Check the values in the CDW record.

**TC-US3-001 Expected Results:**
*   **Step 3:** HTTP status code `202 Accepted` is returned.
*   **Step 4 & 5:** A new record exists in the CDW `Subjects` table with the following mappings:
    *   `subject_id`: `SUB-TEST-001`
    *   `protocol_identifier`: `PROT-TEST-001`
    *   `clinical_site_id`: `SITE-TEST-01`
    *   `date_of_enrollment`: `2024-01-15 10:00:00+00` (or equivalent timestamp with timezone)
    *   `subject_dob`: `1995-03-20`
    *   `gender`: `Male`

**TC-US3-002 Steps (Positive - Date Conversion):**
1.  Construct a valid CTMS subject enrollment JSON payload, ensuring `enrollmentDate` and `dateOfBirth` are in the specified string formats.
2.  Send the request as in TC-US1-001.
3.  Query the CDW `Subjects` table for the newly inserted record.
4.  Verify the data types and formats of `date_of_enrollment` and `subject_dob` in the CDW.

**TC-US3-002 Expected Results:**
*   `date_of_enrollment` is stored as `TIMESTAMP WITH TIME ZONE`.
*   `subject_dob` is stored as `DATE`.
*   The values correctly reflect the input string dates.

**TC-US3-003 Steps (Negative - Invalid Date Format):**
1.  Construct a CTMS subject enrollment JSON payload with an invalid `dateOfBirth` format (e.g., `"dateOfBirth": "20 March 1995"` or `"dateOfBirth": "1995/03/20"` if only `YYYY-MM-DD` is expected).
2.  Send the request as in TC-US1-001.
3.  Observe the HTTP response.
4.  Check Anypoint Monitoring logs.

**TC-US3-003 Expected Results:**
*   HTTP status code `500 Internal Server Error` is returned.
*   An error log (likely from DataWeave transformation failure) is present in Anypoint Monitoring, indicating a data format error for `dateOfBirth`.
*   An email notification is sent to `it.support@example.com` (as per global error handling).

---

### 2.4. User Story 4: CDW New Subject Record Creation

| Test Case ID | Description                                                              | Preconditions                                                                                                                                                                                                |
| :----------- | :----------------------------------------------------------------------- | :----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| TC-US4-001   | Verify successful new record insertion into CDW.                         | 1. MuleSoft service is deployed and running. <br/> 2. Secure properties are configured. <br/> 3. CDW `Subjects` table is accessible and does not contain `SUB-TEST-002`. <br/> 4. Anypoint Monitoring is accessible. |

**Steps:**
1.  Construct a valid CTMS subject enrollment JSON payload (e.g., `SUB-TEST-002`).
2.  Send the request as in TC-US1-001.
3.  Observe the HTTP response.
4.  Query the CDW `Subjects` table for the newly inserted record (`subject_id = 'SUB-TEST-002'`).
5.  Check Anypoint Monitoring logs.

**Expected Results:**
*   **Step 3:** HTTP status code `202 Accepted` is returned.
*   **Step 4:** A new record for `SUB-TEST-002` is successfully created in the CDW `Subjects` table with all mapped data.
*   **Step 5:** Log entries indicating "Successful database insertion" (including CDW `subject_id` and `transactionId`) and "Transaction End Success" are present in Anypoint Monitoring.

---

### 2.5. User Story 5: Database Insertion Failure Notification

| Test Case ID | Description                                                              | Preconditions                                                                                                                                                                                                |
| :----------- | :----------------------------------------------------------------------- | :----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| TC-US5-001   | Verify notification on database constraint violation (e.g., duplicate PK). | 1. MuleSoft service is deployed and running. <br/> 2. Secure properties are configured. <br/> 3. CDW `Subjects` table contains a record with `subject_id = 'SUB-DUPLICATE-001'`. <br/> 4. Anypoint Monitoring is accessible. <br/> 5. Email service is configured and accessible. |
| TC-US5-002   | Verify notification on simulated database connection error.              | 1. MuleSoft service is deployed and running. <br/> 2. Secure properties are configured. <br/> 3. **CDW database is temporarily made unavailable or connection details are intentionally incorrect.** <br/> 4. Anypoint Monitoring is accessible. <br/> 5. Email service is configured and accessible. |

**TC-US5-001 Steps (Negative - Duplicate Primary Key):**
1.  Construct a valid CTMS subject enrollment JSON payload with `subjectIdentifier: "SUB-DUPLICATE-001"`.
2.  Send the request as in TC-US1-001.
3.  Observe the HTTP response.
4.  Attempt to query the CDW `Subjects` table for `SUB-DUPLICATE-001` (expect no new record or an error).
5.  Check Anypoint Monitoring logs.
6.  Check the `it.support@example.com` inbox for an email notification.

**TC-US5-001 Expected Results:**
*   **Step 3:** HTTP status code `500 Internal Server Error` is returned.
*   **Step 4:** No new record is inserted; the existing `SUB-DUPLICATE-001` record remains unchanged or the insert fails due to unique constraint violation.
*   **Step 5:** Log entries indicating "Database Insertion Failure" with the full error stack trace (e.g., `PSQLException: ERROR: duplicate key value violates unique constraint "subjects_pkey"`) and the payload, and "Transaction End Failure" are present in Anypoint Monitoring.
*   **Step 6:** An email notification is received by `it.support@example.com` with details about the failed transaction, the `transactionId`, and the nature of the database error.

**TC-US5-002 Steps (Negative - Database Connection Error):**
1.  Ensure the CDW database is temporarily unavailable (e.g., stop the database service, or misconfigure connection string in MuleSoft).
2.  Construct a valid CTMS subject enrollment JSON payload (e.g., `SUB-TEST-003`).
3.  Send the request as in TC-US1-001.
4.  Observe the HTTP response.
5.  Check Anypoint Monitoring logs.
6.  Check the `it.support@example.com` inbox for an email notification.
7.  Restore CDW database availability/correct configuration.

**TC-US5-002 Expected Results:**
*   **Step 4:** HTTP status code `500 Internal Server Error` is returned.
*   **Step 5:** Log entries indicating "Database Insertion Failure" with the full error stack trace (e.g., connection refused, timeout) and the payload, and "Transaction End Failure" are present in Anypoint Monitoring.
*   **Step 6:** An email notification is received by `it.support@example.com` with details about the failed transaction, the `transactionId`, and the nature of the database connection error.

---

### 2.6. User Story 6 & 7: PHI Masking in Logs & Global Error Handling

| Test Case ID | Description                                                              | Preconditions                                                                                                                                                                                                |
| :----------- | :----------------------------------------------------------------------- | :----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| TC-US6-001   | Verify PHI masking for `Date of Birth` in logs during normal processing. | 1. MuleSoft service is deployed and running. <br/> 2. Secure properties are configured. <br/> 3. Anypoint Monitoring is accessible.                                                                           |
| TC-US7-001   | Verify global error handling for an unhandled transformation error.      | 1. MuleSoft service is deployed and running. <br/> 2. Secure properties are configured. <br/> 3. Anypoint Monitoring is accessible. <br/> 4. Email service is configured and accessible.                       |
| TC-US7-002   | Verify global error handling for a malformed JSON payload (early failure). | 1. MuleSoft service is deployed and running. <br/> 2. Secure properties are configured. <br/> 3. Anypoint Monitoring is accessible. <br/> 4. Email service is configured and accessible.                       |

**TC-US6-001 Steps (Positive - PHI Masking):**
1.  Construct a valid CTMS subject enrollment JSON payload including `dateOfBirth` (e.g., `SUB-TEST-004`, `dateOfBirth: "1980-01-01"`).
2.  Send the request as in TC-US1-001.
3.  Observe the HTTP response.
4.  Check Anypoint Monitoring logs for any entries that would log the incoming payload or intermediate data.

**TC-US6-001 Expected Results:**
*   **Step 3:** HTTP status code `202 Accepted` is returned.
*   **Step 4:** Any log entries that contain the `dateOfBirth` field (e.g., the received payload log, or a log of the transformed data before DB insertion if it's logged) must show `dateOfBirth` masked (e.g., `***MASKED***` or `null`). Other non-PHI fields should be logged as-is.

**TC-US7-001 Steps (Negative - Unhandled Transformation Error):**
1.  Construct a CTMS subject enrollment JSON payload where a required field for transformation is missing or has an unexpected type (e.g., `subjectIdentifier` is `null` or a number, if the DataWeave expects a string and doesn't have explicit null handling or type coercion).
2.  Send the request as in TC-US1-001.
3.  Observe the HTTP response.
4.  Check Anypoint Monitoring logs.
5.  Check the `it.support@example.com` inbox for an email notification.

**TC-US7-001 Expected Results:**
*   **Step 3:** HTTP status code `500 Internal Server Error` is returned.
*   **Step 4:** Log entries indicating "Global Error" or "Unhandled Error" with the full error stack trace (e.g., DataWeave transformation error) and the *masked* incoming payload, and "Transaction End Failure" are present in Anypoint Monitoring.
*   **Step 5:** An email notification is received by `it.support@example.com` with details about the global error, the `transactionId`, and the time of the error.

**TC-US7-002 Steps (Negative - Malformed JSON Payload):**
1.  Construct a malformed JSON payload (e.g., `{ "subjectIdentifier": "SUB-TEST-005", "protocolId": "PROT-TEST-005", ` - missing closing brace, or extra comma).
2.  Send an HTTP POST request to `http://<service-base-url>/subject-enrollment` with `Content-Type: application/json` and `X-API-KEY: CTMS_SECRET_API_KEY_123`.
3.  Observe the HTTP response.
4.  Check Anypoint Monitoring logs.
5.  Check the `it.support@example.com` inbox for an email notification.

**TC-US7-002 Expected Results:**
*   **Step 3:** HTTP status code `400 Bad Request` or `500 Internal Server Error` (depending on where the Mule runtime catches the parsing error) is returned.
*   **Step 4:** Log entries indicating "Global Error" or "Malformed JSON" with the full error stack trace and the (potentially partial/unparsable) payload, and "Transaction End Failure" are present in Anypoint Monitoring.
*   **Step 5:** An email notification is received by `it.support@example.com` with details about the parsing error, the `transactionId`, and the time of the error.

---

## 3. Test Automation Scripts

These automation scripts are written in Python using the `requests` library for API interaction and `pytest` for test execution.

### 3.1. Setup

**Prerequisites:**
*   Python 3.x installed.
*   `requests` and `pytest` libraries installed:
    ```bash
    pip install requests pytest
    ```
*   The MuleSoft service is deployed and running on CloudHub, accessible via a base URL.
*   A test CDW database is available and accessible for verification (optional for these scripts, but highly recommended for full integration testing).
*   A test email account is set up to receive notifications.

**Configuration File (`config.py`):**

```python
# config.py
SERVICE_BASE_URL = "http://your-mulesoft-app-name.cloudhub.io" # Replace with your actual CloudHub URL
VALID_API_KEY = "CTMS_SECRET_API_KEY_123" # Replace with your actual test API key
INVALID_API_KEY = "INVALID_KEY_XYZ"
IT_SUPPORT_EMAIL = "it.support@example.com" # Replace with your test IT support email
```

**Test File (`test_ctms_sync_service.py`):**

```python
# test_ctms_sync_service.py
import requests
import pytest
import datetime
from uuid import uuid4

# Import configuration
from config import SERVICE_BASE_URL, VALID_API_KEY, INVALID_API_KEY, IT_SUPPORT_EMAIL

# Define the endpoint
WEBHOOK_ENDPOINT = f"{SERVICE_BASE_URL}/subject-enrollment"

# Helper function to generate unique subject IDs for testing
def generate_unique_subject_id():
    return f"SUB-AUTO-{uuid4().hex[:8].upper()}"

# --- Test Cases ---

@pytest.fixture(scope="module")
def common_headers():
    return {
        "Content-Type": "application/json",
        "X-API-KEY": VALID_API_KEY
    }

@pytest.fixture(scope="module")
def invalid_headers():
    return {
        "Content-Type": "application/json",
        "X-API-KEY": INVALID_API_KEY
    }

@pytest.fixture(scope="module")
def missing_headers():
    return {
        "Content-Type": "application/json"
    }

def get_valid_payload(subject_id=None):
    if subject_id is None:
        subject_id = generate_unique_subject_id()
    return {
        "subjectIdentifier": subject_id,
        "protocolId": "PROT-AUTO-001",
        "siteId": "SITE-AUTO-01",
        "enrollmentDate": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'),
        "dateOfBirth": "1990-01-01",
        "sex": "Male",
        "additionalData": {}
    }

### 3.2. Script 1: Happy Path Enrollment (US1, US2-positive, US3, US4-positive)

def test_happy_path_subject_enrollment(common_headers):
    """
    Tests successful subject enrollment from CTMS to CDW.
    Covers: US1 (reception), US2 (auth), US3 (mapping), US4 (creation).
    """
    subject_id = generate_unique_subject_id()
    payload = get_valid_payload(subject_id)

    print(f"\nSending happy path request for subject: {subject_id}")
    response = requests.post(WEBHOOK_ENDPOINT, headers=common_headers, json=payload)

    assert response.status_code == 202, f"Expected 202 Accepted, got {response.status_code}: {response.text}"
    response_json = response.json()
    assert "message" in response_json
    assert "transactionId" in response_json
    print(f"Response: {response_json}")

    # --- Manual/Integration Verification Step (not automated here due to environment complexity) ---
    # In a full automation suite, you would now:
    # 1. Query Anypoint Monitoring to verify log entries (Transaction Start, DB Insert Success, Transaction End Success).
    # 2. Query the CDW database to verify the new subject record with `subject_id` is present and data is correctly mapped.
    #    Example (pseudo-code):
    #    db_record = query_cdw_for_subject(subject_id)
    #    assert db_record is not None
    #    assert db_record['protocol_identifier'] == payload['protocolId']
    #    assert str(db_record['subject_dob']) == payload['dateOfBirth']
    print(f"Verification: Check Anypoint Monitoring for logs and CDW for subject '{subject_id}'")

### 3.3. Script 2: Unauthorized Access (US2-negative)

def test_unauthorized_access_missing_api_key(missing_headers):
    """
    Tests rejection of requests with a missing API key. (US2 negative)
    """
    subject_id = generate_unique_subject_id()
    payload = get_valid_payload(subject_id)

    print(f"\nSending request with MISSING API key for subject: {subject_id}")
    response = requests.post(WEBHOOK_ENDPOINT, headers=missing_headers, json=payload)

    assert response.status_code == 401, f"Expected 401 Unauthorized, got {response.status_code}: {response.text}"
    response_json = response.json()
    assert response_json.get("message") == "Unauthorized: Invalid or missing API Key"
    print(f"Response: {response_json}")

    # Verification: Check Anypoint Monitoring for "Failed authentication attempt" log.
    print(f"Verification: Check Anypoint Monitoring for 'Failed authentication attempt' log.")

def test_unauthorized_access_invalid_api_key(invalid_headers):
    """
    Tests rejection of requests with an invalid API key. (US2 negative)
    """
    subject_id = generate_unique_subject_id()
    payload = get_valid_payload(subject_id)

    print(f"\nSending request with INVALID API key for subject: {subject_id}")
    response = requests.post(WEBHOOK_ENDPOINT, headers=invalid_headers, json=payload)

    assert response.status_code == 401, f"Expected 401 Unauthorized, got {response.status_code}: {response.text}"
    response_json = response.json()
    assert response_json.get("message") == "Unauthorized: Invalid or missing API Key"
    print(f"Response: {response_json}")

    # Verification: Check Anypoint Monitoring for "Failed authentication attempt" log.
    print(f"Verification: Check Anypoint Monitoring for 'Failed authentication attempt' log.")

### 3.4. Script 3: Invalid Payload (related to US3, US7)

def test_invalid_payload_malformed_json(common_headers):
    """
    Tests handling of a malformed JSON payload. (US7 global error handling)
    """
    malformed_json_string = '{ "subjectIdentifier": "SUB-MALFORMED-001", "protocolId": "PROT-MALFORMED-001", ' # Missing closing brace
    
    print(f"\nSending malformed JSON payload.")
    response = requests.post(WEBHOOK_ENDPOINT, headers=common_headers, data=malformed_json_string) # Use data= for raw string

    # Depending on Mule's JSON parsing, this might be 400 or 500. HLD suggests 400 for 'Invalid request payload'
    assert response.status_code in [400, 500], f"Expected 400 or 500, got {response.status_code}: {response.text}"
    print(f"Response: {response.text}")

    # Verification: Check Anypoint Monitoring for global error log and email notification.
    print(f"Verification: Check Anypoint Monitoring for global error log and email to {IT_SUPPORT_EMAIL}")

def test_invalid_payload_missing_required_field_for_transformation(common_headers):
    """
    Tests handling of a payload missing a field critical for transformation. (US3, US7)
    This should trigger a transformation error caught by global error handling.
    """
    subject_id = generate_unique_subject_id()
    payload = get_valid_payload(subject_id)
    del payload['protocolId'] # Remove a required field

    print(f"\nSending payload missing 'protocolId' for subject: {subject_id}")
    response = requests.post(WEBHOOK_ENDPOINT, headers=common_headers, json=payload)

    assert response.status_code == 500, f"Expected 500 Internal Server Error, got {response.status_code}: {response.text}"
    response_json = response.json()
    assert "message" in response_json
    assert "transactionId" in response_json
    print(f"Response: {response_json}")

    # Verification: Check Anypoint Monitoring for global error log (DataWeave error) and email notification.
    print(f"Verification: Check Anypoint Monitoring for global error log (DataWeave error) and email to {IT_SUPPORT_EMAIL}")

### 3.5. Script 4: Simulate Database Constraint Violation (US5, US7)

# This test requires a subject_id that already exists in the CDW.
# For automation, you'd typically insert this record as part of test setup (fixture)
# or use a known static ID. For this example, we'll assume 'SUB-DUPLICATE-001' already exists.
# Before running this, ensure 'SUB-DUPLICATE-001' exists in your test CDW's Subjects table.

def test_database_insertion_failure_duplicate_pk(common_headers):
    """
    Tests handling of a database insertion failure due to a duplicate primary key. (US5)
    Assumes 'SUB-DUPLICATE-001' already exists in the CDW.
    """
    duplicate_subject_id = "SUB-DUPLICATE-001" # Pre-existing in CDW for this test
    payload = get_valid_payload(duplicate_subject_id)

    print(f"\nSending request for DUPLICATE subject: {duplicate_subject_id}")
    response = requests.post(WEBHOOK_ENDPOINT, headers=common_headers, json=payload)

    assert response.status_code == 500, f"Expected 500 Internal Server Error, got {response.status_code}: {response.text}"
    response_json = response.json()
    assert "message" in response_json
    assert "transactionId" in response_json
    print(f"Response: {response_json}")

    # Verification: Check Anypoint Monitoring for "Database Insertion Failure" log and email notification.
    # Also, verify no new record was created/updated in the CDW for this subject_id.
    print(f"Verification: Check Anypoint Monitoring for 'Database Insertion Failure' log and email to {IT_SUPPORT_EMAIL}")
    print(f"Verification: Ensure no new record for '{duplicate_subject_id}' was created/updated in CDW.")

```

**How to Run Automation Tests:**
1.  Save `config.py` and `test_ctms_sync_service.py` in the same directory.
2.  Update `config.py` with your actual service URL and API key.
3.  Ensure your test CDW has the `SUB-DUPLICATE-001` record for the duplicate PK test.
4.  Open a terminal in that directory and run:
    ```bash
    pytest -v
    ```