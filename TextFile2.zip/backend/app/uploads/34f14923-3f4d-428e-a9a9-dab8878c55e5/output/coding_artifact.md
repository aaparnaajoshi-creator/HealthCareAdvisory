```xml
<!-- pom.xml -->
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.mulesoft.ctms</groupId>
    <artifactId>ctms-cdw-sync-api</artifactId>
    <version>1.0.0-SNAPSHOT</version>
    <packaging>mule-application</packaging>

    <name>ctms-cdw-sync-api</name>

    <properties>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <project.reporting.outputEncoding>UTF-8</project.reporting.outputEncoding>

        <app.runtime>4.4.0-20230220</app.runtime>
        <mule.maven.plugin.version>4.0.0</mule.maven.plugin.version>
        <munit.version>2.3.11</munit.version>
        <apikit.version>1.8.0</apikit.version>
    </properties>

    <build>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-clean-plugin</artifactId>
                <version>3.2.0</version>
            </plugin>
            <plugin>
                <groupId>org.mule.tools.maven</groupId>
                <artifactId>mule-maven-plugin</artifactId>
                <version>${mule.maven.plugin.version}</version>
                <extensions>true</extensions>
                <configuration>
                    <sharedLibraries>
                        <sharedLibrary>
                            <groupId>org.postgresql</groupId>
                            <artifactId>postgresql</artifactId>
                        </sharedLibrary>
                    </sharedLibraries>
                </configuration>
            </plugin>
            <plugin>
                <groupId>com.mulesoft.munit.tools</groupId>
                <artifactId>munit-maven-plugin</artifactId>
                <version>${munit.version}</version>
                <executions>
                    <execution>
                        <id>test</id>
                        <phase>test</phase>
                        <goals>
                            <goal>test</goal>
                        </goals>
                    </execution>
                </executions>
                <configuration>
                    <coverage>
                        <runCoverage>true</runCoverage>
                        <formats>
                            <format>html</format>
                        </formats>
                    </coverage>
                </configuration>
            </plugin>
        </plugins>
    </build>

    <dependencies>
        <dependency>
            <groupId>org.mule.connectors</groupId>
            <artifactId>mule-http-connector</artifactId>
            <version>1.7.1</version>
            <classifier>mule-plugin</classifier>
        </dependency>
        <dependency>
            <groupId>org.mule.connectors</groupId>
            <artifactId>mule-db-connector</artifactId>
            <version>1.16.1</version>
            <classifier>mule-plugin</classifier>
        </dependency>
        <dependency>
            <groupId>org.mule.connectors</groupId>
            <artifactId>mule-email-connector</artifactId>
            <version>1.2.6</version>
            <classifier>mule-plugin</classifier>
        </dependency>
        <dependency>
            <groupId>org.mule.modules</groupId>
            <artifactId>mule-module-apikit</artifactId>
            <version>${apikit.version}</version>
            <classifier>mule-plugin</classifier>
        </dependency>
        <dependency>
            <groupId>org.mule.modules</groupId>
            <artifactId>mule-module-secure-properties</artifactId>
            <version>1.2.6</version>
            <classifier>mule-plugin</classifier>
        </dependency>
        <dependency>
            <groupId>org.postgresql</groupId>
            <artifactId>postgresql</artifactId>
            <version>42.5.0</version>
        </dependency>
        <dependency>
            <groupId>com.mulesoft.munit</groupId>
            <artifactId>munit-runner</artifactId>
            <version>${munit.version}</version>
            <classifier>mule-plugin</classifier>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>com.mulesoft.munit</groupId>
            <artifactId>munit-tools</artifactId>
            <version>${munit.version}</version>
            <classifier>mule-plugin</classifier>
            <scope>test</scope>
        </dependency>
    </dependencies>

    <repositories>
        <repository>
            <id>anypoint-exchange-v3</id>
            <name>Anypoint Exchange V3</name>
            <url>https://maven.anypoint.mulesoft.com/api/v3/maven</url>
            <layout>default</layout>
        </repository>
        <repository>
            <id>mulesoft-releases</id>
            <name>MuleSoft Releases</name>
            <url>https://repository.mulesoft.org/releases/</url>
            <layout>default</layout>
        </repository>
    </repositories>

    <pluginRepositories>
        <pluginRepository>
            <id>mulesoft-releases</id>
            <name>MuleSoft Releases</name>
            <url>https://repository.mulesoft.org/releases/</url>
            <layout>default</layout>
        </pluginRepository>
    </pluginRepositories>
</project>
```

```json
<!-- mule-artifact.json -->
{
  "minMuleVersion": "4.4.0",
  "secureProperties": [
    "api.key",
    "db.host",
    "db.port",
    "db.user",
    "db.password",
    "db.name",
    "email.host",
    "email.port",
    "email.user",
    "email.password",
    "email.from.address",
    "email.it.support.address"
  ]
}
```

```xml
<!-- log4j2.xml -->
<?xml version="1.0" encoding="UTF-8"?>
<Configuration>
    <Appenders>
        <Console name="Console" target="SYSTEM_OUT">
            <PatternLayout pattern="%-5p %d [%t] [transactionId: %X{transactionId}] %c: %M - %m%n"/>
        </Console>
    </Appenders>
    <Loggers>
        <!-- Http Logger shows wire traffic on DEBUG. -->
        <AsyncLogger name="org.mule.service.http.impl.service.HttpMessageLogger" level="INFO"/>
        <AsyncLogger name="org.mule.extension.http" level="INFO"/>
        <AsyncLogger name="org.mule.connectors.http" level="INFO"/>

        <AsyncRoot level="INFO">
            <AppenderRef ref="Console"/>
        </AsyncRoot>
    </Loggers>
</Configuration>
```

```yaml
# src/main/resources/application-dev.yaml
# Secure properties are encrypted when deployed, but defined here for local dev.
# For production, these would be managed in Runtime Manager.

# Secure Properties (Example values - REPLACE WITH ACTUAL SECURE VALUES)
secure::api.key: "your-ctms-api-key-12345" # Example: CTMS_API_KEY_ENV_VAR
secure::db.host: "localhost"
secure::db.port: "5432"
secure::db.user: "postgres"
secure::db.password: "postgres"
secure::db.name: "cdw_db"

secure::email.host: "smtp.example.com"
secure::email.port: "587"
secure::email.user: "mule_alerts@example.com"
secure::email.password: "your_email_password" # Use app password if 2FA is on
secure::email.from.address: "mule_alerts@example.com"
secure::email.it.support.address: "it.support@example.com"

# HTTP Listener Configuration
http.port: "8081"
```

```raml
# src/main/resources/api/ctms-cdw-sync.raml
#%RAML 1.0
title: CTMS Subject Enrollment to CDW Sync API
version: 1.0
baseUri: /api

types:
  CTMSSubjectEnrollment: !include schemas/ctms-enrollment-request.json

/subject-enrollment:
  post:
    description: Receives subject enrollment data from the CTMS for synchronization to CDW.
    headers:
      X-API-KEY:
        type: string
        required: true
        description: Secure API key/token for authenticating the CTMS system.
        example: "your-ctms-api-key-12345"
    body:
      application/json:
        type: CTMSSubjectEnrollment
        examples:
          example1: !include examples/ctms-enrollment-example.json
    responses:
      202:
        description: Subject enrollment data received for processing.
        body:
          application/json:
            example:
              message: "Subject enrollment data received for processing"
              transactionId: "a1b2c3d4-e5f6-7890-1234-567890abcdef"
      400:
        description: Bad Request - Invalid request payload.
        body:
          application/json:
            example:
              message: "Invalid request payload"
              details: "JSON validation failed: instance type (string) does not match required type (integer) for field 'subjectIdentifier'"
      401:
        description: Unauthorized - Invalid or missing API Key.
        body:
          application/json:
            example:
              message: "Unauthorized: Invalid or missing API Key"
      500:
        description: Internal Server Error - An unexpected error occurred.
        body:
          application/json:
            example:
              message: "An internal error occurred during processing. Please contact support."
              transactionId: "a1b2c3d4-e5f6-7890-1234-567890abcdef"

```

```json
# src/main/resources/api/schemas/ctms-enrollment-request.json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "CTMS Subject Enrollment Request",
  "description": "Schema for incoming CTMS subject enrollment data.",
  "type": "object",
  "properties": {
    "subjectIdentifier": {
      "type": "string",
      "description": "Unique identifier for the subject in CTMS.",
      "pattern": "^SUB-[0-9]{6}$"
    },
    "protocolId": {
      "type": "string",
      "description": "Identifier for the clinical protocol.",
      "pattern": "^PROT-[A-Z]{3}-[0-9]{3}$"
    },
    "siteId": {
      "type": "string",
      "description": "Identifier for the clinical site.",
      "pattern": "^SITE-[A-Z]{3}-[0-9]{2}$"
    },
    "enrollmentDate": {
      "type": "string",
      "format": "date-time",
      "description": "Date and time of subject enrollment (ISO 8601 format)."
    },
    "dateOfBirth": {
      "type": "string",
      "format": "date",
      "description": "Subject's date of birth (YYYY-MM-DD format). PHI field."
    },
    "sex": {
      "type": "string",
      "enum": ["Male", "Female", "Other", "Unknown"],
      "description": "Biological sex of the subject."
    },
    "additionalData": {
      "type": "object",
      "description": "Any additional, non-critical data from CTMS.",
      "properties": {
        "race": { "type": "string" },
        "ethnicity": { "type": "string" },
        "studyArm": { "type": "string" }
      },
      "additionalProperties": true
    }
  },
  "required": [
    "subjectIdentifier",
    "protocolId",
    "siteId",
    "enrollmentDate",
    "dateOfBirth",
    "sex"
  ],
  "additionalProperties": true
}
```

```json
# src/main/resources/api/examples/ctms-enrollment-example.json
{
  "subjectIdentifier": "SUB-001234",
  "protocolId": "PROT-XYZ-001",
  "siteId": "SITE-ABC-05",
  "enrollmentDate": "2023-10-26T10:30:00Z",
  "dateOfBirth": "1990-05-15",
  "sex": "Female",
  "additionalData": {
    "race": "Asian",
    "ethnicity": "Non-Hispanic or Latino",
    "studyArm": "Control Group"
  }
}
```

```sql
-- sql/create_table.sql
-- This file is for reference to create the CDW Subjects table.
-- It is not part of the MuleSoft application's deployable artifacts.

CREATE TABLE IF NOT EXISTS Subjects (
    subject_id VARCHAR(255) PRIMARY KEY,
    protocol_identifier VARCHAR(255) NOT NULL,
    clinical_site_id VARCHAR(255) NOT NULL,
    date_of_enrollment TIMESTAMP WITH TIME ZONE NOT NULL,
    subject_dob DATE NOT NULL,
    gender VARCHAR(50) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Optional: Add a trigger to update 'updated_at' column automatically
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE OR REPLACE TRIGGER update_subjects_updated_at
BEFORE UPDATE ON Subjects
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

```

```xml
<!-- src/main/mule/config.xml -->
<?xml version="1.0" encoding="UTF-8"?>
<mule xmlns:db="http://www.mulesoft.org/schema/mule/db"
      xmlns:email="http://www.mulesoft.org/schema/mule/email"
      xmlns:secure-properties="http://www.mulesoft.org/schema/mule/secure-properties"
      xmlns:http="http://www.mulesoft.org/schema/mule/http"
      xmlns="http://www.mulesoft.org/schema/mule/core"
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
      xsi:schemaLocation="
        http://www.mulesoft.org/schema/mule/core http://www.mulesoft.org/schema/mule/core/current/mule.xsd
        http://www.mulesoft.org/schema/mule/http http://www.mulesoft.org/schema/mule/http/current/mule-http.xsd
        http://www.mulesoft.org/schema/mule/secure-properties http://www.mulesoft.org/schema/mule/secure-properties/current/mule-secure-properties.xsd
        http://www.mulesoft.org/schema/mule/email http://www.mulesoft.org/schema/mule/email/current/mule-email.xsd
        http://www.mulesoft.org/schema/mule/db http://www.mulesoft.org/schema/mule/db/current/mule-db.xsd">

    <!-- Secure Properties Configuration -->
    <secure-properties:config name="Secure_Properties_Config"
                              file="application-dev.yaml"
                              key="${secure.key}"
                              doc:name="Secure Properties Config"
                              doc:id="d9f4a1e2-3b6c-4f8d-9a0b-1c2d3e4f5a6b">
        <secure-properties:encrypt algorithm="Blowfish" mode="CBC" />
    </secure-properties:config>
    
    <!-- HTTP Listener Configuration -->
    <http:listener-config name="HTTP_Listener_config" doc:name="HTTP Listener config" doc:id="a5b2c1d3-e4f5-6789-0123-456789abcdef" >
        <http:listener-connection host="0.0.0.0" port="${http.port}" />
    </http:listener-config>

    <!-- Database Configuration (PostgreSQL) -->
    <db:config name="CDW_Database_Config" doc:name="Database Config" doc:id="f7e8d9c0-b1a2-3456-7890-1234567890ab">
        <db:postgresql-connection host="${secure::db.host}" port="${secure::db.port}" user="${secure::db.user}" password="${secure::db.password}" database="${secure::db.name}"/>
    </db:config>

    <!-- Email SMTP Configuration -->
    <email:smtp-config name="Email_SMTP_Config" doc:name="Email SMTP Config" doc:id="a1b2c3d4-e5f6-7890-1234-567890abcdef">
        <email:smtp-connection host="${secure::email.host}" port="${secure::email.port}" user="${secure::email.user}" password="${secure::email.password}" enableTLS="true">
            <reconnection-strategy >
                <reconnect-forever />
            </reconnection-strategy>
        </email:smtp-connection>
    </email:smtp-config>

</mule>
```

```xml
<!-- src/main/mule/global-error-handler.xml -->
<?xml version="1.0" encoding="UTF-8"?>
<mule xmlns:email="http://www.mulesoft.org/schema/mule/email"
      xmlns:apikit="http://www.mulesoft.org/schema/mule/apikit"
      xmlns:http="http://www.mulesoft.org/schema/mule/http"
      xmlns="http://www.mulesoft.org/schema/mule/core"
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
      xsi:schemaLocation="
        http://www.mulesoft.org/schema/mule/core http://www.mulesoft.org/schema/mule/core/current/mule.xsd
        http://www.mulesoft.org/schema/mule/http http://www.mulesoft.org/schema/mule/http/current/mule-http.xsd
        http://www.mulesoft.org/schema/mule/apikit http://www.mulesoft.org/schema/mule/apikit/current/mule-apikit.xsd
        http://www.mulesoft.org/schema/mule/email http://www.mulesoft.org/schema/mule/email/current/mule-email.xsd">

    <error-handler name="global-error-handler" doc:id="d7e8f9a0-b1c2-3d4e-5f6a-7b8c9d0e1f2a">
        <!-- Handler for APIKit Bad Request (Payload validation failures) -->
        <on-error-continue type="APIKIT:BAD_REQUEST">
            <set-payload value='#[output application/json --- { message: "Invalid request payload", details: error.description } ]' doc:name="Set 400 Payload" doc:id="a1b2c3d4-e5f6-7890-1234-567890abcdef" />
            <set-http-status method="SET_STATUS_CODE" value="400" doc:name="Set 400 Status" doc:id="f1e2d3c4-b5a6-7890-1234-567890abcdef" />
            <logger level="ERROR" doc:name="Log Bad Request Error" doc:id="c1d2e3f4-a5b6-7890-1234-567890abcdef"
                    message="Transaction ID #[vars.transactionId]: Bad Request - Payload validation failed. Error: #[error.description]"/>
            <logger level="INFO" doc:name="Log Transaction End Failure" doc:id="e1f2d3c4-a5b6-7890-1234-567890abcdef"
                    message="Transaction ID #[vars.transactionId] ended with failure (Bad Request)." />
        </on-error-continue>

        <!-- Handler for Unauthorized Access (API Key validation failures) -->
        <on-error-continue type="APP:UNAUTHORIZED_ACCESS">
            <set-payload value='#[output application/json --- { message: "Unauthorized: Invalid or missing API Key" } ]' doc:name="Set 401 Payload" doc:id="b1c2d3e4-f5a6-7890-1234-567890abcdef" />
            <set-http-status method="SET_STATUS_CODE" value="401" doc:name="Set 401 Status" doc:id="g1h2i3j4-k5l6-7890-1234-567890abcdef" />
            <logger level="WARN" doc:name="Log Unauthorized Error" doc:id="d1e2f3a4-b5c6-7890-1234-567890abcdef"
                    message="Transaction ID #[vars.transactionId]: Unauthorized access attempt from IP: #[attributes.remoteAddress default 'N/A']. Error: #[error.description]"/>
            <logger level="INFO" doc:name="Log Transaction End Failure" doc:id="f1g2h3i4-j5k6-7890-1234-567890abcdef"
                    message="Transaction ID #[vars.transactionId] ended with failure (Unauthorized)." />
        </on-error-continue>

        <!-- Handler for Database Insertion Failures -->
        <on-error-continue type="APP:DB_INSERT_FAILED">
            <set-payload value='#[output application/json --- { message: "An internal error occurred during CDW insertion. Please contact support.", transactionId: vars.transactionId } ]' doc:name="Set 500 Payload" doc:id="c5d6e7f8-a9b0-1c2d-3e4f-5a6b7c8d9e0f" />
            <set-http-status method="SET_STATUS_CODE" value="500" doc:name="Set 500 Status" doc:id="h1i2j3k4-l5m6-7890-1234-567890abcdef" />
            <logger level="ERROR" doc:name="Log DB Insert Failure" doc:id="e5f6g7h8-i9j0-1k2l-3m4n-5o6p7q8r9s0t"
                    message="Transaction ID #[vars.transactionId]: CDW insertion failed. Error: #[error.description]. IT support has been notified."/>
            <logger level="INFO" doc:name="Log Transaction End Failure" doc:id="i1j2k3l4-m5n6-7890-1234-567890abcdef"
                    message="Transaction ID #[vars.transactionId] ended with failure (DB Insertion)." />
        </on-error-continue>

        <!-- Catch-all Global Error Handler -->
        <on-error-continue type="ANY">
            <!-- Mask PHI from original payload for logging -->
            <try doc:name="Try Mask Original Payload" doc:id="0a1b2c3d-e4f5-6789-0123-456789abcdef">
                <set-variable variableName="maskedOriginalPayloadForErrorLog" doc:name="Mask Original Payload for Error Log" doc:id="1a2b3c4d-e5f6-7890-1234-567890abcdef" >
                    <ee:transform xmlns:ee="http://www.mulesoft.org/schema/mule/ee/core">
                        <ee:message>
                            <ee:set-variable variableName="maskedOriginalPayloadForErrorLog" ><![CDATA[%dw 2.0
output application/json
---
if (vars.originalPayload.dateOfBirth?)
    (vars.originalPayload - "dateOfBirth") ++ { dateOfBirth: "***MASKED***" }
else
    vars.originalPayload]]></ee:set-variable>
                        </ee:message>
                    </ee:transform>
                </set-variable>
                <error-handler>
                    <on-error-continue enableNotifications="true" logException="true" doc:name="On Error Continue" doc:id="d9f4a1e2-3b6c-4f8d-9a0b-1c2d3e4f5a6b">
                        <logger level="WARN" message="Failed to mask original payload for error logging." />
                        <set-variable variableName="maskedOriginalPayloadForErrorLog" value="Failed to mask original payload." />
                    </on-error-continue>
                </error-handler>
            </try>

            <logger level="ERROR" doc:name="Log Global Error" doc:id="j1k2l3m4-n5o6-7890-1234-567890abcdef"
                    message="Transaction ID #[vars.transactionId]: Global error caught. Error: #[error.description]. Details: #[error.detailedDescription]. Stack: #[error.errorMessage.stackTrace]. Payload (masked): #[vars.maskedOriginalPayloadForErrorLog default 'N/A']"/>
            <flow-ref name="send-error-email-flow" doc:name="Send Error Email" doc:id="k1l2m3n4-o5p6-7890-1234-567890abcdef">
                <arg key="errorType" value="Global Unhandled Error"/>
                <arg key="errorDescription" value="#[error.description]"/>
                <arg key="errorDetails" value="#[error.detailedDescription]"/>
                <arg key="errorStack" value="#[error.errorMessage.stackTrace]"/>
                <arg key="errorPayload" value="#[vars.maskedOriginalPayloadForErrorLog default 'N/A']"/>
            </flow-ref>
            <set-payload value='#[output application/json --- { message: "An internal error occurred during processing. Please contact support.", transactionId: vars.transactionId } ]' doc:name="Set 500 Payload" doc:id="l1m2n3o4-p5q6-7890-1234-567890abcdef" />
            <set-http-status method="SET_STATUS_CODE" value="500" doc:name="Set 500 Status" doc:id="m1n2o3p4-q5r6-7890-1234-567890abcdef" />
            <logger level="INFO" doc:name="Log Transaction End Failure" doc:id="p1q2r3s4-t5u6-7890-1234-567890abcdef"
                    message="Transaction ID #[vars.transactionId] ended with global failure." />
        </on-error-continue>
    </error-handler>

</mule>
```

```xml
<!-- src/main/mule/ctms-cdw-sync-api.xml -->
<?xml version="1.0" encoding="UTF-8"?>
<mule xmlns:db="http://www.mulesoft.org/schema/mule/db"
      xmlns:email="http://www.mulesoft.org/schema/mule/email"
      xmlns:apikit="http://www.mulesoft.org/schema/mule/apikit"
      xmlns:http="http://www.mulesoft.org/schema/mule/http"
      xmlns:secure-properties="http://www.mulesoft.org/schema/mule/secure-properties"
      xmlns:ee="http://www.mulesoft.org/schema/mule/ee/core"
      xmlns="http://www.mulesoft.org/schema/mule/core"
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
      xsi:schemaLocation="
        http://www.mulesoft.org/schema/mule/core http://www.mulesoft.org/schema/mule/core/current/mule.xsd
        http://www.mulesoft.org/schema/mule/http http://www.mulesoft.org/schema/mule/http/current/mule-http.xsd
        http://www.mulesoft.org/schema/mule/ee/core http://www.mulesoft.org/schema/mule/ee/core/current/mule-ee.xsd
        http://www.mulesoft.org/schema/mule/apikit http://www.mulesoft.org/schema/mule/apikit/current/mule-apikit.xsd
        http://www.mulesoft.org/schema/mule/email http://www.mulesoft.org/schema/mule/email/current/mule-email.xsd
        http://www.mulesoft.org/schema/mule/db http://www.mulesoft.org/schema/mule/db/current/mule-db.xsd
        http://www.mulesoft.org/schema/mule/secure-properties http://www.mulesoft.org/schema/mule/secure-properties/current/mule-secure-properties.xsd">

    <apikit:config name="ctms-cdw-sync-api-config" api="resource::api/ctms-cdw-sync.raml" outboundHeadersMapName="outboundHeaders" httpStatusVarName="httpStatus" doc:name="APIkit Router" doc:id="f1e2d3c4-b5a6-7890-1234-567890abcdef" />

    <flow name="ctms-cdw-sync-api-main-flow" doc:id="a1b2c3d4-e5f6-7890-1234-567890abcdef">
        <http:listener doc:name="Listener" doc:id="b1c2d3e4-f5a6-7890-1234-567890abcdef" config-ref="HTTP_Listener_config" path="/subject-enrollment" allowedMethods="POST"/>
        <set-variable variableName="transactionId" value="#[uuid()]" doc:name="Set Transaction ID" doc:id="c1d2e3f4-a5b6-7890-1234-567890abcdef"/>
        <set-variable variableName="originalPayload" value="#[payload]" doc:name="Store Original Payload" doc:id="d1e2f3g4-h5i6-7890-1234-567890abcdef"/>
        <logger level="INFO" doc:name="Log Transaction Start" doc:id="e1f2g3h4-i5j6-7890-1234-567890abcdef"
                message="Transaction started for ID: #[vars.transactionId]"/>

        <apikit:router config-ref="ctms-cdw-sync-api-config" doc:name="APIkit Router" doc:id="f1g2h3i4-j5k6-7890-1234-567890abcdef" />
        
        <flow-ref name="authenticate-api-key-flow" doc:name="Authenticate API Key" doc:id="g1h2i3j4-k5l6-7890-1234-567890abcdef"/>

        <flow-ref name="transform-ctms-to-cdw-flow" doc:name="Transform CTMS to CDW" doc:id="h1i2j3k4-l5m6-7890-1234-567890abcdef"/>

        <flow-ref name="insert-cdw-subject-flow" doc:name="Insert CDW Subject" doc:id="i1j2k3l4-m5n6-7890-1234-567890abcdef"/>

        <ee:transform doc:name="Set Success Response" doc:id="j1k2l3m4-n5o6-7890-1234-567890abcdef">
            <ee:message>
                <ee:set-payload><![CDATA[%dw 2.0
output application/json
---
{
  message: "Subject enrollment data received for processing",
  transactionId: vars.transactionId
}]]></ee:set-payload>
            </ee:message>
            <ee:variables>
                <ee:set-variable variableName="httpStatus"><![CDATA[202]]></ee:set-variable>
            </ee:variables>
        </ee:transform>
        <logger level="INFO" doc:name="Log Transaction End Success" doc:id="k1l2m3n4-o5p6-7890-1234-567890abcdef"
                message="Transaction ID #[vars.transactionId] ended successfully."/>
        <error-handler ref="global-error-handler"/>
    </flow>

    <flow name="authenticate-api-key-flow" doc:id="l1m2n3o4-p5q6-7890-1234-567890abcdef">
        <choice doc:name="API Key Validation Choice" doc:id="m1n2o3p4-q5r6-7890-1234-567890abcdef">
            <when expression="#[attributes.headers['x-api-key'] == p('secure::api.key')]">
                <logger level="INFO" doc:name="Log Auth Success" doc:id="n1o2p3q4-r5s6-7890-1234-567890abcdef"
                        message="Transaction ID #[vars.transactionId]: API Key authenticated successfully."/>
            </when>
            <otherwise>
                <logger level="WARN" doc:name="Log Auth Failure" doc:id="o1p2q3r4-s5t6-7890-1234-567890abcdef"
                        message="Transaction ID #[vars.transactionId]: Unauthorized access attempt from IP: #[attributes.remoteAddress default 'N/A']. Invalid or missing API Key."/>
                <raise-error type="APP:UNAUTHORIZED_ACCESS" doc:name="Raise Unauthorized Error" doc:id="p1q2r3s4-t5u6-7890-1234-567890abcdef"/>
            </otherwise>
        </choice>
    </flow>

    <flow name="transform-ctms-to-cdw-flow" doc:id="q1r2s3t4-u5v6-7890-1234-567890abcdef">
        <ee:transform doc:name="Map CTMS to CDW Schema" doc:id="r1s2t3u4-v5w6-7890-1234-567890abcdef">
            <ee:message>
                <ee:set-payload><![CDATA[%dw 2.0
output application/java
---
{
  subject_id: payload.subjectIdentifier,
  protocol_identifier: payload.protocolId,
  clinical_site_id: payload.siteId,
  date_of_enrollment: payload.enrollmentDate as DateTime,
  subject_dob: payload.dateOfBirth as Date,
  gender: payload.sex
}]]></ee:set-payload>
            </ee:message>
            <ee:variables>
                <ee:set-variable variableName="cdwPayload"><![CDATA[%dw 2.0
output application/java
---
{
  subject_id: payload.subjectIdentifier,
  protocol_identifier: payload.protocolId,
  clinical_site_id: payload.siteId,
  date_of_enrollment: payload.enrollmentDate as DateTime,
  subject_dob: payload.dateOfBirth as Date,
  gender: payload.sex
}]]></ee:set-variable>
                <ee:set-variable variableName="maskedOriginalPayloadForLog"><![CDATA[%dw 2.0
output application/json
---
(vars.originalPayload - "dateOfBirth") ++ {
  dateOfBirth: "***MASKED***"
}]]></ee:set-variable>
            </ee:variables>
        </ee:transform>
        <logger level="INFO" doc:name="Log Masked Payload" doc:id="s1t2u3v4-w5x6-7890-1234-567890abcdef"
                message="Transaction ID #[vars.transactionId]: Transformed payload (masked PHI): #[vars.maskedOriginalPayloadForLog]"/>
    </flow>

    <flow name="insert-cdw-subject-flow" doc:id="t1u2v3w4-x5y6-7890-1234-567890abcdef">
        <try doc:name="Try Database Insert" doc:id="u1v2w3x4-y5z6-7890-1234-567890abcdef">
            <db:insert doc:name="Insert Subject into CDW" doc:id="v1w2x3y4-z5a6-7890-1234-567890abcdef" config-ref="CDW_Database_Config">
                <db:sql><![CDATA[INSERT INTO Subjects (subject_id, protocol_identifier, clinical_site_id, date_of_enrollment, subject_dob, gender)
VALUES (:subject_id, :protocol_identifier, :clinical_site_id, :date_of_enrollment, :subject_dob, :gender)]]></db:sql>
                <db:input-parameters><![CDATA[#[vars.cdwPayload]]]></db:input-parameters>
            </db:insert>
            <logger level="INFO" doc:name="Log DB Insert Success" doc:id="w1x2y3z4-a5b6-7890-1234-567890abcdef"
                    message="Transaction ID #[vars.transactionId]: Subject #[vars.cdwPayload.subject_id] inserted successfully into CDW."/>
            <error-handler>
                <on-error-continue type="DB:ANY" doc:name="On Error Continue DB Failure" doc:id="x1y2z3a4-b5c6-7890-1234-567890abcdef">
                    <logger level="ERROR" doc:name="Log DB Insertion Failure" doc:id="y1z2a3b4-c5d6-7890-1234-567890abcdef"
                            message="Transaction ID #[vars.transactionId]: Database insertion failed. Error: #[error.description]. Payload: #[vars.cdwPayload]"/>
                    <flow-ref name="send-error-email-flow" doc:name="Send Error Email" doc:id="z1a2b3c4-d5e6-7890-1234-567890abcdef">
                        <arg key="errorType" value="CDW Database Insertion Failure"/>
                        <arg key="errorDescription" value="#[error.description]"/>
                        <arg key="errorDetails" value="#[error.detailedDescription]"/>
                        <arg key="errorStack" value="#[error.errorMessage.stackTrace]"/>
                        <arg key="errorPayload" value="#[vars.cdwPayload]"/>
                    </flow-ref>
                    <raise-error type="APP:DB_INSERT_FAILED" doc:name="Raise DB Insert Failed Error" doc:id="a1b2c3d4-e5f6-7890-1234-567890abcdef"/>
                </on-error-continue>
            </error-handler>
        </try>
    </flow>

    <flow name="send-error-email-flow" doc:id="b1c2d3e4-f5a6-7890-1234-567890abcdef">
        <email:send doc:name="Send Email Notification" doc:id="c1d2e3f4-a5b6-7890-1234-567890abcdef" config-ref="Email_SMTP_Config" fromAddress="${secure::email.from.address}" toAddresses="${secure::email.it.support.address}">
            <email:subject><![CDATA[CTMS-CDW Sync Service Error - Transaction ID: #[vars.transactionId] - Type: #[vars.errorType]]]></email:subject>
            <email:body contentType="text/html"><![CDATA[
                <html>
                    <body>
                        <h2>CTMS Subject Enrollment to CDW Sync Service - Error Notification</h2>
                        <p><strong>Transaction ID:</strong> #[vars.transactionId]</p>
                        <p><strong>Timestamp:</strong> #[now() as String { format: "yyyy-MM-dd HH:mm:ss z" }]</p>
                        <p><strong>Error Type:</strong> #[vars.errorType]</p>
                        <p><strong>Description:</strong> #[vars.errorDescription]</p>
                        <p><strong>Details:</strong> #[vars.errorDetails]</p>
                        <p><strong>Caused by Payload:</strong><pre>#[write(vars.errorPayload, "application/json")]</pre></p>
                        <p><strong>Stack Trace:</strong><pre>#[vars.errorStack]</pre></p>
                        <p>Please investigate this issue in Anypoint Monitoring.</p>
                    </body>
                </html>
            ]]></email:body>
        </email:send>
        <logger level="INFO" doc:name="Log Email Sent" doc:id="d1e2f3g4-h5i6-7890-1234-567890abcdef"
                message="Transaction ID #[vars.transactionId]: Error notification email sent to IT Support for error type: #[vars.errorType]"/>
    </flow>

</mule>
```

```xml
<!-- src/test/mule/ctms-cdw-sync-api-test.xml -->
<?xml version="1.0" encoding="UTF-8"?>
<mule xmlns:db="http://www.mulesoft.org/schema/mule/db"
      xmlns:email="http://www.mulesoft.org/schema/mule/email"
      xmlns:munit="http://www.mulesoft.org/schema/mule/munit"
      xmlns:munit-tools="http://www.mulesoft.org/schema/mule/munit-tools"
      xmlns:http="http://www.mulesoft.org/schema/mule/http"
      xmlns:apikit="http://www.mulesoft.org/schema/mule/apikit"
      xmlns:secure-properties="http://www.mulesoft.org/schema/mule/secure-properties"
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
      xmlns="http://www.mulesoft.org/schema/mule/core"
      xsi:schemaLocation="
        http://www.mulesoft.org/schema/mule/core http://www.mulesoft.org/schema/mule/core/current/mule.xsd
        http://www.mulesoft.org/schema/mule/munit http://www.mulesoft.org/schema/mule/munit/current/mule-munit.xsd
        http://www.mulesoft.org/schema/mule/munit-tools http://www.mulesoft.org/schema/mule/munit-tools/current/mule-munit-tools.xsd
        http://www.mulesoft.org/schema/mule/http http://www.mulesoft.org/schema/mule/http/current/mule-http.xsd
        http://www.mulesoft.org/schema/mule/apikit http://www.mulesoft.org/schema/mule/apikit/current/mule-apikit.xsd
        http://www.mulesoft.org/schema/mule/email http://www.mulesoft.org/schema/mule/email/current/mule-email.xsd
        http://www.mulesoft.org/schema/mule/db http://www.mulesoft.org/schema/mule/db/current/mule-db.xsd
        http://www.mulesoft.org/schema/mule/secure-properties http://www.mulesoft.org/schema/mule/secure-properties/current/mule-secure-properties.xsd">

    <munit:config name="ctms-cdw-sync-api-test.xml" doc:id="f9061596-f6d8-4f51-b847-a7c5b6a7d8e9" />
    <secure-properties:config name="Secure_Properties_Config_Test"
                              file="application-dev.yaml"
                              key="test_key"
                              doc:name="Secure Properties Config"
                              doc:id="d9f4a1e2-3b6c-4f8d-9a0b-1c2d3e4f5a6b">
        <secure-properties:encrypt algorithm="Blowfish" mode="CBC" />
    </secure-properties:config>

    <http:listener-config name="HTTP_Listener_config_Test" doc:name="HTTP Listener config" doc:id="a5b2c1d3-e4f5-6789-0123-456789abcdef" >
        <http:listener-connection host="0.0.0.0" port="8082" />
    </http:listener-config>

    <!-- Munit Test Suite for ctms-cdw-sync-api -->
    <munit:test-suite name="ctms-cdw-sync-api-test-suite" >
        <munit:before-suite>
            <logger level="INFO" message="Starting CTMS-CDW Sync API Test Suite" />
        </munit:before-suite>
        <munit:after-suite>
            <logger level="INFO" message="Finished CTMS-CDW Sync API Test Suite" />
        </munit:after-suite>

        <!-- Test Case 1: Successful Subject Enrollment -->
        <munit:test name="should-successfully-enroll-subject" doc:id="c2d3e4f5-a6b7-8c9d-0e1f-2a3b4c5d6e7f">
            <munit:behavior >
                <http:request-builder >
                    <http:uri-params ><![CDATA[#[{
                        "path": "/subject-enrollment"
                    }]]]></http:uri-params>
                    <http:headers ><![CDATA[#[{
                        "X-API-KEY": "your-ctms-api-key-12345"
                    }]]]></http:headers>
                </http:request-builder>
                <munit-tools:mock-http-listener-request path="/subject-enrollment">
                    <munit-tools:with-attributes >
                        <munit-tools:attribute whereValue="#['POST']" attributeName="method" />
                        <munit-tools:attribute whereValue="#['/subject-enrollment']" attributeName="path" />
                    </munit-tools:with-attributes>
                    <munit-tools:with-headers >
                        <munit-tools:header key="X-API-KEY" value="your-ctms-api-key-12345" />
                    </munit-tools:with-headers>
                    <munit-tools:with-content ><![CDATA[{
                        "subjectIdentifier": "SUB-TEST01",
                        "protocolId": "PROT-TST-001",
                        "siteId": "SITE-TST-01",
                        "enrollmentDate": "2024-01-01T10:00:00Z",
                        "dateOfBirth": "1995-01-01",
                        "sex": "Male",
                        "additionalData": {
                            "race": "Caucasian"
                        }
                    }]]></munit-tools:with-content>
                </munit-tools:mock-http-listener-request>
                <db:mock-when name="Mock DB Insert Success" doc:id="a1b2c3d4-e5f6-7890-1234-567890abcdef" connectorConfig="CDW_Database_Config" method="INSERT">
                    <db:then-return >
                        <db:affected-rows >1</db:affected-rows>
                    </db:then-return>
                </db:mock-when>
                <email:mock-when name="Mock Email Send Success" doc:id="b1c2d3e4-f5a6-7890-1234-567890abcdef" connectorConfig="Email_SMTP_Config" method="SEND"/>
            </munit:behavior>
            <munit:execution >
                <flow-ref name="ctms-cdw-sync-api-main-flow" doc:id="d2e3f4a5-b6c7-8d9e-0f1a-2b3c4d5e6f7a"/>
            </munit:execution>
            <munit:validation >
                <munit-tools:assert-that expression="#[attributes.statusCode]" is="#[munit-tools:equalTo(202)]" doc:name="Assert 202 Status" doc:id="e2f3a4b5-c6d7-8e9f-0a1b-2c3d4e5f6a7b"/>
                <munit-tools:assert-that expression="#[payload.message]" is="#[munit-tools:equalTo('Subject enrollment data received for processing')]" doc:name="Assert Success Message" doc:id="f2a3b4c5-d6e7-8f9a-0b1c-2d3e4f5a6b7c"/>
                <munit-tools:verify-call connectorConfig="CDW_Database_Config" method="INSERT" times="1" doc:name="Verify DB Insert" doc:id="g2h3i4j5-k6l7-8m9n-0o1p-2q3r4s5t6u7v"/>
                <munit-tools:verify-call connectorConfig="Email_SMTP_Config" method="SEND" times="0" doc:name="Verify No Email Sent" doc:id="h2i3j4k5-l6m7-8n9o-0p1q-2r3s4t5u6v7w"/>
            </munit:validation>
        </munit:test>

        <!-- Test Case 2: Unauthorized Access (Invalid API Key) -->
        <munit:test name="should-return-401-for-invalid-api-key" doc:id="i2j3k4l5-m6n7-8o9p-0q1r-2s3t4u5v6w7x">
            <munit:behavior >
                <http:request-builder >
                    <http:uri-params ><![CDATA[#[{
                        "path": "/subject-enrollment"
                    }]]]></http:uri-params>
                    <http:headers ><![CDATA[#[{
                        "X-API-KEY": "invalid-api-key"
                    }]]]></http:headers>
                </http:request-builder>
                <munit-tools:mock-http-listener-request path="/subject-enrollment">
                    <munit-tools:with-attributes >
                        <munit-tools:attribute whereValue="#['POST']" attributeName="method" />
                        <munit-tools:attribute whereValue="#['/subject-enrollment']" attributeName="path" />
                    </munit-tools:with-attributes>
                    <munit-tools:with-headers >
                        <munit-tools:header key="X-API-KEY" value="invalid-api-key" />
                    </munit-tools:with-headers>
                    <munit-tools:with-content ><![CDATA[{
                        "subjectIdentifier": "SUB-TEST02",
                        "protocolId": "PROT-TST-002",
                        "siteId": "SITE-TST-02",
                        "enrollmentDate": "2024-01-02T10:00:00Z",
                        "dateOfBirth": "1996-01-01",
                        "sex": "Female"
                    }]]></munit-tools:with-content>
                </munit-tools:mock-http-listener-request>
            </munit:behavior>
            <munit:execution >
                <flow-ref name="ctms-cdw-sync-api-main-flow" doc:id="j2k3l4m5-n6o7-8p9q-0r1s-2t3u4v5w6x7y"/>
            </munit:execution>
            <munit:validation >
                <munit-tools:assert-that expression="#[attributes.statusCode]" is="#[munit-tools:equalTo(401)]" doc:name="Assert 401 Status" doc:id="k2l3m4n5-o6p7-8q8r-0s1t-2u3v4w5x6y7z"/>
                <munit-tools:assert-that expression="#[payload.message]" is="#[munit-tools:equalTo('Unauthorized: Invalid or missing API Key')]" doc:name="Assert Error Message" doc:id="l2m3n4o5-p6q7-8r9s-0t1u-2v3w4x5y6z7a"/>
                <munit-tools:verify-call connectorConfig="CDW_Database_Config" method="INSERT" times="0" doc:name="Verify No DB Insert" doc:id="m2n3o4p5-q6r7-8s9t-0u1v-2w3x4y5z6a7b"/>
            </munit:validation>
        </munit:test>

        <!-- Test Case 3: Bad Request (Invalid Payload - APIKit Validation) -->
        <munit:test name="should-return-400-for-invalid-payload" doc:id="n2o3p4q5-r6s7-8t9u-0v1w-2x3y4z5a6b7c">
            <munit:behavior >
                <http:request-builder >
                    <http:uri-params ><![CDATA[#[{
                        "path": "/subject-enrollment"
                    }]]]></http:uri-params>
                    <http:headers ><![CDATA[#[{
                        "X-API-KEY": "your-ctms-api-key-12345"
                    }]]]></http:headers>
                </http:request-builder>
                <munit-tools:mock-http-listener-request path="/subject-enrollment">
                    <munit-tools:with-attributes >
                        <munit-tools:attribute whereValue="#['POST']" attributeName="method" />
                        <munit-tools:attribute whereValue="#['/subject-enrollment']" attributeName="path" />
                    </munit-tools:with-attributes>
                    <munit-tools:with-headers >
                        <munit-tools:header key="X-API-KEY" value="your-ctms-api-key-12345" />
                    </munit-tools:with-headers>
                    <munit-tools:with-content ><![CDATA[{
                        "subjectIdentifier": "INVALID-ID",
                        "protocolId": "PROT-TST-003",
                        "siteId": "SITE-TST-03",
                        "enrollmentDate": "2024-01-03T10:00:00Z",
                        "dateOfBirth": "1997-01-01",
                        "sex": "Male"
                    }]]></munit-tools:with-content>
                </munit-tools:mock-http-listener-request>
            </munit:behavior>
            <munit:execution >
                <flow-ref name="ctms-cdw-sync-api-main-flow" doc:id="o2p3q4r5-s6t7-8u9v-0w1x-2y3z4a5b6c7d"/>
            </munit:execution>
            <munit:validation >
                <munit-tools:assert-that expression="#[attributes.statusCode]" is="#[munit-tools:equalTo(400)]" doc:name="Assert 400 Status" doc:id="p2q3r4s5-t6u7-8v9w-0x1y-2z3a4b5c6d7e"/>
                <munit-tools:assert-that expression="#[payload.message]" is="#[munit-tools:equalTo('Invalid request payload')]" doc:name="Assert Error Message" doc:id="q2r3s4t5-u6v7-8w9x-0y1z-2a3b4c5d6e7f"/>
                <munit-tools:assert-that expression="#[payload.details]" is="#[munit-tools:notNullValue()]" doc:name="Assert Details Present" doc:id="r2s3t4u5-v6w7-8x9y-0z1a-2b3c4d5e6f7g"/>
                <munit-tools:verify-call connectorConfig="CDW_Database_Config" method="INSERT" times="0" doc:name="Verify No DB Insert" doc:id="s2t3u4v5-w6x7-8y9z-0a1b-2c3d4e5f6g7h"/>
            </munit:validation>
        </munit:test>

        <!-- Test Case 4: Database Insertion Failure -->
        <munit:test name="should-return-500-and-send-email-on-db-failure" doc:id="t2u3v4w5-x6y7-8z9a-0b1c-2d3e4f5g6h7i">
            <munit:behavior >
                <http:request-builder >
                    <http:uri-params ><![CDATA[#[{
                        "path": "/subject-enrollment"
                    }]]]></http:uri-params>
                    <http:headers ><![CDATA[#[{
                        "X-API-KEY": "your-ctms-api-key-12345"
                    }]]]></http:headers>
                </http:request-builder>
                <munit-tools:mock-http-listener-request path="/subject-enrollment">
                    <munit-tools:with-attributes >
                        <munit-tools:attribute whereValue="#['POST']" attributeName="method" />
                        <munit-tools:attribute whereValue="#['/subject-enrollment']" attributeName="path" />
                    </munit-tools:with-attributes>
                    <munit-tools:with-headers >
                        <munit-tools:header key="X-API-KEY" value="your-ctms-api-key-12345" />
                    </munit-tools:with-headers>
                    <munit-tools:with-content ><![CDATA[{
                        "subjectIdentifier": "SUB-TEST04",
                        "protocolId": "PROT-TST-004",
                        "siteId": "SITE-TST-04",
                        "enrollmentDate": "2024-01-04T10:00:00Z",
                        "dateOfBirth": "1998-01-01",
                        "sex": "Other"
                    }]]></munit-tools:with-content>
                </munit-tools:mock-http-listener-request>
                <db:mock-when name="Mock DB Insert Failure" doc:id="u2v3w4x5-y6z7-8a9b-0c1d-2e3f4g5h6i7j" connectorConfig="CDW_Database_Config" method="INSERT">
                    <db:then-return >
                        <munit-tools:error type="DB:CONNECTIVITY" description="Simulated DB connection error"/>
                    </db:then-return>
                </db:mock-when>
                <email:mock-when name="Mock Email Send for Error" doc:id="v2w3x4y5-z6a7-8b9c-0d1e-2f3g4h5i6j7k" connectorConfig="Email_SMTP_Config" method="SEND"/>
            </munit:behavior>
            <munit:execution >
                <flow-ref name="ctms-cdw-sync-api-main-flow" doc:id="w2x3y4z5-a6b7-8c9d-0e1f-2g3h4i5j6k7l"/>
            </munit:execution>
            <munit:validation >
                <munit-tools:assert-that expression="#[attributes.statusCode]" is="#[munit-tools:equalTo(500)]" doc:name="Assert 500 Status" doc:id="x2y3z4a5-b6c7-8d9e-0f1g-2h3i4j5k6l7m"/>
                <munit-tools:assert-that expression="#[payload.message]" is="#[munit-tools:equalTo('An internal error occurred during CDW insertion. Please contact support.')]" doc:name="Assert Error Message" doc:id="y2z3a4b5-c6d7-8e9f-0g1h-2i3j4k5l6m7n"/>
                <munit-tools:verify-call connectorConfig="CDW_Database_Config" method="INSERT" times="1" doc:name="Verify DB Insert Attempted" doc:id="z2a3b4c5-d6e7-8f9g-0h1i-2j4k5l6m7n8o"/>
                <munit-tools:verify-call connectorConfig="Email_SMTP_Config" method="SEND" times="1" doc:name="Verify Email Sent" doc:id="a3b4c5d6-e7f8-9g0h-1i2j-3k4l5m6n7o8p"/>
            </munit:validation>
        </munit:test>

        <!-- Test Case 5: Global Unhandled Error -->
        <munit:test name="should-return-500-and-send-email-on-global-unhandled-error" doc:id="b3c4d5e6-f7g8-9h0i-1j2k-3l4m5n6o7p8q">
            <munit:behavior >
                <http:request-builder >
                    <http:uri-params ><![CDATA[#[{
                        "path": "/subject-enrollment"
                    }]]]></http:uri-params>
                    <http:headers ><![CDATA[#[{
                        "X-API-KEY": "your-ctms-api-key-12345"
                    }]]]></http:headers>
                </http:request-builder>
                <munit-tools:mock-http-listener-request path="/subject-enrollment">
                    <munit-tools:with-attributes >
                        <munit-tools:attribute whereValue="#['POST']" attributeName="method" />
                        <munit-tools:attribute whereValue="#['/subject-enrollment']" attributeName="path" />
                    </munit-tools:with-attributes>
                    <munit-tools:with-headers >
                        <munit-tools:header key="X-API-KEY" value="your-ctms-api-key-12345" />
                    </munit-tools:with-headers>
                    <munit-tools:with-content ><![CDATA[{
                        "subjectIdentifier": "SUB-TEST05",
                        "protocolId": "PROT-TST-005",
                        "siteId": "SITE-TST-05",
                        "enrollmentDate": "2024-01-05T10:00:00Z",
                        "dateOfBirth": "1999-01-01",
                        "sex": "Male"
                    }]]></munit-tools:with-content>
                </munit-tools:mock-http-listener-request>
                <!-- Mock DB insert to throw a non-specific error for global handler -->
                <db:mock-when name="Mock DB Insert Global Failure" doc:id="c3d4e5f6-g7h8-9i0j-1k2l-3m4n5o6p7q8r" connectorConfig="CDW_Database_Config" method="INSERT">
                    <db:then-return >
                        <munit-tools:error type="ANY" description="Simulated unexpected error during DB operation" />
                    </db:then-return>
                </db:mock-when>
                <email:mock-when name="Mock Email Send for Global Error" doc:id="d3e4f5g6-h7i8-9j0k-1l2m-3n4o5p6q7r8s" connectorConfig="Email_SMTP_Config" method="SEND"/>
            </munit:behavior>
            <munit:execution >
                <flow-ref name="ctms-cdw-sync-api-main-flow" doc:id="e3f4g5h6-i7j8-9k0l-1m2n-3o4p5q6r7s8t"/>
            </munit:execution>
            <munit:validation >
                <munit-tools:assert-that expression="#[attributes.statusCode]" is="#[munit-tools:equalTo(500)]" doc:name="Assert 500 Status" doc:id="f3g4h5i6-j7k8-9l0m-1n2o-3p4q5r6s7t8u"/>
                <munit-tools:assert-that expression="#[payload.message]" is="#[munit-tools:equalTo('An internal error occurred during processing. Please contact support.')]" doc:name="Assert Error Message" doc:id="g3h4i5j6-k7l8-9m0n-1o2p-3q4r5s6t7u8v"/>
                <munit-tools:verify-call connectorConfig="CDW_Database_Config" method="INSERT" times="1" doc:name="Verify DB Insert Attempted" doc:id="h3i4j5k6-l7m8-9n0o-1p2q-3r4s5t6u7v8w"/>
                <munit-tools:verify-call connectorConfig="Email_SMTP_Config" method="SEND" times="1" doc:name="Verify Email Sent" doc:id="i3j4k5l6-m7n8-9o0p-1q2r-3s4t5u6v7w8x"/>
            </munit:validation>
        </munit:test>

    </munit:test-suite>
</mule>
```