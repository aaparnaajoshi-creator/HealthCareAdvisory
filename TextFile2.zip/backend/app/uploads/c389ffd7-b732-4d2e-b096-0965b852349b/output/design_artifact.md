# High-Level Design (HLD): PharmaCorp Commercial Website

## 1. Introduction

This document outlines the high-level design and system architecture for the PharmaCorp Commercial Website. The design is based on the provided user stories (SRS) and technical constraints, focusing on creating a secure, performant, and accessible public-facing website for patients and healthcare professionals (HCPs).

The system will serve informational content, details about commercial products, and provide basic user engagement features like a contact form and newsletter signup, all while adhering to strict compliance and accessibility standards.

## 2. Guiding Principles & Architectural Decisions

*   **Architecture Pattern:** A **Monolithic Architecture** is chosen for this project. The scope of the website is well-defined and cohesive, making a monolith simpler to develop, deploy, and maintain compared to a microservices architecture, which would be an over-engineering for this use case.
*   **Rendering Strategy:** A **Server-Side Rendering (SSR)** approach will be primary. The Python backend will render HTML pages using a templating engine. This is optimal for Search Engine Optimization (SEO), performance (fast First Contentful Paint), and directly aligns with the "HTML5 + JavaScript" constraint, avoiding complex client-side frameworks.
*   **Technology Stack Adherence:** The design strictly adheres to the specified technology stack:
    *   **Frontend:** Vanilla HTML5 and JavaScript for interactivity.
    *   **Backend:** Python with the FastAPI framework.
    *   **Database:** PostgreSQL.
    *   **File Storage:** Cloud-based Object Storage.
*   **Security First:** Security considerations, including data protection, secure endpoints, and compliance, are integrated into the design from the outset.
*   **Performance & Accessibility:** The design prioritizes fast load times (PCW-015) and adherence to WCAG 2.2 Level AA standards (PCW-014).

## 3. System Architecture Diagram

The architecture consists of a CDN, a reverse proxy, the core web application, a database, and an object store for file assets.

```mermaid
graph TD
    subgraph "Internet"
        U[User (Patient/HCP)]
    end

    subgraph "Cloud Infrastructure"
        CDN[Content Delivery Network (CDN)]
        subgraph "Virtual Private Cloud (VPC)"
            RP[Reverse Proxy (Nginx)]
            subgraph "Application"
                WebApp[Python FastAPI Application]
            end
            subgraph "Data Tier"
                DB[(PostgreSQL Database)]
                OS[Object Storage (S3/GCS)]
            end
        end
    end

    subgraph "CI/CD Pipeline"
        CICD[CI/CD Pipeline (e.g., GitHub Actions)]
        REPO[Code Repository (Git)]
    end

    U -- HTTPS --> CDN
    CDN -- Cached Content --> U
    CDN -- Origin Request --> RP
    RP -- Serves Static Assets (CSS/JS) --> CDN
    RP -- Proxies Requests --> WebApp
    WebApp -- Queries/Stores Data --> DB
    WebApp -- Generates Pre-signed URLs for --> OS
    WebApp -- Serves Rendered HTML --> RP
    CICD -- Deploys to --> RP & WebApp
    REPO -- Triggers --> CICD

    style U fill:#dff,stroke:#333,stroke-width:2px
    style CDN fill:#cde,stroke:#333,stroke-width:2px
    style WebApp fill:#f9f,stroke:#333,stroke-width:2px
    style DB fill:#fdb,stroke:#333,stroke-width:2px
    style OS fill:#fdb,stroke:#333,stroke-width:2px
```

## 4. Component Breakdown

| Component | Technology | Responsibilities | User Stories Addressed |
| :--- | :--- | :--- | :--- |
| **User Browser** | HTML5, CSS, Vanilla JavaScript | Render UI, handle client-side interactions (sticky ISI, form validation), manage cookie consent. | PCW-007, PCW-009, PCW-010, PCW-013, PCW-014, PCW-016 |
| **CDN** | e.g., Cloudflare, AWS CloudFront | Cache static assets (CSS, JS, images) and static pages to reduce latency and server load. Provide DDoS protection. | PCW-015 |
| **Reverse Proxy** | Nginx | Terminate HTTPS, serve static assets directly, implement rate limiting, load balance (if scaled), and proxy dynamic requests to the FastAPI application. | HL-TR (Security), PCW-009 |
| **Web Application** | Python (FastAPI) + Jinja2 Templates | Handle business logic, render HTML pages server-side, provide API endpoints, validate data, and interact with the database and object store. | PCW-001 to PCW-006, PCW-008 to PCW-012 |
| **Database** | PostgreSQL | Persist structured data: page content, product information, contact form submissions, and newsletter subscribers. Enable full-text search. | HL-TR (Database), PCW-009, PCW-010, PCW-011 |
| **Object Storage** | e.g., AWS S3, Azure Blob | Store and serve large binary files, specifically the Prescribing Information (PI) PDFs. | HL-TR (Storage), PCW-008 |
| **CI/CD Pipeline** | e.g., GitHub Actions, Jenkins | Automate testing, building, and deploying the application to Dev, Staging, and Production environments. | HL-TR (Deployment) |

## 5. Data Design

### 5.1. Database Schema

The PostgreSQL database will use the following schema to store website content and user-submitted data.

```mermaid
erDiagram
    products {
        INTEGER id PK "Primary Key"
        VARCHAR(255) name "Product Name"
        TEXT description "Brief description for listing page"
        TEXT full_content "Detailed content for detail page"
        TEXT isi_text "Important Safety Information"
        VARCHAR(255) image_url "URL for product image"
        VARCHAR(255) image_alt_text "Alt-text for accessibility"
        VARCHAR(100) slug UK "URL-friendly unique identifier"
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }

    product_documents {
        INTEGER id PK
        INTEGER product_id FK "Foreign Key to products.id"
        VARCHAR(255) document_name "e.g., Prescribing Information"
        VARCHAR(255) object_key "File key/path in Object Storage"
        TIMESTAMP created_at
    }

    pages {
        INTEGER id PK
        VARCHAR(100) slug UK "e.g., 'about-us', 'privacy-policy'"
        VARCHAR(255) title "Page Title"
        TEXT content "HTML or Markdown content"
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }

    contact_submissions {
        INTEGER id PK
        VARCHAR(255) name
        VARCHAR(255) email
        TEXT message
        TIMESTAMP created_at
    }

    newsletter_subscribers {
        INTEGER id PK
        VARCHAR(255) email UK "Unique email address"
        TIMESTAMP created_at
    }

    products ||--o{ product_documents : "has"
```

### 5.2. Data Dictionary

*   **products**: Stores all information related to a specific product. The `slug` is used for creating SEO-friendly URLs (PCW-006). `image_alt_text` supports accessibility (PCW-001, PCW-014).
*   **product\_documents**: A linking table to associate products with their PDF documents in Object Storage (PCW-008).
*   **pages**: A simple CMS-like table to hold content for static pages like "About Us", "Privacy Policy", etc. (PCW-002, PCW-012).
*   **contact\_submissions**: Stores data submitted via the contact form (PCW-009).
*   **newsletter\_subscribers**: Stores emails of users who signed up for the newsletter (PCW-010).

## 6. API Specification

The FastAPI application will expose a minimal set of RESTful API endpoints for client-side JavaScript interactions. All other pages will be server-rendered.

---

### **POST** `/api/contact`

*   **Description:** Submits the contact form.
*   **User Story:** PCW-009
*   **Request Body:**
    ```json
    {
      "name": "Jane Doe",
      "email": "jane.doe@example.com",
      "message": "I have a question about..."
    }
    ```
*   **Success Response (201 Created):**
    ```json
    {
      "status": "success",
      "message": "Thank you for your message!"
    }
    ```
*   **Error Response (422 Unprocessable Entity):**
    ```json
    {
      "detail": [
        {
          "loc": ["body", "email"],
          "msg": "value is not a valid email address",
          "type": "value_error.email"
        }
      ]
    }
    ```
*   **Security:** Rate limiting will be applied to this endpoint. Server-side validation is mandatory.

---

### **POST** `/api/newsletter`

*   **Description:** Subscribes a user to the newsletter.
*   **User Story:** PCW-010
*   **Request Body:**
    ```json
    {
      "email": "visitor@example.com"
    }
    ```
*   **Success Response (201 Created):**
    ```json
    {
      "status": "success",
      "message": "You have been subscribed successfully."
    }
    ```
*   **Error Response (409 Conflict):** If the email already exists.
    ```json
    {
      "detail": "This email address is already subscribed."
    }
    ```

---

### **GET** `/api/search`

*   **Description:** Retrieves search results. This API is called by the server itself when rendering the search results page, not directly by client-side JS. The user submits a form, which triggers a server-side page load of `/search?q=...`.
*   **User Story:** PCW-011
*   **Query Parameters:** `q` (string, required) - The search term.
*   **Usage:** The FastAPI application will have a route `/search` that calls an internal function to query the database using PostgreSQL's full-text search on `products` and `pages` tables. It will then render an HTML page with the results. This avoids an unnecessary client-side JS implementation for a core feature.

## 7. Data Flow Diagram: Contact Form Submission (PCW-009)

This diagram illustrates the sequence of events when a user submits the contact form.

```mermaid
sequenceDiagram
    participant User
    participant Browser (Vanilla JS)
    participant ReverseProxy (Nginx)
    participant WebApp (FastAPI)
    participant DB (PostgreSQL)

    User->>Browser: Fills and submits contact form
    Browser->>Browser: Performs client-side validation
    alt Invalid Data
        Browser->>User: Shows inline error messages
    else Valid Data
        Browser->>ReverseProxy: POST /api/contact (JSON Payload)
        ReverseProxy->>WebApp: Forwards POST /api/contact
        WebApp->>WebApp: Performs server-side validation (Pydantic)
        alt Invalid Data
            WebApp-->>ReverseProxy: 422 Unprocessable Entity
            ReverseProxy-->>Browser: 422 Unprocessable Entity
            Browser->>User: Displays server error
        else Valid Data
            WebApp->>DB: INSERT into contact_submissions
            DB-->>WebApp: Success confirmation
            WebApp-->>ReverseProxy: 201 Created (Success JSON)
            ReverseProxy-->>Browser: 201 Created (Success JSON)
            Browser->>User: Displays "Thank you" message
        end
    end
```

## 8. Security, Compliance, and NFRs

*   **HTTPS (HL-TR):** SSL/TLS will be enforced across the entire site, terminated at the CDN or Reverse Proxy.
*   **Content Security Policy (CSP) (HL-TR):** A strict CSP header will be set by the FastAPI application (via middleware) or Nginx to prevent XSS attacks by restricting sources of content.
*   **Rate Limiting (PCW-009):** Nginx's `limit_req_zone` will be used to limit submission rates on API endpoints (`/api/contact`, `/api/newsletter`) to prevent abuse.
*   **Input Validation (PCW-009):** Handled at two levels: client-side with JavaScript for immediate user feedback and, most importantly, server-side within FastAPI using Pydantic models to ensure data integrity and prevent injection attacks.
*   **Accessibility (PCW-014):** All server-side templates will be built using semantic HTML5. Dynamic elements created with JavaScript will be managed to maintain focus order and ARIA attributes. Alt-text for images will be stored in the DB and rendered in `<img>` tags.
*   **Performance (PCW-015):** Achieved through:
    *   **SSR:** Fast initial page loads.
    *   **CDN:** Caching of assets close to the user.
    *   **Asset Optimization:** Minification of CSS/JS and image compression will be part of the CI/CD pipeline.
*   **Responsive Design (PCW-016):** Implemented using standard CSS media queries. No backend logic is required.
*   **Cookie Consent (PCW-013):** A vanilla JavaScript component will manage the banner. User preference will be stored in the browser's `localStorage`. No server-side logic is needed beyond serving the initial JS file.

## 9. Deployment Strategy

A standard multi-environment CI/CD pipeline will be established.

*   **Environments:** `Development`, `Staging`, and `Production`. Each environment will have its own instance of the application, database, and object storage.
*   **CI/CD Pipeline:**
    1.  **Commit:** Developers push code to a Git repository.
    2.  **Build & Test:** A pull request triggers automated steps in the CI/CD tool (e.g., GitHub Actions) to lint the code, run unit/integration tests.
    3.  **Deploy to Staging:** On merging to the main branch, the application is automatically built into a container and deployed to the Staging environment for QA and UAT.
    4.  **Deploy to Production:** A manual approval step triggers the deployment of the validated build from Staging to the Production environment. This ensures stability.