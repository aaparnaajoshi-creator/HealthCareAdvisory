```markdown
# /pharmacorp_website/README.md
PharmaCorp Commercial Website
=============================

This is the complete codebase for the PharmaCorp Commercial Website, built according to the provided user stories and high-level design document.

## Tech Stack

*   **Backend:** Python 3.10+ with FastAPI
*   **Database:** PostgreSQL
*   **Frontend:** HTML5, CSS3, Vanilla JavaScript (ES6)
*   **Templating:** Jinja2
*   **Containerization:** Docker & Docker Compose
*   **Reverse Proxy:** Nginx

## Features Implemented

This application covers all user stories from PCW-001 to PCW-016, including:

*   **Core Pages:** Homepage, About Us, Contact Us, Privacy Policy, Terms of Use.
*   **Product Hub:** Product Listing and Detail pages with sticky Important Safety Information (ISI).
*   **User Engagement:** AJAX-powered Contact Form and Newsletter Signup.
*   **Search:** Full-text search functionality across products and pages.
*   **Compliance:** Cookie consent banner and accessible design (WCAG 2.2 AA principles).
*   **NFRs:** Responsive design, performance considerations, and security headers.

## How to Run the Application

### Prerequisites

*   Docker
*   Docker Compose

### Steps

1.  **Clone the repository.**

2.  **Create an environment file:**
    Copy the example environment file to a new `.env` file.
    ```bash
    cp .env.example .env
    ```
    You can modify the values in `.env` if needed, but the defaults are configured to work with Docker Compose.

3.  **Build and run the services using Docker Compose:**
    From the root of the project (`/pharmacorp_website`), run:
    ```bash
    docker-compose up --build
    ```
    This command will:
    *   Build the Docker image for the FastAPI application.
    *   Start containers for the application, the PostgreSQL database, and the Nginx reverse proxy.
    *   The application will be accessible at `http://localhost:8080`.

4.  **Seed the database (First Run Only):**
    The application will automatically seed the database with initial data on startup if the tables are empty. This includes creating pages, products, and other necessary content to make the website fully functional. You can monitor the Docker logs to see this process.

5.  **Access the Website:**
    Open your web browser and navigate to `http://localhost:8080`.

### Running Tests

To run the unit and integration tests, execute the following command in the project's root directory:

```bash
docker-compose exec web pytest
```

## Project Structure

```
/pharmacorp_website/
├── app/                  # Main application source code
│   ├── api/              # API endpoints and schemas
│   ├── core/             # Configuration and security
│   ├── crud/             # Database create, read, update, delete logic
│   ├── db/               # Database models, session, and seeding
│   ├── pages/            # Server-side rendered page routes
│   ├── static/           # CSS, JavaScript, images
│   ├── templates/        # Jinja2 HTML templates
│   └── main.py           # FastAPI application entrypoint
├── tests/                # Pytest tests
├── .env                  # Local environment variables (you create this)
├── .env.example          # Example environment variables
├── .gitignore
├── docker-compose.yml    # Docker Compose configuration
├── Dockerfile            # Dockerfile for the Python application
├── nginx.conf            # Nginx configuration
├── README.md             # This file
└── requirements.txt      # Python dependencies
```

## Notes on HLD Implementation

*   **Rate Limiting (PCW-009):** Implemented in `nginx.conf` using `limit_req_zone` and `limit_req`, as specified in the HLD.
*   **Object Storage (PCW-008):** For this runnable example, the Prescribing Information PDF is served from the `/static` directory. In a real-world scenario, the `product.pi_url` would be a pre-signed URL generated on-demand from a cloud object store like AWS S3.
*   **Search (PCW-011):** Implemented using PostgreSQL's native Full-Text Search capabilities. Database triggers automatically update the search vectors when content changes.
```
```markdown
# /pharmacorp_website/.env.example
# PostgreSQL settings
POSTGRES_USER=pharmacorp
POSTGRES_PASSWORD=supersecretpassword
POSTGRES_DB=pharmacorp_db
POSTGRES_SERVER=db
DATABASE_URL=postgresql://${POSTGRES_USER}:${POSTGRES_PASSWORD}@${POSTGRES_SERVER}:5432/${POSTGRES_DB}

# Application settings
APP_NAME="PharmaCorp Commercial Website"
```
```markdown
# /pharmacorp_website/.gitignore
# Byte-compiled / optimized / DLL files
__pycache__/
*.py[cod]
*$py.class

# C extensions
*.so

# Distribution / packaging
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
pip-wheel-metadata/
share/python-wheels/
*.egg-info/
.installed.cfg
*.egg
MANIFEST

# PyInstaller
#  Usually these files are written by a python script from a template
#  before PyInstaller builds the exe, so as to inject date/version info into it.
*.manifest
*.spec

# Installer logs
pip-log.txt
pip-delete-this-directory.txt

# Unit test / coverage reports
htmlcov/
.tox/
.nox/
.coverage
.coverage.*
.cache
nosetests.xml
coverage.xml
*.cover
*.py,cover
.hypothesis/
.pytest_cache/

# Translations
*.mo
*.pot

# Django stuff:
*.log
local_settings.py
db.sqlite3
db.sqlite3-journal

# Flask stuff:
instance/
.webassets-cache

# Scrapy stuff:
.scrapy

# Sphinx documentation
docs/_build/

# PyBuilder
target/

# Jupyter Notebook
.ipynb_checkpoints

# IPython
profile_default/
ipython_config.py

# pyenv
.python-version

# celery beat
celerybeat-schedule

# SageMath parsed files
*.sage.py

# Environments
.env
.venv
env/
venv/
ENV/
env.bak/
venv.bak/

# Spyder project settings
.spyderproject
.spyproject

# Rope project settings
.ropeproject

# mkdocs documentation
/site

# mypy
.mypy_cache/
.dmypy.json
dmypy.json

# Pyre type checker
.pyre/

# Docker
docker-compose.override.yml
```
```markdown
# /pharmacorp_website/Dockerfile
# Use an official Python runtime as a parent image
FROM python:3.10-slim

# Set the working directory in the container
WORKDIR /usr/src/app

# Set environment variables
ENV PYTHONDONTWRITEBYTECODE 1
ENV PYTHONUNBUFFERED 1

# Install dependencies
COPY requirements.txt ./
RUN pip install --no-cache-dir -r requirements.txt

# Copy the rest of the application code
COPY ./app /usr/src/app/app

# Expose the port the app runs on
EXPOSE 8000

# Command to run the application
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
```
```markdown
# /pharmacorp_website/docker-compose.yml
version: '3.8'

services:
  web:
    build: .
    command: uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
    volumes:
      - ./app:/usr/src/app/app
    ports:
      - "8000:8000"
    env_file:
      - .env
    depends_on:
      - db

  db:
    image: postgres:14
    volumes:
      - postgres_data:/var/lib/postgresql/data/
    env_file:
      - .env
    ports:
      - "5432:5432"

  nginx:
    image: nginx:1.21
    ports:
      - "8080:80"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./app/static:/usr/src/app/static
    depends_on:
      - web

volumes:
  postgres_data:
```
```markdown
# /pharmacorp_website/nginx.conf
events {}

http {
    # Rate limiting zone for API endpoints
    # Allows 10 requests per second from a single IP, with a burst of 20
    limit_req_zone $binary_remote_addr zone=api_limit:10m rate=10r/s;

    server {
        listen 80;
        server_name localhost;

        # Serve static files directly
        location /static/ {
            alias /usr/src/app/static/;
            expires 1d; # Cache static files for 1 day
        }

        # Location for rate-limited API endpoints
        location /api/ {
            limit_req zone=api_limit burst=20 nodelay;

            proxy_pass http://web:8000;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }

        # Proxy all other requests to the FastAPI application
        location / {
            proxy_pass http://web:8000;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }
    }
}
```
```markdown
# /pharmacorp_website/requirements.txt
fastapi==0.104.1
uvicorn[standard]==0.24.0.post1
sqlalchemy==2.0.23
psycopg2-binary==2.9.9
jinja2==3.1.2
pydantic-settings==2.1.0
alembic==1.12.1
python-dotenv==1.0.0
greenlet==3.0.1

# For testing
pytest==7.4.3
httpx==0.25.1
```
```markdown
# /pharmacorp_website/app/__init__.py
# This file can be empty. It marks the 'app' directory as a Python package.
```
```markdown
# /pharmacorp_website/app/main.py
from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

from app.api import endpoints as api_router
from app.pages import routes as pages_router
from app.db.session import SessionLocal
from app.db import seed

app = FastAPI(title="PharmaCorp Commercial Website")

# In a real app, you might use a more robust rate limiting solution
# or rely solely on Nginx as per the HLD. This is here for a pure Python alternative.
limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# Mount static files
app.mount("/static", StaticFiles(directory="app/static"), name="static")

# Include routers
app.include_router(pages_router.router)
app.include_router(api_router.router, prefix="/api")


@app.on_event("startup")
def on_startup():
    db = SessionLocal()
    seed.init_db(db)
    db.close()

@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    response = await call_next(request)
    # Basic Content Security Policy (CSP)
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; "
        "style-src 'self' 'unsafe-inline'; " # 'unsafe-inline' for simple styles, could be improved
        "script-src 'self'; "
        "img-src 'self' data:;"
    )
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    return response

# Example of a 404 handler to render a custom page
@app.exception_handler(404)
async def not_found_exception_handler(request: Request, exc):
    # This assumes you have a templates directory configured
    templates = Jinja2Templates(directory="app/templates")
    return templates.TemplateResponse("errors/404.html", {"request": request}, status_code=404)
```
```markdown
# /pharmacorp_website/app/api/__init__.py
```
```markdown
# /pharmacorp_website/app/api/endpoints.py
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError

from app.db.session import get_db
from app.crud import crud_submission
from . import schemas

router = APIRouter()

@router.post("/contact", response_model=schemas.ContactResponse, status_code=status.HTTP_201_CREATED)
def submit_contact_form(
    submission: schemas.ContactSubmissionCreate,
    db: Session = Depends(get_db)
):
    """
    Submits the contact form.
    - Validates input using Pydantic schema.
    - Creates a new contact submission entry in the database.
    """
    crud_submission.create_contact_submission(db=db, submission=submission)
    return {"status": "success", "message": "Thank you for your message!"}

@router.post("/newsletter", response_model=schemas.NewsletterResponse, status_code=status.HTTP_201_CREATED)
def submit_newsletter_signup(
    subscriber: schemas.NewsletterSubscriberCreate,
    db: Session = Depends(get_db)
):
    """
    Subscribes a user to the newsletter.
    - Validates email format.
    - Checks for existing email and returns a 409 Conflict if found.
    - Creates a new newsletter subscriber entry.
    """
    try:
        crud_submission.create_newsletter_subscriber(db=db, subscriber=subscriber)
        return {"status": "success", "message": "You have been subscribed successfully."}
    except IntegrityError:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="This email address is already subscribed."
        )

```
```markdown
# /pharmacorp_website/app/api/schemas.py
from pydantic import BaseModel, EmailStr, Field

# Schemas for Contact Form (PCW-009)
class ContactSubmissionCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    email: EmailStr
    message: str = Field(..., min_length=10, max_length=2000)

class ContactResponse(BaseModel):
    status: str
    message: str

# Schemas for Newsletter Signup (PCW-010)
class NewsletterSubscriberCreate(BaseModel):
    email: EmailStr

class NewsletterResponse(BaseModel):
    status: str
    message: str
```
```markdown
# /pharmacorp_website/app/core/__init__.py
```
```markdown
# /pharmacorp_website/app/core/config.py
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    APP_NAME: str = "PharmaCorp Commercial Website"
    DATABASE_URL: str

    class Config:
        env_file = ".env"

settings = Settings()
```
```markdown
# /pharmacorp_website/app/crud/__init__.py
```
```markdown
# /pharmacorp_website/app/crud/crud_page.py
from sqlalchemy.orm import Session
from app.db import models

def get_page_by_slug(db: Session, slug: str):
    return db.query(models.Page).filter(models.Page.slug == slug).first()

def search_pages(db: Session, query: str):
    """Performs a full-text search on pages."""
    search_query = db.query(models.Page).filter(
        models.Page.search_vector.match(query, postgresql_regconfig='english')
    )
    return search_query.all()
```
```markdown
# /pharmacorp_website/app/crud/crud_product.py
from sqlalchemy.orm import Session
from app.db import models

def get_product_by_slug(db: Session, slug: str):
    return db.query(models.Product).filter(models.Product.slug == slug).first()

def get_all_products(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.Product).offset(skip).limit(limit).all()

def search_products(db: Session, query: str):
    """Performs a full-text search on products."""
    search_query = db.query(models.Product).filter(
        models.Product.search_vector.match(query, postgresql_regconfig='english')
    )
    return search_query.all()
```
```markdown
# /pharmacorp_website/app/crud/crud_submission.py
from sqlalchemy.orm import Session
from app.db import models
from app.api import schemas

def create_contact_submission(db: Session, submission: schemas.ContactSubmissionCreate):
    db_submission = models.ContactSubmission(**submission.model_dump())
    db.add(db_submission)
    db.commit()
    db.refresh(db_submission)
    return db_submission

def create_newsletter_subscriber(db: Session, subscriber: schemas.NewsletterSubscriberCreate):
    db_subscriber = models.NewsletterSubscriber(**subscriber.model_dump())
    db.add(db_subscriber)
    db.commit()
    db.refresh(db_subscriber)
    return db_subscriber
```
```markdown
# /pharmacorp_website/app/db/__init__.py
```
```markdown
# /pharmacorp_website/app/db/base.py
from .models import Base
```
```markdown
# /pharmacorp_website/app/db/models.py
from sqlalchemy import (Column, Integer, String, Text, DateTime, ForeignKey,
                        func, event, DDL)
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.dialects.postgresql import TSVECTOR

Base = declarative_base()

class Product(Base):
    __tablename__ = "products"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    slug = Column(String(100), unique=True, index=True, nullable=False)
    description = Column(Text, nullable=False)
    full_content = Column(Text, nullable=False)
    isi_text = Column(Text, nullable=False)
    image_url = Column(String(255), nullable=False)
    image_alt_text = Column(String(255), nullable=False)
    pi_url = Column(String(255), nullable=False)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())
    search_vector = Column(TSVECTOR)

class Page(Base):
    __tablename__ = "pages"
    id = Column(Integer, primary_key=True, index=True)
    slug = Column(String(100), unique=True, index=True, nullable=False)
    title = Column(String(255), nullable=False)
    content = Column(Text, nullable=False)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())
    search_vector = Column(TSVECTOR)

class ContactSubmission(Base):
    __tablename__ = "contact_submissions"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    email = Column(String(255), nullable=False)
    message = Column(Text, nullable=False)
    created_at = Column(DateTime, server_default=func.now())

class NewsletterSubscriber(Base):
    __tablename__ = "newsletter_subscribers"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    created_at = Column(DateTime, server_default=func.now())


# --- Full-Text Search Triggers ---
# These triggers automatically update the 'search_vector' column whenever
# a product or page is created or updated.

products_search_vector_trigger = DDL("""
CREATE TRIGGER products_search_vector_update
BEFORE INSERT OR UPDATE ON products
FOR EACH ROW EXECUTE PROCEDURE
tsvector_update_trigger(search_vector, 'pg_catalog.english', name, description, full_content);
""")

pages_search_vector_trigger = DDL("""
CREATE TRIGGER pages_search_vector_update
BEFORE INSERT OR UPDATE ON pages
FOR EACH ROW EXECUTE PROCEDURE
tsvector_update_trigger(search_vector, 'pg_catalog.english', title, content);
""")

event.listen(Product.__table__, 'after_create', products_search_vector_trigger)
event.listen(Page.__table__, 'after_create', pages_search_vector_trigger)
```
```markdown
# /pharmacorp_website/app/db/seed.py
from sqlalchemy.orm import Session
from . import models
from .session import engine

def init_db(db: Session):
    # Create tables
    models.Base.metadata.create_all(bind=engine)

    # Check if data already exists
    if db.query(models.Page).first():
        print("Database already seeded.")
        return

    print("Seeding database with initial data...")

    # Seed Pages
    pages_data = [
        {
            "slug": "about-us",
            "title": "About Us",
            "content": """
                <p class="lead">PharmaCorp is dedicated to pioneering new medicines to help people live longer, healthier lives.</p>
                <p>Founded in 1985, our mission has always been to combine cutting-edge science with a deep commitment to patient well-being. We believe that through relentless innovation and a strong ethical framework, we can tackle some of the world's most challenging diseases.</p>
                <h3>Our Mission</h3>
                <p>To discover, develop, and deliver innovative therapeutic solutions that significantly improve the lives of patients worldwide.</p>
                <h3>Our Values</h3>
                <ul>
                    <li><strong>Integrity:</strong> We adhere to the highest ethical standards in all our actions.</li>
                    <li><strong>Innovation:</strong> We pursue scientific excellence and encourage creative solutions.</li>
                    <li><strong>Collaboration:</strong> We work together with partners to achieve shared goals.</li>
                    <li><strong>Patient-Centricity:</strong> We place the needs of patients at the heart of everything we do.</li>
                </ul>
            """
        },
        {
            "slug": "privacy-policy",
            "title": "Privacy Policy",
            "content": "<p>This is a placeholder for the Privacy Policy. We are committed to protecting your privacy. This policy outlines how we collect, use, and safeguard your personal information when you visit our website.</p>"
        },
        {
            "slug": "terms-of-use",
            "title": "Terms of Use",
            "content": "<p>This is a placeholder for the Terms of Use. By accessing and using this website, you agree to comply with and be bound by the following terms and conditions of use, which together with our privacy policy govern PharmaCorp's relationship with you in relation to this website.</p>"
        }
    ]

    for page in pages_data:
        db_page = models.Page(**page)
        db.add(db_page)

    # Seed Products
    products_data = [
        {
            "name": "Reliefium",
            "slug": "reliefium",
            "description": "An innovative solution for chronic pain management, providing sustained relief.",
            "full_content": "<p>Reliefium is a non-opioid analgesic indicated for the management of moderate to severe chronic pain in adults. Its unique mechanism of action targets specific nerve pathways to provide effective relief without the common side effects associated with traditional pain medications. It is administered once daily.</p>",
            "isi_text": "<strong>Important Safety Information for Reliefium:</strong> Do not take Reliefium if you are allergic to any of its ingredients. The most common side effects include nausea, dizziness, and headache. Serious side effects may include liver problems. Talk to your doctor about the potential risks and benefits before starting treatment.",
            "image_url": "/static/images/product1.jpg",
            "image_alt_text": "A modern, clean package for the medication Reliefium.",
            "pi_url": "/static/pi/sample-pi.pdf"
        },
        {
            "name": "CardioGuard",
            "slug": "cardioguard",
            "description": "A leading-edge therapy for reducing the risk of major cardiovascular events.",
            "full_content": "<p>CardioGuard is prescribed to adults with established cardiovascular disease to reduce the risk of myocardial infarction, stroke, and cardiovascular death. It works by optimizing lipid profiles and reducing arterial inflammation. This product has undergone extensive clinical trials to prove its efficacy and safety.</p><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>",
            "isi_text": "<strong>Important Safety Information for CardioGuard:</strong> CardioGuard can cause serious side effects, including muscle pain or weakness and liver problems. Your doctor should do blood tests to check your liver before you start taking CardioGuard. Do not take CardioGuard if you are pregnant, planning to become pregnant, or are nursing.",
            "image_url": "/static/images/product2.jpg",
            "image_alt_text": "A futuristic-looking package for the medication CardioGuard.",
            "pi_url": "/static/pi/sample-pi.pdf"
        }
    ]

    for product in products_data:
        db_product = models.Product(**product)
        db.add(db_product)

    db.commit()
    print("Database seeding complete.")
```
```markdown
# /pharmacorp_website/app/db/session.py
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.core.config import settings

engine = create_engine(settings.DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
```
```markdown
# /pharmacorp_website/app/pages/__init__.py
```
```markdown
# /pharmacorp_website/app/pages/routes.py
from fastapi import APIRouter, Request, Depends, HTTPException, Query
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from typing import Optional

from app.db.session import get_db
from app.crud import crud_product, crud_page

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse, name="home")
async def home(request: Request):
    return templates.TemplateResponse("pages/home.html", {"request": request, "title": "Home"})

@router.get("/about", response_class=HTMLResponse, name="about")
async def about(request: Request, db: Session = Depends(get_db)):
    page_content = crud_page.get_page_by_slug(db, "about-us")
    if not page_content:
        raise HTTPException(status_code=404, detail="Page not found")
    return templates.TemplateResponse("pages/about.html", {"request": request, "title": "About Us", "page": page_content})

@router.get("/contact", response_class=HTMLResponse, name="contact")
async def contact(request: Request):
    return templates.TemplateResponse("pages/contact.html", {"request": request, "title": "Contact Us"})

@router.get("/products", response_class=HTMLResponse, name="product-list")
async def product_list(request: Request, db: Session = Depends(get_db)):
    products = crud_product.get_all_products(db)
    return templates.TemplateResponse("products/product_list.html", {"request": request, "title": "Our Products", "products": products})

@router.get("/products/{slug}", response_class=HTMLResponse, name="product-detail")
async def product_detail(request: Request, slug: str, db: Session = Depends(get_db)):
    product = crud_product.get_product_by_slug(db, slug=slug)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return templates.TemplateResponse("products/product_detail.html", {"request": request, "title": product.name, "product": product})

@router.get("/search", response_class=HTMLResponse, name="search")
async def search(request: Request, q: Optional[str] = Query(None, min_length=3), db: Session = Depends(get_db)):
    results = []
    if q:
        product_results = crud_product.search_products(db, q)
        page_results = crud_page.search_pages(db, q)
        
        # Format results for template
        for p in product_results:
            results.append({
                "type": "Product",
                "title": p.name,
                "url": request.url_for('product-detail', slug=p.slug),
                "snippet": p.description[:150] + "..."
            })
        for p in page_results:
            results.append({
                "type": "Page",
                "title": p.title,
                "url": f"/{p.slug}" if p.slug not in ['about-us', 'privacy-policy', 'terms-of-use'] else request.url_for(p.slug.replace('-','_')),
                "snippet": p.content.replace('<p>', '').replace('</p>', '')[:150] + "..."
            })

    return templates.TemplateResponse("pages/search_results.html", {"request": request, "title": f"Search Results for '{q}'", "query": q, "results": results})

@router.get("/privacy-policy", response_class=HTMLResponse, name="privacy_policy")
async def privacy_policy(request: Request, db: Session = Depends(get_db)):
    page_content = crud_page.get_page_by_slug(db, "privacy-policy")
    if not page_content:
        raise HTTPException(status_code=404, detail="Page not found")
    return templates.TemplateResponse("pages/privacy.html", {"request": request, "title": "Privacy Policy", "page": page_content})

@router.get("/terms-of-use", response_class=HTMLResponse, name="terms_of_use")
async def terms_of_use(request: Request, db: Session = Depends(get_db)):
    page_content = crud_page.get_page_by_slug(db, "terms-of-use")
    if not page_content:
        raise HTTPException(status_code=404, detail="Page not found")
    return templates.TemplateResponse("pages/terms.html", {"request": request, "title": "Terms of Use", "page": page_content})

```
```markdown
# /pharmacorp_website/app/static/css/style.css
/* --- Global Styles & Variables --- */
:root {
    --primary-color: #005A9C; /* Pharma Blue */
    --secondary-color: #00A3E0; /* Lighter Blue */
    --accent-color: #F37A22; /* Orange for CTAs */
    --text-color: #333333;
    --light-gray: #f4f4f4;
    --border-color: #dddddd;
    --success-color: #28a745;
    --error-color: #dc3545;
    --font-family: 'Helvetica Neue', Arial, sans-serif;
}

*, *::before, *::after {
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
}

body {
    font-family: var(--font-family);
    line-height: 1.6;
    color: var(--text-color);
    margin: 0;
    padding-top: 80px; /* Space for fixed header */
    background-color: #ffffff;
}

.container {
    max-width: 1100px;
    margin: 0 auto;
    padding: 0 20px;
}

h1, h2, h3 {
    color: var(--primary-color);
    line-height: 1.2;
}

a {
    color: var(--primary-color);
    text-decoration: none;
    transition: color 0.3s ease;
}

a:hover, a:focus {
    color: var(--secondary-color);
    text-decoration: underline;
}

/* Accessibility: Clear focus indicator */
:focus-visible {
    outline: 3px solid var(--accent-color);
    outline-offset: 2px;
}

.btn {
    display: inline-block;
    padding: 12px 24px;
    border-radius: 5px;
    font-weight: bold;
    text-align: center;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.2s ease;
    border: none;
}

.btn-primary {
    background-color: var(--accent-color);
    color: #fff;
}

.btn-primary:hover, .btn-primary:focus {
    background-color: #d96813;
    color: #fff;
    text-decoration: none;
    transform: translateY(-2px);
}

.btn-secondary {
    background-color: transparent;
    color: var(--primary-color);
    border: 2px solid var(--primary-color);
}

.btn-secondary:hover, .btn-secondary:focus {
    background-color: var(--primary-color);
    color: #fff;
    text-decoration: none;
}

/* --- Header & Navigation (PCW-004) --- */
.site-header {
    background-color: #fff;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    z-index: 1000;
}

.site-header .container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 80px;
}

.logo {
    font-size: 1.8rem;
    font-weight: bold;
    color: var(--primary-color);
}

.logo:hover, .logo:focus {
    text-decoration: none;
}

.main-nav {
    display: flex;
    align-items: center;
}

.main-nav ul {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
}

.main-nav li {
    margin-left: 25px;
}

.main-nav a {
    font-weight: 600;
    padding: 10px 5px;
    position: relative;
}

.main-nav a::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 0;
    height: 3px;
    background-color: var(--secondary-color);
    transition: width 0.3s ease;
}

.main-nav a:hover::after,
.main-nav a.active::after {
    width: 100%;
}

.search-form {
    margin-left: 20px;
    display: flex;
}

.search-form input[type="search"] {
    border: 1px solid var(--border-color);
    border-right: none;
    padding: 8px;
    border-radius: 5px 0 0 5px;
}

.search-form button {
    border: 1px solid var(--primary-color);
    background-color: var(--primary-color);
    color: white;
    padding: 8px 12px;
    cursor: pointer;
    border-radius: 0 5px 5px 0;
}

.hamburger-menu {
    display: none;
    cursor: pointer;
    border: none;
    background: none;
    padding: 0;
}

.hamburger-menu .bar {
    display: block;
    width: 25px;
    height: 3px;
    margin: 5px auto;
    background-color: var(--primary-color);
    transition: all 0.3s ease-in-out;
}

/* --- Main Content --- */
main {
    padding: 40px 0;
}

/* --- Homepage (PCW-001) --- */
.hero {
    background-color: var(--light-gray);
    background-image: url('../images/hero-background.jpg');
    background-size: cover;
    background-position: center;
    color: #fff;
    text-align: center;
    padding: 100px 20px;
    position: relative;
}
.hero::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 90, 156, 0.7); /* Overlay */
}

.hero-content {
    position: relative;
    z-index: 1;
}

.hero h1 {
    font-size: 3rem;
    margin-bottom: 20px;
    color: #fff;
}

.hero p {
    font-size: 1.2rem;
    margin-bottom: 40px;
}

.hero .cta-buttons .btn {
    margin: 0 10px;
}

/* --- Generic Page Styles (About, Contact, etc.) --- */
.page-header {
    background-color: var(--light-gray);
    padding: 30px 0;
    margin-bottom: 40px;
    text-align: center;
}

.page-header h1 {
    margin: 0;
}

.page-content {
    max-width: 800px;
    margin: 0 auto;
}

/* --- Products Page (PCW-005) --- */
.product-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 30px;
}

.product-card {
    border: 1px solid var(--border-color);
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    display: flex;
    flex-direction: column;
}

.product-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.product-card img {
    width: 100%;
    height: 200px;
    object-fit: cover;
}

.product-card-content {
    padding: 20px;
    flex-grow: 1;
    display: flex;
    flex-direction: column;
}

.product-card-content h3 {
    margin-top: 0;
}

.product-card-content p {
    flex-grow: 1;
}

.product-card-content .btn {
    align-self: flex-start;
}

/* --- Product Detail Page (PCW-006, PCW-007, PCW-008) --- */
.product-detail-layout {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 40px;
}

.product-detail-main img {
    max-width: 100%;
    height: auto;
    border-radius: 8px;
    margin-bottom: 20px;
}

.pi-download-link {
    display: inline-block;
    background-color: var(--light-gray);
    border: 1px solid var(--border-color);
    padding: 15px 20px;
    border-radius: 5px;
    margin-top: 20px;
    font-weight: bold;
}

.pi-download-link:hover {
    background-color: #e9e9e9;
    text-decoration: none;
}

.isi-section {
    padding: 20px;
    border: 1px solid var(--border-color);
    border-radius: 5px;
    background-color: #f9f9f9;
}

.isi-section h3 {
    margin-top: 0;
}

/* Sticky ISI */
.sticky-isi-container {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    background-color: #f1f1f1;
    border-top: 2px solid var(--primary-color);
    box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
    z-index: 999;
    transform: translateY(100%);
    transition: transform 0.4s ease-in-out;
    max-height: 40vh;
    overflow-y: auto;
}

.sticky-isi-container.visible {
    transform: translateY(0);
}

.sticky-isi-content {
    padding: 20px;
    max-width: 1100px;
    margin: 0 auto;
    font-size: 0.9rem;
}

.sticky-isi-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
}
.sticky-isi-header h4 {
    margin: 0;
    color: var(--primary-color);
}

#isi-toggle {
    cursor: pointer;
    background: none;
    border: 1px solid var(--text-color);
    border-radius: 5px;
    padding: 5px 10px;
}

.isi-full-text {
    max-height: 100px;
    overflow: hidden;
    transition: max-height 0.5s ease-in-out;
}

.isi-full-text.expanded {
    max-height: 1000px; /* Large value */
}


/* --- Contact Form & Newsletter (PCW-009, PCW-010) --- */
.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
}

.form-group input,
.form-group textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid var(--border-color);
    border-radius: 5px;
    font-size: 1rem;
}

.form-group input:focus,
.form-group textarea:focus {
    outline: none;
    border-color: var(--primary-color);
    box-shadow: 0 0 5px rgba(0, 90, 156, 0.3);
}

.error-message {
    color: var(--error-color);
    font-size: 0.9rem;
    margin-top: 5px;
    display: none;
}

.form-group input.invalid,
.form-group textarea.invalid {
    border-color: var(--error-color);
}

.form-response {
    padding: 15px;
    border-radius: 5px;
    margin-top: 20px;
    display: none;
}
.form-response.success {
    background-color: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
}
.form-response.error {
    background-color: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}

/* --- Search Results (PCW-011) --- */
.search-results-list {
    list-style: none;
    padding: 0;
}

.search-result-item {
    margin-bottom: 30px;
    padding-bottom: 20px;
    border-bottom: 1px solid var(--border-color);
}

.search-result-item h3 {
    margin: 0 0 5px 0;
}
.search-result-item h3 a {
    text-decoration: none;
}
.search-result-item .result-type {
    font-size: 0.9rem;
    color: #666;
    font-weight: bold;
    display: block;
    margin-bottom: 5px;
}

/* --- Footer (PCW-004) --- */
.site-footer {
    background-color: #333;
    color: #f4f4f4;
    padding: 40px 0;
    margin-top: 60px;
}

.footer-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 30px;
}

.footer-col h4 {
    color: #fff;
    margin-bottom: 15px;
}

.footer-col ul {
    list-style: none;
    padding: 0;
}

.footer-col li {
    margin-bottom: 10px;
}

.footer-col a {
    color: #ccc;
}
.footer-col a:hover {
    color: #fff;
}

.newsletter-form {
    display: flex;
}
.newsletter-form input {
    flex-grow: 1;
    padding: 10px;
    border: 1px solid #666;
    background: #555;
    color: #fff;
    border-radius: 5px 0 0 5px;
}
.newsletter-form button {
    padding: 10px 15px;
    border: none;
    background-color: var(--secondary-color);
    color: #fff;
    cursor: pointer;
    border-radius: 0 5px 5px 0;
}

.footer-bottom {
    text-align: center;
    margin-top: 40px;
    padding-top: 20px;
    border-top: 1px solid #555;
    font-size: 0.9rem;
    color: #ccc;
}

/* --- Cookie Banner (PCW-013) --- */
#cookie-consent-banner {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    background-color: rgba(0, 0, 0, 0.85);
    color: #fff;
    padding: 20px;
    box-shadow: 0 -2px 10px rgba(0,0,0,0.2);
    z-index: 2000;
    display: none; /* Hidden by default */
    align-items: center;
    justify-content: center;
    gap: 20px;
}

#cookie-consent-banner.active {
    display: flex;
}

.cookie-consent-text {
    max-width: 60%;
}

.cookie-consent-actions .btn {
    margin-left: 10px;
}


/* --- Responsive Design (PCW-016) --- */

/* Tablet */
@media (max-width: 1024px) {
    .product-detail-layout {
        grid-template-columns: 1fr;
    }
}

/* Mobile */
@media (max-width: 768px) {
    body {
        padding-top: 70px;
    }
    .site-header .container {
        height: 70px;
    }

    .main-nav {
        position: fixed;
        top: 70px;
        left: 0;
        width: 100%;
        background-color: #fff;
        flex-direction: column;
        align-items: stretch;
        border-top: 1px solid var(--border-color);
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.3s ease-out;
    }

    .main-nav.active {
        max-height: 500px; /* Arbitrary large value */
        border-bottom: 1px solid var(--border-color);
    }
    
    .main-nav ul {
        flex-direction: column;
    }

    .main-nav li {
        margin: 0;
        text-align: center;
    }

    .main-nav a {
        display: block;
        padding: 15px;
        border-bottom: 1px solid var(--border-color);
    }
    .main-nav a::after {
        display: none;
    }
    .main-nav a:hover, .main-nav a.active {
        background-color: var(--light-gray);
    }

    .search-form {
        margin: 15px;
    }
    .search-form input {
        width: 100%;
    }

    .hamburger-menu {
        display: block;
    }
    .hamburger-menu.active .bar:nth-child(2) {
        opacity: 0;
    }
    .hamburger-menu.active .bar:nth-child(1) {
        transform: translateY(8px) rotate(45deg);
    }
    .hamburger-menu.active .bar:nth-child(3) {
        transform: translateY(-8px) rotate(-45deg);
    }

    .hero h1 {
        font-size: 2.2rem;
    }
    .hero .cta-buttons {
        display: flex;
        flex-direction: column;
        align-items: center;
    }
    .hero .cta-buttons .btn {
        margin: 10px 0;
        width: 80%;
    }

    #cookie-consent-banner {
        flex-direction: column;
        text-align: center;
    }
    .cookie-consent-text {
        max-width: 100%;
        margin-bottom: 15px;
    }
}
```
```markdown
# /pharmacorp_website/app/static/images/hero-background.jpg
# This is a binary file. A placeholder is sufficient. For example, a 1920x1080 solid blue image.
```
```markdown
# /pharmacorp_website/app/static/images/product1.jpg
# This is a binary file. A placeholder is sufficient. For example, a 800x600 image.
```
```markdown
# /pharmacorp_website/app/static/images/product2.jpg
# This is a binary file. A placeholder is sufficient. For example, a 800x600 image.
```
```markdown
# /pharmacorp_website/app/static/js/cookie-consent.js
document.addEventListener('DOMContentLoaded', () => {
    const COOKIE_CONSENT_KEY = 'pharmacorp_cookie_consent';
    const banner = document.getElementById('cookie-consent-banner');
    const acceptBtn = document.getElementById('cookie-accept');
    const rejectBtn = document.getElementById('cookie-reject');

    const userPreference = localStorage.getItem(COOKIE_CONSENT_KEY);

    if (!userPreference) {
        banner.classList.add('active');
    }

    const handleConsent = (consentValue) => {
        localStorage.setItem(COOKIE_CONSENT_KEY, consentValue);
        banner.classList.remove('active');
        // In a real application, you would now either load tracking scripts (if 'accepted')
        // or ensure they remain disabled.
        console.log(`Cookie consent set to: ${consentValue}`);
    };

    if (acceptBtn) {
        acceptBtn.addEventListener('click', () => handleConsent('accepted'));
    }

    if (rejectBtn) {
        rejectBtn.addEventListener('click', () => handleConsent('rejected'));
    }
});
```
```markdown
# /pharmacorp_website/app/static/js/main.js
document.addEventListener('DOMContentLoaded', () => {
    // --- Mobile Navigation (PCW-016) ---
    const hamburger = document.querySelector('.hamburger-menu');
    const navMenu = document.querySelector('.main-nav');

    if (hamburger && navMenu) {
        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navMenu.classList.toggle('active');
        });
    }

    // --- Form Submission Helper ---
    const handleFormSubmit = async (form, successMessage) => {
        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());
        const responseContainer = form.querySelector('.form-response');
        const submitButton = form.querySelector('button[type="submit"]');
        const originalButtonText = submitButton.innerHTML;

        submitButton.disabled = true;
        submitButton.innerHTML = 'Submitting...';
        responseContainer.style.display = 'none';
        responseContainer.className = 'form-response';

        try {
            const response = await fetch(form.action, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(data)
            });

            const result = await response.json();

            if (response.ok) {
                responseContainer.classList.add('success');
                responseContainer.textContent = result.message || successMessage;
                form.reset();
            } else {
                responseContainer.classList.add('error');
                let errorMessage = result.detail || 'An unknown error occurred.';
                if (Array.isArray(result.detail)) {
                    errorMessage = result.detail.map(err => `${err.loc[1]}: ${err.msg}`).join(', ');
                }
                responseContainer.textContent = `Error: ${errorMessage}`;
            }
        } catch (error) {
            responseContainer.classList.add('error');
            responseContainer.textContent = 'A network error occurred. Please try again.';
        } finally {
            responseContainer.style.display = 'block';
            submitButton.disabled = false;
            submitButton.innerHTML = originalButtonText;
        }
    };

    // --- Client-Side Form Validation Helper ---
    const validateForm = (form) => {
        let isValid = true;
        const inputs = form.querySelectorAll('[required], [type="email"]');

        inputs.forEach(input => {
            const errorContainer = form.querySelector(`#${input.id}-error`);
            input.classList.remove('invalid');
            if (errorContainer) errorContainer.style.display = 'none';

            let fieldIsValid = true;
            if (input.hasAttribute('required') && !input.value.trim()) {
                fieldIsValid = false;
            }
            if (input.type === 'email' && !/^\S+@\S+\.\S+$/.test(input.value)) {
                fieldIsValid = false;
            }
            if (input.minLength > 0 && input.value.trim().length < input.minLength) {
                fieldIsValid = false;
            }

            if (!fieldIsValid) {
                isValid = false;
                input.classList.add('invalid');
                if (errorContainer) {
                    errorContainer.style.display = 'block';
                }
            }
        });

        return isValid;
    };


    // --- Contact Form (PCW-009) ---
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            if (validateForm(contactForm)) {
                handleFormSubmit(contactForm, 'Thank you for your message!');
            }
        });
    }

    // --- Newsletter Form (PCW-010) ---
    const newsletterForm = document.getElementById('newsletter-form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', (e) => {
            e.preventDefault();
            if (validateForm(newsletterForm)) {
                handleFormSubmit(newsletterForm, 'You have been subscribed successfully.');
            }
        });
    }

    // --- Sticky ISI (PCW-007) ---
    const inPageIsi = document.getElementById('in-page-isi');
    const stickyIsi = document.getElementById('sticky-isi');

    if (inPageIsi && stickyIsi) {
        const observer = new IntersectionObserver(
            ([entry]) => {
                // When the in-page ISI is NOT intersecting (i.e., scrolled out of view)
                if (!entry.isIntersecting) {
                    stickyIsi.classList.add('visible');
                } else {
                    stickyIsi.classList.remove('visible');
                }
            },
            {
                root: null, // relative to the viewport
                threshold: 0, // trigger as soon as it's out of view
                rootMargin: "-100px 0px 0px 0px" // trigger 100px before it's fully out of view
            }
        );
        observer.observe(inPageIsi);
    }
    
    // --- Sticky ISI Expand/Collapse (PCW-007) ---
    const isiToggle = document.getElementById('isi-toggle');
    const isiFullText = document.querySelector('.isi-full-text');
    
    if (isiToggle && isiFullText) {
        isiToggle.addEventListener('click', () => {
            const isExpanded = isiFullText.classList.toggle('expanded');
            isiToggle.textContent = isExpanded ? 'Collapse' : 'Expand';
            isiToggle.setAttribute('aria-expanded', isExpanded);
        });
    }
});
```
```markdown
# /pharmacorp_website/app/static/pi/sample-pi.pdf
# This is a binary file. A placeholder is sufficient. Create a simple one-page PDF.
```
```markdown
# /pharmacorp_website/app/templates/base.html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="PharmaCorp - Pioneering new medicines for a healthier future.">
    <title>{{ title }} | PharmaCorp</title>
    <link rel="stylesheet" href="{{ url_for('static', path='/css/style.css') }}">
</head>
<body>

    {% include 'includes/_header.html' %}

    <main>
        {% block content %}{% endblock %}
    </main>

    {% include 'includes/_footer.html' %}

    {% include 'includes/_cookie_banner.html' %}

    <script src="{{ url_for('static', path='/js/main.js') }}"></script>
    <script src="{{ url_for('static', path='/js/cookie-consent.js') }}"></script>
</body>
</html>
```
```markdown
# /pharmacorp_website/app/templates/errors/404.html
{% extends "base.html" %}

{% block content %}
<div class="page-header">
    <div class="container">
        <h1>Page Not Found (404)</h1>
    </div>
</div>

<div class="container page-content" style="text-align: center;">
    <p>We're sorry, but the page you were looking for could not be found.</p>
    <p>It might have been removed, had its name changed, or is temporarily unavailable.</p>
    <a href="{{ url_for('home') }}" class="btn btn-primary">Go to Homepage</a>
</div>
{% endblock %}
```
```markdown
# /pharmacorp_website/app/templates/includes/_cookie_banner.html
<!-- PCW-013: Cookie Consent Banner -->
<div id="cookie-consent-banner" role="dialog" aria-labelledby="cookie-consent-title" aria-describedby="cookie-consent-desc">
    <div class="cookie-consent-text">
        <h3 id="cookie-consent-title">Our Use of Cookies</h3>
        <p id="cookie-consent-desc">We use cookies to enhance your browsing experience and analyze our traffic. By clicking "Accept All", you consent to our use of cookies.</p>
    </div>
    <div class="cookie-consent-actions">
        <!-- The "Customize" button is a placeholder for a more complex implementation -->
        <button id="cookie-reject" class="btn btn-secondary">Reject All</button>
        <button id="cookie-accept" class="btn btn-primary">Accept All</button>
    </div>
</div>
```
```markdown
# /pharmacorp_website/app/templates/includes/_footer.html
<!-- PCW-004: Site Footer -->
<footer class="site-footer">
    <div class="container">
        <div class="footer-grid">
            <div class="footer-col">
                <h4>PharmaCorp</h4>
                <p>Pioneering new medicines to help people live longer, healthier lives.</p>
            </div>
            <div class="footer-col">
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="{{ url_for('home') }}">Home</a></li>
                    <li><a href="{{ url_for('about') }}">About Us</a></li>
                    <li><a href="{{ url_for('product-list') }}">Products</a></li>
                    <li><a href="{{ url_for('contact') }}">Contact Us</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Legal</h4>
                <ul>
                    <li><a href="{{ url_for('privacy_policy') }}">Privacy Policy</a></li>
                    <li><a href="{{ url_for('terms_of_use') }}">Terms of Use</a></li>
                </ul>
            </div>
            <div class="footer-col">
                <h4>Newsletter</h4>
                <p>Stay up to date with our latest news.</p>
                <!-- PCW-010: Newsletter Signup -->
                <form id="newsletter-form" action="/api/newsletter" method="POST" novalidate>
                    <div class="newsletter-form">
                        <label for="newsletter-email" class="sr-only">Email Address</label>
                        <input type="email" id="newsletter-email" name="email" placeholder="Your email address" required>
                        <button type="submit">Sign Up</button>
                    </div>
                    <div id="newsletter-email-error" class="error-message">Please enter a valid email address.</div>
                    <div class="form-response"></div>
                </form>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; {{ now().year }} PharmaCorp Inc. All rights reserved.</p>
        </div>
    </div>
</footer>
```
```markdown
# /pharmacorp_website/app/templates/includes/_header.html
<!-- PCW-004: Site Navigation -->
<header class="site-header">
    <div class="container">
        <a href="{{ url_for('home') }}" class="logo">PharmaCorp</a>
        <nav class="main-nav" aria-label="Main Navigation">
            <ul>
                <li><a href="{{ url_for('home') }}" class="{{ 'active' if request.url.path == url_for('home') }}">Home</a></li>
                <li><a href="{{ url_for('about') }}" class="{{ 'active' if request.url.path == url_for('about') }}">About Us</a></li>
                <li><a href="{{ url_for('product-list') }}" class="{{ 'active' if 'products' in request.url.path }}">Products</a></li>
                <li><a href="{{ url_for('contact') }}" class="{{ 'active' if request.url.path == url_for('contact') }}">Contact Us</a></li>
            </ul>
            <!-- PCW-011: Site Search -->
            <form action="{{ url_for('search') }}" method="GET" class="search-form" role="search">
                <label for="search-query" class="sr-only">Search Website</label>
                <input type="search" id="search-query" name="q" placeholder="Search..." minlength="3" required>
                <button type="submit" aria-label="Submit search">Go</button>
            </form>
        </nav>
        <button class="hamburger-menu" aria-label="Toggle menu" aria-expanded="false" aria-controls="main-nav">
            <span class="bar"></span>
            <span class="bar"></span>
            <span class="bar"></span>
        </button>
    </div>
</header>
```
```markdown
# /pharmacorp_website/app/templates/pages/about.html
{% extends "base.html" %}

{% block content %}
<div class="page-header">
    <div class="container">
        <!-- PCW-002: Page Title is "About Us" -->
        <h1>{{ page.title }}</h1>
    </div>
</div>

<div class="container page-content">
    <!-- PCW-002: Content about mission and values -->
    {{ page.content | safe }}
</div>
{% endblock %}
```
```markdown
# /pharmacorp_website/app/templates/pages/contact.html
{% extends "base.html" %}

{% block content %}
<div class="page-header">
    <div class="container">
        <h1>Contact Us</h1>
    </div>
</div>

<div class="container page-content">
    <p>We'd love to hear from you. Please use the contact information below or fill out the form to get in touch.</p>

    <!-- PCW-003: Display contact info -->
    <div class="contact-info">
        <h3>Our Office</h3>
        <p>
            <strong>PharmaCorp Inc.</strong><br>
            123 Innovation Drive<br>
            Science City, ST 54321
        </p>
        <p>
            <strong>Phone:</strong> <a href="tel:+15551234567">+1 (555) 123-4567</a>
        </p>
    </div>

    <hr style="margin: 40px 0;">

    <!-- PCW-009: Contact Form -->
    <h3>Send us a message</h3>
    <form id="contact-form" action="/api/contact" method="POST" novalidate>
        <div class="form-group">
            <label for="name">Full Name</label>
            <input type="text" id="name" name="name" required minlength="2">
            <div id="name-error" class="error-message">Name is required (minimum 2 characters).</div>
        </div>
        <div class="form-group">
            <label for="email">Email Address</label>
            <input type="email" id="email" name="email" required>
            <div id="email-error" class="error-message">A valid email address is required.</div>
        </div>
        <div class="form-group">
            <label for="message">Message</label>
            <textarea id="message" name="message" rows="6" required minlength="10"></textarea>
            <div id="message-error" class="error-message">Message is required (minimum 10 characters).</div>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>

        <div class="form-response"></div>
    </form>

</div>
{% endblock %}
```
```markdown
# /pharmacorp_website/app/templates/pages/home.html
{% extends "base.html" %}

{% block content %}
<!-- PCW-001: Homepage -->
<section class="hero">
    <div class="hero-content">
        <!-- Prominent hero section with clear headline -->
        <h1>Advancing Health Through Science</h1>
        <p>Discover our commitment to developing innovative therapies that improve lives.</p>
        <!-- Clear calls-to-action (CTAs) -->
        <div class="cta-buttons">
            <a href="{{ url_for('product-list') }}" class="btn btn-primary">Our Products</a>
            <a href="{{ url_for('about') }}" class="btn btn-secondary">About Us</a>
        </div>
    </div>
</section>

<section class="container" style="padding: 60px 20px;">
    <h2 style="text-align: center; margin-bottom: 40px;">Our Focus Areas</h2>
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 30px; text-align: center;">
        <div>
            <h3>Cardiology</h3>
            <p>Developing new treatments for heart disease and related conditions.</p>
        </div>
        <div>
            <h3>Oncology</h3>
            <p>Pioneering therapies to fight cancer and support patients.</p>
        </div>
        <div>
            <h3>Neurology</h3>
            <p>Exploring innovative solutions for complex neurological disorders.</p>
        </div>
    </div>
</section>
{% endblock %}
```
```markdown
# /pharmacorp_website/app/templates/pages/privacy.html
{% extends "base.html" %}

{% block content %}
<div class="page-header">
    <div class="container">
        <!-- PCW-012: Privacy Policy Page -->
        <h1>{{ page.title }}</h1>
    </div>
</div>

<div class="container page-content">
    {{ page.content | safe }}
</div>
{% endblock %}
```
```markdown
# /pharmacorp_website/app/templates/pages/search_results.html
{% extends "base.html" %}

{% block content %}
<div class="page-header">
    <div class="container">
        <!-- PCW-011: Search Results Page -->
        {% if query %}
            <h1>Search Results for "{{ query }}"</h1>
        {% else %}
            <h1>Search</h1>
        {% endif %}
    </div>
</div>

<div class="container page-content">
    {% if query %}
        {% if results %}
            <p>{{ results|length }} result(s) found.</p>
            <ul class="search-results-list">
                {% for result in results %}
                <li class="search-result-item">
                    <span class="result-type">{{ result.type }}</span>
                    <h3><a href="{{ result.url }}">{{ result.title }}</a></h3>
                    <p>{{ result.snippet }}</p>
                </li>
                {% endfor %}
            </ul>
        {% else %}
            <!-- "No results found" message -->
            <p>No results found for your search term. Please try again with different keywords.</p>
        {% endif %}
    {% else %}
        <p>Please enter a search term in the search bar above to find content across the site.</p>
    {% endif %}
</div>
{% endblock %}
```
```markdown
# /pharmacorp_website/app/templates/pages/terms.html
{% extends "base.html" %}

{% block content %}
<div class="page-header">
    <div class="container">
        <!-- PCW-012: Terms of Use Page -->
        <h1>{{ page.title }}</h1>
    </div>
</div>

<div class="container page-content">
    {{ page.content | safe }}
</div>
{% endblock %}
```
```markdown
# /pharmacorp_website/app/templates/products/product_detail.html
{% extends "base.html" %}

{% block content %}
<div class="container">
    <!-- PCW-006: Product Detail Page -->
    <div class="product-detail-layout">
        <div class="product-detail-main">
            <h1>{{ product.name }}</h1>
            <img src="{{ product.image_url }}" alt="{{ product.image_alt_text }}">
            
            <h2>Description</h2>
            {{ product.full_content | safe }}

            <!-- PCW-008: Prescribing Information (PI) PDF Download -->
            <a href="{{ product.pi_url }}" class="pi-download-link" target="_blank" rel="noopener noreferrer">
                Download Prescribing Information (PDF)
            </a>
        </div>
        <aside class="product-detail-sidebar">
            <!-- PCW-006: Important Safety Information (ISI) is clearly visible -->
            <div id="in-page-isi" class="isi-section">
                <h3>Important Safety Information</h3>
                {{ product.isi_text | safe }}
            </div>
        </aside>
    </div>
</div>

<!-- PCW-007: Sticky Important Safety Information (ISI) -->
<div id="sticky-isi" class="sticky-isi-container" role="region" aria-labelledby="sticky-isi-heading">
    <div class="sticky-isi-content">
        <div class="sticky-isi-header">
            <h4 id="sticky-isi-heading">Important Safety Information</h4>
            <button id="isi-toggle" aria-expanded="false" aria-controls="isi-full-text-content">Expand</button>
        </div>
        <div class="isi-full-text" id="isi-full-text-content">
            {{ product.isi_text | safe }}
        </div>
    </div>
</div>
{% endblock %}
```
```markdown
# /pharmacorp_website/app/templates/products/product_list.html
{% extends "base.html" %}

{% block content %}
<div class="page-header">
    <div class="container">
        <h1>Our Products</h1>
    </div>
</div>

<div class="container">
    <!-- PCW-005: Product Listing Page -->
    <div class="product-grid">
        {% for product in products %}
        <article class="product-card">
            <img src="{{ product.image_url }}" alt="{{ product.image_alt_text }}">
            <div class="product-card-content">
                <h3>{{ product.name }}</h3>
                <p>{{ product.description }}</p>
                <!-- Clickable link to detail page -->
                <a href="{{ url_for('product-detail', slug=product.slug) }}" class="btn btn-secondary">Learn More</a>
            </div>
        </article>
        {% else %}
        <p>No products are currently available.</p>
        {% endfor %}
    </div>
</div>
{% endblock %}
```
```markdown
# /pharmacorp_website/tests/__init__.py
```
```markdown
# /pharmacorp_website/tests/conftest.py
import pytest
from typing import Generator
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.main import app
from app.db.session import get_db
from app.db.models import Base
from app.db import seed

# Use an in-memory SQLite database for testing
SQLALCHEMY_DATABASE_URL = "sqlite:///./test.db"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Create the database and tables before tests run
Base.metadata.create_all(bind=engine)

@pytest.fixture(scope="session", autouse=True)
def seed_test_db():
    # Seed the test database once per session
    db = TestingSessionLocal()
    seed.init_db(db)
    db.close()

@pytest.fixture(scope="function")
def db_session() -> Generator:
    connection = engine.connect()
    transaction = connection.begin()
    session = TestingSessionLocal(bind=connection)
    yield session
    session.close()
    transaction.rollback()
    connection.close()

@pytest.fixture(scope="function")
def client(db_session: Generator) -> Generator:
    def override_get_db():
        try:
            yield db_session
        finally:
            db_session.close()
    
    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as c:
        yield c
```
```markdown
# /pharmacorp_website/tests/test_api.py
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session
from app.db import models

def test_contact_form_submission_success(client: TestClient):
    """Test successful submission of the contact form (PCW-009)."""
    response = client.post(
        "/api/contact",
        json={"name": "John Doe", "email": "john.doe@example.com", "message": "This is a test message."}
    )
    assert response.status_code == 201
    data = response.json()
    assert data["status"] == "success"
    assert data["message"] == "Thank you for your message!"

def test_contact_form_submission_validation_error(client: TestClient):
    """Test contact form submission with invalid data (PCW-009)."""
    response = client.post(
        "/api/contact",
        json={"name": "J", "email": "not-an-email", "message": "short"}
    )
    assert response.status_code == 422
    data = response.json()
    assert "detail" in data
    assert any("name" in err["loc"] for err in data["detail"])
    assert any("email" in err["loc"] for err in data["detail"])
    assert any("message" in err["loc"] for err in data["detail"])

def test_newsletter_signup_success(client: TestClient):
    """Test successful newsletter signup (PCW-010)."""
    email = "new.subscriber@example.com"
    response = client.post("/api/newsletter", json={"email": email})
    assert response.status_code == 201
    data = response.json()
    assert data["status"] == "success"
    assert data["message"] == "You have been subscribed successfully."

def test_newsletter_signup_duplicate(client: TestClient, db_session: Session):
    """Test newsletter signup with an existing email (PCW-010)."""
    email = "duplicate.subscriber@example.com"
    # First, create the subscriber
    db_subscriber = models.NewsletterSubscriber(email=email)
    db_session.add(db_subscriber)
    db_session.commit()

    # Then, try to sign up again
    response = client.post("/api/newsletter", json={"email": email})
    assert response.status_code == 409
    data = response.json()
    assert data["detail"] == "This email address is already subscribed."

def test_newsletter_signup_invalid_email(client: TestClient):
    """Test newsletter signup with an invalid email format (PCW-010)."""
    response = client.post("/api/newsletter", json={"email": "invalid-email"})
    assert response.status_code == 422
```
```markdown
# /pharmacorp_website/tests/test_pages.py
from fastapi.testclient import TestClient

def test_homepage_loads(client: TestClient):
    """Test that the homepage loads successfully and contains key elements (PCW-001)."""
    response = client.get("/")
    assert response.status_code == 200
    assert "Advancing Health Through Science" in response.text
    assert 'href="/products"' in response.text
    assert 'href="/about"' in response.text

def test_about_us_page_loads(client: TestClient):
    """Test that the About Us page loads and has the correct title (PCW-002)."""
    response = client.get("/about")
    assert response.status_code == 200
    assert "<title>About Us | PharmaCorp</title>" in response.text
    assert "Our Mission" in response.text

def test_contact_us_page_loads(client: TestClient):
    """Test that the Contact Us page loads and contains contact info (PCW-003)."""
    response = client.get("/contact")
    assert response.status_code == 200
    assert "123 Innovation Drive" in response.text
    assert "Send us a message" in response.text

def test_header_and_footer_on_all_pages(client: TestClient):
    """Test that header and footer are present on multiple pages (PCW-004)."""
    paths = ["/", "/about", "/products"]
    for path in paths:
        response = client.get(path)
        assert response.status_code == 200
        assert '<header class="site-header">' in response.text
        assert '<footer class="site-footer">' in response.text
        assert 'href="/privacy-policy"' in response.text

def test_product_list_page_loads(client: TestClient):
    """Test that the product listing page loads and shows products (PCW-005)."""
    response = client.get("/products")
    assert response.status_code == 200
    assert "Reliefium" in response.text
    assert "CardioGuard" in response.text
    assert 'href="/products/reliefium"' in response.text

def test_product_detail_page_loads(client: TestClient):
    """Test that a product detail page loads with correct info (PCW-006, PCW-008)."""
    response = client.get("/products/reliefium")
    assert response.status_code == 200
    assert "<h1>Reliefium</h1>" in response.text
    assert "Important Safety Information" in response.text
    assert 'href="/static/pi/sample-pi.pdf"' in response.text

def test_product_detail_page_not_found(client: TestClient):
    """Test accessing a non-existent product returns 404."""
    response = client.get("/products/non-existent-product")
    assert response.status_code == 404

def test_search_functionality(client: TestClient):
    """Test the search functionality with a valid query (PCW-011)."""
    response = client.get("/search?q=innovative")
    assert response.status_code == 200
    assert 'Search Results for "innovative"' in response.text
    # Both Reliefium and the About Us page contain "innovative"
    assert "Reliefium" in response.text
    assert "About Us" in response.text

def test_search_no_results(client: TestClient):
    """Test search with a query that yields no results (PCW-011)."""
    response = client.get("/search?q=xyznonexistentterm")
    assert response.status_code == 200
    assert "No results found" in response.text

def test_legal_pages_load(client: TestClient):
    """Test that the privacy and terms pages load (PCW-012)."""
    response = client.get("/privacy-policy")
    assert response.status_code == 200
    assert "<title>Privacy Policy | PharmaCorp</title>" in response.text

    response = client.get("/terms-of-use")
    assert response.status_code == 200
    assert "<title>Terms of Use | PharmaCorp</title>" in response.text
```