```markdown
# /pharmacorp_website/README.md
PharmaCorp Commercial Website
=============================

This is the complete codebase for the PharmaCorp Commercial Website, built according to the provided user stories and high-level design document.

## Tech Stack

*   **Backend:** Python 3.10+ with FastAPI
*   **Database:** PostgreSQL
*   **Frontend:** HTML5, CSS3, Vanilla JavaScript (ES6)
*   **Templating:** Jinja2
*   **Containerization:** Docker & Docker Compose
*   **Reverse Proxy:** Nginx

## Features Implemented

This application covers all user stories from PCW-001 to PCW-016, including:

*   **Core Pages:** Homepage, About Us, Contact Us, Privacy Policy, Terms of Use.
*   **Product Hub:** Product Listing and Detail pages with sticky Important Safety Information (ISI).
*   **User Engagement:** AJAX-powered Contact Form and Newsletter Signup.
*   **Search:** Full-text search functionality across products and pages.
*   **Compliance:** Cookie consent banner and accessible design (WCAG 2.2 AA principles).
*   **NFRs:** Responsive design, performance considerations, and security headers.

## How to Run the Application

### Prerequisites

*   Docker
*   Docker Compose

### Steps

1.  **Clone the repository.**

2.  **Create an environment file:**
    Copy the example environment file to a new `.env` file.
    ```bash
    cp .env.example .env
    ```
    You can modify the values in `.env` if needed, but the defaults are configured to work with Docker Compose.

3.  **Build and run the services using Docker Compose:**
    From the root of the project (`/pharmacorp_website`), run:
    ```bash
    docker-compose up --build
    ```
    This command will:
    *   Build the Docker image for the FastAPI application.
    *   Start containers for the application, the PostgreSQL database, and the Nginx reverse proxy.
    *   The application will be accessible at `http://localhost:8080`.

4.  **Seed the database (First Run Only):**
    The application will automatically seed the database with initial data on startup if the tables are empty. This includes creating pages, products, and other necessary content to make the website fully functional. You can monitor the Docker logs to see this process.

5.  **Access the Website:**
    Open your web browser and navigate to `http://localhost:8080`.

### Running Tests

To run the unit and integration tests, execute the following command in the project's root directory:

```bash
docker-compose exec web pytest
```

## Project Structure

```
/pharmacorp_website/
├── app/                  # Main application source code
│   ├── api/              # API endpoints and schemas
│   ├── core/             # Configuration and security
│   ├── crud/             # Database create, read, update, delete logic
│   ├── db/               # Database models, session, and seeding
│   ├── pages/            # Server-side rendered page routes
│   ├── static/           # CSS, JavaScript, images
│   ├── templates/        # Jinja2 HTML templates
│   └── main.py           # FastAPI application entrypoint
├── tests/                # Pytest tests
├── .env                  # Local environment variables (you create this)
├── .env.example          # Example environment variables
├── .gitignore
├── docker-compose.yml    # Docker Compose configuration
├── Dockerfile            # Dockerfile for the Python application
├── nginx.conf            # Nginx configuration
├── README.md             # This file
└── requirements.txt      # Python dependencies
```

## Notes on HLD Implementation

*   **Rate Limiting (PCW-009):** Implemented in `nginx.conf` using `limit_req_zone` and `limit_req`, as specified in the HLD.
*   **Object Storage (PCW-008):** For this runnable example, the Prescribing Information PDF is served from the `/static` directory. In a real-world scenario, the `product.pi_url` would be a pre-signed URL generated on-demand from a cloud object store like AWS S3.
*   **Search (PCW-011):** Implemented using PostgreSQL's native Full-Text Search capabilities. Database triggers automatically update the search vectors when content changes.
```
```markdown
# /pharmacorp_website/Dockerfile
# Use an official Python runtime as a parent image
FROM python:3.10-slim

# Set the working directory in the container
WORKDIR /usr/src/app

# Set environment variables
ENV PYTHONDONTWRITEBYTECODE 1
ENV PYTHONUNBUFFERED 1

# Install dependencies
COPY requirements.txt ./
RUN pip install --no-cache-dir -r requirements.txt

# Copy the rest of the application code
COPY ./app /usr/src/app/app

# Expose the port the app runs on
EXPOSE 8000

# Command to run the application
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
```
```markdown
# /pharmacorp_website/docker-compose.yml
version: '3.8'

services:
  web:
    build: .
    command: uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
    volumes:
      - ./app:/usr/src/app/app
    ports:
      - "8000:8000"
    env_file:
      - .env
    depends_on:
      - db

  db:
    image: postgres:14
    volumes:
      - postgres_data:/var/lib/postgresql/data/
    env_file:
      - .env
    ports:
      - "5432:5432"

  nginx:
    image: nginx:1.21
    ports:
      - "8080:80"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./app/static:/usr/src/app/static
    depends_on:
      - web

volumes:
  postgres_data:
```