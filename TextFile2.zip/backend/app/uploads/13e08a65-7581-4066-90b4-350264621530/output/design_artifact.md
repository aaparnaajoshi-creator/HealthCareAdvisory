```markdown
# High-Level Design: Pharma Inc. Corporate Website

## 1. Architecture
A simple client-server architecture will be used. A Python Flask backend will serve static HTML/CSS/JS files and provide a single API endpoint for the contact form. This lightweight approach is suitable for a low-traffic corporate website.

## 2. Components

### Frontend
-   **index.html:** The main landing page.
-   **about.html:** Company information page.
-   **products.html:** Product listing page.
-   --[**contact.html:** Contact form and details page.]--
    --[**contact.html:** Contact page containing a form with Name, Email, and Message fields (all required), and displaying the company's contact email address (contact@pharma-inc.com) in the footer.]--
    ++[**contact.html:** Contact page containing a form with Name, Email, and Message fields (all required), and displaying the company's contact email address (contact@pharma-inc.com) as a clickable mailto link in the footer.]++
-   **css/style.css:** Shared stylesheet for a consistent look and feel.
-   --[**js/main.js:** JavaScript for handling the contact form submission.]--
    ++[**js/main.js:** JavaScript for handling client-side form validation (e.g., required fields) and submission of the contact form.]++

### Backend (`app.py`)
-   A Python Flask application.
-   Serves the static HTML pages from the root and static assets from their respective folders.
-   Provides a single API endpoint: `POST /api/contact`.

## 3. API Specification

### `POST /api/contact`
-   --[**Description:** Receives user inquiries from the contact form.]--
    --[**Description:** Receives user inquiries from the contact form.]--
    ++[**Description:** Receives user inquiries from the contact form. All fields (name, email, message) are required.]++
-   **Request Body (JSON):**
    ```json
    {
      "name": "string",
      "email": "string (email format)",
      "message": "string"
    }
    ```
-   **Success Response (200 OK):**
    ```json
    {
      "message": "Your inquiry has been sent!"
    }
    ```
-   --[**Error Response (400 Bad Request):**]--
    --[**Error Response (400 Bad Request):** Indicates invalid data provided.]--
    ++[**Error Response (400 Bad Request):** Indicates invalid data provided, e.g., missing required fields or incorrect format.]++
    ```json
    {
      "error": "Invalid data provided."
    }
    ```
-   **Internal Logic:** The endpoint will receive the form data and send it to the hardcoded email address: `contact@pharma-inc.com`.

## 4. Technology Stack
-   **Frontend:** HTML5, CSS3, Vanilla JavaScript
-   **Backend:** Python 3, Flask
```