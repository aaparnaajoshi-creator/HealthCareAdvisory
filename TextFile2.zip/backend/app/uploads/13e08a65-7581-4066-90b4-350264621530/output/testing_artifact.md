```markdown
Test Plan: Corporate Website
1. Test Strategy
Manual testing will be performed across major browsers (Chrome, Firefox) to verify the functionality of all pages. The focus will be on navigation, content display, and form submission, including validation.
Automated tests will supplement manual testing for core functionalities like navigation, page content, and form interactions.

2. Test Cases
TC-HOME-001:
Description: Verify that the Home page displays the correct heading and mission statement.
Steps: 1. Load the home page.
Expected Result: The main heading is "Welcome to Pharma Inc." and a mission statement is clearly visible.
TC-HOME-002:
Description: Verify the Home page loads within the specified performance criteria.
Steps: 1. Load the home page and record load time.
Expected Result: The page loads in under 3 seconds.

TC-NAV-001:
Description: Verify that the main navigation links on the home page work correctly.
Steps: 1. Load the home page. 2. Click on each link in the navigation bar.
Expected Result: Each link navigates to the correct page (/about, /products, /contact) and the page title is correct for each page (e.g., "About - Pharma Inc." for About Us).

TC-ABOUT-001:
Description: Verify that the "About Us" page contains the required sections.
Steps: 1. Navigate to the "About Us" page.
Expected Result: The page contains distinct sections for "Our History" and "Our Values".

TC-PRODUCTS-001:
Description: Verify that the "Products" page displays a list of products with descriptions.
Steps: 1. Navigate to the "Products" page.
Expected Result: The page displays a bulleted list with at least three products, each having a brief description.

TC-CONTENT-001:
Description: Verify that the content on all pages displays correctly.
Steps: 1. Navigate to each page. 2. Check for text, headings, and lists.
Expected Result: All static content is present and legible as per the requirements.

TC-CONTACT-001:
Description: Verify that the contact email address is correct.
Steps: 1. Navigate to the Contact Us page. 2. Locate the footer section.
Expected Result: The email "--[contact@pharma-inc.com]--++inquiries@pharma-corp.com++" is displayed and is a clickable mailto: link.

TC-CONTACT-002 (Positive):
Description: Verify successful form submission with valid data.
Steps: 1. Fill all form fields with valid data. 2. Click "Send."
Expected Result: A successful form submission must trigger a POST request to the /api/contact endpoint. A success message is displayed, and the form fields are cleared.

TC-CONTACT-003 (Negative):
Description: Verify that the form cannot be submitted with an empty required field.
Steps: 1. Leave the "Name" field blank. 2. Fill other fields. 3. Click "Send."
Expected Result: The form does not submit. An HTML5 validation message appears.
TC-CONTACT-004 (Negative):
Description: Verify that all contact form fields are marked as required.
Steps: 1. Navigate to the Contact Us page. 2. Inspect the "Name", "Email", and "Message" fields.
Expected Result: All three fields ("Name", "Email", "Message") have the `required` HTML attribute.
++TC-CONTACT-005:++
++Description: Verify that a successful form submission triggers the backend to send an inquiry notification to the correct email address.++
++Steps: 1. Submit the contact form with valid data. 2. (Requires backend access/mocking) Verify that an email is sent to inquiries@pharma-corp.com containing the submitted inquiry details.++
++Expected Result: An email notification is successfully sent to inquiries@pharma-corp.com.++

---
# test_contact_page.py

import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

# --- Test Setup ---

@pytest.fixture
def browser():
    """Initializes and quits the browser for each test function."""
    driver = webdriver.Chrome()
    driver.implicitly_wait(10)
    yield driver
    driver.quit()

# --- Test Cases ---

def test_home_page_content(browser):
    """
    Test Case TC-HOME-001: Verify that the Home page displays the correct heading and mission statement.
    Test Case TC-HOME-002: Verify the Home page loads within the specified performance criteria (basic check).
    """
    start_time = time.time()
    browser.get("http://127.0.0.1:5000/")
    end_time = time.time()
    load_time = end_time - start_time

    # Verify heading
    heading = browser.find_element(By.TAG_NAME, "h1")
    assert heading.text == "Welcome to Pharma Inc."

    # Verify mission statement (assuming it's in a paragraph or div with a specific class)
    # This might need adjustment based on actual HTML structure, assuming a div with class 'mission-statement'
    mission_statement = browser.find_element(By.CLASS_NAME, "mission-statement") 
    assert len(mission_statement.text) > 20, "Mission statement is empty or too short."

    # Basic performance check
    assert load_time < 3.0, f"Home page loaded in {load_time:.2f} seconds, which is over 3 seconds."


def test_page_titles(browser):
    """
    Test Case TC-NAV-001: Verify that the main navigation links work correctly
    and lead to pages with the correct titles.
    """
    base_url = "http://127.0.0.1:5000"
    pages = {
        "/": "Pharma Inc. - Home",
        "/about": "About - Pharma Inc.",
        "/products": "Products - Pharma Inc.",
        "/contact": "Contact - Pharma Inc."
    }

    for path, title in pages.items():
        browser.get(base_url + path)
        assert title in browser.title

def test_about_page_content(browser):
    """
    Test Case TC-ABOUT-001: Verify that the "About Us" page contains the required sections.
    """
    browser.get("http://127.0.0.1:5000/about")

    # Check for "Our History" section (assuming h2 or h3 heading)
    history_heading = WebDriverWait(browser, 10).until(
        EC.presence_of_element_located((By.XPATH, "//h2[contains(text(), 'Our History')]"))
    )
    assert history_heading.is_displayed()

    # Check for "Our Values" section
    values_heading = WebDriverWait(browser, 10).until(
        EC.presence_of_element_located((By.XPATH, "//h2[contains(text(), 'Our Values')]"))
    )
    assert values_heading.is_displayed()

def test_products_page_content(browser):
    """
    Test Case TC-PRODUCTS-001: Verify that the "Products" page displays a list of products with descriptions.
    """
    browser.get("http://127.0.0.1:5000/products")

    # Check for a bulleted list (ul element)
    product_list = WebDriverWait(browser, 10).until(
        EC.presence_of_element_located((By.TAG_NAME, "ul"))
    )
    assert product_list.is_displayed()

    # Check for at least three list items (li elements) within the list
    list_items = product_list.find_elements(By.TAG_NAME, "li")
    assert len(list_items) >= 3, f"Expected at least 3 products, but found {len(list_items)}."

    # Check that each list item has a brief description (e.g., text content is reasonably long)
    for item in list_items:
        assert len(item.text) > 10, f"Product item '{item.text}' does not seem to have a description."

def test_contact_email_display(browser):
    """
    Test Case TC-CONTACT-001: Verify that the contact email address is displayed correctly.
    """
    browser.get("http://127.0.0.1:5000/contact")
    
    email_link = WebDriverWait(browser, 10).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, "footer a"))
    )
    
    assert email_link.text == "--[contact@pharma-inc.com]--++inquiries@pharma-corp.com++"
    assert email_link.get_attribute("href") == "--[mailto:contact@pharma-inc.com]--++mailto:inquiries@pharma-corp.com++"

def test_contact_form_submission_success(browser):
    """
    Test Case TC-CONTACT-002 (Positive): Verify successful form submission with valid data.
    """
    browser.get("http://127.0.0.1:5000/contact")
    
    # Fill out the form
    browser.find_element(By.ID, "name").send_keys("John Doe")
    browser.find_element(By.ID, "email").send_keys("john.doe@example.com")
    browser.find_element(By.ID, "message").send_keys("This is a test inquiry.")
    
    # Submit the form
    browser.find_element(By.CSS_SELECTOR, "button[type='submit']").click()
    
    # Wait for the success message
    success_message = WebDriverWait(browser, 10).until(
        EC.text_to_be_present_in_element((By.ID, "form-status"), "Your inquiry has been sent!")
    )
    assert success_message

def test_contact_form_submission_failure(browser):
    """
    Test Case TC-CONTACT-003 (Negative): Verify form does not submit with an empty required field.
    """
    browser.get("http://127.0.0.1:5000/contact")
    
    # Leave name field blank
    browser.find_element(By.ID, "email").send_keys("jane.doe@example.com")
    browser.find_element(By.ID, "message").send_keys("This is another test.")
    
    # Submit the form
    browser.find_element(By.CSS_SELECTOR, "button[type='submit']").click()
    
    # Check that the success message does not appear within a short timeout
    --time.sleep(1)-- 
    try:
        WebDriverWait(browser, 2).until(
            EC.text_to_be_present_in_element((By.ID, "form-status"), "Your inquiry has been sent!")
        )
        assert False, "Success message appeared when it shouldn't have for missing required field."
    except Exception: # Catch any exception, including TimeoutException
        assert True # Success message did not appear, which is expected

def test_contact_form_required_attributes(browser):
    """
    Test Case TC-CONTACT-004 (Negative): Verify that all contact form fields are marked as required.
    """
    browser.get("http://127.0.0.1:5000/contact")

    name_field = browser.find_element(By.ID, "name")
    email_field = browser.find_element(By.ID, "email")
    message_field = browser.find_element(By.ID, "message")

    assert name_field.get_attribute("required") == "true", "Name field is not marked as required."
    assert email_field.get_attribute("required") == "true", "Email field is not marked as required."
    assert message_field.get_attribute("required") == "true", "Message field is not marked as required."