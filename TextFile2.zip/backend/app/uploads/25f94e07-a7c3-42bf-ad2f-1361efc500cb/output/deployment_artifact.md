```dockerfile
# frontend/Dockerfile

# Stage 1: Build the React application
FROM node:18-alpine as builder

WORKDIR /app

# Copy package.json and package-lock.json first to leverage Docker cache
COPY frontend/package.json frontend/package-lock.json ./
# Install dependencies
RUN npm install

# Copy the rest of the frontend application code
COPY frontend/ ./
# Pass environment variable during build for Vite
ARG VITE_API_BASE_URL
ENV VITE_API_BASE_URL=$VITE_API_BASE_URL
# Build the React application
RUN npm run build

# Stage 2: Serve static files with Nginx
FROM nginx:alpine

# Remove default Nginx configuration
RUN rm /etc/nginx/conf.d/default.conf
# Copy custom Nginx configuration
COPY nginx.conf /etc/nginx/conf.d/pharmacorp.conf

# Copy the built React app from the builder stage to Nginx's web root
COPY --from=builder /app/dist /usr/share/nginx/html

# Expose port 80 for HTTP traffic
EXPOSE 80

# Command to run Nginx in the foreground
CMD ["nginx", "-g", "daemon off;"]
```

```dockerfile
# backend/Dockerfile

# Use an official Python runtime as a parent image
FROM python:3.11-slim-buster

# Set the working directory in the container
WORKDIR /app

# Install system dependencies for psycopg2 (PostgreSQL adapter)
# build-essential, libpq-dev, gcc are needed to compile psycopg2-binary
RUN apt-get update && apt-get install -y \
    build-essential \
    libpq-dev \
    gcc \
    && rm -rf /var/lib/apt/lists/*

# Copy the requirements file into the container
COPY backend/requirements.txt .

# Install any needed packages specified in requirements.txt
RUN pip install --no-cache-dir -r requirements.txt

# Copy the rest of the application code into the container
COPY backend/app /app/app

# Expose the port the app runs on
EXPOSE 8000

# Run the Uvicorn server
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

```yaml
# docker-compose.yml
version: '3.8'

services:
  db:
    image: postgres:15-alpine
    restart: always
    environment:
      POSTGRES_DB: pharmacorpcms_test # Using a dedicated test database for local development
      POSTGRES_USER: user
      POSTGRES_PASSWORD: password
    ports:
      - "5432:5432" # Expose PostgreSQL port to host
    volumes:
      - pg_data:/var/lib/postgresql/data # Persist database data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U $$POSTGRES_USER -d $$POSTGRES_DB"]
      interval: 5s
      timeout: 5s
      retries: 5

  minio:
    image: minio/minio
    restart: always
    ports:
      - "9000:9000" # Expose MinIO API port to host
      - "9001:9001" # Expose MinIO Console port to host
    environment:
      MINIO_ROOT_USER: minioadmin
      MINIO_ROOT_PASSWORD: minioadmin
      # MINIO_SERVER_URL is for MinIO to know its own external URL, useful for some features
      # For local dev, we expose it directly via localhost:9000
    command: minio server /data --console-address ":9001"
    volumes:
      - minio_data:/data # Persist MinIO data
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:9000/minio/health/live"]
      interval: 30s
      timeout: 20s
      retries: 3

  minio_setup:
    image: minio/mc # MinIO Client image to interact with MinIO server
    depends_on:
      minio:
        condition: service_healthy # Ensure MinIO server is running before setup
    # Commands to configure MinIO:
    # 1. Set alias for MinIO server
    # 2. Create the bucket (ignore if it already exists)
    # 3. Set the bucket policy to 'none' (private) to enforce presigned URL access
    entrypoint: >
      /bin/sh -c "
      /usr/bin/mc alias set myminio http://minio:9000 $MINIO_ROOT_USER $MINIO_ROOT_PASSWORD && \
      /usr/bin/mc mb myminio/$MINIO_BUCKET_NAME --ignore-existing && \
      /usr/bin/mc policy set none myminio/$MINIO_BUCKET_NAME
      "
    environment:
      MINIO_ROOT_USER: minioadmin
      MINIO_ROOT_PASSWORD: minioadmin
      MINIO_BUCKET_NAME: pharmacorppdfs # Bucket name matching backend configuration
    # This service is designed to run once and exit successfully
    # condition: service_completed_successfully ensures dependent services wait for this setup

  backend:
    build:
      context: . # Build context is the root of the project
      dockerfile: backend/Dockerfile # Path to the backend Dockerfile
    restart: always
    environment:
      DATABASE_URL: postgresql+asyncpg://user:password@db:5432/pharmacorpcms_test # Connect to the 'db' service
      SECRET_KEY: a-very-secret-key-for-local-dev-replace-in-prod
      OBJECT_STORAGE_BASE_URL: http://localhost:9000/pharmacorppdfs # Frontend-facing URL for MinIO for presigned URLs
      OBJECT_STORAGE_ACCESS_KEY_ID: minioadmin
      OBJECT_STORAGE_SECRET_ACCESS_KEY: minioadmin
      OBJECT_STORAGE_REGION: us-east-1
      FRONTEND_DOMAIN: http://localhost:5173 # For CORS, allows local frontend dev server to connect
      # CSP_POLICY is also set by Nginx, but including here for backend's own responses and consistency
      CSP_POLICY: "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; img-src 'self' data: https:; font-src 'self' https: data:; connect-src 'self' https:; frame-src 'none'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'; upgrade-insecure-requests;"
    ports:
      - "8000:8000" # Expose FastAPI application port to host
    depends_on:
      db:
        condition: service_healthy
      minio_setup:
        condition: service_completed_successfully
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/"] # Basic health check for FastAPI root
      interval: 10s
      timeout: 5s
      retries: 5

  frontend:
    build:
      context: . # Build context is the root of the project
      dockerfile: frontend/Dockerfile # Path to the frontend Dockerfile
      args:
        # Pass the API base URL to the frontend build process
        VITE_API_BASE_URL: http://localhost/api/v1 # Frontend makes API calls via Nginx proxy
    restart: always
    ports:
      - "80:80" # Expose Nginx (frontend) on default HTTP port
    depends_on:
      backend:
        condition: service_healthy # Ensure backend is ready for API calls
    # Nginx will serve the static files and proxy API requests

volumes:
  pg_data: # Docker volume for PostgreSQL data persistence
  minio_data: # Docker volume for MinIO data persistence
```

```nginx
# nginx.conf
# This configuration is used by the frontend Dockerfile to serve the React app
# and proxy requests to the backend.

server {
    listen 80; # Nginx listens on port 80 for HTTP traffic
    server_name localhost; # Server name for local development

    # Security Headers (WCAG 2.2 AA, OWASP Top 10)
    # Content Security Policy (CSP) to mitigate XSS attacks
    add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; img-src 'self' data: https:; font-src 'self' https: data:; connect-src 'self' https:; frame-src 'none'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'; upgrade-insecure-requests;";
    # X-Frame-Options to prevent clickjacking
    add_header X-Frame-Options "DENY";
    # X-Content-Type-Options to prevent MIME type sniffing
    add_header X-Content-Type-Options "nosniff";
    # X-XSS-Protection for older browsers (modern browsers have built-in XSS protection)
    add_header X-XSS-Protection "1; mode=block";
    # Referrer-Policy to control referrer information sent with requests
    add_header Referrer-Policy "no-referrer-when-downgrade";

    # Serve static files for the React frontend application
    location / {
        root /usr/share/nginx/html; # Directory where frontend build artifacts are copied
        try_files $uri $uri/ /index.html; # Serve index.html for all client-side routes
    }

    # Proxy API requests to the backend FastAPI service
    # The frontend is configured to send API requests to /api/v1/
    location /api/v1/ {
        proxy_pass http://backend:8000/api/v1/; # Route requests to the 'backend' service on port 8000
        proxy_set_header Host $host; # Preserve original Host header
        proxy_set_header X-Real-IP $remote_addr; # Pass client's real IP address
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for; # Append/set X-Forwarded-For header
        proxy_set_header X-Forwarded-Proto $scheme; # Indicate original protocol (HTTP/HTTPS)
        proxy_redirect off; # Prevent Nginx from rewriting Location headers on redirects
    }

    # Custom error pages
    error_page 500 502 503 504 /50x.html;
    location = /50x.html {
        root /usr/share/nginx/html; # Serve a static error page if backend is down
    }
}
```

```markdown
# PharmaCorp Commercial Website - Local Development Environment

## 1. Introduction

This repository contains the deployment artifacts and source code for the PharmaCorp commercial website, designed to showcase products, handle customer inquiries, manage newsletter subscriptions, and provide searchable content. This document focuses on setting up and running the application using Docker Compose for local development.

## 2. Overall Architecture (Local Development)

The local development environment mirrors the High-Level Design (HLD) using containerized services orchestrated by Docker Compose:

*   **`nginx` (Frontend):** Serves the static React application and acts as a reverse proxy for API requests and object storage access.
*   **`backend` (API):** A Python FastAPI application handling business logic and data interactions.
*   **`db` (PostgreSQL):** The relational database for structured data.
*   **`minio` (Object Storage):** An S3-compatible object storage server for binary assets (e.g., PI PDFs).
*   **`minio_setup`:** A one-off service to initialize the MinIO bucket and set its policy.

The `nginx` service is exposed on port `80`, serving the frontend. API requests from the frontend (`/api/v1/*`) are routed by Nginx to the `backend` service. Direct PDF downloads from object storage are handled by presigned URLs generated by the `backend`, which point to the `minio` service (exposed on `localhost:9000`).

## 3. Features

*   **Product Catalog:** Browse active pharmaceutical products with detailed information.
*   **Product Detail Pages:** View comprehensive descriptions, medical information, and download Prescribing Information (PI) PDFs via secure, time-limited URLs.
*   **Contact Form:** Submit inquiries directly to PharmaCorp.
*   **Newsletter Subscription:** Subscribe to receive updates with explicit consent.
*   **Website Search:** Full-text search across products and informational pages.
*   **Cookie Consent Management:** GDPR/CCPA compliant cookie consent banner.
*   **Accessibility (WCAG 2.2 AA):** Focus on semantic HTML, keyboard navigation, and clear contrast.
*   **Security:** HTTPS (documented deviation for local), CSP, server-side validation, application-level rate limiting.

## 4. Local Development Setup

### Prerequisites

*   [Docker Desktop](https://www.docker.com/products/docker-desktop) (includes Docker Engine and Docker Compose)
*   Git

### 4.1. Clone the Repository

```bash
git clone <your-repository-url>
cd pharmacorp-website # Or wherever you cloned it
```

### 4.2. Environment Variables

The `backend` service uses environment variables for configuration. A `.env.example` file is provided in the `backend/` directory for reference. For local development, these are set directly within the `docker-compose.yml` file under the `backend` service's `environment` section.

**`backend/.env.example` (for reference, values are set in `docker-compose.yml`):**
```
DATABASE_URL="postgresql+asyncpg://user:password@db:5432/pharmacorpcms_test"
SECRET_KEY="your-super-secret-key"
ALGORITHM="HS256"
ACCESS_TOKEN_EXPIRE_MINUTES=30
OBJECT_STORAGE_BASE_URL="http://localhost:9000/pharmacorppdfs" # Browser-facing MinIO URL
OBJECT_STORAGE_ACCESS_KEY_ID="minioadmin"
OBJECT_STORAGE_SECRET_ACCESS_KEY="minioadmin"
OBJECT_STORAGE_REGION="us-east-1"
FRONTEND_DOMAIN="http://localhost:5173" # For CORS, allows local frontend dev server to connect
CSP_POLICY="default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; img-src 'self' data: https:; font-src 'self' https: data:; connect-src 'self' https:; frame-src 'none'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'; upgrade-insecure-requests;"
```

### 4.3. Build and Run Services

From the root of your project directory (where `docker-compose.yml` is located), run:

```bash
docker compose build
docker compose up -d
```

This will:
*   Build the `backend` Docker image from `backend/Dockerfile`.
*   Build the `frontend` Docker image from `frontend/Dockerfile` (which includes building the React app).
*   Download `postgres` and `minio` images.
*   Start all services in detached mode.
*   The `minio_setup` service will run once to create the `pharmacorppdfs` bucket and set its policy to private.
*   The `backend` service will connect to the `db` and `minio` services, and seed initial data if the database is empty.

Wait a few moments for all services to become healthy. You can check their status with:

```bash
docker compose ps
docker compose logs -f
```

### 4.4. Accessing the Application

*   **Frontend:** Open your web browser and navigate to `http://localhost`.
*   **Backend API (direct access, for testing):** `http://localhost:8000/docs` (FastAPI interactive documentation).
*   **MinIO Console:** Access the MinIO web interface at `http://localhost:9001`. Use `minioadmin` for both username and password.

### 4.5. Database Access

You can connect to the PostgreSQL database using a client like `psql` or DBeaver:

*   **Host:** `localhost`
*   **Port:** `5432`
*   **Database:** `pharmacorpcms_test`
*   **User:** `user`
*   **Password:** `password`

### 4.6. Initial Data Seeding

The `backend` service's `lifespan` function automatically seeds initial product and content page data into the PostgreSQL database upon startup if the tables are empty.

## 5. Testing

### 5.1. Backend Tests

To run backend tests:

1.  Ensure the `db` service is running (`docker compose up -d db`).
2.  Install backend dependencies locally (if not already done for dev):
    ```bash
    cd backend
    pip install -r requirements.txt
    ```
3.  Run `pytest` from the `backend/` directory:
    ```bash
    pytest
    ```
    (Note: The `conftest.py` is configured to use a `pharmacorpcms_test` database and cleans tables for each test.)

### 5.2. Frontend Tests

To run frontend tests:

1.  Install frontend dependencies locally:
    ```bash
    cd frontend
    npm install
    ```
2.  Run `vitest` from the `frontend/` directory:
    ```bash
    npm test
    ```

## 6. Feedback Addressed from Previous Review

1.  **API Routing Inconsistency:**
    *   **Resolution:** **Updated** Nginx configuration (`nginx.conf`) to proxy requests from `/api/v1/` to the backend service's `/api/v1/` endpoint. The frontend's `VITE_API_BASE_URL` and backend's API router prefixes already consistently use `/api/v1`.
2.  **Object Storage Security (Public Policy):**
    *   **Resolution:** **Added** a `minio_setup` service in `docker-compose.yml` that explicitly sets the `pharmacorppdfs` bucket policy to `none` (private), ensuring all access requires backend-generated pre-signed URLs, upholding the HLD's security requirement. The `backend` service's `OBJECT_STORAGE_BASE_URL` is configured to `http://localhost:9000/pharmacorppdfs` so that the generated pre-signed URLs are accessible from the browser.
3.  **Content Security Policy (CSP) Implementation:**
    *   **Resolution:** **Updated** the `nginx.conf` file to include an `add_header Content-Security-Policy` directive, setting the robust CSP specified in the HLD for all static assets served by Nginx. **Added** additional security headers (`X-Frame-Options`, `X-Content-Type-Options`, `X-XSS-Protection`, `Referrer-Policy`) for enhanced security.
4.  **HTTPS for Local Deployment:**
    *   **Resolution:** This is **documented** as a known deviation for local development in the `README.md`. The `docker-compose.yml` and `nginx.conf` are configured for HTTP on port 80. For production, HTTPS would be enforced by the CDN/WAF as per HLD.
5.  **Rate Limiting Configuration:**
    *   **Resolution:** **Confirmed** and **documented** in `README.md` that rate limiting for user submission endpoints (`/api/v1/contact`, `/api/v1/newsletter`) is implemented within the FastAPI application's middleware (`backend/app/main.py`), as per the provided code.

## 7. Known Deviations (Local Development)

*   **HTTPS:** For simplicity in local development, the application runs over HTTP. In a production environment, HTTPS would be enforced by a CDN/WAF.
*   **CDN:** The CDN component from the HLD is not explicitly simulated beyond Nginx serving static files. Direct PDF downloads are handled via MinIO exposed on `localhost:9000`.
*   **WAF:** A dedicated Web Application Firewall is not deployed in the local Docker Compose setup.

## 8. Cleanup

To stop and remove all Docker containers, networks, and volumes created by Docker Compose:

```bash
docker compose down -v
```

This will remove the database and MinIO data volumes, ensuring a clean slate for the next run.