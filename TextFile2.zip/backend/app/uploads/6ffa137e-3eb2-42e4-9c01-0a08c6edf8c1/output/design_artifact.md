# High-Level Design (HLD): PharmaCorp Commercial Website

**Version:** 1.0
**Date:** 2023-10-27
**Author:** Solutions Architect

---

## 1. Introduction

### 1.1. Purpose
This document provides a comprehensive high-level architectural design for the PharmaCorp commercial website. The system is designed to serve as an informational portal for patients and Healthcare Professionals (HCPs), providing details about the company, its products, and offering channels for communication.

### 1.2. Scope
The scope of this design covers the public-facing website as defined by the user stories. This includes:
*   Core informational pages (Homepage, About Us, Legal).
*   Product listing and detail pages.
*   User engagement features (Contact Form, Newsletter Signup).
*   Site-wide utilities (Search, Cookie Consent).
*   Backend services to support these features.
*   The underlying infrastructure, data models, and API contracts.

Out of scope for this document are the internal content management system (CMS) administration interface and third-party marketing automation integrations beyond the initial data capture.

### 1.3. Definitions and Acronyms
*   **HLD:** High-Level Design
*   **SRS:** Software Requirements Specification (User Stories)
*   **HCP:** Healthcare Professional
*   **PI:** Prescribing Information
*   **ISI:** Important Safety Information
*   **WCAG:** Web Content Accessibility Guidelines
*   **LCP:** Largest Contentful Paint
*   **CDN:** Content Delivery Network
*   **API:** Application Programming Interface
*   **CSP:** Content-Security-Policy
*   **CI/CD:** Continuous Integration / Continuous Deployment

---

## 2. Architecture Overview

A **Decoupled Frontend + Monolithic API** architecture is selected for this project. This model provides a clear separation of concerns between the presentation layer (frontend) and the business logic/data layer (backend), aligning perfectly with the specified technical constraints.

*   **Frontend (Client-Side):** A static website built with vanilla **HTML5, CSS, and JavaScript**. It contains no server-side rendering logic. All pages are pre-built or dynamically populated with data fetched from the backend API. This approach is highly performant, secure, and scalable, as the static assets can be served globally from a CDN.

*   **Backend (Server-Side):** A single, monolithic API service built with **Python (FastAPI)**. This API is responsible for all server-side operations: serving content from the database, handling form submissions, and processing search queries. FastAPI is chosen for its high performance, built-in data validation via Pydantic, and automatic OpenAPI documentation.

*   **Database:** A **PostgreSQL** relational database will serve as the primary data store for all structured content, including page information, product details, and user submissions.

*   **Object Storage:** A cloud-based object store (e.g., AWS S3, Azure Blob Storage) will be used to store and serve large binary files, specifically the Product PI PDFs.

This architecture directly addresses the requirements for performance (LCP < 2.5s) by leveraging static site hosting via CDN, and for security by creating a clear boundary for the backend API which can be hardened and protected.

### 2.1. System Architecture Diagram

```mermaid
graph TD
    subgraph "User's Browser"
        A[User: Patient/HCP]
    end

    subgraph "Cloud Infrastructure (e.g., AWS, Azure)"
        B[CDN / WAF]
        C{Backend API (Python/FastAPI)}
        D[PostgreSQL Database]
        E[Object Storage for PDFs]
        F[Static Site Assets (HTML, JS, CSS)]

        B -- HTTPS --> F
        B -- HTTPS /api/* --> C
        C -- Reads/Writes --> D
        C -- Reads/Generates URLs --> E
    end

    A -- HTTPS --> B
    B -- Serves Static Content --> A
    B -- Proxies API Requests --> C
    A -- Fetches Data via JS --> B
    A -- Downloads PDF from signed URL --> E
```
*Figure 1: High-Level System Architecture*

---

## 3. System Components

### 3.1. Frontend Application
*   **Technology:** HTML5, CSS3, JavaScript (ES6+).
*   **Description:** A collection of static files. JavaScript will be used to fetch dynamic content (e.g., product lists, page content) from the Backend API on page load and to handle interactive elements like form submissions, the sticky ISI component, and the cookie banner.
*   **Responsibilities:**
    *   Rendering all UI components and pages.
    *   Ensuring a responsive layout for mobile, tablet, and desktop (US-1, 2, 4, 5).
    *   Meeting WCAG 2.2 AA accessibility standards (US-1, 2, 4, 5, 6).
    *   Handling client-side form validation.
    *   Managing the cookie consent state.
    *   Making asynchronous (AJAX) calls to the backend API.

### 3.2. Backend API
*   **Technology:** Python 3.10+ with the FastAPI framework.
*   **Description:** A RESTful API service that acts as the single gateway to the system's data and business logic.
*   **Responsibilities:**
    *   Provide secure, RESTful endpoints for content and data.
    *   Validate and sanitize all incoming data (US-12).
    *   Handle business logic for contact form and newsletter submissions (US-8, 9).
    *   Interface with the PostgreSQL database to store and retrieve data.
    *   Implement search functionality by querying the database (US-10).
    *   Enforce security measures like rate limiting on sensitive endpoints (US-8, 12).

### 3.3. Database
*   **Technology:** PostgreSQL.
*   **Description:** The primary persistence layer for structured data.
*   **Responsibilities:**
    *   Store content for pages (About Us, Legal, etc.).
    *   Store product information.
    *   Store submissions from the Contact Us and Newsletter forms (US-8, 9).
    *   Maintain indexes on searchable fields (e.g., product name, page title) to ensure efficient query performance (US-10).

### 3.4. Object Storage
*   **Technology:** Cloud-agnostic Object Storage (e.g., AWS S3, Azure Blob Storage).
*   **Description:** A highly durable and available storage service for unstructured data like PDF files.
*   **Responsibilities:**
    *   Securely store all Prescribing Information (PI) PDF documents (US-7).
    *   Serve these documents on demand, ideally through pre-signed URLs generated by the backend to ensure controlled access.

### 3.5. CDN & Security Layer
*   **Technology:** Cloud-agnostic CDN (e.g., AWS CloudFront, Cloudflare).
*   **Description:** A global network of edge locations used to cache and serve content closer to users, improving performance and providing a security layer.
*   **Responsibilities:**
    *   Cache and serve the static frontend assets (HTML, CSS, JS, images).
    *   Enforce HTTPS-only traffic via redirection (US-12).
    *   Serve as a Web Application Firewall (WAF) to protect against common attacks like DDoS.
    *   Set security headers like Content-Security-Policy (CSP) (US-12).
    *   Proxy API requests to the Backend API origin.

---

## 4. Data Model & Database Schema

The following tables will be created in the PostgreSQL database.

### 4.1. `pages`
Stores content for simple, static pages like "About Us", "Privacy Policy", etc.

| Column Name | Data Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | SERIAL | PRIMARY KEY | Unique identifier for the page. |
| `slug` | VARCHAR(255) | UNIQUE, NOT NULL | URL-friendly identifier (e.g., 'about-us'). |
| `title` | VARCHAR(255) | NOT NULL | The title of the page. |
| `content` | TEXT | NOT NULL | The main content of the page (HTML or Markdown). |
| `created_at` | TIMESTAMPZ | NOT NULL, DEFAULT NOW() | Timestamp of creation. |
| `updated_at` | TIMESTAMPZ | NOT NULL, DEFAULT NOW() | Timestamp of last update. |

### 4.2. `products`
Stores information about each pharmaceutical product.

| Column Name | Data Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | SERIAL | PRIMARY KEY | Unique identifier for the product. |
| `slug` | VARCHAR(255) | UNIQUE, NOT NULL | URL-friendly identifier for the product. |
| `name` | VARCHAR(255) | NOT NULL | The commercial name of the product. |
| `image_url` | VARCHAR(512) | | URL to the product's representative image. |
| `short_description` | TEXT | NOT NULL | A brief, one-sentence description for the listing page. |
| `long_description` | TEXT | | Detailed descriptive text for the detail page. |
| `isi_text` | TEXT | NOT NULL | The Important Safety Information text. |
| `created_at` | TIMESTAMPZ | NOT NULL, DEFAULT NOW() | Timestamp of creation. |
| `updated_at` | TIMESTAMPZ | NOT NULL, DEFAULT NOW() | Timestamp of last update. |

### 4.3. `product_documents`
Links products to their associated documents, like PI PDFs.

| Column Name | Data Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | SERIAL | PRIMARY KEY | Unique identifier for the document record. |
| `product_id` | INTEGER | FK to `products.id`, NOT NULL | The product this document belongs to. |
| `document_type` | VARCHAR(50) | NOT NULL | Type of document (e.g., 'PI'). |
| `storage_key` | VARCHAR(1024) | NOT NULL | The key/path to the file in object storage. |
| `created_at` | TIMESTAMPZ | NOT NULL, DEFAULT NOW() | Timestamp of upload. |

### 4.4. `contact_submissions`
Stores all submissions from the "Contact Us" form.

| Column Name | Data Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | SERIAL | PRIMARY KEY | Unique identifier for the submission. |
| `full_name` | VARCHAR(255) | NOT NULL | Submitter's full name. |
| `email` | VARCHAR(255) | NOT NULL | Submitter's email address. |
| `subject` | VARCHAR(255) | | Optional subject line. |
| `message` | TEXT | NOT NULL | The content of the message. |
| `submitted_at` | TIMESTAMPZ | NOT NULL, DEFAULT NOW() | Timestamp of submission. |

### 4.5. `newsletter_subscriptions`
Stores all email addresses subscribed to the newsletter.

| Column Name | Data Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | SERIAL | PRIMARY KEY | Unique identifier for the subscription. |
| `email` | VARCHAR(255) | UNIQUE, NOT NULL | Subscriber's email address. |
| `consent_given` | BOOLEAN | NOT NULL | Tracks if the user checked the consent box. |
| `subscribed_at` | TIMESTAMPZ | NOT NULL, DEFAULT NOW() | Timestamp of subscription. |

---

## 5. API Design (Contracts)

All endpoints will be prefixed with `/api/v1`.

### 5.1. Content Endpoints

#### `GET /pages/{slug}`
Fetches content for a specific static page.
*   **Parameters:**
    *   `slug` (path): The URL slug of the page (e.g., `about-us`).
*   **Success Response (200 OK):**
    ```json
    {
      "slug": "about-us",
      "title": "About Us",
      "content": "<h1>Our Mission</h1><p>...</p>",
      "updated_at": "2023-10-27T10:00:00Z"
    }
    ```
*   **Error Response (404 Not Found):**
    ```json
    { "detail": "Page not found" }
    ```

#### `GET /products`
Fetches a list of all products for the listing page.
*   **Success Response (200 OK):**
    ```json
    {
      "products": [
        {
          "slug": "product-a",
          "name": "Product A",
          "image_url": "https://cdn.example.com/product-a.jpg",
          "short_description": "A brief description of Product A."
        }
      ]
    }
    ```

#### `GET /products/{slug}`
Fetches detailed information for a single product.
*   **Parameters:**
    *   `slug` (path): The URL slug of the product.
*   **Success Response (200 OK):**
    ```json
    {
      "slug": "product-a",
      "name": "Product A",
      "image_urls": ["..."],
      "long_description": "<p>Detailed information...</p>",
      "isi_text": "Important Safety Information...",
      "pi_document_url": "https://storage.example.com/pi_product_a.pdf?sig=..."
    }
    ```
*   **Error Response (404 Not Found):**
    ```json
    { "detail": "Product not found" }
    ```

### 5.2. User Engagement Endpoints

#### `POST /contact`
Submits the contact form. This endpoint will be rate-limited.
*   **Request Body:**
    ```json
    {
      "fullName": "Jane Doe",
      "email": "jane.doe@example.com",
      "subject": "Inquiry",
      "message": "This is my message."
    }
    ```
*   **Success Response (201 Created):**
    ```json
    { "message": "Thank you for your message!" }
    ```
*   **Error Response (422 Unprocessable Entity):**
    ```json
    { "detail": "Validation Error: Please provide a valid email." }
    ```
*   **Error Response (429 Too Many Requests):**
    ```json
    { "detail": "Rate limit exceeded" }
    ```

#### `POST /newsletter`
Submits an email for newsletter subscription.
*   **Request Body:**
    ```json
    {
      "email": "john.doe@example.com",
      "consent": true
    }
    ```
*   **Success Response (201 Created):**
    ```json
    { "message": "Successfully subscribed!" }
    ```
*   **Error Response (422 Unprocessable Entity):**
    ```json
    { "detail": "Invalid email or consent not provided." }
    ```

### 5.3. Utility Endpoints

#### `GET /search`
Performs a site-wide search.
*   **Query Parameters:**
    *   `q` (string): The search query.
*   **Success Response (200 OK):**
    ```json
    {
      "query": "safety",
      "results": [
        {
          "title": "Product A",
          "url": "/products/product-a",
          "snippet": "...contains Important <b>Safety</b> Information..."
        },
        {
          "title": "Privacy Policy",
          "url": "/privacy-policy",
          "snippet": "We take the <b>safety</b> of your data very seriously..."
        }
      ]
    }
    ```
---

## 6. Key Workflows & Data Flow Diagrams

### 6.1. Product Detail Page Load
This workflow describes how a user views a product page, including its PI PDF link.

```mermaid
sequenceDiagram
    participant User
    participant Browser
    participant CDN
    participant BackendAPI
    participant ObjectStorage

    User->>Browser: Navigates to /products/product-a
    Browser->>CDN: GET /products/product-a.html
    CDN-->>Browser: Returns static HTML/CSS/JS shell
    Browser->>CDN: GET /api/v1/products/product-a
    CDN->>BackendAPI: Forwards request
    BackendAPI->>ObjectStorage: Generate pre-signed URL for PI PDF
    ObjectStorage-->>BackendAPI: Returns pre-signed URL
    BackendAPI-->>CDN: Returns product data + signed URL
    CDN-->>Browser: Returns JSON data
    Browser->>User: Renders page with product details and PI link
```

### 6.2. Contact Form Submission
This workflow shows the process of submitting the contact form, including validation and storage.

```mermaid
sequenceDiagram
    participant User
    participant Browser
    participant CDN
    participant BackendAPI
    participant Database

    User->>Browser: Fills and submits Contact Form
    Browser->>Browser: Performs client-side validation
    Browser->>CDN: POST /api/v1/contact (with form data)
    CDN->>BackendAPI: Forwards request
    BackendAPI->>BackendAPI: Applies Rate Limiting
    BackendAPI->>BackendAPI: Validates & sanitizes input data
    alt Input is valid
        BackendAPI->>Database: INSERT into contact_submissions
        Database-->>BackendAPI: Success
        BackendAPI-->>CDN: 201 Created response
        CDN-->>Browser: 201 Created response
        Browser->>User: Displays "Success" message
    else Input is invalid
        BackendAPI-->>CDN: 422 Unprocessable Entity
        CDN-->>Browser: 422 Unprocessable Entity
        Browser->>User: Displays inline error messages
    end
```

---

## 7. Non-Functional Requirements (NFRs)

### 7.1. Performance
*   **LCP under 2.5 seconds (US-1, US-5):** Achieved by:
    1.  Serving all static assets (HTML, CSS, JS, images) from a global CDN.
    2.  Optimizing images and using modern formats (e.g., WebP).
    3.  Keeping the initial JavaScript payload small.
    4.  Ensuring backend API response times are < 200ms via efficient database queries and indexing.

### 7.2. Security
*   **HTTPS Only (US-12):** The CDN or load balancer will be configured to redirect all HTTP traffic to HTTPS.
*   **Content-Security-Policy (CSP) (US-12):** A strict CSP header will be applied via the CDN or web server to prevent XSS by restricting the sources of scripts, styles, and other assets.
*   **Input Sanitization (US-12):** FastAPI's use of Pydantic models provides automatic request validation. Further sanitization will be applied to prevent SQL injection and other injection attacks.
*   **Rate Limiting (US-8, US-12):** A middleware (e.g., `slowapi`) will be implemented in the FastAPI application to limit requests to endpoints like `/contact` and `/newsletter` based on IP address.
*   **Secure Storage (US-7):** PI PDFs will be stored in a private object storage bucket. Access will be granted via short-lived, pre-signed URLs generated by the backend, preventing direct, unauthorized access.

### 7.3. Accessibility
*   **WCAG 2.2 AA Compliance (US-1, 2, 4, 5, 6):** This is primarily a frontend development concern. The design mandates that all HTML must be semantic, images must have `alt` attributes, color contrast ratios must be met, and the entire site must be navigable and usable via keyboard and screen readers.

### 7.4. Scalability & Availability
*   **Frontend:** The static site hosted on a CDN is inherently highly available and scalable.
*   **Backend:** The FastAPI application will be deployed as a containerized service. It can be scaled horizontally by increasing the number of container instances behind a load balancer to handle increased traffic.
*   **Database:** A managed PostgreSQL service (e.g., AWS RDS, Azure Database for PostgreSQL) will be used, which allows for easy scaling (read replicas, instance size changes) and provides high availability through failover configurations.

---

## 8. Deployment & CI/CD

A three-environment strategy (Development, Staging, Production) will be implemented.

*   **Source Control:** Git (e.g., on GitHub, GitLab).
*   **CI/CD Pipeline:** Automated using tools like GitHub Actions or Jenkins.

### 8.1. Frontend Deployment
1.  A developer pushes code to a feature branch.
2.  A pull request to the `main` or `develop` branch triggers the CI pipeline.
3.  The pipeline runs linters and tests on the JavaScript and CSS.
4.  On merge to `develop`, the pipeline deploys the static files to the **Staging** S3 bucket/CDN.
5.  On merge/tag to `main`, the pipeline deploys the static files to the **Production** S3 bucket/CDN.

### 8.2. Backend Deployment
1.  A developer pushes code to a feature branch.
2.  A pull request triggers the CI pipeline.
3.  The pipeline runs linters, unit tests, and integration tests for the Python code.
4.  On merge, the pipeline builds a Docker image, tags it, and pushes it to a container registry (e.g., AWS ECR).
5.  The pipeline then triggers a deployment of the new container image to the corresponding environment's container service (e.g., AWS App Runner, ECS). Database migrations will be run as a step in this deployment process.

---