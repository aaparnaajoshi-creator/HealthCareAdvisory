# High-Level Design (HLD): HubSpot Company to Customer DB Sync Service

## 1. Introduction

### 1.1. Purpose
This High-Level Design (HLD) document outlines the architecture and key components for the HubSpot Company to Customer Database Synchronization Service. The primary goal of this service is to automatically synchronize new Company records created in HubSpot CRM to an internal PostgreSQL customer database, ensuring data consistency and availability for internal systems.

### 1.2. Scope
The scope of this document covers the design of a MuleSoft System API deployed on CloudHub, including its API definition, data models, integration patterns, security mechanisms, error handling, and logging strategies, based on the provided user stories and technical constraints. This HLD does not cover detailed implementation specifics or low-level code design.

## 2. Architecture Overview

### 2.1. High-Level Architecture Description
The system architecture revolves around a MuleSoft System API deployed on CloudHub. This API acts as a secure webhook listener for HubSpot `company.creation` events. Upon receiving a webhook, the MuleSoft API validates its authenticity using the `X-HubSpot-Signature` header, transforms the HubSpot company data into an internal customer format, and then inserts this data as a new record into a PostgreSQL database. Comprehensive logging is integrated throughout the process, and a global error handler ensures that any critical failures trigger email notifications to IT administrators and detailed logging to Anypoint Monitoring.

### 2.2. Components
*   **HubSpot CRM**: The source system where new Company records are created. It sends webhook notifications for `company.creation` events.
*   **MuleSoft System API (CloudHub)**: The core integration component.
    *   **HTTP Listener**: Exposes the webhook endpoint.
    *   **Webhook Security Component**: Validates `X-HubSpot-Signature`.
    *   **Transformation Component (DataWeave 2.0)**: Maps HubSpot data to the internal customer database schema.
    *   **Database Connector**: Performs `INSERT` operations into the PostgreSQL database.
    *   **Email Connector**: Sends error notifications to IT administrators.
    *   **Logging Components**: Generates detailed logs for key events.
    *   **Global Error Handler**: Manages exceptions, logs errors, and triggers notifications.
*   **PostgreSQL Database**: The target internal customer database where synchronized company data is stored.
*   **Anypoint Monitoring**: MuleSoft's operational visibility tool for centralized logging, monitoring, and troubleshooting.
*   **IT Admins Email**: Recipients for critical error notifications.

### 2.3. Architecture Diagram

```mermaid
graph LR
    A[HubSpot CRM] -- company.creation webhook --> B(MuleSoft System API - CloudHub)
    B -- INSERT customer data --> C[PostgreSQL Database]
    B -- Logs/Metrics --> D[Anypoint Monitoring]
    B -- Error Notification (Email) --> E[IT Admins Email]
```

## 3. API Design

### 3.1. API Endpoint Definition (RAML 1.0)
The MuleSoft System API exposes a single HTTP POST endpoint to receive HubSpot webhook notifications. The API is defined using RAML 1.0.

```raml
#%RAML 1.0
title: HubSpot Company Sync API
version: v1
baseUri: /api/v1 # Placeholder. Actual base URI will be CloudHub-specific (e.g., http://app-name.region.cloudhub.io/api/v1)

/hubspot/company-creation:
  post:
    description: Receives webhook notifications from HubSpot for new company creations and initiates synchronization.
    headers:
      X-HubSpot-Signature:
        type: string
        required: true
        description: HMAC-SHA256 signature for webhook authenticity validation, generated using the HubSpot Client Secret.
    body:
      application/json:
        type: object
        properties:
          portalId: integer
          eventGroupId: integer
          objectId: integer # HubSpot Company ID
          subscriptionId: integer
          appId: integer
          occurredAt: datetime
          subscriptionType: string
          attemptNumber: integer
          objectType: string
          changeSource: string
          changeFlag: string
          eventId: integer
          properties: # Contains the actual company properties
            type: object
            properties:
              name: string
              domain: string
              createdate: string # ISO 8601 timestamp
              hs_object_id: string # HubSpot Company ID (redundant with objectId but often present here)
              # ... other potential HubSpot company properties relevant for future expansion
        example: |
          {
            "portalId": 62515,
            "eventGroupId": 1000,
            "objectId": 512,
            "subscriptionId": 123456789,
            "appId": 12345,
            "occurredAt": "2023-10-26T14:30:00.000Z",
            "subscriptionType": "company.creation",
            "attemptNumber": 1,
            "objectType": "COMPANY",
            "changeSource": "CRM",
            "changeFlag": "NEW",
            "eventId": 987654321,
            "properties": {
              "name": "Acme Corp",
              "domain": "acmecorp.com",
              "createdate": "2023-10-26T14:29:00.000Z",
              "hs_object_id": "512"
            }
          }
    responses:
      200:
        description: Webhook received and processed successfully.
        body:
          application/json:
            example: |
              {
                "status": "success",
                "message": "Company creation event received and processing initiated."
              }
      401:
        description: Unauthorized - Invalid or missing X-HubSpot-Signature.
        body:
          application/json:
            example: |
              {
                "status": "error",
                "message": "Invalid or missing X-HubSpot-Signature."
              }
      500:
        description: Internal Server Error - An unexpected error occurred during processing.
        body:
          application/json:
            example: |
              {
                "status": "error",
                "message": "An unexpected error occurred. Please contact support.",
                "transactionId": "abc-123"
              }

```

### 3.2. Request/Response Formats

*   **Request Format**: `application/json` (HubSpot webhook payload).
*   **Success Response (HTTP 200 OK)**:
    *   Content Type: `application/json`
    *   Body: `{ "status": "success", "message": "Company creation event received and processing initiated." }`
*   **Unauthorized Response (HTTP 401 Unauthorized)**:
    *   Content Type: `application/json`
    *   Body: `{ "status": "error", "message": "Invalid or missing X-HubSpot-Signature." }`
*   **Internal Server Error Response (HTTP 500 Internal Server Error)**:
    *   Content Type: `application/json`
    *   Body: `{ "status": "error", "message": "An unexpected error occurred. Please contact support.", "transactionId": "abc-123" }` (Transaction ID for traceability).

## 4. Data Model Design

### 4.1. HubSpot Company Data (Inferred Payload Structure)
The incoming HubSpot webhook payload for `company.creation` events will be a JSON object with the following key fields relevant for transformation:

*   `objectId`: The HubSpot internal ID of the created company.
*   `properties.name`: The name of the company.
*   `properties.domain`: The primary domain/website of the company.
*   `properties.hs_object_id`: (Often present) The HubSpot internal ID, mirroring `objectId`.
*   Other `properties` fields as required by specific data mapping (FR-002).

### 4.2. PostgreSQL Customer Database Schema
A single table `customers` will be created in the PostgreSQL database to store the synchronized company data.

```sql
CREATE TABLE customers (
    customer_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(), -- Unique identifier for the customer record
    hubspot_company_id   VARCHAR(255) UNIQUE NOT NULL,              -- HubSpot's internal company ID (Ensures no duplicate HubSpot companies)
    customer_name        VARCHAR(255) NOT NULL,                     -- Mapped from HubSpot 'name'
    website              VARCHAR(2048) NULL,                        -- Mapped from HubSpot 'domain', allowing for nulls
    created_at           TIMESTAMP WITH TIME ZONE DEFAULT NOW(),    -- Timestamp of record creation in DB
    updated_at           TIMESTAMP WITH TIME ZONE DEFAULT NOW()     -- Timestamp of last update (though only INSERT is currently supported)
);

-- Index for faster lookups if needed, though not explicitly required for this HLD
CREATE INDEX idx_hubspot_company_id ON customers (hubspot_company_id);
```

## 5. Data Flow

### 5.1. Detailed Flow Description
1.  **Receive Webhook**: The MuleSoft HTTP Listener component (configured for `/hubspot/company-creation`) receives the `POST` request from HubSpot upon a new company creation.
2.  **Generate Correlation ID**: A unique correlation ID is generated and logged to track the entire transaction.
3.  **Log Incoming Payload**: The raw incoming HubSpot payload is logged to Anypoint Monitoring, with any sensitive data masked.
4.  **Validate Webhook Authenticity**: The `X-HubSpot-Signature` header is validated against the request body and the HubSpot Client Secret (retrieved from secure properties).
    *   If invalid/missing, the request is rejected with a `401 Unauthorized` response, and a security alert is logged.
5.  **Transform Data**: If the signature is valid, the HubSpot company payload is transformed into the internal customer database schema using DataWeave 2.0. This includes mapping fields (e.g., `name` to `customer_name`, `domain` to `website`), applying default values, and handling missing optional fields.
6.  **Insert into Database**: The transformed data is passed to the Database Connector, which executes an `INSERT` statement into the `customers` table in PostgreSQL. Database credentials are securely retrieved from secure properties.
7.  **Log Database Operation**: The success or failure of the database insertion, including the number of records inserted, is logged to Anypoint Monitoring.
8.  **Complete Transaction**: If the database insertion is successful, the transaction is marked as complete, and a success log entry is generated. An `HTTP 200 OK` response is returned to HubSpot.
9.  **Error Handling**: If any step encounters a critical error (e.g., transformation error, database connection failure, database insertion failure), the global error handler is triggered.
    *   The full error stack trace and the problematic payload (with sensitive data masked) are logged to Anypoint Monitoring.
    *   An email notification containing relevant error details (transaction ID, timestamp, description) is sent to pre-defined IT administration recipients using the Email Connector.
    *   An `HTTP 500 Internal Server Error` response is returned.

### 5.2. Data Flow Diagram

```mermaid
graph TD
    subgraph MuleSoft System API (CloudHub)
        A[HTTP Listener /hubspot/company-creation] --> A1(Log: Transaction Start & Correlation ID)
        A1 --> A2(Log: Incoming Payload - Masked)
        A2 --> B{Validate X-HubSpot-Signature}
        B -- Invalid --> F[Error Handler: 401 Unauthorized]
        B -- Valid --> C[Transform Message (DataWeave 2.0)]
        C --> D[Database Connector: INSERT into PostgreSQL]
        D -- Success --> E[Log: DB Insert Success & End Transaction]
        D -- Failure --> G[Error Handler: DB Insertion Failure]
        E --> H(HTTP 200 OK Response)
        F --> I(HTTP 401 Unauthorized Response)
        G --> J[Log Error to Anypoint Monitoring]
        G --> K[Send Email Notification]
        G --> L(HTTP 500 Internal Server Error Response)
        subgraph Global Error Handler
            J
            K
        end
    end
    HubSpot --> A
    D --> PostgreSQL
    J --> Anypoint Monitoring
    K --> IT_Admins_Email
```

## 6. Security Considerations

*   **Webhook Authentication**: All incoming HubSpot webhooks are authenticated by validating the `X-HubSpot-Signature` header against the request body and a pre-configured HubSpot Client Secret. Invalid signatures result in an `HTTP 401 Unauthorized` response and security logging.
*   **Credential Management**: HubSpot Client Secret, PostgreSQL database credentials (username/password), and Email server credentials will be stored securely using MuleSoft's secure properties functionality, leveraging encryption at rest and environment-specific property files. These properties will be accessed at runtime using expressions like `p('hubspot.client.secret')`.
*   **Data Masking**: Sensitive data within incoming payloads (e.g., PII if present, or any API keys) will be masked in logs to prevent accidental exposure, adhering to User Story 6.
*   **HTTPS/TLS**: CloudHub applications inherently use HTTPS/TLS for secure communication, ensuring data in transit is encrypted.

## 7. Error Handling Strategy

*   **Global Error Handler**: A centralized global error handler will be implemented within the Mule application to catch and manage all critical exceptions (e.g., validation failures, transformation errors, database errors).
*   **Notification Mechanism**: Upon a critical error, the Email Connector will be used to send immediate email notifications to a pre-defined list of IT administration recipients. The email content will include crucial details such as the correlation ID, timestamp, and a brief description of the failure.
*   **Logging for Errors**: The global error handler will ensure that the full error stack trace and the problematic payload (with sensitive data masked) are logged to Anypoint Monitoring for detailed investigation and troubleshooting.
*   **Idempotency (Future Consideration)**: While the current design is for `INSERT` only, for future updates or retries, mechanisms to ensure idempotency might be considered (e.g., upsert logic based on `hubspot_company_id`).

## 8. Logging and Monitoring

*   **Comprehensive Logging**: The application will generate detailed logs at key stages of the transaction:
    *   Start of the transaction, including a unique correlation ID.
    *   Received HubSpot webhook payload (with sensitive data masked).
    *   Success or failure of the database insertion, including the number of records processed.
    *   End of the transaction, indicating its final status (success/failure) and the correlation ID.
*   **Correlation ID**: A unique correlation ID will be generated at the start of each transaction and propagated throughout the flow, enabling end-to-end traceability across logs in Anypoint Monitoring.
*   **Sensitive Data Masking**: As per User Story 6, any sensitive data within payloads will be masked before being written to logs.
*   **Monitoring Tools**: All logs and application metrics will be accessible and monitored via Anypoint Monitoring, providing a centralized platform for operational visibility, health checks, and troubleshooting.

## 9. Deployment Strategy

*   **CloudHub Deployment**: The MuleSoft System API will be deployed to CloudHub, MuleSoft's managed cloud platform.
*   **Resource Allocation**: The application will be allocated 0.1 vCores on CloudHub, consistent with the technical requirements for a lightweight, event-driven service.
*   **Runtime Version**: The application will utilize Mule 4.4+ runtime.
*   **Environment Configuration**: Environment-specific configurations (e.g., database connection strings, HubSpot client secret, email recipients) will be managed using CloudHub environment properties and secure properties.