# PharmaCorp Commercial Website - Comprehensive Testing Document

## 1. Test Strategy

### 1.1 Introduction
This document outlines the comprehensive test strategy for the PharmaCorp Commercial Website project. It defines the scope, objectives, types of testing, environments, tools, and responsibilities to ensure the delivery of a high-quality, reliable, secure, and performant website that meets all specified requirements.

### 1.2 Test Scope
The testing scope encompasses all functional and non-functional requirements detailed in the Project Requirements (SRS) and the High-Level Design (HLD) document. This includes:
*   **Core Website Pages:** Home, About Us, Products List, Product Detail, Contact Us, Privacy Policy, Terms of Use.
*   **Website Features:** Newsletter Signup, Site Search, Cookie Consent Management.
*   **Technical Enablers:** Verification of CI/CD pipelines, Database & Content Management, Object Storage integration, Backend API functionality, and Website Security implementations.
*   **Non-functional Aspects:** Performance, security, accessibility (WCAG 2.2 AA), responsiveness, data integrity, and compliance (GDPR, CCPA).

### 1.3 Test Objectives
The primary objectives of testing are to:
*   **Validate Functionality:** Ensure all user stories and acceptance criteria are met, and the website behaves as expected.
*   **Ensure Data Integrity:** Verify that all data stored in the PostgreSQL database (product info, content, form submissions, newsletter signups) is accurate, consistent, and securely handled.
*   **Confirm Performance:** Verify that critical pages (e.g., Home Page LCP < 2.5s) load quickly and the system responds efficiently under expected load.
*   **Verify Security:** Identify and mitigate vulnerabilities, ensuring protection against common web attacks (XSS, SQL Injection), secure data transmission (HTTPS), and proper security header implementation.
*   **Guarantee Accessibility:** Ensure the website meets WCAG 2.2 AA guidelines to be usable by individuals with disabilities.
*   **Confirm Responsiveness:** Verify the website's layout and functionality adapt correctly across various screen sizes and devices (desktop, tablet, mobile).
*   **Ensure Compliance:** Confirm adherence to GDPR and CCPA regulations, especially concerning cookie consent and personal data handling.
*   **Validate CI/CD & Deployment:** Verify the automated build, test, and deployment processes across all environments, including the manual approval gate and rollback strategy.

### 1.4 Test Phases and Types of Testing

#### 1.4.1 Test Phases
*   **Unit Testing:** Performed by developers during development to test individual components/functions. QA will review unit test coverage and results.
*   **Integration Testing:** Focuses on the interfaces and interactions between different modules/services (e.g., Frontend-Backend API, Backend-Database, Backend-Object Storage, Backend-reCAPTCHA).
*   **System Testing:** End-to-end testing of the complete integrated system to verify it meets all specified requirements from a user perspective.
*   **Regression Testing:** Executed after code changes, bug fixes, or new feature deployments to ensure existing functionality remains intact and no new defects are introduced.
*   **User Acceptance Testing (UAT):** Performed by stakeholders/end-users to confirm the system meets business requirements and is ready for production deployment.
*   **Production Monitoring:** Continuous monitoring of the live environment for performance, errors, and security issues.

#### 1.4.2 Types of Testing

*   **Functional Testing:**
    *   **Smoke Testing:** Quick, high-level tests to ensure core functionalities are working after a build.
    *   **Sanity Testing:** A subset of regression testing to ensure that a specific bug fix or new feature works as expected and hasn't broken other functionalities.
    *   **Black Box Testing:** Testing without knowledge of internal system structure.
    *   **UI Testing:** Verification of all graphical user interface elements.
    *   **API Testing:** Direct testing of backend API endpoints for correctness, performance, and security.
    *   **Database Testing:** Verification of data storage, retrieval, and integrity in PostgreSQL.
*   **Non-Functional Testing:**
    *   **Performance Testing:**
        *   **Load Testing:** Assessing system behavior under anticipated peak load.
        *   **Stress Testing:** Determining system stability beyond normal operational limits.
        *   **Page Load Time (LCP):** Specific verification for Home Page LCP < 2.5 seconds.
    *   **Security Testing:**
        *   **Vulnerability Scanning:** Using automated tools to identify known vulnerabilities.
        *   **Penetration Testing:** Simulating attacks to uncover exploitable weaknesses.
        *   **Input Validation Testing:** Thoroughly testing client-side and server-side validation for all forms.
        *   **Rate Limiting Testing:** Verifying rate limits on form submissions.
        *   **CSP & HTTP Headers Testing:** Ensuring correct implementation of Content Security Policy and other security headers.
        *   **reCAPTCHA Bypass Testing:** Attempting to bypass the anti-spam mechanism.
    *   **Accessibility Testing (WCAG 2.2 AA):**
        *   Manual checks using assistive technologies (screen readers).
        *   Automated tools (e.g., Lighthouse, axe-core).
        *   Keyboard navigation testing.
        *   Color contrast checks.
    *   **Compatibility Testing:**
        *   **Browser Compatibility:** Testing across major browsers (Chrome, Firefox, Safari, Edge) and versions.
        *   **Device Compatibility:** Testing on various devices (desktop, tablet, mobile) and operating systems.
    *   **Usability Testing:** Assessing the ease of use and user-friendliness of the website.
    *   **Data Integrity Testing:** Ensuring data consistency and accuracy across the application and database.
*   **Infrastructure & DevOps Testing:**
    *   **CI/CD Pipeline Validation:** Verifying automated builds, unit/integration test execution, automated deployments to Dev/Staging, and the manual approval process for Production.
    *   **Environment Configuration Testing:** Ensuring correct and secure environment-specific configurations.
    *   **Rollback Strategy Testing:** Verifying the ability to revert to a stable previous version in production.
    *   **Monitoring & Logging Verification:** Confirming that logs are generated correctly and monitoring systems are capturing relevant metrics and alerts.

### 1.5 Test Environment
Testing will be conducted across three distinct environments:
*   **Development (Dev):** Used by developers for local testing and initial integration. QA performs smoke tests here.
*   **Staging (Staging):** A replica of the production environment, used for comprehensive system testing, performance testing, security testing, and UAT. Automated deployments occur here.
*   **Production (Prod):** The live environment. Post-deployment sanity checks and continuous monitoring are performed here.

### 1.6 Tools and Technologies
*   **Test Management:** Jira, Azure DevOps, or similar.
*   **Test Automation (UI):** Playwright with Python (recommended for modern web apps) or Selenium with Python.
*   **Test Automation (API):** Python `requests` library.
*   **Performance Testing:** Apache JMeter, Locust.io.
*   **Security Testing:** OWASP ZAP, Burp Suite, specific vulnerability scanners.
*   **Accessibility Testing:** Lighthouse, axe-core, manual screen reader testing (NVDA, JAWS, VoiceOver).
*   **CI/CD:** Jenkins, GitLab CI/CD, GitHub Actions, Azure DevOps Pipelines.
*   **Version Control:** Git.
*   **Reporting:** Allure Reporter or custom reporting tools.

### 1.7 Roles and Responsibilities
*   **QA Automation Engineer:** Develops test strategies, creates test plans, designs and executes manual test cases, develops and maintains automation scripts, reports defects, and ensures overall quality.
*   **Developers:** Write unit tests, assist QA in debugging, and fix reported defects.
*   **DevOps Engineer:** Manages CI/CD pipelines, environments, and infrastructure; assists QA in infrastructure testing.
*   **Project Manager:** Oversees the testing process, manages risks, and facilitates communication.

### 1.8 Test Reporting
Test results will be documented and reported regularly. This includes:
*   Test case execution status (Pass/Fail/Blocked/Skipped).
*   Defect logging, tracking, and retesting.
*   Summary reports on test coverage and overall quality.
*   Performance and security test results.

---

## 2. Manual Test Cases

This section provides detailed manual test cases for key user stories and requirements, including those identified for explicit verification.

### 2.1 Core Website Pages

#### 2.1.1 Home Page Display
*   **Test Case ID:** TC-HP-001
*   **User Story:** Home Page Display
*   **Test Objective:** To verify the Home Page displays correctly, is responsive, and meets performance and accessibility criteria.
*   **Preconditions:** Website is accessible.
*   **Steps:**
    1.  Navigate to the Home Page URL.
    2.  Verify the PharmaCorp logo is prominently displayed in the header.
    3.  Verify the main navigation menu (About Us, Products, Contact Us, Privacy Policy, Terms of Use) is clearly visible and clickable.
    4.  Verify a hero section with a compelling headline and relevant image is present.
    5.  Resize the browser window to simulate tablet and mobile screen sizes.
    6.  Verify the page content and layout adapt correctly and remain usable on different screen sizes.
    7.  Use a browser developer tool (e.g., Chrome Lighthouse) to measure Largest Contentful Paint (LCP) for the Home Page.
    8.  Use an accessibility checker (e.g., axe DevTools browser extension) to scan the page for WCAG 2.2 AA violations.
*   **Expected Result:**
    1.  PharmaCorp logo is visible and correctly positioned.
    2.  Navigation menu items are visible, correctly linked, and functional.
    3.  Hero section is present and visually appealing.
    4.  Page content is fully responsive and renders without layout issues on desktop, tablet, and mobile.
    5.  LCP for the Home Page is consistently below 2.5 seconds.
    6.  The page passes WCAG 2.2 AA checks with no critical or serious violations.
*   **Priority:** P1
*   **Test Type:** Functional, UI, Performance, Accessibility, Responsiveness

#### 2.1.2 About Us Page Display (Explicit Manual Test Case)
*   **Test Case ID:** TC-AU-001
*   **User Story:** About Us Page Display
*   **Test Objective:** To verify the About Us page displays comprehensive content fetched from the database, is responsive, and meets accessibility criteria.
*   **Preconditions:** Website is accessible, About Us content is populated in the PostgreSQL database.
*   **Steps:**
    1.  Navigate to the About Us page (e.g., via the navigation menu).
    2.  Verify the page title and heading clearly indicate "About Us".
    3.  Verify comprehensive text about PharmaCorp's history, mission, and core values is displayed.
    4.  Verify the content appears to be dynamic (e.g., if a content update mechanism exists, update content and re-verify, or check database directly).
    5.  Resize the browser window to simulate tablet and mobile screen sizes.
    6.  Verify the page content and layout adapt correctly and remain usable on different screen sizes.
    7.  Use an accessibility checker (e.g., axe DevTools browser extension) to scan the page for WCAG 2.2 AA violations.
*   **Expected Result:**
    1.  About Us page title and content are correct.
    2.  The displayed content matches the data in the PostgreSQL database for the About Us section.
    3.  The page content is fully responsive and renders without layout issues on various screen sizes.
    4.  The page passes WCAG 2.2 AA checks with no critical or serious violations.
*   **Priority:** P2
*   **Test Type:** Functional, UI, Data Integrity, Responsiveness, Accessibility

#### 2.1.3 Product Detail Page
*   **Test Case ID:** TC-PD-001
*   **User Story:** Product Detail Page
*   **Test Objective:** To verify detailed product information, PI PDF download, sticky ISI, responsiveness, and accessibility on the Product Detail Page.
*   **Preconditions:** Website is accessible, products are available in the database, PI PDFs are in object storage.
*   **Steps:**
    1.  Navigate to the Products List page.
    2.  Click on any product entry to navigate to its Product Detail Page.
    3.  Verify the product name, detailed description, indications, dosage, and potential side effects are accurately displayed.
    4.  Verify a prominent button or link to download the official Product Information (PI) PDF document is present.
    5.  Click the PI PDF download link and verify the PDF document opens or downloads correctly.
    6.  Scroll down the page and verify the "Important Safety Information (ISI)" section remains sticky at the bottom of the viewport.
    7.  Resize the browser window to simulate tablet and mobile screen sizes.
    8.  Verify the page content and layout adapt correctly and remain usable on different screen sizes.
    9.  Use an accessibility checker to scan the page for WCAG 2.2 AA violations.
*   **Expected Result:**
    1.  All product details are accurately displayed and match database entries.
    2.  The PI PDF download link is present and functional, leading to the correct PDF served from object storage.
    3.  The "Important Safety Information (ISI)" section is sticky at the bottom of the viewport as the user scrolls.
    4.  Page content is fully responsive across different screen sizes.
    5.  The page passes WCAG 2.2 AA checks with no critical or serious violations.
*   **Priority:** P1
*   **Test Type:** Functional, UI, Data Integrity, Responsiveness, Accessibility

#### 2.1.4 Contact Us Page with Form
*   **Test Case ID:** TC-CU-001 (Successful Submission)
*   **User Story:** Contact Us Page with Form
*   **Test Objective:** To verify successful submission of the contact form with valid data, confirmation message, and secure storage.
*   **Preconditions:** Website is accessible, reCAPTCHA is configured.
*   **Steps:**
    1.  Navigate to the Contact Us page.
    2.  Locate the contact form.
    3.  Enter valid data into Name, Email Address, Subject, and Message fields.
    4.  Complete the reCAPTCHA challenge.
    5.  Click the "Submit" button.
    6.  Verify a clear confirmation message is displayed to the user.
    7.  (Backend/DB check) Verify the submitted data is securely stored in the PostgreSQL database.
    8.  Resize the browser window to simulate tablet and mobile screen sizes.
    9.  Verify the form and page content are responsive.
    10. Use an accessibility checker to scan the page for WCAG 2.2 AA violations.
*   **Expected Result:**
    1.  Form fields accept input correctly.
    2.  reCAPTCHA challenge is presented and successfully completed.
    3.  A confirmation message (e.g., "Your inquiry has been submitted successfully.") is displayed.
    4.  The submitted data is found in the `contact_submissions` table in the PostgreSQL database.
    5.  The form and page are fully responsive.
    6.  The page passes WCAG 2.2 AA checks.
*   **Priority:** P1
*   **Test Type:** Functional, UI, Data Integrity, Security, Responsiveness, Accessibility

*   **Test Case ID:** TC-CU-002 (Validation Errors)
*   **User Story:** Contact Us Page with Form
*   **Test Objective:** To verify client-side and server-side input validation on the contact form.
*   **Preconditions:** Website is accessible.
*   **Steps:**
    1.  Navigate to the Contact Us page.
    2.  Attempt to submit the form with:
        *   All fields empty.
        *   Invalid email format (e.g., "invalid-email").
        *   Missing required fields.
        *   (If applicable) Exceeding field length limits.
    3.  Verify client-side validation messages appear immediately upon attempting submission or losing focus.
    4.  Attempt to bypass client-side validation (e.g., by disabling JavaScript in browser, if applicable).
    5.  Submit the form with invalid data (e.g., SQL injection attempt in message).
    6.  Verify server-side validation prevents submission or sanitizes input, and appropriate error messages are displayed.
*   **Expected Result:**
    1.  Client-side validation messages clearly indicate missing/invalid required fields.
    2.  Form cannot be submitted until client-side validation passes.
    3.  Server-side validation rejects invalid/malicious input, preventing database injection, and returns a user-friendly error message.
    4.  No invalid data is stored in the database.
*   **Priority:** P1
*   **Test Type:** Functional, Security, UI

#### 2.1.5 Privacy Policy Page (Explicit Manual Test Case)
*   **Test Case ID:** TC-PP-001
*   **User Story:** Privacy Policy Page
*   **Test Objective:** To verify the Privacy Policy page displays the full, legally compliant text, is responsive, and meets accessibility and compliance criteria.
*   **Preconditions:** Website is accessible, Privacy Policy content is populated in the PostgreSQL database.
*   **Steps:**
    1.  Navigate to the Privacy Policy page (e.g., via the navigation menu or footer link).
    2.  Verify the page title and heading clearly indicate "Privacy Policy".
    3.  Verify the full, legally compliant Privacy Policy text is displayed, covering data collection, usage, user rights, and cookie policies.
    4.  Verify the content appears to be dynamic (e.g., by checking database content).
    5.  Confirm the policy explicitly mentions GDPR and CCPA compliance.
    6.  Resize the browser window to simulate tablet and mobile screen sizes.
    7.  Verify the page content and layout adapt correctly and remain usable on different screen sizes.
    8.  Use an accessibility checker to scan the page for WCAG 2.2 AA violations.
*   **Expected Result:**
    1.  Privacy Policy page title and content are correct and comprehensive.
    2.  The displayed content matches the data in the PostgreSQL database for the Privacy Policy section.
    3.  GDPR and CCPA compliance statements are present.
    4.  The page content is fully responsive.
    5.  The page passes WCAG 2.2 AA checks.
*   **Priority:** P2
*   **Test Type:** Functional, UI, Data Integrity, Compliance, Responsiveness, Accessibility

#### 2.1.6 Terms of Use Page (Explicit Manual Test Case)
*   **Test Case ID:** TC-TOU-001
*   **User Story:** Terms of Use Page
*   **Test Objective:** To verify the Terms of Use page displays the full, legally compliant text, is responsive, and meets accessibility criteria.
*   **Preconditions:** Website is accessible, Terms of Use content is populated in the PostgreSQL database.
*   **Steps:**
    1.  Navigate to the Terms of Use page (e.g., via the navigation menu or footer link).
    2.  Verify the page title and heading clearly indicate "Terms of Use".
    3.  Verify the full, legally compliant Terms of Use text is displayed, outlining legal conditions and guidelines.
    4.  Verify the content appears to be dynamic (e.g., by checking database content).
    5.  Resize the browser window to simulate tablet and mobile screen sizes.
    6.  Verify the page content and layout adapt correctly and remain usable on different screen sizes.
    7.  Use an accessibility checker to scan the page for WCAG 2.2 AA violations.
*   **Expected Result:**
    1.  Terms of Use page title and content are correct and comprehensive.
    2.  The displayed content matches the data in the PostgreSQL database for the Terms of Use section.
    3.  The page content is fully responsive.
    4.  The page passes WCAG 2.2 AA checks.
*   **Priority:** P2
*   **Test Type:** Functional, UI, Data Integrity, Responsiveness, Accessibility

### 2.2 Website Features

#### 2.2.1 Cookie Consent Management
*   **Test Case ID:** TC-CC-001
*   **User Story:** Cookie Consent Management
*   **Test Objective:** To verify the cookie consent banner displays correctly, allows preference management, and remembers choices.
*   **Preconditions:** User is visiting the website for the first time or cookies are cleared.
*   **Steps:**
    1.  Clear browser cookies and navigate to the website's Home Page.
    2.  Verify a clear and prominent cookie consent banner or pop-up is displayed.
    3.  Verify the banner provides options like "Accept All," "Decline All," and "Manage Preferences" (or "Customize").
    4.  Click "Manage Preferences" and verify a detailed cookie settings panel appears, allowing users to enable/disable specific cookie categories (e.g., strictly necessary, analytics, marketing).
    5.  Select specific preferences (e.g., decline marketing cookies, accept analytics), save, and close the panel.
    6.  Refresh the page or navigate to another page and verify the banner does not reappear, and the selected preferences are remembered (e.g., check browser cookies for analytics/marketing cookies).
    7.  Repeat steps 1-3, but this time click "Decline All". Verify the banner disappears, and only strictly necessary cookies are set.
    8.  Repeat steps 1-3, but this time click "Accept All". Verify the banner disappears, and all cookie categories are set.
    9.  Verify the mechanism is compliant with GDPR/CCPA (e.g., no non-essential cookies set before consent).
    10. Resize the browser and verify the banner/panel is responsive.
    11. Use an accessibility checker to scan the banner/panel for WCAG 2.2 AA violations.
*   **Expected Result:**
    1.  Cookie consent banner appears on first visit.
    2.  Options "Accept All," "Decline All," and "Manage Preferences" are present and functional.
    3.  "Manage Preferences" opens a panel allowing granular control over cookie categories.
    4.  User's consent choice is remembered across sessions.
    5.  Website functionality respects consent choices (e.g., analytics scripts don't load if analytics cookies are declined).
    6.  The mechanism is GDPR/CCPA compliant.
    7.  The banner/panel is responsive and accessible.
*   **Priority:** P1
*   **Test Type:** Functional, UI, Compliance, Security, Responsiveness, Accessibility

### 2.3 Enabler / Technical Stories

#### 2.3.1 CI/CD Pipelines and Deployment Environments (Explicit Manual/Verification Test Case)
*   **Test Case ID:** TC-CI_CD-001
*   **User Story:** Establish CI/CD Pipelines and Deployment Environments
*   **Test Objective:** To verify the functionality of the CI/CD pipeline, automated deployments, manual approval gate, and rollback strategy.
*   **Preconditions:** CI/CD pipeline is configured, Dev, Staging, Production environments are provisioned.
*   **Steps:**
    1.  **Verify CI Trigger & Build:** Make a small, non-breaking code change in the Git repository and commit it.
    2.  Observe the CI pipeline (e.g., Jenkins, GitLab CI) to confirm it automatically triggers a build.
    3.  Verify the build completes successfully, including linting, unit tests, and integration tests.
    4.  **Verify Automated Deployment (Dev/Staging):** After a successful CI build, verify the updated code is automatically deployed to the Development environment.
    5.  Perform a quick smoke test on the Dev environment to confirm the deployment was successful.
    6.  Verify the updated code is automatically deployed to the Staging environment.
    7.  Perform a thorough system test on the Staging environment to confirm the deployment was successful and all functionalities work as expected.
    8.  **Verify Manual Approval Gate (Production):** Initiate a deployment from Staging to Production.
    9.  Verify the pipeline pauses and requires a manual approval step before proceeding to Production.
    10. Approve the deployment and verify the code is deployed to the Production environment.
    11. Perform a quick sanity check on the Production environment.
    12. **Verify Rollback Strategy:** Introduce a known, easily detectable bug into the code, commit, and deploy it through the CI/CD pipeline up to Production (after approval).
    13. Once the bug is in Production, initiate the defined rollback procedure.
    14. Verify the system successfully reverts to the previous stable production release, and the bug is no longer present.
    15. Verify environment-specific configurations (e.g., database credentials, API keys) are correctly loaded and distinct for Dev, Staging, and Production.
*   **Expected Result:**
    1.  Code commits trigger CI builds automatically.
    2.  CI builds successfully run tests and produce artifacts.
    3.  Automated deployments to Dev and Staging environments complete successfully.
    4.  A manual approval gate is enforced for Production deployments.
    5.  The rollback strategy effectively reverts Production to a stable state.
    6.  Environment-specific configurations are correctly applied per environment.
*   **Priority:** P1
*   **Test Type:** Infrastructure, DevOps, Functional, Regression

---

## 3. Automation Test Scripts (Python with Playwright)

This section provides example automation test scripts using Python with Playwright for critical user stories.

**Prerequisites:**
*   Python 3.8+ installed.
*   Playwright installed: `pip install playwright`
*   Install browser binaries: `playwright install`

**Project Structure (Example):**

```
pharma_tests/
├── tests/
│   ├── conftest.py
│   ├── test_home_page.py
│   ├── test_product_detail.py
│   ├── test_contact_us_form.py
├── pages/
│   ├── base_page.py
│   ├── home_page.py
│   ├── product_detail_page.py
│   ├── contact_us_page.py
├── utils/
│   ├── config.py
│   ├── db_utils.py  # For potential DB validation (optional for UI tests)
├── requirements.txt
```

**`requirements.txt`:**
```
playwright
pytest
python-dotenv
psycopg2-binary # If direct DB interaction is needed for validation
```

**`utils/config.py`:**
```python
import os
from dotenv import load_dotenv

load_dotenv() # Load environment variables from .env file

BASE_URL = os.getenv("BASE_URL", "http://localhost:8000")
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_NAME = os.getenv("DB_NAME", "pharmacorp_db")
DB_USER = os.getenv("DB_USER", "user")
DB_PASSWORD = os.getenv("DB_PASSWORD", "password")
```

**`conftest.py` (for shared fixtures like browser instance):**
```python
import pytest
from playwright.sync_api import sync_playwright
from utils.config import BASE_URL

@pytest.fixture(scope="session")
def browser():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True) # Set to False for visible browser
        yield browser
        browser.close()

@pytest.fixture(scope="function")
def page(browser):
    page = browser.new_page()
    page.goto(BASE_URL)
    yield page
    page.close()
```

**`pages/base_page.py`:**
```python
class BasePage:
    def __init__(self, page):
        self.page = page
        self.logo_selector = "img[alt='PharmaCorp Logo']"
        self.nav_menu_selector = "nav ul li a"

    def verify_logo_visible(self):
        return self.page.locator(self.logo_selector).is_visible()

    def get_navigation_links(self):
        return [link.text_content() for link in self.page.locator(self.nav_menu_selector).all()]

    def navigate_to(self, link_text):
        self.page.locator(f"nav ul li a:has-text('{link_text}')").click()
        self.page.wait_for_load_state("networkidle")
```

#### 3.1 Automation Test Script: Home Page Display & Responsiveness

**`pages/home_page.py`:**
```python
from pages.base_page import BasePage

class HomePage(BasePage):
    def __init__(self, page):
        super().__init__(page)
        self.hero_headline_selector = "section.hero h1"
        self.hero_image_selector = "section.hero img"

    def verify_hero_section_present(self):
        return self.page.locator(self.hero_headline_selector).is_visible() and \
               self.page.locator(self.hero_image_selector).is_visible()

    def check_responsiveness(self, width, height):
        self.page.set_viewport_size({"width": width, "height": height})
        # Add more specific checks here, e.g., for element positions, visibility
        # For simplicity, we just check if the page loads without major breaks.
        # A more robust check would involve comparing screenshots or checking specific element properties.
        return True # Placeholder for actual layout verification
```

**`tests/test_home_page.py`:**
```python
import pytest
from pages.home_page import HomePage
from playwright.sync_api import Page

def test_home_page_display_and_responsiveness(page: Page):
    home_page = HomePage(page)

    # 1. Verify logo and navigation
    assert home_page.verify_logo_visible(), "PharmaCorp logo is not visible on Home Page."
    expected_nav_links = ["About Us", "Products", "Contact Us", "Privacy Policy", "Terms of Use"]
    assert all(link in home_page.get_navigation_links() for link in expected_nav_links), \
        "Main navigation menu is missing expected links."

    # 2. Verify hero section
    assert home_page.verify_hero_section_present(), "Hero section (headline/image) is not present."

    # 3. Check responsiveness
    # Desktop
    assert home_page.check_responsiveness(1280, 800), "Home page not responsive on desktop."
    # Tablet (e.g., iPad Pro)
    assert home_page.check_responsiveness(768, 1024), "Home page not responsive on tablet."
    # Mobile (e.g., iPhone X)
    assert home_page.check_responsiveness(375, 812), "Home page not responsive on mobile."

    # Note: LCP and WCAG 2.2 AA require integration with specific tools or deeper analysis
    # For LCP, you'd typically use browser performance APIs or external tools in CI.
    # For WCAG, integrate with axe-core or similar tools.
    # Example (conceptual, requires axe-playwright integration):
    # from axe_playwright_python.sync_playwright import Axe
    # results = Axe(page).run()
    # assert len(results.violations) == 0, f"Accessibility violations found: {results.violations}"
```

#### 3.2 Automation Test Script: Product Detail Page & Sticky ISI

**`pages/product_detail_page.py`:**
```python
from pages.base_page import BasePage

class ProductDetailPage(BasePage):
    def __init__(self, page):
        super().__init__(page)
        self.product_name_selector = "h1.product-name"
        self.detailed_description_selector = ".product-description"
        self.indications_selector = ".product-indications"
        self.dosage_selector = ".product-dosage"
        self.side_effects_selector = ".product-side-effects"
        self.pi_pdf_link_selector = "a.pi-pdf-download"
        self.isi_section_selector = ".important-safety-info"

    def navigate_to_product(self, product_id):
        # Assuming product list page or direct URL for product detail
        self.page.goto(f"/products/{product_id}") # Adjust URL path as per HLD
        self.page.wait_for_load_state("networkidle")

    def get_product_name(self):
        return self.page.locator(self.product_name_selector).text_content()

    def get_product_description(self):
        return self.page.locator(self.detailed_description_selector).text_content()

    def get_pi_pdf_link(self):
        return self.page.locator(self.pi_pdf_link_selector).get_attribute("href")

    def is_isi_sticky(self):
        # This is a simplified check. A true sticky check involves scrolling and verifying position.
        # For Playwright, you'd scroll and then check bounding box or computed style 'position: sticky'.
        # For demonstration, we'll check if it's visible after scrolling.
        self.page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        self.page.wait_for_timeout(500) # Give time for sticky effect
        isi_element = self.page.locator(self.isi_section_selector)
        if not isi_element.is_visible():
            return False
        # More advanced check: get bounding box and compare with viewport bottom
        # bbox = isi_element.bounding_box()
        # viewport_height = self.page.viewport_size['height']
        # return bbox['y'] + bbox['height'] == viewport_height # Simplistic check for bottom alignment
        return True # Assume visible means sticky for this demo

    def verify_product_details_present(self):
        return self.page.locator(self.product_name_selector).is_visible() and \
               self.page.locator(self.detailed_description_selector).is_visible() and \
               self.page.locator(self.indications_selector).is_visible() and \
               self.page.locator(self.dosage_selector).is_visible() and \
               self.page.locator(self.side_effects_selector).is_visible()
```

**`tests/test_product_detail.py`:**
```python
import pytest
from pages.product_detail_page import ProductDetailPage
from playwright.sync_api import Page

# Assuming a test product ID exists in your dev/test environment
TEST_PRODUCT_ID = "123e4567-e89b-12d3-a456-426614174000" # Replace with an actual product ID from your DB

def test_product_detail_page_content_and_features(page: Page):
    product_detail_page = ProductDetailPage(page)
    product_detail_page.navigate_to_product(TEST_PRODUCT_ID)

    # 1. Verify product details are displayed
    assert product_detail_page.verify_product_details_present(), "Not all product details are displayed."
    assert product_detail_page.get_product_name() == "Sample Product Name", "Product name mismatch."
    # Add more specific assertions for description, indications, dosage, side effects if known

    # 2. Verify PI PDF link and download
    pi_pdf_link = product_detail_page.get_pi_pdf_link()
    assert pi_pdf_link is not None, "PI PDF download link is missing."
    assert "object-storage-url" in pi_pdf_link, "PI PDF link does not point to object storage." # Check URL structure

    # You can also attempt to download the PDF to verify it's accessible
    with page.expect_download() as download_info:
        page.locator(product_detail_page.pi_pdf_link_selector).click()
    download = download_info.value
    assert download.suggested_filename.endswith(".pdf"), "Downloaded file is not a PDF."
    # You could save and verify size/content if needed: download.save_as("downloaded.pdf")

    # 3. Verify ISI section is sticky
    assert product_detail_page.is_isi_sticky(), "Important Safety Information (ISI) section is not sticky."

    # 4. Check responsiveness (similar to Home Page)
    assert product_detail_page.check_responsiveness(768, 1024), "Product detail page not responsive on tablet."
    assert product_detail_page.check_responsiveness(375, 812), "Product detail page not responsive on mobile."

    # 5. WCAG 2.2 AA (conceptual, requires axe-playwright integration)
    # from axe_playwright_python.sync_playwright import Axe
    # results = Axe(page).run()
    # assert len(results.violations) == 0, f"Accessibility violations found: {results.violations}"
```

#### 3.3 Automation Test Script: Contact Us Form Submission

**`pages/contact_us_page.py`:**
```python
from pages.base_page import BasePage

class ContactUsPage(BasePage):
    def __init__(self, page):
        super().__init__(page)
        self.name_field = "#name"
        self.email_field = "#email"
        self.subject_field = "#subject"
        self.message_field = "#message"
        self.recaptcha_checkbox = "#recaptcha-checkbox" # Simplified, actual reCAPTCHA interaction is complex
        self.submit_button = "button[type='submit']"
        self.confirmation_message = ".confirmation-message"
        self.error_message = ".error-message" # For client-side validation errors

    def navigate_to_contact_us(self):
        self.navigate_to("Contact Us")

    def fill_form(self, name, email, subject, message):
        self.page.fill(self.name_field, name)
        self.page.fill(self.email_field, email)
        self.page.fill(self.subject_field, subject)
        self.page.fill(self.message_field, message)

    def submit_form(self):
        # For reCAPTCHA, in automation, you might need to use a test key or bypass it in test env
        # Actual reCAPTCHA interaction is usually manual or mocked for automation.
        # For this script, we assume a successful reCAPTCHA "click" or bypass is possible.
        # self.page.locator(self.recaptcha_checkbox).click() # Uncomment if clickable
        self.page.locator(self.submit_button).click()
        self.page.wait_for_load_state("networkidle")

    def get_confirmation_message(self):
        return self.page.locator(self.confirmation_message).text_content()

    def get_client_side_error_messages(self):
        return [err.text_content() for err in self.page.locator(self.error_message).all()]
```

**`tests/test_contact_us_form.py`:**
```python
import pytest
import time
from pages.contact_us_page import ContactUsPage
from playwright.sync_api import Page

# For simulating unique emails
def generate_unique_email():
    return f"testuser_{int(time.time())}@example.com"

def test_contact_us_form_successful_submission(page: Page):
    contact_us_page = ContactUsPage(page)
    contact_us_page.navigate_to_contact_us()

    name = "Automation Test"
    email = generate_unique_email()
    subject = "Inquiry from Automation Script"
    message = "This is an automated test message for PharmaCorp."

    contact_us_page.fill_form(name, email, subject, message)
    contact_us_page.submit_form()

    # Verify confirmation message
    assert "Your inquiry has been submitted successfully." in contact_us_page.get_confirmation_message(), \
        "Confirmation message not displayed after successful submission."

    # Optional: Direct database verification (requires db_utils.py and psycopg2-binary)
    # from utils.db_utils import get_contact_submission_by_email
    # db_record = get_contact_submission_by_email(email)
    # assert db_record is not None, "Contact submission not found in database."
    # assert db_record['name'] == name
    # assert db_record['subject'] == subject
    # assert db_record['message'] == message

def test_contact_us_form_client_side_validation(page: Page):
    contact_us_page = ContactUsPage(page)
    contact_us_page.navigate_to_contact_us()

    # Attempt to submit an empty form
    contact_us_page.submit_form()
    errors = contact_us_page.get_client_side_error_messages()
    assert len(errors) >= 4, "Not all required fields showed client-side validation errors." # Name, Email, Subject, Message
    assert any("required" in e.lower() for e in errors), "No 'required' error message found."

    # Test invalid email format
    contact_us_page.fill_form("Test", "invalid-email", "Subject", "Message")
    contact_us_page.submit_form()
    errors = contact_us_page.get_client_side_error_messages()
    assert any("email" in e.lower() and "valid" in e.lower() for e in errors), "Invalid email format error not shown."

def test_contact_us_form_server_side_validation_and_security(page: Page):
    contact_us_page = ContactUsPage(page)
    contact_us_page.navigate_to_contact_us()

    # Simulate a SQL Injection attempt
    name = "SQL Injector"
    email = generate_unique_email()
    subject = "Test"
    message = "'; DROP TABLE contact_submissions; --" # Malicious input

    contact_us_page.fill_form(name, email, subject, message)
    contact_us_page.submit_form()

    # Expect an error message or generic success if sanitized and stored safely
    # This test primarily verifies the *absence* of a successful injection
    # and the presence of a non-success confirmation.
    confirmation_text = contact_us_page.get_confirmation_message()
    assert "successfully" in confirmation_text or "error" in confirmation_text.lower(), \
        "Neither success nor error message for SQL injection attempt."

    # Optional: Verify DB directly to ensure table was not dropped and data is sanitized/not stored.
    # from utils.db_utils import check_table_exists, get_contact_submission_by_email
    # assert check_table_exists("contact_submissions"), "Contact submissions table was dropped!"
    # db_record = get_contact_submission_by_email(email)
    # assert db_record is None or db_record['message'] != message, "Malicious input was stored unsanitized!"
```

---