# Test Strategy & Plan: Patient Enrollment Automation

**Version:** 1.0
**Date:** 2023-10-27
**Author:** QA Automation Engineer

---

## 1. Introduction

### 1.1. Purpose
This document outlines the comprehensive testing strategy and plan for the **Patient Enrollment Automation** project. Its purpose is to ensure that the new MuleSoft System API for patient enrollment meets all functional, security, compliance, and error-handling requirements as defined in the System Requirements Specification (SRS) and High-Level Design (HLD).

This plan will guide all QA activities, including the types of testing to be performed, test environments, tools, and the criteria for successful completion. The primary artifact for test case definition will be a Behavior-Driven Development (BDD) feature file, which will also serve as the foundation for the automated test suite.

### 1.2. Referenced Documents
*   Project Requirements (SRS): Epic - Patient Enrollment Automation
*   High-Level Design (HLD): Patient Enrollment Automation v1.0

---

## 2. Test Strategy

### 2.1. Scope of Testing

#### 2.1.1. In-Scope
*   **API Functional Testing:** Validating the `POST /patients` endpoint for successful creation of patient records, including data mapping from the source JSON to the target database schema.
*   **API Input Validation (Negative Testing):** Testing the API's response to invalid, incomplete, or malformed request payloads.
*   **Security Testing:** Verifying JWT-based authentication, ensuring requests with invalid, missing, or expired tokens are rejected. Verifying that communication is encrypted over HTTPS (TLS 1.2+).
*   **Error Handling and Resilience Testing:** Simulating backend failures (e.g., database unavailability) to ensure the system responds with the correct 5xx error codes, logs the error, and triggers email notifications as per requirements.
*   **Compliance and Audit Testing:** Validating the secure logging mechanism, including the presence of a correlation ID and the masking of all Protected Health Information (PHI) in application logs.
*   **Integration Testing:** Verifying the API's interaction with external components, specifically the Healthcare Patient Database, the Secure Vault for credentials, and the SMTP Email Service.

#### 2.1.2. Out-of-Scope
*   The front-end Patient Enrollment Portal (UI/UX testing).
*   The JWT Identity Provider (IdP) implementation and its user authentication logic.
*   Performance, load, or stress testing of the API.
*   Database-level testing of the encryption-at-rest mechanism (this will be verified as a configuration check).
*   End-to-end testing involving the actual Patient Portal UI.
*   Infrastructure testing of the CloudHub/Private Cloud environment.

### 2.2. Testing Objectives
*   To verify that a valid patient enrollment request successfully creates a new record in the `Patients` database table (US-101).
*   To ensure the API returns a `201 Created` status and the new `patient_id` upon successful enrollment (US-101).
*   To validate that the API gracefully handles database insertion failures by returning a `5xx` server error, logging the failure, and sending an email notification to IT support (US-102).
*   To confirm that all transactions are logged with a unique correlation ID and that all PHI is correctly masked in the logs (US-103).
*   To ensure the API is secured via JWT authentication and that all data is transmitted over HTTPS (US-104).
*   To verify that the API rejects requests with invalid payloads (e.g., missing mandatory fields, incorrect data formats) with a `400 Bad Request` status code.

### 2.3. Testing Types

| Testing Type                        | Description                                                                                                                                                                                                                                                          | Requirements Covered |
| ----------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------- |
| **API Functional Testing**          | Black-box testing of the `POST /patients` endpoint. Focuses on verifying the happy path, data transformations, HTTP status codes (`201`, `400`), and response bodies based on valid and invalid inputs.                                                                  | US-101, Feedback     |
| **Integration Testing**             | Verifies the interactions between the MuleSoft API and its dependencies: the database, the secure vault, and the email service. This involves checking if data is correctly persisted and if notifications are triggered.                                                 | US-101, US-102, US-104 |
| **Security Testing**                | Focuses on access control and data protection. This includes testing with valid, invalid, and expired JWTs to validate the API Gateway policy. It also includes configuration checks to ensure TLS 1.2+ is enforced.                                                     | US-104               |
| **Error Handling & Resilience Testing** | Involves simulating failure conditions to test the system's robustness. This will be done by mocking database connection failures to verify that the Global Error Handler functions correctly.                                                                         | US-102               |
| **Compliance & Audit Testing**      | Involves inspecting the application's log outputs (e.g., in Splunk or a log file) to verify that PHI is masked and that correlation IDs are present and consistent for each transaction, whether successful or failed.                                                | US-103               |

### 2.4. Test Environment & Tools

*   **Test Environment:** A dedicated QA/Staging environment that mirrors the production configuration. This includes a deployed version of the MuleSoft API, access to a non-production instance of the Healthcare Patient Database, and a configured SMTP service for email testing.
*   **Test Automation Framework:** A BDD framework such as **Cucumber** (with Java/RestAssured) or **Behave** (with Python/Requests) will be used to automate the scenarios defined in the feature file.
*   **API Test Client:** **Postman** will be used for manual, exploratory, and ad-hoc testing of the API endpoint.
*   **Mocking Service:** A tool like **WireMock** or **MockServer** will be used to simulate unavailable database or email services to test failure scenarios (US-102).
*   **Log Analysis Tool:** A tool like **Splunk**, **ELK Stack**, or direct server log access will be required to validate the secure logging requirements (US-103).

### 2.5. Test Data Management
Test data will consist of fictional patient information. No real PHI will be used in the test environment. The test data will be designed to cover various valid inputs and edge cases. For negative tests, specific invalid data sets will be created to trigger expected validation errors. The database will be reset or cleaned between test runs to ensure test independence.

### 2.6. Entry & Exit Criteria

#### 2.6.1. Entry Criteria
*   The Patient Enrollment API has been successfully built and deployed to the designated QA environment.
*   All dependencies (database, email service, secure vault) are available and configured for the QA environment.
*   The test environment is stable and accessible to the QA team.
*   Unit and component tests have been completed and passed by the development team.

#### 2.6.2. Exit Criteria
*   All planned test cases (derived from the BDD feature file) have been executed.
*   100% of test cases for critical path scenarios (e.g., successful enrollment, security checks) have passed.
*   Over 95% of all test cases have passed.
*   No open critical or high-severity defects.
*   All medium-severity defects have a documented plan for resolution.
*   The Test Summary Report is complete and has been signed off by project stakeholders.

---

## 3. BDD Feature File: Patient Enrollment

Feature: Patient Enrollment API
  As a QA Engineer, I want to test the Patient Enrollment API
  to ensure it is secure, reliable, and compliant with healthcare standards.

  Background:
    Given a valid JWT authentication token is available

  Scenario: Successful Patient Enrollment
    This scenario validates the end-to-end happy path for creating a new patient record.
    It covers the requirements of US-101.

    Given the Patient Enrollment API is available
    When I send a POST request to "/patients" with the following valid data:
      | Field                     | Value              |
      | Patient Full Name         | John Everyman      |
      | Date of Birth             | 1992-05-15         |
      | Gender                    | Male               |
      | Address                   | 456 Medical Lane   |
      | City                      | Healthville        |
      | State/Region              | TX                 |
      | Postal Code               | 75001              |
      | Phone Number              | 555-987-6543       |
      | Insurance Policy Number   | ABC987654321       |
    Then the API response status code should be "201"
    And the response body should contain a non-null "patient_id"
    And a new record should be created in the "Patients" database table with the mapped data
    And the application logs must contain a "Database Insert Successful" message with masked PHI

  Scenario: Handle Database Insertion Failure
    This scenario validates the system's resilience and error handling when the database is unavailable.
    It covers the requirements of US-102.

    Given the Patient Enrollment API is available
    And the backend database is unavailable
    When I send a valid POST request to "/patients"
    Then the API response status code should be "503"
    And the response body should contain a "transaction_id"
    And an error should be logged with a unique transaction ID and masked PHI
    And an email notification with the subject "Patient Enrollment Failure" should be sent to the "Healthcare IT support group"

  Scenario: Unauthorized Access Attempt due to Invalid Token
    This scenario validates the API's security policy for rejecting requests with bad credentials.
    It covers the security requirements of US-104.

    Given the Patient Enrollment API is available
    When I send a POST request to "/patients" with an invalid JWT token
    Then the API response status code should be "401"
    And the response body should contain an "Unauthorized" error message

  Scenario: Secure Logging and PHI Masking Verification
    This scenario validates the compliance requirement for secure logging.
    It covers the requirements of US-103.

    Given a patient enrollment request is successfully processed for patient "Alice Wonder"
    When I inspect the application logs for the corresponding transaction
    Then all log entries for the transaction must share the same correlation ID
    And the logs must capture the key stages: "Request Received", "Authentication Successful", "Data Transformation Complete", and "Database Insert Successful"
    And the log entries must not contain the unmasked values "Alice Wonder", her address, or her insurance ID

  Scenario Outline: Validate Invalid Client Input
    This scenario validates that the API correctly rejects requests with malformed or missing data, returning a client error.
    This addresses the review feedback for negative test cases.

    Given the Patient Enrollment API is available
    When I send a patient enrollment request that is invalid because it is "<reason>"
    Then the API response status code should be "400"
    And the response body should contain a specific error message about the invalid input

    Examples:
      | reason                                             |
      | missing the mandatory 'Patient Full Name' field    |
      | using an invalid date format like "JAN-01-1990"    |
      | providing a null value for the mandatory 'Address' field |