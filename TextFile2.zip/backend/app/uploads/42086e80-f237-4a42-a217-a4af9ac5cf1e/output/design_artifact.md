# High-Level Design (HLD): Patient Enrollment Automation

**Version:** 1.0
**Date:** 2023-10-27
**Author:** Solutions Architect

---

## 1. Introduction

This document provides the High-Level Design (HLD) for the Patient Enrollment Automation system. The primary goal is to create a secure, reliable, and automated process for creating new patient records in the core healthcare database.

The system will be implemented as a REST API, built on the MuleSoft integration platform. It will receive enrollment form data from a patient portal, validate it, transform it, and securely insert it into the target healthcare database. This design addresses requirements for data security, error handling, and compliance logging.

---

## 2. Scope

### 2.1. In-Scope

*   A REST API endpoint to accept new patient enrollment data.
*   Authentication of incoming requests using JSON Web Tokens (JWT).
*   Transformation of incoming data to match the target database schema.
*   Insertion of new patient records into the `Patients` table.
*   Secure management of database credentials.
*   Encryption of data in-transit (TLS 1.2+) and at-rest (for PHI).
*   Structured and secure logging with PHI masking and correlation IDs.
*   Automated email notifications to the IT support team upon database insertion failures.

### 2.2. Out-of-Scope

*   The design and implementation of the front-end Patient Enrollment Portal.
*   The implementation of the JWT Identity Provider (IdP).
*   Patient record updates or deletions (CRUD operations other than Create).
*   User management and access control within the portal.
*   The underlying infrastructure of CloudHub or the private cloud (assumed to be managed by a separate team).

---

## 3. Architecture

The system will be implemented using an **API-led architecture**. A System API will be created in MuleSoft to encapsulate the logic of interacting with the core Patient Management Database. This promotes reusability, security, and decouples the front-end portal from the backend database system.

### 3.1. High-Level Architecture Diagram

The following diagram illustrates the key components and their interactions.

```mermaid
graph TD
    subgraph "Client Tier"
        A[Patient Enrollment Portal<br>(Web/Mobile)]
    end

    subgraph "Integration Tier (CloudHub / Private Cloud)"
        B(MuleSoft API Gateway) --> C{Patient Enrollment System API}
        C --> |1. Transform (DataWeave)| D[Data Transformation Logic]
        D --> |2. Insert Record| E[Database Connector]
        C --> |On Failure| F[Global Error Handler]
        F --> G[Secure Logger<br>(Masks PHI)]
        F --> H[Email Connector]
        C --> I[Secure Properties<br>(Credentials)]
    end

    subgraph "Backend Tier"
        E --> J[Healthcare Patient DB<br>(PostgreSQL/Oracle)]
        H --> K[Email Service]
        I --> L[Secure Vault]
    end

    A -- "1. HTTPS POST /patients<br>(with JWT)" --> B
    B -- "2. Validates JWT & Routes" --> C
    J -- "3. Returns patient_id" --> E
    C -- "4. Returns 201 Created<br>or 5xx Error" --> A
```

### 3.2. Component Descriptions

| Component                       | Technology/Platform             | Description                                                                                                                              |
| ------------------------------- | ------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------- |
| **Patient Enrollment Portal**   | Source System                   | The client-facing web or mobile application where users submit new patient enrollment forms. Responsible for acquiring the JWT.            |
| **MuleSoft API Gateway**        | MuleSoft                        | The entry point for all incoming requests. Enforces security policies like JWT validation and rate limiting. Routes requests to the System API. |
| **Patient Enrollment System API** | MuleSoft, RAML/OpenAPI          | The core application logic. It orchestrates the process of data transformation, database insertion, and error handling.                    |
| **Global Error Handler**        | MuleSoft                        | A centralized component within the API that catches all exceptions, triggers logging, and initiates failure notifications.                 |
| **Secure Logger**               | MuleSoft (Custom Logger)        | A logging component configured to mask all PHI fields before writing to logs, ensuring compliance (US-103).                               |
| **Email Connector**             | MuleSoft                        | A standard MuleSoft connector used to send email notifications to the IT support group upon processing failures (US-102).                  |
| **Secure Vault**                | CloudHub / External Vault       | A secure, encrypted repository for storing sensitive configuration, such as database credentials (US-104).                                |
| **Healthcare Patient DB**       | PostgreSQL / Oracle             | The target system of record. Stores patient information and is responsible for generating the unique `patient_id`.                         |
| **Email Service**               | SMTP Server                     | An external or internal email service used to dispatch notifications.                                                                    |

---

## 4. Data Design

### 4.1. Data Model

The data model represents a patient record based on the fields specified in the user stories.

*   **Patient:**
    *   patient_id (string, unique identifier)
    *   patient_name (string)
    *   dob (date)
    *   gender (string)
    *   address_line1 (string)
    *   city (string)
    *   state (string)
    *   postal_code (string)
    *   contact_phone (string)
    *   insurance_id (string)

### 4.2. Database Schema

A single table, `Patients`, will be used to store the enrollment data.

**Table:** `Patients`

| Column Name     | Data Type          | Constraints                               | Description                                                                 | PHI (Encrypted at Rest) |
| --------------- | ------------------ | ----------------------------------------- | --------------------------------------------------------------------------- | ----------------------- |
| `patient_id`    | `UUID` or `SERIAL` | `PRIMARY KEY`, `NOT NULL`                 | Unique, database-generated identifier for the patient.                      | No                      |
| `patient_name`  | `VARCHAR(255)`     | `NOT NULL`                                | Full name of the patient.                                                   | **Yes**                 |
| `dob`           | `DATE`             | `NOT NULL`                                | Date of birth.                                                              | **Yes**                 |
| `gender`        | `VARCHAR(50)`      |                                           | Gender of the patient.                                                      | No                      |
| `address_line1` | `VARCHAR(255)`     | `NOT NULL`                                | Street address.                                                             | **Yes**                 |
| `city`          | `VARCHAR(100)`     | `NOT NULL`                                | City of residence.                                                          | No                      |
| `state`         | `VARCHAR(100)`     | `NOT NULL`                                | State or region of residence.                                               | No                      |
| `postal_code`   | `VARCHAR(20)`      | `NOT NULL`                                | Postal or ZIP code.                                                         | No                      |
| `contact_phone` | `VARCHAR(50)`      |                                           | Primary contact phone number.                                               | **Yes**                 |
| `insurance_id`  | `VARCHAR(100)`     |                                           | Insurance policy number.                                                    | **Yes**                 |
| `created_at`    | `TIMESTAMP WITH TZ`| `NOT NULL`, `DEFAULT NOW()`               | Timestamp of when the record was created.                                   | No                      |

*Note: The mechanism for encryption at rest (e.g., PostgreSQL's `pgcrypto` extension or Oracle TDE) will be configured at the database level.*

---

## 5. API Design (RAML/OpenAPI)

The system exposes a single RESTful endpoint for creating new patient records.

### 5.1. Endpoint Definition

*   **Endpoint:** `/patients`
*   **Method:** `POST`
*   **Description:** Creates a new patient record in the healthcare system.
*   **Authentication:** Required. A valid JWT must be provided in the `Authorization` header.

### 5.2. Request

*   **Headers:**
    *   `Authorization`: `Bearer <JWT_TOKEN>` (Required)
    *   `Content-Type`: `application/json` (Required)
    *   `X-Correlation-ID`: `string` (Optional, but recommended. If not provided, the API will generate one.)

*   **Request Body (JSON):**
    ```json
    {
      "Patient Full Name": "Jane Doe",
      "Date of Birth": "1985-02-20",
      "Gender": "Female",
      "Address": "123 Health St",
      "City": "Metropolis",
      "State/Region": "CA",
      "Postal Code": "90210",
      "Phone Number": "555-123-4567",
      "Insurance Policy Number": "XYZ123456789"
    }
    ```

### 5.3. Responses

*   **Success Response (`201 Created`):**
    *   **Body (JSON):**
        ```json
        {
          "patient_id": "a1b2c3d4-e5f6-7890-1234-567890abcdef"
        }
        ```

*   **Error Response (`401 Unauthorized`):**
    *   Triggered if the JWT is missing, invalid, or expired.
    *   **Body (JSON):**
        ```json
        {
          "error": "Unauthorized",
          "message": "Authentication token is invalid or has expired."
        }
        ```

*   **Error Response (`500 Internal Server Error` / `503 Service Unavailable`):**
    *   Triggered on database insertion failure or other unexpected server-side errors.
    *   **Body (JSON):**
        ```json
        {
          "error": "Service Error",
          "message": "The patient record could not be created at this time. Please contact support.",
          "transaction_id": "f47ac10b-58cc-4372-a567-0e02b2c3d479"
        }
        ```

---

## 6. Integration and Data Flow

### 6.1. Successful Enrollment Flow (US-101)

This diagram shows the sequence of events for a successful patient enrollment.

```mermaid
sequenceDiagram
    participant Portal as Patient Portal
    participant Gateway as MuleSoft API Gateway
    participant API as Patient Enrollment API
    participant Vault as Secure Vault
    participant DB as Healthcare Patient DB

    Portal->>+Gateway: POST /patients (Payload, JWT)
    Gateway->>+API: Validate JWT & Forward Request
    API->>API: Generate Correlation ID
    API->>API: Log "Request Received" (Masked)
    API->>API: Transform payload (DataWeave)
    API->>API: Log "Data Transformation Complete"
    API->>+Vault: Request DB Credentials
    Vault-->>-API: Return DB Credentials
    API->>+DB: INSERT INTO Patients (...) VALUES (...)
    DB->>DB: Create record, generate patient_id
    DB-->>-API: Return new patient_id
    API->>API: Log "Database Insert Successful"
    API-->>-Gateway: 201 Created ({"patient_id": "..."})
    Gateway-->>-Portal: 201 Created ({"patient_id": "..."})
```

### 6.2. Database Insertion Failure Flow (US-102)

This diagram illustrates the error handling process when the database insertion fails.

```mermaid
sequenceDiagram
    participant Portal as Patient Portal
    participant API as Patient Enrollment API
    participant ErrorHandler as Global Error Handler
    participant Logger as Secure Logger
    participant Email as Email Service
    participant DB as Healthcare Patient DB

    API->>+DB: INSERT INTO Patients (...)
    DB-->>-API: **Failure** (e.g., Connection Error)
    API->>+ErrorHandler: Exception caught
    ErrorHandler->>+Logger: Log error details (with masked PHI, Correlation ID)
    Logger-->>-ErrorHandler: Log written
    ErrorHandler->>+Email: Send Notification (Subject: "Patient Enrollment Failure", Body: Error summary, ID)
    Email-->>-ErrorHandler: Notification Sent
    ErrorHandler-->>-API: Propagate error
    API-->>-Portal: 503 Service Unavailable (Error Payload)
```

---

## 7. Security Design

### 7.1. Authentication and Authorization (US-104)

*   **JWT Validation:** The MuleSoft API Gateway will be configured with a JWT Validation policy. It will verify the token's signature, issuer (`iss`), and expiration (`exp`) before forwarding the request to the backend API.
*   **Authorization:** While not explicitly detailed in the stories, the JWT payload could contain scopes or roles (e.g., `enrollment:create`) that the API can check for more granular access control.

### 7.2. Data Encryption (US-104)

*   **In-Transit:** All communication between the Patient Portal and the MuleSoft API Gateway will be encrypted using HTTPS, with a minimum protocol of TLS 1.2.
*   **At-Rest:** The columns identified as PHI in the `Patients` table schema (Section 4.2) will be encrypted at the database level. This ensures that even with direct database access, the sensitive data remains protected.

### 7.3. Secrets Management (US-104)

*   Database credentials (username, password, host, port) will **not** be stored in the MuleSoft application's properties files or source code.
*   The MuleSoft application will be configured to retrieve these credentials at runtime from a secure, externalized vault (e.g., CloudHub's Secure Properties, HashiCorp Vault, or an equivalent service).

---

## 8. Logging and Monitoring

### 8.1. Logging Strategy (US-103)

*   **Correlation ID:** A unique correlation ID will be associated with every request. If the `X-Correlation-ID` header is present, its value will be used. Otherwise, the API will generate a new UUID. This ID will be included in every log entry for a given transaction, enabling easy tracing.
*   **PHI Masking:** A custom logging component or a DataWeave transformation within the logging flow will be used to mask all PHI fields before the log entry is written. For example, `patient_name: "Jane Doe"` will be logged as `patient_name: "*******"`.
*   **Log Stages:** Logs will be generated at critical processing stages:
    *   `Request Received`
    *   `Authentication Successful/Failed`
    *   `Data Transformation Complete`
    *   `Database Insert Successful/Failed`

### 8.2. Monitoring and Alerting (US-102)

*   **Alert Trigger:** The Global Error Handler in the MuleSoft API will be the single point for triggering failure alerts.
*   **Notification Channel:** Email will be used as the notification channel. The MuleSoft Email Connector will be configured with the SMTP server details and the `Healthcare IT support group` distribution list.
*   **Email Content:** The email will be formatted to include:
    *   **Subject:** `Patient Enrollment Failure`
    *   **Body:**
        *   `Transaction ID`: The correlation ID for the failed request.
        *   `Timestamp`: The time of the failure.
        *   `Error Summary`: A brief, non-sensitive description of the error (e.g., "Database connection timeout").

---