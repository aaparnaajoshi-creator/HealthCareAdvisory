# High-Level Design (HLD): PharmaCorp Commercial Website

## 1. Introduction

This High-Level Design (HLD) document outlines the architectural blueprint for the PharmaCorp Commercial Website. It details the system's components, data models, API specifications, and deployment considerations based on the provided user stories and technical constraints. The primary goal is to deliver a secure, performant, accessible, and user-friendly platform that effectively communicates PharmaCorp's mission, products, and information to its audience.

## 2. Architectural Overview

The PharmaCorp Commercial Website will adopt a multi-tier web application architecture, separating the client-side user interface from the backend API services and data storage. This approach promotes modularity, scalability, and maintainability.

### 2.1 High-Level Architecture Diagram

```mermaid
graph TD
    A[User/Client Device] --> B{Internet / CDN};
    B --> C[CloudFront / CDN (Static Content, Caching)];
    C --> D[WAF / API Gateway (Rate Limiting, Security)];
    D --> E[Python Backend (FastAPI/Flask) API Service];
    E --> F[PostgreSQL Database];
    E --> G[Object Storage (S3/Azure Blob/GCS)];

    C -- "HTTPS" --> A;
    D -- "HTTPS" --> C;
    E -- "HTTPS" --> D;

    subgraph Backend Services
        E
        F
        G
    end

    subgraph Frontend Delivery
        C
    end
```

### 2.2 Key Components & Technologies

*   **Frontend (Client-Side Application):**
    *   **Technologies:** HTML5, CSS3, JavaScript.
    *   **Purpose:** Renders the user interface, handles client-side logic (e.g., responsiveness, form validation, cookie consent UI), and interacts with the backend API.
*   **Content Delivery Network (CDN):**
    *   **Technologies:** AWS CloudFront, Cloudflare, Azure CDN, Google Cloud CDN.
    *   **Purpose:** Serves static assets (HTML, CSS, JS, images) with low latency, improves performance, and offloads traffic from the backend. Also handles HTTPS termination.
*   **Web Application Firewall (WAF) / API Gateway:**
    *   **Technologies:** AWS WAF/API Gateway, Azure Application Gateway/API Management, Google Cloud Armor/API Gateway.
    *   **Purpose:** Provides security (e.g., protection against common web exploits), rate limiting for API endpoints, and centralized API management.
*   **Backend (API Service):**
    *   **Technologies:** Python (FastAPI or Flask).
    *   **Purpose:** Provides RESTful APIs for dynamic content retrieval (products), form submissions (contact, newsletter), and search functionality. Handles server-side validation, business logic, and database interactions.
*   **Database:**
    *   **Technologies:** PostgreSQL.
    *   **Purpose:** Stores structured data such as product information, contact form submissions, and newsletter subscriber details.
*   **Object Storage:**
    *   **Technologies:** AWS S3, Azure Blob Storage, Google Cloud Storage.
    *   **Purpose:** Stores unstructured binary large objects (BLOBs) like Product Information (PI) PDFs and Medication Guide (MedGuide) PDFs.
*   **Security:**
    *   **Measures:** HTTPS for all traffic, Content Security Policy (CSP), client-side and server-side input validation, API rate limiting, GDPR/CCPA compliance.
*   **Deployment:**
    *   **Process:** CI/CD pipeline for automated deployments across Dev, Staging, and Production environments.

## 3. Component Deep Dive

### 3.1 Frontend (Client-Side Application)

*   **Technologies:** HTML5, CSS3, JavaScript. Frameworks like React, Vue, or Angular are not explicitly mentioned but could be considered for larger-scale JS applications; for this scope, vanilla JS or a lightweight library might suffice.
*   **Key Features:**
    *   **Responsiveness:** Utilizes CSS media queries and flexible layouts to ensure optimal viewing and interaction across desktop, tablet, and mobile devices (AC1.4, AC2.3, AC3.4, AC4.4, AC5.5, AC6.7, AC7.8, AC8.8, AC9.6, AC10.7).
    *   **Accessibility (WCAG 2.2 AA):** Implements semantic HTML, ARIA attributes, keyboard navigation, sufficient color contrast, and focus management to meet accessibility standards (AC1.5, AC2.4, AC3.5, AC4.5, AC5.6, AC6.8, AC7.8, AC8.8, AC9.6, AC10.7).
    *   **Sticky ISI (AC6.4):** The frontend will incorporate a dedicated component for the Important Safety Information (ISI) section on product detail pages. This component will utilize CSS `position: sticky;` combined with appropriate `top` or `bottom` values, potentially augmented with JavaScript for broader browser compatibility or more complex scroll-based interactions, to ensure the ISI remains visible as the user scrolls.
    *   **Cookie Consent UI (AC10.1-10.7):** A JavaScript-driven banner/pop-up will be displayed on first visit, managing user preferences locally (e.g., via browser cookies/localStorage) and controlling the loading of non-essential scripts (e.g., analytics).
    *   **Form Validation:** Client-side validation for contact and newsletter forms (AC7.3, AC8.3).
    *   **Performance:** Optimized asset loading, image compression, and efficient JavaScript to achieve LCP < 2.5 seconds (AC1.6, AC2.5, AC3.6, AC4.6, AC5.7, AC6.9, AC10.8).

### 3.2 Backend (API Service)

*   **Technologies:** Python (FastAPI or Flask). FastAPI is generally preferred for new API development due to its modern features, automatic OpenAPI documentation, and asynchronous capabilities.
*   **Core Responsibilities:**
    *   **API Serving:** Exposes RESTful endpoints for all dynamic data needs.
    *   **Data Retrieval:** Fetches product information and search results from PostgreSQL (AC5.4, AC6.3, AC9.4).
    *   **Data Persistence:** Stores contact form submissions (AC7.5) and newsletter subscriptions (AC8.5) in PostgreSQL.
    *   **Input Validation:** Performs server-side validation for all incoming form data to ensure data integrity and security (AC7.3, AC8.3).
    *   **Business Logic:** Implements any specific business rules related to data processing or interactions.
    *   **Rate Limiting:** Implements API rate limiting for contact form and newsletter signup endpoints to prevent abuse (AC7.6, AC8.7).
    *   **Security:** Handles authentication (if user accounts were introduced later), ensures data privacy, and interacts securely with the database and object storage.

### 3.3 Database (PostgreSQL)

*   **Purpose:** Relational database for structured content and user submissions.
*   **Schema Design:**

    ```sql
    -- Table for Product Information
    CREATE TABLE products (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        indications TEXT,
        dosage TEXT,
        isi_text TEXT, -- Important Safety Information text (AC6.4)
        pi_pdf_url VARCHAR(2048), -- URL to Product Information PDF in object storage (AC6.5)
        medguide_pdf_url VARCHAR(2048), -- URL to Medication Guide PDF in object storage (AC6.5)
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    );

    -- Table for Contact Form Submissions
    CREATE TABLE contact_submissions (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        subject VARCHAR(512),
        message TEXT NOT NULL,
        submitted_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    );

    -- Table for Newsletter Subscribers
    CREATE TABLE newsletter_subscribers (
        id SERIAL PRIMARY KEY,
        email VARCHAR(255) UNIQUE NOT NULL,
        name VARCHAR(255), -- Optional
        consent_given_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        is_active BOOLEAN DEFAULT TRUE, -- For unsubscribe management
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    );

    -- Optional: Index for search performance on products
    -- Consider using PostgreSQL's built-in full-text search capabilities
    CREATE INDEX idx_products_search ON products USING GIN (to_tsvector('english', name || ' ' || description || ' ' || indications || ' ' || dosage));
    ```

### 3.4 Object Storage

*   **Purpose:** Securely store and serve large binary files (PDFs).
*   **Integration:**
    *   The backend API will store and retrieve references (URLs) to these documents in the `products` table.
    *   The actual PDFs will be served directly from the object storage via pre-signed URLs or public URLs, ensuring secure delivery over HTTPS (AC6.6, AC6.10).

### 3.5 Infrastructure & Deployment

*   **CDN:** All static frontend assets (HTML, CSS, JS, images) will be served via a CDN for global distribution, caching, and performance.
*   **WAF/API Gateway:** Positioned in front of the backend API to provide security, rate limiting, and centralized traffic management.
*   **CI/CD Pipeline:** Automated build, test, and deployment processes using tools like Jenkins, GitLab CI/CD, GitHub Actions, or Azure DevOps. This pipeline will deploy:
    *   Frontend assets to the CDN.
    *   Backend API to containerized environments (e.g., Docker containers deployed on a managed service like AWS ECS/EKS, Azure AKS, Google Cloud Run/GKE).
*   **Environments:** Separate Dev, Staging, and Production environments to ensure proper testing and quality assurance before release.

## 4. API Design

The backend API will expose RESTful endpoints for data interaction.

### 4.1 API Endpoints

| Endpoint                               | Method | Description                                                | Request Body (JSON)                                        | Success Response (JSON)                                        | Error Responses (JSON)                                      |
| :------------------------------------- | :----- | :--------------------------------------------------------- | :--------------------------------------------------------- | :------------------------------------------------------------- | :---------------------------------------------------------- |
| `/api/products`                        | `GET`  | Retrieve a list of all products.                           | `N/A`                                                      | `[{"id": 1, "name": "Drug A", "description": "...", ...}]`    | `{"error": "message"}` (e.g., 500 Internal Server Error)    |
| `/api/products/{id}`                   | `GET`  | Retrieve details for a specific product.                   | `N/A`                                                      | `{"id": 1, "name": "Drug A", "description": "...", "isi_text": "...", "pi_pdf_url": "...", "medguide_pdf_url": "..."}` | `{"error": "Product not found"}` (404 Not Found)            |
| `/api/contact`                         | `POST` | Submit a contact form message.                             | `{"name": "...", "email": "...", "subject": "...", "message": "..."}` | `{"status": "success", "message": "Form submitted successfully."}` | `{"error": "Validation failed", "details": {...}}` (400 Bad Request), `{"error": "Too many requests"}` (429 Too Many Requests) |
| `/api/newsletter/subscribe`            | `POST` | Subscribe an email to the newsletter.                      | `{"email": "...", "name": "..."}`                          | `{"status": "success", "message": "Subscribed successfully."}` | `{"error": "Invalid email format"}` (400 Bad Request), `{"error": "Email already subscribed"}` (409 Conflict), `{"error": "Too many requests"}` (429 Too Many Requests) |
| `/api/search?q={query}`                | `GET`  | Perform a site-wide search based on a query string.        | `N/A`                                                      | `[{"type": "product", "title": "...", "snippet": "...", "url": "..."}, {"type": "page", "title": "...", "snippet": "...", "url": "..."}]` | `{"error": "message"}` (e.g., 500 Internal Server Error)    |

## 5. Data Flow Diagrams

### 5.1 Product Detail Page Data Flow

```mermaid
sequenceDiagram
    participant U as User
    participant F as Frontend (Browser)
    participant C as CDN
    participant W as WAF/API Gateway
    participant B as Python Backend API
    participant D as PostgreSQL DB
    participant O as Object Storage

    U->>F: Navigates to Product Detail Page URL
    F->>C: Request HTML, CSS, JS for page
    C-->>F: Serve static assets (cached)
    F->>W: API Call: GET /api/products/{id} (AC6.1, AC6.3)
    W->>B: Forward API Request
    B->>D: Query DB for product details by ID (AC6.3)
    D-->>B: Return product data (name, description, ISI, PDF URLs)
    B-->>W: Return Product Data (JSON)
    W-->>F: Return Product Data (JSON)
    F->>F: Render Product Detail Page with dynamic data (AC6.2)
    F->>F: Display sticky ISI (AC6.4)
    F->>O: User clicks to download PI/MedGuide PDF (AC6.5)
    O-->>F: Serve PDF file securely (AC6.6, AC6.10)
```

### 5.2 Contact Form Submission Data Flow

```mermaid
sequenceDiagram
    participant U as User
    participant F as Frontend (Browser)
    participant W as WAF/API Gateway
    participant B as Python Backend API
    participant D as PostgreSQL DB

    U->>F: Fills out Contact Form (AC7.2)
    F->>F: Client-side validation (AC7.3)
    F->>W: API Call: POST /api/contact (AC7.9 - HTTPS)
    W->>W: Apply Rate Limiting (AC7.6)
    W->>B: Forward API Request
    B->>B: Server-side validation (AC7.3)
    B->>D: Store form data (AC7.5)
    D-->>B: Confirmation of storage
    B-->>W: Return success confirmation (JSON)
    W-->>F: Return success confirmation (JSON)
    F->>F: Display confirmation message to user (AC7.4)
```

## 6. Security Considerations

*   **HTTPS Everywhere:** All communication between the client, CDN, WAF/API Gateway, and backend will be encrypted using HTTPS (AC1.7, AC2.6, AC3.7, AC4.7, AC5.8, AC6.10, AC7.9, AC8.9, AC9.7).
*   **Content Security Policy (CSP):** Implemented on the frontend to mitigate XSS attacks by restricting sources of content (scripts, styles, images) (AC7.9, AC8.9).
*   **Input Validation:** Robust client-side (JavaScript) and server-side (Python API) validation to prevent injection attacks (SQL injection, XSS) and ensure data integrity (AC7.3, AC8.3).
*   **Rate Limiting:** Implemented at the API Gateway and/or backend level for form submissions (contact, newsletter) to prevent denial-of-service attacks and spam (AC7.6, AC8.7).
*   **Data Privacy (GDPR/CCPA Compliance):**
    *   Cookie Consent: Clear banner/pop-up for granular consent management (AC10.1-10.7).
    *   Privacy Policy: Easily accessible links to the Privacy Policy (AC1.3, AC4.1, AC8.6, AC10.6).
    *   Consent Mechanisms: Explicit consent for marketing communications (newsletter) and data processing (contact form) (AC7.7, AC8.6).
*   **Secure Storage:** Sensitive data (if any, though not explicit in SRS) would be encrypted at rest and in transit. PDFs in object storage are securely served (AC6.6).
*   **Least Privilege:** Backend services and database access will operate with the minimum necessary permissions.

## 7. Scalability & Performance

*   **CDN Caching:** Leveraged extensively for static content (HTML, CSS, JS, images) and potentially for API responses that change infrequently (e.g., product lists), significantly reducing backend load and improving LCP.
*   **Backend Horizontal Scaling:** The Python backend API service will be designed for statelessness, allowing for easy horizontal scaling by adding more instances based on traffic demand.
*   **Database Optimization:** PostgreSQL can be optimized with proper indexing (e.g., for search queries), query tuning, and connection pooling. For future scale, read replicas could be introduced.
*   **Efficient Frontend:** Minified assets, optimized images, and efficient JavaScript execution contribute to fast page loads and responsiveness.
*   **API Gateway:** Can handle traffic routing and load balancing across backend instances.

## 8. Accessibility (WCAG 2.2 AA)

Accessibility is a core non-functional requirement across all user stories. The design incorporates:

*   Semantic HTML5 elements.
*   Appropriate ARIA roles and attributes.
*   Keyboard navigability for all interactive elements.
*   Sufficient color contrast ratios.
*   Clear focus indicators.
*   Descriptive alt text for images.
*   Proper form labeling and error handling.
*   Responsive design that maintains usability across screen sizes.

## 9. Monitoring & Logging

*   **Application Logging:** Backend API will log requests, errors, and critical events.
*   **Performance Monitoring:** Tools will monitor API response times, database query performance, and server resource utilization.
*   **Frontend Performance:** Metrics like LCP, FID, CLS will be tracked.
*   **Alerting:** Automated alerts for critical errors or performance degradation.

## 10. Future Considerations

*   **Content Management System (CMS):** For managing static pages (About Us, Legal) and potentially product information, a headless CMS could be integrated, reducing direct database dependency for content.
*   **Analytics:** Integration with web analytics tools (e.g., Google Analytics) for tracking user behavior, subject to cookie consent.
*   **User Authentication:** If future requirements involve user-specific content or personalized experiences, a user authentication system would be added.