```sql
-- database/init.sql
-- Table for Product Information
CREATE TABLE IF NOT EXISTS products (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    indications TEXT,
    dosage TEXT,
    isi_text TEXT, -- Important Safety Information text
    pi_pdf_url VARCHAR(2048), -- URL to Product Information PDF in object storage
    medguide_pdf_url VARCHAR(2048), -- URL to Medication Guide PDF in object storage
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Table for Contact Form Submissions
CREATE TABLE IF NOT EXISTS contact_submissions (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    subject VARCHAR(512),
    message TEXT NOT NULL,
    submitted_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Table for Newsletter Subscribers
CREATE TABLE IF NOT EXISTS newsletter_subscribers (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(255), -- Optional
    consent_given_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE, -- For unsubscribe management
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Optional: Index for search performance on products
-- Consider using PostgreSQL's built-in full-text search capabilities
CREATE INDEX IF NOT EXISTS idx_products_search ON products USING GIN (to_tsvector('english', name || ' ' || description || ' ' || indications || ' ' || dosage));

-- Insert some sample data for products (for testing/demo purposes)
INSERT INTO products (name, description, indications, dosage, isi_text, pi_pdf_url, medguide_pdf_url) VALUES
('PharmaDrug X', 'A revolutionary medication for chronic pain.', 'Chronic pain, inflammation', 'Take 1 tablet daily with food.', 'Important Safety Information for PharmaDrug X: May cause drowsiness. Do not operate heavy machinery. Consult your doctor before use if you have liver or kidney conditions. Keep out of reach of children.', 'https://example.com/pdfs/pharmadrugx_pi.pdf', 'https://example.com/pdfs/pharmadrugx_medguide.pdf'),
('VitalLife Z', 'An advanced supplement for immune support.', 'Immune system support, general wellness', 'Take 2 capsules daily.', 'Important Safety Information for VitalLife Z: Not intended to diagnose, treat, cure, or prevent any disease. Pregnant or nursing mothers, children under 18, and individuals with a known medical condition should consult a physician before using this or any dietary supplement.', 'https://example.com/pdfs/vitallifez_pi.pdf', 'https://example.com/pdfs/vitallifez_medguide.pdf'),
('NeuroCalm', 'A new therapy for anxiety and stress relief.', 'Generalized anxiety disorder, acute stress', 'Administer 1 dose every 8 hours as needed.', 'Important Safety Information for NeuroCalm: Avoid alcohol consumption. May impair ability to drive or operate machinery. Risk of dependence with prolonged use. Discuss all medications with your healthcare provider.', 'https://example.com/pdfs/neurocalm_pi.pdf', 'https://example.com/pdfs/neurocalm_medguide.pdf')
ON CONFLICT (id) DO NOTHING; -- Prevents re-insertion on subsequent runs