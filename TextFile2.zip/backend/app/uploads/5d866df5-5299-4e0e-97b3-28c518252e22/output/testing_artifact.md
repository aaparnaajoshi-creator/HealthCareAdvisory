# Test Plan & Strategy: Patient Enrollment Automation

**Version:** 1.0
**Date:** 2023-10-27
**Author:** QA Automation Engineer

---

## 1. Test Strategy

### 1.1. Introduction
This document outlines the comprehensive testing strategy and plan for the **Patient Enrollment Automation** project. The goal is to ensure the Patient Management API is secure, reliable, and functions according to the specified requirements. This plan covers the scope, objectives, testing types, and automation approach for validating the API's functionality.

### 1.2. Scope

#### 1.2.1. In-Scope
*   **API Functional Testing:** Testing the `POST /patients` endpoint for successful creation (US-101), data validation, and negative scenarios.
*   **Security Testing:** Validating JWT-based authentication mechanisms (US-103).
*   **Error Handling Testing:** Verifying the system's behavior during backend failures, including database unavailability and constraint violations (US-102).
*   **Notification Testing:** Ensuring email alerts are triggered correctly upon failure, with the correct content and no PHI (US-102).
*   **Logging & Compliance Testing:** Verifying that all transaction logs are created, traceable via a transaction ID, and that all PHI is appropriately masked (US-104).
*   **Integration Testing:** Validating the data flow from the API to the Healthcare Patient Database, ensuring correct data mapping and persistence.

#### 1.2.2. Out-of-Scope
*   **UI Testing:** The Patient Enrollment Portal front-end is not part of this testing effort.
*   **Third-Party System Testing:** The JWT generation service, the email server (e.g., SMTP server uptime), and the underlying database performance are considered external dependencies and are not under the scope of this test plan. We will use mocks or stubs where necessary.
*   **Performance & Load Testing:** While foundational, a full-scale performance test is out of scope for this initial functional testing phase but is recommended for a future release cycle.
*   **Infrastructure Testing:** Testing the CloudHub/PCE deployment environment, VPC configuration, or network latency.

### 1.3. Quality Objectives
*   **Functionality:** Achieve 100% coverage of all acceptance criteria defined in the user stories.
*   **Security:** Ensure no unauthorized access is possible and all security requirements (US-103) are met.
*   **Reliability:** Validate that the error handling and notification system (US-102) is robust and operates as expected under failure conditions.
*   **Compliance:** Confirm that all logging and data handling practices comply with PHI masking requirements (US-104).
*   **Data Integrity:** Guarantee that data is accurately transformed and stored in the database without corruption or loss.

### 1.4. Testing Types
*   **API Testing (Functional & Negative):** Using tools like Postman and automated scripts to send requests to the API endpoint, verifying responses, status codes, and data persistence. This includes testing with valid, invalid, and malformed payloads.
*   **Security Testing:** Focused on validating the authentication controls. This involves sending requests with valid, invalid, expired, and missing JWTs to ensure the endpoint is properly secured.
*   **Integration Testing:** Verifying the end-to-end flow, from API request to database record creation, ensuring the API correctly interacts with the database.
*   **Database Testing:** Directly querying the database to confirm that records are created, updated, or not created as expected by the test scenarios.
*   **Error Handling Testing:** Simulating failure conditions (e.g., bringing down a mock database, sending duplicate keys) to test the global error handler, logging, and notification mechanisms.

### 1.5. Test Environment & Tools
| Component | Tool / Specification | Purpose |
| :--- | :--- | :--- |
| **Test Execution** | Postman / Newman | Manual API exploration and automated CI/CD test runs. |
| **Automation Framework**| BDD Framework (e.g., Cucumber, Behave) with Python/Java | To write and execute automated tests based on Gherkin feature files. |
| **Mocking** | WireMock / Mockoon | To simulate database failures and other downstream dependencies. |
| **Email Validation** | MailHog / Mock SMTP Server | To intercept and validate outbound email notifications without spamming real inboxes. |
| **Database Client** | DBeaver / pgAdmin | To connect to the test database and verify data integrity. |
| **Log Viewer** | Splunk / ELK Stack | To inspect application logs and verify masking and error details. |
| **Test Environment** | QA/Staging Environment | An isolated environment mirroring production with the API deployed and connected to a test database. |

### 1.6. Entry & Exit Criteria
*   **Entry Criteria:**
    *   The Test Plan is approved by all stakeholders.
    *   The Patient Management API is successfully deployed to the QA environment.
    *   All required test data (e.g., valid JWTs for testing) is available.
    *   The QA environment, including the database and logging/email services, is stable and accessible.
*   **Exit Criteria:**
    *   All planned test cases have been executed.
    *   95% of test cases have passed.
    *   There are no open Critical or High severity defects.
    *   All defects are documented, and a bug triage has been completed.
    *   The test summary report is generated and shared with stakeholders.

---

## 2. Test Plan & Manual Test Cases

### 2.1. US-101: Successful Patient Record Creation via API

| Test Case ID | Description | Preconditions | Steps | Expected Result |
| :--- | :--- | :--- | :--- | :--- |
| TC-101-01 | **Happy Path:** Create a patient with all valid data. | A valid, unexpired JWT is available. | 1. Construct a valid JSON payload. <br> 2. Send a POST request to `/patients` with the payload and JWT. | 1. HTTP status code `201 Created` is returned. <br> 2. The response body contains a `patient_id`. <br> 3. A new record matching the payload data is created in the `Patients` table. |
| TC-101-02 | **Data Validation:** Create a patient with a missing required field (e.g., `Patient Full Name`). | A valid JWT is available. | 1. Construct a JSON payload missing the `Patient Full Name` field. <br> 2. Send a POST request to `/patients`. | 1. HTTP status code `400 Bad Request` is returned. <br> 2. The response body contains a clear error message. <br> 3. No record is created in the database. |
| TC-101-03 | **Data Validation:** Create a patient with an invalid data format (e.g., `Date of Birth` as "12-04-1985"). | A valid JWT is available. | 1. Construct a JSON payload with an invalid date format. <br> 2. Send a POST request to `/patients`. | 1. HTTP status code `400 Bad Request` is returned. <br> 2. The response body contains a clear error message about the date format. <br> 3. No record is created in the database. |

### 2.2. US-102: Handle Failed Patient Record Creation

| Test Case ID | Description | Preconditions | Steps | Expected Result |
| :--- | :--- | :--- | :--- | :--- |
| TC-102-01 | **DB Failure:** Attempt to create a patient when the database is unavailable. | The test database is shut down or inaccessible from the API. A valid JWT is available. | 1. Construct a valid JSON payload. <br> 2. Send a POST request to `/patients`. | 1. HTTP status code `503 Service Unavailable` is returned. <br> 2. An email alert is sent to the IT Support list with the subject `CRITICAL ALERT: Patient Enrollment Failure`. <br> 3. The email body contains a transaction ID and an error like "Database connection failed" but **no PHI**. <br> 4. The system log contains a masked entry for the failure. |
| TC-102-02 | **DB Constraint Failure:** Attempt to create a patient with a duplicate `patient_id`. | A patient with a known `patient_id` already exists. The API is manipulated to reuse this ID. | 1. Construct a valid JSON payload. <br> 2. Send a POST request to `/patients` that will result in a primary key violation. | 1. HTTP status code `500 Internal Server Error` is returned. <br> 2. An email alert is sent with an error like "Duplicate key violation" and **no PHI**. <br> 3. The system log contains a masked entry with the specific database error. |

### 2.3. US-103: Secure API Endpoint with Authentication

| Test Case ID | Description | Preconditions | Steps | Expected Result |
| :--- | :--- | :--- | :--- | :--- |
| TC-103-01 | **Unauthorized:** Send request with an invalid/malformed JWT. | An invalid JWT string is available. | 1. Construct a valid JSON payload. <br> 2. Send a POST request to `/patients` with the invalid JWT in the `Authorization` header. | 1. HTTP status code `401 Unauthorized` is returned. <br> 2. No record is created in the database. |
| TC-103-02 | **Unauthorized:** Send request with an expired JWT. | An expired JWT is available. | 1. Construct a valid JSON payload. <br> 2. Send a POST request to `/patients` with the expired JWT. | 1. HTTP status code `401 Unauthorized` is returned. <br> 2. No record is created in the database. |
| TC-103-03 | **Unauthorized:** Send request with no JWT. | - | 1. Construct a valid JSON payload. <br> 2. Send a POST request to `/patients` without the `Authorization` header. | 1. HTTP status code `401 Unauthorized` is returned. <br> 2. No record is created in the database. |

### 2.4. US-104: Secure Logging and Data Masking

| Test Case ID | Description | Preconditions | Steps | Expected Result |
| :--- | :--- | :--- | :--- | :--- |
| TC-104-01 | **Verify Masking on Success:** Check logs after a successful patient creation. | A patient has been successfully created via TC-101-01. | 1. Execute test case TC-101-01. <br> 2. Access the application logs for the corresponding transaction. | 1. A log entry for the successful transaction exists. <br> 2. The log entry includes a transaction ID and timestamp. <br> 3. All PHI fields (`patient_name`, `dob`, `address`, `insurance_id`, etc.) in the logged payload are masked. |
| TC-104-02 | **Verify Masking on Failure:** Check logs after a failed transaction. | A database failure has been simulated via TC-102-01. | 1. Execute test case TC-102-01. <br> 2. Access the application logs for the corresponding transaction. | 1. An ERROR log entry for the failed transaction exists. <br> 2. The log entry includes a transaction ID, timestamp, and non-sensitive error details. <br> 3. Any logged part of the request payload containing PHI is masked. |

---

## 3. BDD Feature File (For Automation)

Feature: Patient Enrollment API
  As a healthcare system, I need to create, secure, and monitor patient enrollment records
  to ensure data is processed efficiently, accurately, and in compliance with PHI regulations.

  Background:
    Given the Patient Management API is running at "https://api.healthcare.org/v1"
    And I have a valid, unexpired JWT for authentication

  Scenario Outline: Successfully create a new patient record
    Given I have the following patient data
      | Patient Full Name         | Date of Birth | Gender | Address          | City    | State/Region | Postal Code | Phone Number | Insurance Policy Number |
      | <Patient Full Name>       | <DOB>         | <Gender> | <Address>        | <City>  | <State>      | <Zip>       | <Phone>      | <Insurance ID>          |
    When I send a POST request to "/patients" with the patient data
    Then the response status code should be 201
    And the response body should contain a non-null "patient_id"
    And a patient record for "<Patient Full Name>" with insurance ID "<Insurance ID>" should exist in the database
    And the system log should contain a success entry with all PHI fields masked

    Examples:
      | Patient Full Name | DOB        | Gender | Address            | City      | State | Zip     | Phone        | Insurance ID  |
      | "Jane Doe"        | "1990-05-21" | "Female" | "456 Oak Avenue"   | "Springfield" | "IL"  | "62704" | "555-987-6543" | "DEF456789012"  |
      | "Peter Jones"     | "1978-11-02" | "Male"   | "789 Pine Street"  | "Metropolis"  | "NY"  | "10001" | "555-555-5555" | "GHI789012345"  |

  Scenario Outline: Attempt to process a request with invalid authentication
    Given I have valid patient data for "John Wick"
    When I send a POST request to "/patients" using an "<Auth Type>" token
    Then the response status code should be 401
    And the response body should contain an "Unauthorized" error message
    And no patient record for "John Wick" should be created in the database

    Examples:
      | Auth Type         |
      | "invalid"         |
      | "expired"         |
      | "missing"         |

  Scenario: Handle patient creation failure due to a database error and verify notifications and logs
    Given I have valid patient data for a new patient "Error Case"
    And the database is configured to fail the next insert operation with a "Duplicate key violation" error
    When I send a POST request to "/patients" with the "Error Case" data
    Then the response status code should be 500
    And an email alert should be sent with the following details
      | Field   | Value                               |
      | Subject | CRITICAL ALERT: Patient Enrollment Failure |
      | To      | Healthcare IT Support               |
    And the email body must contain the transaction ID and a non-PHI error message
    And the system log should contain a masked error entry for the transaction
    And the log entry must not contain any of the following unmasked PHI fields
      | Field Name              |
      | patient_name            |
      | dob                     |
      | address_line1           |
      | insurance_id            |