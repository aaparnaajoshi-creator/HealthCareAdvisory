# High-Level Design (HLD): Patient Enrollment Automation

**Version:** 1.0
**Date:** 2023-10-27
**Author:** Solutions Architect

---

## 1. Introduction

This document outlines the high-level design for the Patient Enrollment Automation system. The primary goal is to create a secure, reliable, and automated integration solution that captures new patient data from a source portal and persists it into the core Healthcare Patient Database.

The solution will be implemented as a RESTful API using the MuleSoft Anypoint Platform. It will handle data transformation, security enforcement via JWT, and robust error handling with notifications, ensuring data integrity and compliance with PHI regulations.

## 2. Architecture Overview

The system will be designed following an **API-Led Connectivity** approach, where the Patient Management API acts as a System API. This architecture promotes reusability, security, and clear separation of concerns. The API provides a secure, modern RESTful interface to a backend database system.

The overall flow is as follows:
1.  The **Patient Enrollment Portal** captures patient data and obtains a JWT for authentication.
2.  The portal sends an HTTPS POST request with the patient data and JWT to the **Patient Management API**.
3.  The API, deployed on **CloudHub/Private Cloud**, validates the JWT and the incoming request payload.
4.  Upon successful validation, the API transforms the data and inserts a new record into the **Healthcare Patient DB**.
5.  If the database operation fails, the API's global error handler logs the masked error and sends an email notification to the **IT Support team**.

### 2.1. System Architecture Diagram

```mermaid
graph TD
    subgraph "Source System"
        PEP[Patient Enrollment Portal]
    end

    subgraph "Integration Layer (MuleSoft on CloudHub/Private Cloud)"
        API[Patient Management API <br> (HTTPS REST)]
        API -- 1. POST /patients --> SEC{Security Filter <br> JWT Validation}
        SEC -- 2. Validated Request --> VAL{Validation & Transformation <br> (DataWeave)}
        VAL -- 3. Mapped Data --> DBC[Database Connector]
        DBC -- 4. Insert Record --> DB[(Healthcare Patient DB <br> PostgreSQL/Oracle)]
        DBC -- 5. Success --> API
        API -- 6. 201 Created --> PEP

        subgraph "Error Handling"
            GEH{Global Error Handler}
            DBC -- 4a. DB Failure --> GEH
            GEH -- 4b. Log Masked Error --> LOG[Logging Service]
            GEH -- 4c. Send Alert --> MAIL[Email Service]
            GEH -- 4d. 5xx Error --> API
            API -- 4e. 5xx Response --> PEP
        end
    end

    subgraph "Backend Systems"
        DB
    end

    subgraph "Support Systems"
        LOG
        MAIL
    end
```

## 3. Data Model and Database Schema

The solution will interact with the `Patients` table in the Healthcare Patient Database. The schema is designed to store the required patient information as specified in the user stories.

### 3.1. `Patients` Table Schema

The target database can be PostgreSQL or Oracle. The following schema is defined using PostgreSQL syntax.

```sql
CREATE TABLE Patients (
    patient_id VARCHAR(255) PRIMARY KEY, -- System-generated unique identifier
    patient_name VARCHAR(255) NOT NULL,
    dob DATE NOT NULL,
    gender VARCHAR(50),
    address_line1 VARCHAR(255) NOT NULL,
    city VARCHAR(100) NOT NULL,
    state VARCHAR(100) NOT NULL,
    postal_code VARCHAR(20) NOT NULL,
    contact_phone VARCHAR(50),
    insurance_id VARCHAR(255) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Optional: Add a unique constraint on insurance_id if it should be unique per patient
-- ALTER TABLE Patients ADD CONSTRAINT unique_insurance_id UNIQUE (insurance_id);
```

## 4. API Design (RAML/OpenAPI)

The Patient Management API will expose a single endpoint for creating new patient records. The API contract will be defined using RAML or OpenAPI Specification.

**Base URI:** `https://api.healthcare.org/v1`
**Authentication:** Bearer Token (JWT)

---

### 4.1. Endpoint: Create New Patient

*   **Resource:** `/patients`
*   **Method:** `POST`
*   **Description:** Creates a new patient record from an enrollment form submission.

#### **Headers:**
*   `Authorization`: `Bearer <JWT_TOKEN>` (Required)
*   `Content-Type`: `application/json` (Required)
*   `X-Transaction-ID`: `string` (Optional, but recommended for traceability)

#### **Request Body (application/json):**

```json
{
  "Patient Full Name": "John Smith",
  "Date of Birth": "1985-04-12",
  "Gender": "Male",
  "Address": "123 Main Street",
  "City": "Anytown",
  "State/Region": "CA",
  "Postal Code": "90210",
  "Phone Number": "555-123-4567",
  "Insurance Policy Number": "ABC123456789"
}
```

#### **Responses:**

*   **`201 Created`**: The patient record was successfully created.
    **Body (application/json):**
    ```json
    {
      "patient_id": "a1b2c3d4-e5f6-7890-1234-567890abcdef"
    }
    ```

*   **`400 Bad Request`**: The request payload is malformed or fails validation.
    **Body (application/json):**
    ```json
    {
      "error": "Invalid input",
      "message": "Field 'Date of Birth' must be in YYYY-MM-DD format."
    }
    ```

*   **`401 Unauthorized`**: The request lacks a valid JWT, or the token is expired/invalid.
    **Body (application/json):**
    ```json
    {
      "error": "Unauthorized",
      "message": "Authentication token is missing or invalid."
    }
    ```

*   **`500 Internal Server Error`**: A general server-side error occurred (e.g., unexpected processing error).
    **Body (application/json):**
    ```json
    {
      "error": "Internal Server Error",
      "message": "An unexpected error occurred. Please contact support.",
      "transaction_id": "xyz-789-abc"
    }
    ```

*   **`503 Service Unavailable`**: The database or a downstream dependency is unavailable.
    **Body (application/json):**
    ```json
    {
      "error": "Service Unavailable",
      "message": "The service is temporarily unavailable. Please try again later.",
      "transaction_id": "xyz-789-def"
    }
    ```

## 5. Security Considerations

Security is paramount due to the handling of Protected Health Information (PHI).

*   **Authentication (US-103):** The API will be secured using a JWT validation policy. The policy will check for the presence of a Bearer token in the `Authorization` header, validate its signature, and ensure it has not expired. All requests without a valid JWT will be rejected with a `401 Unauthorized` status.
*   **Data in Transit:** All communication will be encrypted using HTTPS/TLS 1.2 or higher to protect data transmitted between the portal and the API.
*   **Secrets Management:** Database credentials, JWT signing keys, and email server credentials will be stored securely using CloudHub's secure properties management or an external secrets vault. They will not be hardcoded in the application.
*   **Secure Logging (US-104):** The logging framework will be configured with a custom pattern layout to automatically mask PHI fields (`patient_name`, `dob`, `address`, `insurance_id`, etc.) before writing to logs. A unique transaction ID will be logged with every request for traceability.

## 6. Error Handling and Logging

A global error handling strategy will be implemented in the MuleSoft application to catch all unhandled exceptions, ensuring consistent and secure error responses.

### 6.1. Failure Handling (US-102)

When a database insertion fails:
1.  The Database Connector will throw an exception.
2.  The Global Error Handler will catch the exception.
3.  A unique transaction ID is generated (or retrieved from the request header).
4.  An error log entry is created. The log will contain the transaction ID, timestamp, and a sanitized error message (e.g., `DB:CONNECTIVITY`, `DB:DUPLICATE_KEY`). **No PHI will be logged.**
5.  An email notification is constructed using the Email Connector.
    *   **Recipient:** `Healthcare IT Support` distribution list.
    *   **Subject:** `CRITICAL ALERT: Patient Enrollment Failure`.
    *   **Body:** Contains the transaction ID, timestamp, and the sanitized error message. **No PHI will be included in the email.**
6.  The API responds to the client with an appropriate `5xx` status code and a generic error message.

### 6.2. Logging Format Example

All logs, for both success and failure scenarios, will follow a structured, masked format.

**Success Log Example:**
```
INFO  2023-10-27 10:00:05 [http.listener.01] TransactionID=abc-123-xyz - Patient record created successfully. patient_id=p-98765, request_payload={"Patient Full Name":"J*** S****","Date of Birth":"****-**-**", ...}
```

**Failure Log Example:**
```
ERROR 2023-10-27 10:02:15 [http.listener.01] TransactionID=def-456-uvw - Failed to create patient record. ErrorType=DB:DUPLICATE_KEY, ErrorMessage=Duplicate key value violates unique constraint "patients_pkey" for patient_id 'p-12345'. request_payload={"Patient Full Name":"M*** J******","Date of Birth":"****-**-**", ...}
```

## 7. Data Flow Diagrams

### 7.1. Successful Patient Creation (US-101)

```mermaid
sequenceDiagram
    participant PEP as Patient Enrollment Portal
    participant API as Patient Management API
    participant DB as Healthcare Patient DB

    PEP->>+API: POST /patients (Payload, JWT)
    API->>API: 1. Validate JWT
    API->>API: 2. Validate & Transform Payload (DataWeave)
    API->>+DB: 3. INSERT INTO Patients (...)
    DB-->>-API: 4. Insertion Success
    API->>-PEP: 5. 201 Created ({"patient_id": "..."})
```

### 7.2. Failed Patient Creation (US-102)

```mermaid
sequenceDiagram
    participant PEP as Patient Enrollment Portal
    participant API as Patient Management API
    participant DB as Healthcare Patient DB
    participant LOG as Logging Service
    participant MAIL as Email Service

    PEP->>+API: POST /patients (Payload, JWT)
    API->>API: 1. Validate & Transform
    API->>+DB: 2. INSERT INTO Patients (...)
    DB-->>-API: 3. DB Insertion Fails (e.g., Connection Error)

    Note over API: Global Error Handler is triggered

    API->>LOG: 4. Log masked error with Transaction ID
    API->>MAIL: 5. Send email alert to IT Support
    API->>-PEP: 6. 503 Service Unavailable
```

## 8. Deployment Architecture

The Patient Management API will be packaged as a Mule application and deployed to **CloudHub** or a hospital's **Private Cloud Environment (PCE)**.

*   **CloudHub:** Deployment will utilize CloudHub workers. A VPC can be configured to establish a secure VPN or Direct Connect link to the on-premise/private cloud-hosted Healthcare Patient DB, ensuring that the database is not exposed to the public internet.
*   **Private Cloud:** The application will be deployed to a customer-hosted Mule runtime cluster within the hospital's data center, providing close proximity to the backend database.

In both scenarios, a load balancer will be placed in front of the Mule runtimes to ensure high availability and scalability.