# High-Level Design: Pharma Inc. Corporate Website

## 1. Architecture
A simple client-server architecture will be used. A Python Flask backend will serve static HTML/CSS/JS files and provide a single API endpoint for the contact form. This lightweight approach is suitable for a low-traffic corporate website.

## 2. Components

### Frontend
-   **index.html:** The main landing page.
-   **about.html:** Company information page.
-   **products.html:** Product listing page.
-   **contact.html:** Contact form and details page.
-   **css/style.css:** Shared stylesheet for a consistent look and feel.
-   **js/main.js:** JavaScript for handling the contact form submission.
++-   **Common Footer:** All HTML pages will include a common footer containing the company's contact email (`--[contact@pharma-inc.com]--++[inquiries@pharma-corp.com]++`) as a clickable `mailto:` link.++

### Backend (`app.py`)
-   A Python Flask application.
-   Serves the static HTML pages from the root and static assets from their respective folders.
-   Provides a single API endpoint: `POST /api/contact`.

## 3. API Specification

### `POST /api/contact`
-   **Description:** Receives user inquiries from the contact form.
-   **Request Body (JSON):**
    ```json
    {
      "name": "string",
      "email": "string (email format)",
      "message": "string"
    }
    ```
-   **Success Response (200 OK):**
    ```json
    {
      "message": "Your inquiry has been sent!"
    }
    ```
-   **Error Response (400 Bad Request):**
    ```json
    {
      "error": "Invalid data provided."
    }
    ```
-   **Internal Logic:** The endpoint will receive the form data and send it to the hardcoded email address: `--[contact@pharma-inc.com]--++[inquiries@pharma-corp.com]++`.

## 4. Technology Stack
-   **Frontend:** HTML5, CSS3, Vanilla JavaScript
-   **Backend:** Python 3, Flask
++
## 5. Non-Functional Requirements
-   **Performance:** All pages must be optimized to achieve a load time of under 3 seconds. The choice of a lightweight architecture with static assets directly supports this requirement.++