# Impact Assessment: Customer Wishlist Feature

| **Document Version** | **Date** | **Author** | **Status** |
| :--- | :--- | :--- | :--- |
| 1.0 | 2023-10-27 | Senior Business Analyst | For Review |

---

### 1. Executive Summary

This document outlines the impact of implementing a new "Customer Wishlist" feature. The enhancement will allow authenticated users to save products they are interested in to a personal list for future reference or purchase.

This is a significant new feature that will enhance user engagement and potentially increase conversion rates by allowing users to track items of interest. The implementation will require the creation of a new microservice, a new database table, and modifications to the front-end application, API Gateway, and existing authentication flows. The overall impact on the system is assessed as **high**, with a corresponding development effort.

---

### 2. Affected Modules/Components

The following modules and components will be created or modified:

*   **New:**
    *   `wishlist-service`: A new microservice to manage all wishlist-related business logic (add, remove, view items).
*   **Modified:**
    *   `frontend-webapp`: The main customer-facing React application.
    *   `api-gateway`: The entry point for all client requests, which will need new routing rules.
    *   `auth-service`: Will be used to secure the new wishlist endpoints. No code changes are expected, but its integration is critical.
    *   `product-service`: May require a new batch-retrieval endpoint to efficiently fetch details for multiple products on the wishlist page.

---

### 3. Impact on UI/UX

Significant changes to the user interface and experience are required:

*   **Product Detail Page:**
    *   A new "Add to Wishlist" button (e.g., a heart icon) will be added near the "Add to Cart" button.
    *   The button's state will change to indicate if an item is already in the user's wishlist.
    *   Clicking the button when not logged in will prompt the user to log in or create an account.
*   **User Account Section:**
    *   A new navigation link, "My Wishlist," will be added to the user's account dropdown/dashboard.
*   **New "My Wishlist" Page:**
    *   This new page will display a grid or list of all products the user has saved.
    *   Each item in the list will display the product image, name, current price, and stock status.
    *   Each item will have two actions: "Add to Cart" and "Remove from Wishlist."

---

### 4. Impact on Backend Services/APIs

A new microservice will be introduced, and the API Gateway will be updated.

*   **New `wishlist-service`:**
    *   **Technology Stack:** Go, PostgreSQL, Docker.
    *   **Responsibilities:** Handle all CRUD operations for wishlists.
    *   **New Endpoints:**
        *   `GET /api/v1/wishlist`: Retrieves the authenticated user's wishlist. Returns a list of product IDs.
        *   `POST /api/v1/wishlist`: Adds a product to the authenticated user's wishlist.
            *   Request Body: `{ "productId": "uuid-string" }`
            *   Success Response: `201 Created`
        *   `DELETE /api/v1/wishlist/{productId}`: Removes a product from the authenticated user's wishlist.
            *   Success Response: `204 No Content`
*   **`api-gateway` Changes:**
    *   New routing rules will be added to direct all requests starting with `/api/v1/wishlist` to the new `wishlist-service`.
    *   Authentication middleware must be applied to all new routes to ensure only logged-in users can access wishlist functionality.
*   **`product-service` Changes:**
    *   A new endpoint may be required to support the "My Wishlist" page efficiently.
    *   `POST /api/v1/products/batch`: Accepts a list of product IDs and returns the full details for each. This avoids the front-end making N+1 requests to get details for N items on the wishlist.
        *   Request Body: `{ "productIds": ["uuid-1", "uuid-2"] }`

---

### 5. Database Changes

Changes are required in the primary PostgreSQL database cluster.

*   **New Table:** `wishlist_items`
    *   `id`: `UUID`, Primary Key
    *   `user_id`: `UUID`, Foreign Key to `users.id`, Not Null
    *   `product_id`: `UUID`, Not Null
    *   `created_at`: `TIMESTAMP WITH TIME ZONE`, Not Null, Default `NOW()`
*   **New Indexes:**
    *   A unique composite index on `(user_id, product_id)` to prevent duplicate entries and ensure fast lookups.
    *   An index on `user_id` to quickly retrieve all wishlist items for a given user.
*   **Data Migration:**
    *   A migration script (e.g., using Flyway or a similar tool) will be required to create the new table and indexes before deployment.

---

### 6. Impact on Integrations

*   **Internal Systems:**
    *   The new `wishlist-service` will need to integrate with the `auth-service` to validate JWTs and retrieve the `user_id` for all incoming requests.
    *   The `frontend-webapp` will integrate with the new `wishlist-service` APIs.
*   **Third-Party Services:**
    *   There is no direct impact on existing third-party integrations like payment gateways or shipping providers.

---

### 7. Risks and Mitigation

| Risk | Likelihood | Impact | Mitigation Strategy |
| :--- | :--- | :--- | :--- |
| **Performance Degradation:** The "My Wishlist" page could cause high load on the `product-service` if it needs to look up details for many items. | Medium | High | 1. Implement the `products/batch` endpoint in `product-service` to reduce the number of API calls. <br> 2. The `wishlist-service` can cache basic, non-volatile product data (like name and image URL) upon adding an item. <br> 3. Implement pagination on the "My Wishlist" API and UI. |
| **Data Inconsistency:** A product might be deleted from the catalog but remain in a user's wishlist, leading to a poor user experience. | Medium | Medium | 1. Implement a "soft delete" policy for products. <br> 2. The `wishlist-service` should gracefully handle cases where a `product_id` is no longer valid when retrieving wishlist details. <br> 3. A periodic cleanup job could be run to remove invalid entries from the `wishlist_items` table. |
| **Security Vulnerability:** An unauthorized user could potentially view or modify another user's wishlist. | Low | Critical | 1. Enforce strict authentication and authorization on all `wishlist-service` endpoints via the API Gateway. <br> 2. The service logic must always operate on the `user_id` extracted from the validated security token, never from a user-provided ID in the request body or path. |

---

### 8. Dependencies

*   **Design/UX Team:** Finalized mockups and user flow diagrams for the "Add to Wishlist" button and the "My Wishlist" page are required before front-end development can begin.
*   **DevOps/Platform Team:** Assistance is needed for provisioning infrastructure for the new `wishlist-service`, setting up its CI/CD pipeline, and scheduling the database migration script.
*   **Product Team:** Final decision on the behavior for out-of-stock items within a wishlist (e.g., display a warning, disable "Add to Cart").

---

### 9. Estimated Effort

Based on the need for a new microservice, new database schema, significant UI/UX changes, and cross-team coordination, the estimated effort is:

**L (Large)**

This estimate accounts for design, development (frontend, backend, database), testing (unit, integration, E2E), and deployment activities.