# PharmaCorp Website: High-Level Design

**1. Introduction**

This document outlines the high-level design for the PharmaCorp website, addressing the user stories and technical requirements.  The architecture will employ a microservices approach, separating concerns for better scalability and maintainability.

**2. Architecture**

```mermaid
graph LR
    subgraph Frontend
        A[Website (React)] --> B(API Gateway);
    end
    subgraph Backend
        B --> C[Product API (FastAPI)];
        B --> D[Content API (FastAPI)];
        B --> E[Newsletter API (FastAPI)];
        B --> F[Contact Form API (FastAPI)];
        C --> G((PostgreSQL));
        D --> G;
        E --> G;
        F --> G;
        C --> H[Object Storage (AWS S3)];
        subgraph Search
            B --> I[Elasticsearch];
        end
    end
    subgraph Admin Panel
        J[Admin Panel (React)] --> B;
    end
    subgraph External Services
        B --> K[SendGrid];
    end
```

**3. Data Model**

**PostgreSQL Schema:**

* **products:**
    * `product_id` (SERIAL PRIMARY KEY)
    * `name` (VARCHAR(255) NOT NULL)
    * `description` (TEXT)
    * `image_url` (VARCHAR(255))
    * `pi_url` (VARCHAR(255))  -- URL to PDF in object storage
    * `isi` (TEXT)  -- Important Safety Information
    * `price` (NUMERIC)
    * `availability` (BOOLEAN)
    * `created_at` (TIMESTAMP)
    * `updated_at` (TIMESTAMP)

* **contact_forms:**
    * `id` (SERIAL PRIMARY KEY)
    * `name` (VARCHAR(255))
    * `email` (VARCHAR(255) NOT NULL)
    * `message` (TEXT)
    * `created_at` (TIMESTAMP)

* **newsletter_subscribers:**
    * `id` (SERIAL PRIMARY KEY)
    * `email` (VARCHAR(255) UNIQUE NOT NULL)
    * `created_at` (TIMESTAMP)

* **content:**
    * `id` (SERIAL PRIMARY KEY)
    * `page_name` (VARCHAR(255) UNIQUE NOT NULL)  --e.g., 'about-us', 'privacy-policy'
    * `content` (TEXT)
    * `created_at` (TIMESTAMP)
    * `updated_at` (TIMESTAMP)


**4. API Endpoints**

**Product API:**

* `/products`: GET - Returns a list of products (paginated).
    * Response:  `[{"product_id": 1, "name": "Product A", "description": "...", ...}, ...]`
* `/products/{product_id}`: GET - Returns details for a specific product.
    * Response: `{"product_id": 1, "name": "Product A", "description": "...", "pi_url": "...", "isi": "...", "price": 100.00, "availability": true}`

**Content API:**

* `/content/{page_name}`: GET - Returns content for a specific page (e.g., "about-us", "privacy-policy").
    * Response: `{"page_name": "about-us", "content": "..."}`


**Newsletter API:**

* `/newsletter`: POST - Subscribe to newsletter.  Request body: `{"email": "user@example.com"}`

**Contact Form API:**

* `/contact`: POST - Submit contact form. Request body: `{"name": "John Doe", "email": "john.doe@example.com", "message": "..."}`


**5. Security**

* HTTPS for all communication.
* API Key authentication for all APIs.  API keys will be managed through the admin panel.
* Content Security Policy (CSP) to mitigate XSS attacks.
* Input validation on all API endpoints and frontend forms.
* Rate limiting to prevent abuse.


**6. Admin Panel**

* **Technology Stack:** React, Redux, Material-UI.
* **UI Design:**  (Wireframes/Mockups would be included here in a real HLD.  This is omitted for brevity.)  The admin panel will provide intuitive interfaces for managing products, content (About Us, Privacy Policy, Terms of Use), newsletter subscribers, and contact form submissions.  It will also include tools for managing API keys.

**7. Search**

* **Search Engine:** Elasticsearch.  Data will be indexed from the `products` and `content` tables.


**8. CI/CD**

* **Platform:** GitLab CI.
* **Pipeline:**  Automated build, test (unit, integration, end-to-end), and deployment to Dev, Staging, and Production environments.  Rollback capabilities will be implemented using GitLab's features.
* **Performance Testing:** Lighthouse (integrated into CI/CD) will be used for LCP testing.  Tests will be run on staging before production deployment.


**9. Compliance**

* **WCAG 2.2 AA:**  Automated testing using axe-core and manual accessibility audits by certified accessibility specialists.
* **GDPR/CCPA:**  Data minimization, consent management (cookie banner), data subject access requests, and appropriate data security measures will be implemented.  A Data Processing Agreement (DPA) will be in place with any third-party vendors.


**10. Deployment**

* **Cloud Provider:** AWS (EC2 for servers, S3 for object storage, RDS for PostgreSQL, Elasticsearch Service).
* **Server Configuration:**  Appropriate security hardening (e.g., firewall rules, regular security updates).


**11. Error Handling and Logging**

* **Error Handling:**  All APIs will return appropriate HTTP status codes and error messages.
* **Logging:**  Python's `logging` module will be used.  Logs will be stored in CloudWatch (AWS).  Error logs will be monitored using CloudWatch dashboards.