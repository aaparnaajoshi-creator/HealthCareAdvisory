#!/bin/bash

echo "Deploying Pharma Inc. PHP Website..."

# The target directory for a web server like Apache/Nginx
WEB_ROOT="/var/www/pharma-inc"

# Ensure the web server directory exists
echo "Creating directory $WEB_ROOT if it doesn't exist..."
mkdir -p $WEB_ROOT

# Copy all necessary PHP application files
echo "Copying website files..."
cp *.php "$WEB_ROOT/"
cp -r css "$WEB_ROOT/"
cp -r includes "$WEB_ROOT/"

# REMOVED: The python server is no longer needed.
# A web server (Apache, Nginx) with PHP configured is expected to be running.
echo "Setting permissions for the web server..."
chown -R www-data:www-data "$WEB_ROOT"
find "$WEB_ROOT" -type d -exec chmod 755 {} \;
find "$WEB_ROOT" -type f -exec chmod 644 {} \;

echo "Deployment complete."
echo "Ensure your web server (e.g., Apache or Nginx) is configured to serve from $WEB_ROOT."