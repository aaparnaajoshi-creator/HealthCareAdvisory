<?php 
$pageTitle = 'Products - Pharma Inc.';
include 'includes/header.php'; 
?>

<div class="content">
    <h1>Our Products</h1>
    <ul>
        <li>Product A - For treatment of X</li>
        <li>Product B - For treatment of Y</li>
        <li>Product C - For treatment of Z</li>
    </ul>
</div>

<?php include 'includes/footer.php'; ?>