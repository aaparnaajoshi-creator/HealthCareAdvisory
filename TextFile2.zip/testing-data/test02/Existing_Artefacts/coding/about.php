<?php 
$pageTitle = 'About - Pharma Inc.';
include 'includes/header.php'; 
?>

<div class="content">
    <h1>About Us</h1>
    <p>Founded in 2005, Pharma Inc. has been dedicated to discovering and developing life-changing medicines.</p>
</div>

<?php include 'includes/footer.php'; ?>