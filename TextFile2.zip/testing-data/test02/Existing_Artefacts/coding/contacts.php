<?php
$form_status = '';
// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and get the form data
    $name = htmlspecialchars(strip_tags($_POST['name']));
    $email = htmlspecialchars(strip_tags($_POST['email']));
    $message = htmlspecialchars(strip_tags($_POST['message']));

    // In a real app, you would use a library like PHPMailer to send an email.
    // For this example, we'll simulate the log output like in the Python app.
    $log_message = "--- NEW INQUIRY ---\n" .
                   "Recipient: contact@pharma-inc.com\n" .
                   "From: {$name} <{$email}>\n" .
                   "Message: {$message}\n" .
                   "-------------------\n";

    // In a server environment, this would log to the server's error log.
    error_log($log_message);

    $form_status = "Your inquiry has been sent!";
}

$pageTitle = 'Contact - Pharma Inc.';
include 'includes/header.php';
?>

<div class="content">
    <h1>Contact Us</h1>
    <form id="contact-form" action="contact.php" method="POST">
        <label for="name">Name:</label><br>
        <input type="text" id="name" name="name" required><br>
        
        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email" required><br>
        
        <label for="message">Message:</label><br>
        <textarea id="message" name="message" required></textarea><br><br>
        
        <button type="submit">Send</button>
    </form>
    
    <p id="form-status">
        <?php echo $form_status; ?>
    </p>
    
    <footer>
        <p>For inquiries, please email us at:
            <a href="mailto:contact@pharma-inc.com">contact@pharma-inc.com</a>
        </p>
    </footer>
</div>

<?php include 'includes/footer.php'; ?>