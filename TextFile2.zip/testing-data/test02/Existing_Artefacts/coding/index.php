<?php 
$pageTitle = 'Pharma Inc. - Home';
include 'includes/header.php'; 
?>

<div class="content">
    <h1>Welcome to Pharma Inc.</h1>
    <p>Our mission is to innovate for a healthier tomorrow for everyone.</p>
</div>

<?php include 'includes/footer.php'; ?>