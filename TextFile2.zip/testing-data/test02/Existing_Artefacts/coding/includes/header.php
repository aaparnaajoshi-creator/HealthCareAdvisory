<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo isset($pageTitle) ? $pageTitle : 'Pharma Inc.'; ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav>
        <a href="index.php">Home</a> |
        <a href="about.php">About Us</a> |
        <a href="products.php">Products</a> |
        <a href="contact.php">Contact Us</a>
    </nav>