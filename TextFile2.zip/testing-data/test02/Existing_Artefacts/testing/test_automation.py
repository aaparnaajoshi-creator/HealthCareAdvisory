# test_automation.py

import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

# --- Test Setup ---

@pytest.fixture
def browser():
    """Initializes and quits the browser for each test function."""
    driver = webdriver.Chrome()
    driver.implicitly_wait(10)
    yield driver
    driver.quit()

# --- Test Cases ---

def test_page_titles(browser):
    """
    Test Case TC-NAV-001: Verify navigation links work and lead to correct page titles.
    """
    # MODIFIED: Base URL points to a standard web server, not Flask's port 5000.
    # Assumes files are in a 'pharma-inc' directory on the localhost.
    base_url = "http://127.0.0.1/pharma-inc/"
    pages = {
        "index.php": "Pharma Inc. - Home",
        "about.php": "About - Pharma Inc.",
        "products.php": "Products - Pharma Inc.",
        "contact.php": "Contact - Pharma Inc."
    }

    for page_file, title in pages.items():
        browser.get(base_url + page_file)
        # This matches the test case description TC-NAV-001
        assert title in browser.title

def test_contact_email_display(browser):
    """
    Test Case TC-CONTACT-001: Verify the contact email address is displayed correctly.
    """
    browser.get("http://127.0.0.1/pharma-inc/contact.php")
    
    email_link = WebDriverWait(browser, 10).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, "footer a"))
    )
    
    # This matches the expected result of TC-CONTACT-001
    assert email_link.text == "contact@pharma-inc.com"
    assert email_link.get_attribute("href") == "mailto:contact@pharma-inc.com"

def test_contact_form_submission_success(browser):
    """
    Test Case TC-CONTACT-002 (Positive): Verify successful form submission with valid data.
    """
    browser.get("http://127.0.0.1/pharma-inc/contact.php")
    
    # Fill out the form as per steps in TC-CONTACT-002
    browser.find_element(By.ID, "name").send_keys("John Doe")
    browser.find_element(By.ID, "email").send_keys("john.doe@example.com")
    browser.find_element(By.ID, "message").send_keys("This is a test inquiry.")
    
    browser.find_element(By.CSS_SELECTOR, "button[type='submit']").click()
    
    # In the PHP version, the page reloads. We wait for the message on the new page.
    success_message = WebDriverWait(browser, 10).until(
        EC.text_to_be_present_in_element((By.ID, "form-status"), "Your inquiry has been sent!")
    )
    assert success_message

def test_contact_form_submission_failure(browser):
    """
    Test Case TC-CONTACT-003 (Negative): Verify form does not submit with an empty required field.
    """
    browser.get("http://127.0.0.1/pharma-inc/contact.php")
    
    # Leave name field blank as per steps in TC-CONTACT-003
    browser.find_element(By.ID, "email").send_keys("jane.doe@example.com")
    browser.find_element(By.ID, "message").send_keys("This is another test.")
    
    browser.find_element(By.CSS_SELECTOR, "button[type='submit']").click()
    
    # With HTML5 validation, the form should not submit and the URL shouldn't change.
    # We verify the success message does not appear, aligning with the expected result.
    status_element = browser.find_element(By.ID, "form-status")
    time.sleep(1) 
    assert status_element.text == ""