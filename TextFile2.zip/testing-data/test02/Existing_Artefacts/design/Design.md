# High-Level Design: Pharma Inc. Corporate Website (PHP Version)

## 1. Architecture

A traditional **server-side PHP architecture** will be used. The server will directly execute PHP files to render HTML pages. This approach simplifies the stack by removing the need for a separate backend API for form handling. Each page is a standalone `.php` file that includes common elements like a header and footer for code reusability.

---

## 2. Components

### Page Files
-   **`index.php`:** The main landing page.
-   **`about.php`:** Company information page.
-   **`products.php`:** Product listing page.
-   **`contact.php`:** Contains the contact form and the server-side PHP logic to process it.

### Reusable Includes
-   A shared file containing the opening HTML, head section, and navigation menu. Included in all page files.
-   A shared file containing the closing HTML tags.

### Styling
-   **`css/style.css`:** Shared stylesheet for a consistent look and feel across all pages.

---

## 3. Form Handling

The dedicated `POST /api/contact` endpoint is no longer needed. Instead, form submission is handled by the server-side code within `contact.php`.

-   **Description:** The HTML form on the `contact.php` page submits a `POST` request to itself (`<form action="contact.php" method="POST">`).
-   **Server-Side Logic (`contact.php`):**
    1.  The script checks if the request method is `POST`.
    2.  It retrieves the form data from the `$_POST` superglobal array (`$_POST['name']`, `$_POST['email']`, `$_POST['message']`).
    3.  The input is sanitized to prevent cross-site scripting (XSS) attacks.
    4.  The inquiry is processed (e.g., logged or sent to the hardcoded email address: `contact@pharma-inc.com`).
    5.  A success message is generated and displayed back to the user on the same page.

---

## 4. Technology Stack

-   **Frontend:** HTML5, CSS3
-   **Backend:** PHP